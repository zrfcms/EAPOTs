#include <QScrollBar>
#include <QFileDialog>
#include "StructGLPage.h"
#include "AbInitioPage.h"
#include <stdlib.h>
#include "spglib/spglib.h"
#include "EAPSetPage.h"
#include "EAPFrame.h"

using namespace EAPUI_NS;
using namespace LoadConfig_NS;

CMD::CMD() {};
CMD::~CMD() {};

void CMD::add(const char* pfullname, const char* pshortname,
	double* p0, double* p1, double* p2, double* p3) {
	CMDSTRC newcmd;
	newcmd.mode = TDOUBLE;
	newcmd.fullname = pfullname;
	newcmd.shortname = pshortname;

	newcmd.ptr[0] = (void*)p0;
	newcmd.ptr[1] = (void*)p1;
	newcmd.ptr[2] = (void*)p2;
	newcmd.ptr[3] = (void*)p3;

	newcmd.num = 0;
	for (int i = 0; i < NPTR; i++) {
		if (newcmd.ptr[i] != 0) newcmd.num++;
	}

	int idx = cmdlist.size();
	cmdlist.push_back(newcmd);

	fullmap[pfullname] = idx;
	shortmap[pshortname] = idx;
}

void CMD::eval(QString str) {

	QStringList list = str.split(' ', QString::SkipEmptyParts);

	QString cmd = list[0];

	int idx = -1;

	if (fullmap.find(cmd) != fullmap.end()) idx = fullmap[cmd];
	if (shortmap.find(cmd) != shortmap.end()) idx = shortmap[cmd];

	if (idx >= 0) {

		CMDSTRC &cs = cmdlist[idx];
		int maxcmd = list.size() - 1;

		maxcmd = maxcmd < cs.num ? maxcmd : cs.num;

		for (int i = 0; i < maxcmd; i++) {
			switch (cs.mode) {
			case TDOUBLE: {
				double* ptr = (double*)cs.ptr[i];
				*ptr = list[i + 1].toDouble();
				break;
			}
			case TINT: {
				int* ptr = (int*)cs.ptr[i];
				*ptr = list[i + 1].toInt();
			}
					   break;
			case TSTR: {
				QString* ptr = (QString*)cs.ptr[i];
				*ptr = list[i + 1];
				break;
			}
			}
		}
	}
}






StructGLPage::StructGLPage(QWidget *parent, EAPUI* ptr)
	: QWidget(parent)
	, UiPtr(ptr) 
{	
	ui.setupUi(this);

    int idx = 1;
    ModiferName << "none"
        << "Define transformation"
        << "Define displacement"
        << "Wrap periodicity"
        << "Optimize triclinic geometry"
        << "Find crystal symmetries"
        << "Replicate box"
        << "Change atom type";

    ui.ModificationCombo->addItem(ModiferName[idx++]);
    ui.ModificationCombo->addItem(ModiferName[idx++]);
    ui.ModificationCombo->addItem(ModiferName[idx++]);
    ui.ModificationCombo->addItem(ModiferName[idx++]);
    ui.ModificationCombo->addItem(ModiferName[idx++]);
    ui.ModificationCombo->addItem(ModiferName[idx++]);
    ui.ModificationCombo->addItem(ModiferName[idx++]);


	cmd = new CMD();	
    uiTextBrowser = ui.textBrowser;
}

#include <QMenu>
#include "EAPFrame.h"

void StructGLPage::init() {

	StructGLWidget* GLWidget = ui.StrucGLWidget;
	cmd->add("atom_size", "ats", &GLWidget->outAtomRadius);	

    ui.RightSplitter->setStretchFactor(0, 1);
    ui.RightSplitter->setStretchFactor(1, 5);

    ui.upButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_ArrowUp));
    ui.downButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_ArrowDown));

	connect(ui.CMDEdit, &QLineEdit::returnPressed, this, &StructGLPage::StrucGLCMD);
    connect(ui.ImportButton, &QPushButton::clicked, frame->ui.actionImport, &QAction::triggered);
    connect(ui.ExportButton, &QPushButton::clicked, frame->ui.actionExport, &QAction::triggered);
    connect(frame->ui.actionImport, &QAction::triggered, this, &StructGLPage::SelectImportFile);
    connect(frame->ui.actionExport, &QAction::triggered, this, &StructGLPage::ExportFile);

	connect(ui.ModificationCombo, 
		static_cast<void (QComboBox:: *)(int index)>(&QComboBox::currentIndexChanged),
		this, [=](int idx) { 
            if (ui.ModificationCombo->currentIndex() != 0) {
				ui.ModificationCombo->setCurrentIndex(0);
                ModificationListCreate(idx);
			}
		});

    connect(ui.ModificationList, &QListWidget::itemClicked, this, [=]() { updateMod(NULL); });

    connect(ui.ModificationList, &QListWidget::currentRowChanged,
            this, &StructGLPage::ModificationListCurrentRowChanged);

    connect(ui.deleteButton, &QPushButton::clicked,
            this, &StructGLPage::ModificationListCurrentDelete);

    connect(ui.upButton, &QPushButton::clicked, this, [=]() { ModificationListMove(-1); });
    connect(ui.downButton, &QPushButton::clicked, this, [=]() { ModificationListMove(+1); });

}

StructGLPage::~StructGLPage()
{
	delete cmd;
}

void StructGLPage::ImportFile(const QString& name) {

	// create AtomConfigData and load atom config

	AtomConfigData *data = ui.StrucGLWidget->UIConfig[Orig];
	data->reset();

	AtomConfigLoad load(data);
    load.read_head(name.toLocal8Bit().data());
	load.read_data();

	ui.StrucGLWidget->outColorBarlo = 0;
	ui.StrucGLWidget->outColorBarhi = data->ntype + 1;
	ui.StrucGLWidget->setConfig(View, data);

    updateMod(NULL);
}

void StructGLPage::SelectImportFile() {

    frame->PageRaise(MainPage::StructEdit);
	QString name = QFileDialog::getOpenFileName(this,
		tr("load structure files"), OpenFileDir, tr("Structure (*)"));

	if (name.isEmpty()) return;
	
	OpenFileDir = QFileInfo(name).absolutePath();

	ImportFile(name);
}

void StructGLPage::ExportFile() {

    frame->PageRaise(MainPage::StructEdit);
	QString name = QFileDialog::getSaveFileName(this,
		tr("save project json file"), OpenFileDir, tr("VASP POSCAR(*.POSCAR);;LAMMPS Data(*.lmp)"));
	
	QFile pFile(name);
	if (!pFile.open(QIODevice::WriteOnly)) {
		frame->statusBar()->showMessage("Could't write into projects json: " + name);
		return;
	}
	OpenFileDir = QFileInfo(name).absolutePath();
	QByteArray ba = name.toLatin1();

	AtomConfigData* config = ui.StrucGLWidget->UIConfig[View];
	AtomConfigLoad write(config);	

	if (name.endsWith(".POSCAR")) {
		config->filetype = LoadFileType::VASP;
		write.write(ba.data());
	}
	else if(name.endsWith(".lmp")){
		config->filetype = LoadFileType::LMP_DATA;
		write.write(ba.data());
	}
	else {
		config->filetype = LoadFileType::LMP_DATA;
		write.write(ba.data());
	}
}

void StructGLPage::StrucGLCMD() {

	QString newcmd = ui.CMDEdit->text();

	if (newcmd.isEmpty()) return;

	QString his = ui.CMDhistoryEdit->toPlainText();

	his += "\n" + newcmd;

	ui.CMDEdit->clear();

	ui.CMDhistoryEdit->setPlainText(his);

	QScrollBar* scrollbar = ui.CMDhistoryEdit->verticalScrollBar();

	if (scrollbar) scrollbar->setSliderPosition(scrollbar->maximum());

	cmd->eval(newcmd);
	ui.StrucGLWidget->update();
}

void StructGLPage::ModificationListCurrentRowChanged(int idx){

    ui.scrollArea->takeWidget();
    if (idx >= 0) {
        int pidx = ui.ModificationList->count() - 1 - idx;
        ui.scrollArea->setWidget(Mod[pidx]);
    }
    else{
        ui.scrollArea->setWidget(uiTextBrowser);
    }
}


ModificationWidget* StructGLPage::ModificationListCreate(int type) {

	AtomConfigData* config = ui.StrucGLWidget->UIConfig[View];
	ModificationWidget* newMod = NULL;

	switch (type)	{    
    case 1: newMod = new DefineTransformationWidget(this, config, ModiferName[type]); break;
    case 2: newMod = new DefineDisplacementWidget(this, config, ModiferName[type]); break;
    case 3: newMod = new PeriodicWarpWidget(this, config, ModiferName[type]); break;
    case 4: newMod = new TriclinicOptimizationWidget(this, config, ModiferName[type]); break;
    case 5: newMod = new FindCrystalSymmetriesWidget(this, config, ModiferName[type]); break;
    case 6: newMod = new ReplicateWidget(this, config, ModiferName[type]); break;
    case 7: newMod = new AtomTypeModifyWidget(this, config, ModiferName[type]); break;
	default: return NULL;
	}
	Mod.push_back(newMod);

	QIcon aIcon;
	aIcon.addFile(QString::fromUtf8(":/image/icon/blank"));

	QListWidgetItem* aitem = new QListWidgetItem();
	aitem->setText(newMod->name);
	aitem->setIcon(aIcon);
	aitem->setCheckState(Qt::Checked);
	aitem->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
	ui.ModificationList->insertItem(0, aitem);
	ui.ModificationList->setCurrentRow(0);
    ModificationListCurrentRowChanged(0);

	updateMod(newMod);

	return newMod;
}

void StructGLPage::ModificationListCurrentDelete() {
    int count = ui.ModificationList->count();
    int idx = ui.ModificationList->currentRow();

    if (idx >= 0) {
        ui.scrollArea->takeWidget();
        delete Mod.takeAt(count - idx - 1);
        delete ui.ModificationList->takeItem(idx);

        if (idx >= ui.ModificationList->count()) idx--;
        ui.ModificationList->setCurrentRow(idx);
        // idx can be -1 and ui.ModificationList->setCurrentRow(-1) is OK!
        updateMod(NULL);
    }
}

void StructGLPage::ModificationListMove(int dir){

    int count = ui.ModificationList->count();
    int oldIdx = ui.ModificationList->currentRow();
    int newIdx = oldIdx + dir;

    if (newIdx < 0 || newIdx >= ui.ModificationList->count()) return;

    int oldpIdx = count - 1 - oldIdx;
    int newpIdx = count - 1 - newIdx;

    auto m = Mod[newpIdx];
    Mod[newpIdx] = Mod[oldpIdx];
    Mod[oldpIdx] = m;

    QListWidgetItem* Item = ui.ModificationList->takeItem(oldIdx);
    ui.ModificationList->insertItem(newIdx, Item);

    ui.ModificationList->setCurrentRow(newIdx);
    updateMod(NULL);
}



void StructGLPage::updateMod(ModificationWidget*) {
	
	//std::vector<Modification*>::iterator iter;
	//iter = std::find(Mod.begin(), Mod.end(), imod);
	//if (iter == Mod.end()) return;

	//while (iter < Mod.end()) {
	//	(*iter)->update(NULL);
	//}
	ui.StrucGLWidget->UIConfig[1]->copy(ui.StrucGLWidget->UIConfig[Orig]);

    const int num  = static_cast<int>(Mod.size());
    const int pnum = static_cast<int>(Mod.size() - 1);
	for (int i = 0; i < num; i++) {
		if (ui.ModificationList->item(pnum - i)->checkState() == Qt::Unchecked) {
			continue;
		}
		Mod[i]->update(ui.StrucGLWidget->UIConfig[View]);
	}
	ui.StrucGLWidget->ConfigToVBO();
	ui.StrucGLWidget->update();

	//ModificationWidget* widget = qobject_cast<ModificationWidget*>(ui.scrollArea->widget());
	//widget->updateInfo();
}

#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}
#define set_vector3d(u, x, y, z) {u[0] = x;u[1] = y;u[2] = z;}

#define zero_vector3(u) {u[0] = 0;u[1] = 0;u[2] = 0;}

#define minu_vector3(u, v, w){u[0] = v[0] - w[0];u[1] = v[1] - w[1];u[2] = v[2] - w[2];}

#define plus_vector3(u, v, w){u[0] = v[0] + w[0];u[1] = v[1] + w[1];u[2] = v[2] + w[2];}

#define selfminu_vector3(u, w){u[0] -= w[0];u[1] -= w[1];u[2] -= w[2];}

#define selfplus_vector3(u, w){u[0] += w[0];u[1] += w[1];u[2] += w[2];}

#define selfmult_vector3(u, r){u[0] *= r;u[1] *= r;u[2] *= r;}

#define selfdivi_vector3(u, r){u[0] /= r;u[1] /= r;u[2] /= r;}

#define Mat33Loop 				\
for (int i = 0; i < 3; i++) 	\
for (int j = 0; j < 3; j++) 


#define set_matrix33(u,v) {\
	u[0][0] = v[0][0]; u[0][1] = v[0][1]; u[0][2] = v[0][2]; \
	u[1][0] = v[1][0]; u[1][1] = v[1][1]; u[1][2] = v[1][2]; \
	u[2][0] = v[2][0]; u[2][1] = v[2][1]; u[2][2] = v[2][2]; }

#define dot_matrix33(u,v,w) {										\
	u[0][0] = v[0][0]*w[0][0] + v[0][1]*w[1][0] + v[0][2]*w[2][0];	\
	u[0][1] = v[0][0]*w[0][1] + v[0][1]*w[1][1] + v[0][2]*w[2][1];	\
	u[0][2] = v[0][0]*w[0][2] + v[0][1]*w[1][2] + v[0][2]*w[2][2];	\
	u[1][0] = v[1][0]*w[0][0] + v[1][1]*w[1][0] + v[1][2]*w[2][0];	\
	u[1][1] = v[1][0]*w[0][1] + v[1][1]*w[1][1] + v[1][2]*w[2][1];	\
	u[1][2] = v[1][0]*w[0][2] + v[1][1]*w[1][2] + v[1][2]*w[2][2];	\
	u[2][0] = v[2][0]*w[0][0] + v[2][1]*w[1][0] + v[2][2]*w[2][0];	\
	u[2][1] = v[2][0]*w[0][1] + v[2][1]*w[1][1] + v[2][2]*w[2][1];	\
	u[2][2] = v[2][0]*w[0][2] + v[2][1]*w[1][2] + v[2][2]*w[2][2];	\
}

#define vec_matrix33(u,v,w) {							\
	u[0] = v[0]*w[0][0] + v[1]*w[1][0] + v[2]*w[2][0];	\
	u[1] = v[0]*w[0][1] + v[1]*w[1][1] + v[2]*w[2][1];	\
	u[2] = v[0]*w[0][2] + v[1]*w[1][2] + v[2]*w[2][2];	\
}

#define norm2_vector3(u) (u[0]*u[0] + u[1]*u[1] + u[2]*u[2])

#define norm_vector3(u) (sqrt(u[0]*u[0] + u[1]*u[1] + u[2]*u[2]))

#define normalize_vector3(u) {double r = sqrt(u[0]*u[0] + u[1]*u[1] + u[2]*u[2]);if(r!=0){u[0] /= r;u[1] /= r;u[2] /= r;}}


#define connectUpdate(widget, signal) connect(widget, signal, this, [=]() {	page->updateMod(this); });

ModificationWidget::ModificationWidget(StructGLPage *parent, QString id)
	: QWidget(parent)
	, page(parent)
{
    name = id;
	config = NULL;
}


AtomTypeItem::AtomTypeItem(QWidget *parent)
    : QWidget(parent) {

    layout = new QHBoxLayout(this);
    layout->setContentsMargins(2,2,2,2);
    layout->setSpacing(4);

    id = new QLabel(this);
    layout->addWidget(id);

    ele = new QClickLabel(this);
    layout->addWidget(ele);

    num = new QLabel(this);
    layout->addWidget(num);

    modify = new QPushButton(this);
    modify->setMaximumWidth(20);
    modify->setMaximumHeight(20);
    layout->addWidget(modify);

    modify->setIcon(QApplication::style()->standardIcon(QStyle::SP_FileDialogDetailedView));
    modify->setIconSize(QSize(16, 16));

    connect(modify, &QPushButton::clicked, ele, [=](){

        PeriodicTableDialog* dialog = new PeriodicTableDialog(this);

        connect(dialog->buttonBox, SIGNAL(accepted()), dialog, SLOT(accept()));
        connect(dialog->buttonBox, SIGNAL(rejected()), dialog, SLOT(reject()));

        if (dialog->exec() == QDialog::Accepted){
            QStringList eles = dialog->periodicTable->getSelection();
            if(eles.size() > 0) {
                ele->setText(eles[0]);
                ele->textChanged();
            }
        }
        delete dialog;
    });
}

#define getAtomTypeItem(i) qobject_cast<AtomTypeItem *>(list->itemWidget(list->item(i)));

AtomTypeModifyWidget::AtomTypeModifyWidget(StructGLPage *parent,
        AtomConfigData* pconfig, QString id)
    : ModificationWidget(parent, id) {

    config = pconfig;
    ui.setupUi(this);

    ui.AtomSizeSpinBox->setValue(page->ui.StrucGLWidget->outAtomRadius);

    connect(ui.ConsistTypeButton, &QPushButton::clicked, this, [=](){
        QStringList eles;
        page->setPage->getEleName(eles);
        int nele = static_cast<int>(config->eleName.size());

        QListWidget* list = ui.TypeList;
        int n = MIN(nele, eles.size());
        for (int i = 0; i < n; i++){
            AtomTypeItem *item = getAtomTypeItem(i);
            item->ele->setText(eles[i]);
        }

        page->updateMod(this);
    });

    connect(ui.AtomSizeSpinBox, static_cast<void
            (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            page->ui.StrucGLWidget, &StructGLWidget::setAtomSize);

    connect(page->ui.StrucGLWidget, &StructGLWidget::atomSizeChanged,
            ui.AtomSizeSpinBox, [=](double r){

        ui.AtomSizeSpinBox->blockSignals(true);
        ui.AtomSizeSpinBox->setValue(r);
        ui.AtomSizeSpinBox->blockSignals(false);
    });
}

void AtomTypeModifyWidget::update(AtomConfigData* config) {

    std::vector<std::string> &eleName = config->eleName;
    int nele = static_cast<int>(eleName.size());

    QListWidget* list = ui.TypeList;

    for (int i = ui.TypeList->count(); i < nele; i++){

        AtomTypeItem* item = new AtomTypeItem(this);
        QListWidgetItem *listItem = new QListWidgetItem(list);

        list->addItem(listItem);
        list->setItemWidget(listItem, item);

        listItem->setSizeHint(QSize(0, 26));
        item->id->setText(QString("Type %1").arg(i+1));
        item->ele->setText(eleName[i].c_str());

        connectUpdate(item->ele, &QClickLabel::textChanged);
    }

    for (int i = nele; i < ui.TypeList->count(); i++){

        QListWidgetItem *listItem = list->item(i);
        AtomTypeItem *item = getAtomTypeItem(i);

        list->removeItemWidget(listItem);
        list->takeItem(i);

        delete listItem;
        delete item;
    }

    for (int i = 0; i < nele; i++){
        AtomTypeItem *item = getAtomTypeItem(i);
        item->num->setText(QString::number(config->eleNum[i]) + " Atoms");
        eleName[i] = item->ele->text().toLatin1().data();
    }
}


DefineTransformationWidget::DefineTransformationWidget(
        StructGLPage *parent, AtomConfigData* pconfig, QString id)
    : ModificationWidget(parent, id)
{
	config = pconfig;
	ui.setupUi(this);

	ui.matrixTable->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui.matrixTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

	ui.BeforeTable->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui.BeforeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

	ui.AfterTable->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui.AfterTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    auto matrixModeReset = [=](){
        ui.matrixTable->blockSignals(true);
        Mat33Loop{ ui.matrixTable->item(i, j)->setText("0.0"); };
        ui.matrixTable->item(0, 0)->setText("1.0");
        ui.matrixTable->item(1, 1)->setText("1.0");
        ui.matrixTable->item(2, 2)->setText("1.0");
        ui.matrixTable->blockSignals(false);
        emit ui.matrixTable->cellChanged(0, 0);
    };

    connect(ui.matrixButton, &QRadioButton::clicked, this, matrixModeReset);
    connect(ui.mdeltaButton, &QRadioButton::clicked, this, [=](){
        ui.matrixTable->blockSignals(true);
        Mat33Loop{ ui.matrixTable->item(i, j)->setText("0.0"); };
        ui.matrixTable->blockSignals(false);
        emit ui.matrixTable->cellChanged(0, 0);
    });
    connect(ui.targetButton, &QRadioButton::clicked, this, [=](){
        ui.matrixTable->blockSignals(true);
        Mat33Loop{ ui.matrixTable->item(i, j)->setText(""); };
        ui.matrixTable->blockSignals(false);
        emit ui.matrixTable->cellChanged(0, 0);
    });

    matrixModeReset();
	connectUpdate(ui.matrixTable, &QTableWidget::cellChanged);
	connectUpdate(ui.particleBox, &QCheckBox::clicked);
	connectUpdate(ui.domainBox, &QCheckBox::clicked);
};

DefineTransformationWidget::~DefineTransformationWidget() {

};

void DefineTransformationWidget::update(AtomConfigData* pconfig) {

	config = pconfig;	

    QString cij;
	int flag = 0;
	double mat[3][3], move[3] = { 0,0,0 };

	Mat33Loop{
		ui.BeforeTable->item(i, j)->setText(QString::number(config->basis[i][j]));
        cij = ui.matrixTable->item(i, j)->text();
        mat[i][j] = cij.isEmpty() ? config->basis[i][j] : cij.toDouble();
	};

	if (ui.targetButton->isChecked()) flag |= AtomConfigData::TransMatFinal;
	if (ui.mdeltaButton->isChecked()) flag |= AtomConfigData::TransMatDelta;
    if (ui.domainBox->isChecked())   flag |= AtomConfigData::TransDomain;
	if (ui.particleBox->isChecked()) flag |= AtomConfigData::TransParticle;

    config->Transform(mat, move, flag);

	Mat33Loop{
		ui.AfterTable->item(i, j)->setText(QString::number(config->basis[i][j]));
	};

}


DefineDisplacementWidget::DefineDisplacementWidget(
        StructGLPage *parent, AtomConfigData* pconfig, QString id)
    : ModificationWidget(parent, id)
{
	config = pconfig;
	ui.setupUi(this);

	updateAtomPosSize();
	updateRandomValue();

	//ui.tableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	ui.atomPosTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

	connect(ui.AllAtomButton, &QRadioButton::clicked, this, [=]() {			
		updateRandomValue();
		page->updateMod(this); });

	connect(ui.ManualDeltaButton, &QRadioButton::clicked, this, [=]() {	

		const int num = config->num;
		for (int i = 0; i < num; i++) {
			for (int j = 0; j < 3; j++) {
				ui.atomPosTable->item(i, 3 + j)->setText("0.0");
			}
		}
		page->updateMod(this); });

	connect(ui.ManualFinalButton, &QRadioButton::clicked, this, [=]() {

		const int num = config->num;
		for (int i = 0; i < num; i++) {
			for (int j = 0; j < 3; j++) {
				ui.atomPosTable->item(i, 3 + j)->setText("");
			}
		}
		page->updateMod(this); });

	
	connect(ui.disturbEdit, &QLineEdit::editingFinished, this, [=]() {
		updateRandomValue();
		page->updateMod(this); });

	connect(ui.seedEdit, &QLineEdit::editingFinished, this, [=]() {
		updateRandomValue();
		page->updateMod(this); });

	connectUpdate(ui.atomPosTable, &QTableWidget::cellChanged);
	connectUpdate(ui.xCheckBox, &QCheckBox::clicked);
	connectUpdate(ui.yCheckBox, &QCheckBox::clicked);
	connectUpdate(ui.zCheckBox, &QCheckBox::clicked);

};

DefineDisplacementWidget::~DefineDisplacementWidget()
{
};

void DefineDisplacementWidget::updateRandomValue() {
	double rad;
	const int num = config->num;
	srand(ui.seedEdit->text().toInt());
	double scale = ui.disturbEdit->text().toDouble() * 2;

	for (int i = 0; i < num; i++) {
		for (int j = 0; j < 3; j++) {
			rad = (((double)rand()) / RAND_MAX - 0.5) * scale;
			ui.atomPosTable->item(i, 3 + j)->setText(QString::number(rad));
		}
	}
}

void DefineDisplacementWidget::updateAtomPosSize() {

	const int num = config->num;
	const int onum = ui.atomPosTable->rowCount();

	if (onum == num) return;

	// 1. realloc emory for delta and atomPosTable

	ui.atomPosTable->setRowCount(num);

	for (int i = onum; i < num; i++) {
		for (int j = 0; j < 3; j++) {
			QTableWidgetItem* item = new QTableWidgetItem();
			item->setFlags(item->flags() & (~Qt::ItemIsEditable));
			ui.atomPosTable->setItem(i, j, item);
		}
		for (int j = 3; j < 6; j++) {
			ui.atomPosTable->setItem(i, j, new QTableWidgetItem());
		}
	}

	// 2. reset for new atoms

	if (ui.ManualFinalButton->isChecked()) {
		for (int i = onum; i < num; i++) {
			ui.atomPosTable->item(i, 3)->setText("");
			ui.atomPosTable->item(i, 4)->setText("");
			ui.atomPosTable->item(i, 5)->setText("");
		}
	}
	else {
		for (int i = onum; i < num; i++) {
			ui.atomPosTable->item(i, 3)->setText("0.0");
			ui.atomPosTable->item(i, 4)->setText("0.0");
			ui.atomPosTable->item(i, 5)->setText("0.0");
		}
	}
}

void DefineDisplacementWidget::update(AtomConfigData* pconfig) {

	config = pconfig;

	ui.atomPosTable->blockSignals(TRUE);
	updateAtomPosSize();

	// 1. update atom position before
	const int num = config->num;
	for (int i = 0; i < num; i++) {
		double *ipos = &config->pos[3 * i];

		ui.atomPosTable->item(i, 0)->setText(QString::number(ipos[0]));
		ui.atomPosTable->item(i, 1)->setText(QString::number(ipos[1]));
		ui.atomPosTable->item(i, 2)->setText(QString::number(ipos[2]));
	}


	// 2.update atom position

	bool xselect[3] = {
		ui.xCheckBox->isChecked(),
		ui.yCheckBox->isChecked(),
		ui.zCheckBox->isChecked(),
	};

	if (ui.ManualFinalButton->isChecked()) {

		QTableWidgetItem* item;
		for (int j = 0; j < 3; j++) {
			if (!xselect[j]) continue;

			for (int i = 0; i < num; i++) {
				item = ui.atomPosTable->item(i, 3 + j);
				if (item->text().isEmpty()) continue;
				config->pos[3 * i + j] = item->text().toDouble();
			}
		}
	}
	else {
		for (int j = 0; j < 3; j++) {
			if (!xselect[j]) continue;

			for (int i = 0; i < num; i++) {
				config->pos[3 * i + j] += ui.atomPosTable->item(i, 3 + j)->text().toDouble();
			}
		}
	}
	

	ui.atomPosTable->blockSignals(FALSE);
}


PeriodicWarpWidget::PeriodicWarpWidget(
        StructGLPage *parent, AtomConfigData* pconfig, QString id)
    : ModificationWidget(parent, id)
{
	config = pconfig;
	ui.setupUi(this);

	connectUpdate(ui.WarpNumberBox, &QCheckBox::clicked);
};

void PeriodicWarpWidget::update(AtomConfigData* pconfig) {

	config = pconfig;

	int total = 0;
	if(ui.WarpNumberBox->isChecked()) {
		config->warpByPBC(&total);
		ui.WarpNumberEdit->setText(QString::number(total));
	}
	else {
		config->warpByPBC(NULL);
		ui.WarpNumberEdit->setText("");
	}
}

TriclinicOptimizationWidget::TriclinicOptimizationWidget(
        StructGLPage *parent, AtomConfigData* pconfig, QString id)
    : ModificationWidget(parent, id)
{
	config = pconfig;
	ui.setupUi(this);

	connectUpdate(ui.HaldWarpBox, &QCheckBox::clicked);
	connectUpdate(ui.PrecisionEdit, &QLineEdit::editingFinished);
};

void TriclinicOptimizationWidget::update(AtomConfigData* pconfig) {

	config = pconfig;
	double prec = ui.PrecisionEdit->text().toDouble();
	if (prec < 1e-14) prec = 1e-14;

	config->Tri6ToTri3(prec, 0, NULL);

	if (ui.HaldWarpBox->isChecked()) {
		config->Tri3HalfConditionWarp(prec);
	}	
}

FindCrystalSymmetriesWidget::FindCrystalSymmetriesWidget(
        StructGLPage *parent, AtomConfigData* pconfig, QString id)
    : ModificationWidget(parent, id)
{
	config = pconfig;
	ui.setupUi(this);

	connectUpdate(ui.PrimitiveButton, &QRadioButton::clicked);
	connectUpdate(ui.StandardButton, &QRadioButton::clicked);
	connectUpdate(ui.PrecisionEdit, &QLineEdit::editingFinished);
};

void FindCrystalSymmetriesWidget::update(AtomConfigData* pconfig) {

	config = pconfig;
	double prec = ui.PrecisionEdit->text().toDouble();
	if (prec < 1e-14) prec = 1e-14;

	int SpaceGroupId;
	char SpaceGroup[11];
    config->atomReserve(config->num * 16);

	config->x2lamda();
    config->basisTranspose();
	SpaceGroupId = spg_get_international(SpaceGroup, config->basis,
		(double(*)[3])config->pos, config->type, config->num, prec);

	if (ui.PrimitiveButton->isChecked()) {
		config->num = spg_find_primitive(config->basis,
			(double(*)[3])config->pos, config->type, config->num, prec);
	}
	else if(ui.StandardButton->isChecked()) {
		config->num = spg_standardize_cell(config->basis,
			(double(*)[3])config->pos, config->type, config->num, 0, 0, prec);
	}
    config->basisTranspose();
    config->updateBasis();
	config->lamda2x();

	ui.SpaceGroupStringEdit->setText(SpaceGroup);
	ui.SpaceGroupNumberEdit->setText(QString::number(SpaceGroupId));

}


ReplicateWidget::ReplicateWidget(StructGLPage *parent,
                 AtomConfigData* pconfig, QString id)
    : ModificationWidget(parent, id)
{
	config = pconfig;

	gridLayout = new QGridLayout(this);
	gridLayout->setSpacing(4);
	gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
	gridLayout->setContentsMargins(2, 2, 2, 2);

	Xlabel = new QLabel(this);	gridLayout->addWidget(Xlabel, 1, 0, 1, 1);
	Ylabel = new QLabel(this);	gridLayout->addWidget(Ylabel, 2, 0, 1, 1);
	Zlabel = new QLabel(this);	gridLayout->addWidget(Zlabel, 3, 0, 1, 1);

	toplabel = new QLabel(this);
	QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
	sizePolicy.setHorizontalStretch(0);
	sizePolicy.setVerticalStretch(0);
	sizePolicy.setHeightForWidth(toplabel->sizePolicy().hasHeightForWidth());
	toplabel->setSizePolicy(sizePolicy);
	toplabel->setMinimumSize(QSize(0, 18));
	toplabel->setMaximumSize(QSize(16777215, 18));
	toplabel->setStyleSheet(QString::fromUtf8("background-color: rgb(205, 205, 205);\n"));
	toplabel->setAlignment(Qt::AlignCenter);
	gridLayout->addWidget(toplabel, 0, 0, 1, 2);

	XspinBox = new QSpinBox(this);
	XspinBox->setMinimum(1);
	XspinBox->setMaximum(65535);
	XspinBox->setValue(1);
	gridLayout->addWidget(XspinBox, 1, 1, 1, 1);

	YspinBox = new QSpinBox(this);
	YspinBox->setMinimum(1);
	YspinBox->setMaximum(65535);
	YspinBox->setValue(1);
	gridLayout->addWidget(YspinBox, 2, 1, 1, 1);

	ZspinBox = new QSpinBox(this);
	ZspinBox->setMinimum(1);
	ZspinBox->setMaximum(65535);
	ZspinBox->setValue(1);
	gridLayout->addWidget(ZspinBox, 3, 1, 1, 1);

	downlabel = new QLabel(this);
	gridLayout->addWidget(downlabel, 4, 0, 1, 2);

	Xlabel->setText(QApplication::translate("", "Number of X images", nullptr));
	Ylabel->setText(QApplication::translate("", "Number of Y images", nullptr));
	Zlabel->setText(QApplication::translate("", "Number of Z images", nullptr));
	toplabel->setText(QApplication::translate("", "Replicate", nullptr));		
	downlabel->setText(QString());

	QMetaObject::connectSlotsByName(this);
	
	connectUpdate(XspinBox, static_cast<void (QSpinBox:: *)(int)>(&QSpinBox::valueChanged));
	connectUpdate(YspinBox, static_cast<void (QSpinBox:: *)(int)>(&QSpinBox::valueChanged));
	connectUpdate(ZspinBox, static_cast<void (QSpinBox:: *)(int)>(&QSpinBox::valueChanged));
}

void ReplicateWidget::update(AtomConfigData* pconfig) {
	config = pconfig;
	config->Replicate(XspinBox->value(), YspinBox->value(), ZspinBox->value());
}
