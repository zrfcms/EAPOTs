#include "StructGLWidget.h"
#include <QOpenGLShaderProgram>
#include <QOpenGLTexture>
#include <QMouseEvent>
#include <QDebug>
#include <cmath>

using namespace LoadConfig_NS;

StructGLWidget::StructGLWidget(QWidget *parent)
	: QOpenGLWidget(parent)
	, xRot(-960)
	, yRot(0)
	, zRot(-540)
	, programAtomColorSignedDepth(0)
	, programAtomColorSignedNoDepth(0)
{
	xMove = 0.0;
	yMove = 0.0;
	outAtomRadius = 1.2;
	outWorldSize = 20.0;
	outWorldDepth = 4096;

	UIConfigMax = 0;
	UIConfigCurrent = 0;
	UIConfig = NULL;

	vbobufmax = 4096;
    vbobuf = (GLfloat*)malloc(vbobufmax * sizeof(GLfloat));

}

StructGLWidget::~StructGLWidget()
{
	makeCurrent();

	vboAtom.destroy();
	vboDomain.destroy();

	for (int i = 0; i < UIConfigMax; i++) {
		delete UIConfig[i];
	}
	delete[] UIConfig;

	for (auto ivboColorSigned : vboColorSigned) {
		ivboColorSigned.destroy();
	}	
	for (auto ivboPolyColorUni : vboPolyColorUni) {
		ivboPolyColorUni.destroy();
	}

	free(vbobuf);

	doneCurrent();
}

QSize StructGLWidget::minimumSizeHint() const
{
	return QSize(100, 100);
}

QSize StructGLWidget::sizeHint() const
{
	return QSize(600, 600);
}

void StructGLWidget::moveBy(GLfloat x, GLfloat y) {
	xMove += x;
	yMove += y;
	update();
}

void StructGLWidget::rotateBy(int xAngle, int yAngle, int zAngle)
{
	xRot += xAngle;
	yRot += yAngle;
	zRot += zAngle;
	//qDebug() << xRot << yRot << zRot;
	update();
}

void StructGLWidget::setAtomSize(double r){
    outAtomRadius = r;
    update();
    emit atomSizeChanged(outAtomRadius);
}

void StructGLWidget::initializeGL()
{
	initializeOpenGLFunctions();

	createDefalutConfig();
	createOpenGLShaderProgram();

	glEnable(GL_DEPTH_TEST);
	//glEnable(GL_CULL_FACE);

	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glEnable(GL_POINT_SPRITE);
	glEnable(GL_PROGRAM_POINT_SIZE);

}
void StructGLWidget::createOpenGLShaderProgram()
{

	{
		QOpenGLShader *vshader = new QOpenGLShader(QOpenGLShader::Vertex, this);
		static const char *vsrc =
			"attribute vec4 vVertex;		\n"
			"attribute vec2 inColorStart;	\n"

			"uniform float AtomRadius;\n"
			"uniform mat4 mvpMatrix;\n"

			"varying vec2 pColorStart;\n"

			"void main(void)\n"
			"{\n"
			"    vec4 vNewVertex = vVertex;\n"
			"    gl_PointSize = AtomRadius;\n"
			"    //gl_PointSize = 30.0 + (vNewVertex.z / sqrt(-vNewVertex.z));\n"
			"    // If they are very small, fade them up\n"
			"    // Iif the particles are too small, flickering will occur. We have to gradually darken the color of this point, so that they disappear from the field of view.\n"
			"    // if(gl_PointSize < 4.0)\n"
			"    //    vStarColor = smoothstep(0.0, 4.0, gl_PointSize) * vStarColor;\n"
			"    // Don't forget to transform the geometry!\n"
			"    gl_Position = mvpMatrix * vNewVertex;\n"
			"	 pColorStart = inColorStart;\n"
			"}\n";
		vshader->compileSourceCode(vsrc);

		// r=0.00706, such value makes atom not intersect with box frame line
		QOpenGLShader *fshader = new QOpenGLShader(QOpenGLShader::Fragment, this);
		static const char *fsrc =
			"#version 120\n"
			"varying vec2 pColorStart;\n"
			"uniform float AtomDepth;\n"
			"uniform sampler2D  starImage;\n"
			"void main(void){\n"
			"	 vec2 p = gl_PointCoord * 2.0 - vec2(1.0);\n"
			"	 if (dot(p, p) > 0.94) discard;\n"
			"	 gl_FragDepth = gl_FragCoord.z - sqrt(1-dot(p, p))*AtomDepth;\n"
			"	 //gl_FragDepth = 1-dot(p, p);\n"
			"    gl_FragColor = texture2D(starImage, pColorStart+gl_PointCoord*0.125);\n"
			"}\n";
		fshader->compileSourceCode(fsrc);

		programAtomColorSignedDepth = new QOpenGLShaderProgram;
		programAtomColorSignedDepth->addShader(vshader);
		programAtomColorSignedDepth->addShader(fshader);
		programAtomColorSignedDepth->bindAttributeLocation("vVertex", 0);
		programAtomColorSignedDepth->bindAttributeLocation("inColorStart", 1);
		
		programAtomColorSignedDepth->link();
		programAtomColorSignedDepth->bind();
		programAtomColorSignedDepth->setUniformValue("starImage", 0);
	}

	{
		QOpenGLShader *vshader = new QOpenGLShader(QOpenGLShader::Vertex, this);
		static const char *vsrc =
			"attribute vec4 vVertex;		\n"
			"attribute vec2 inColorStart;	\n"

			"uniform float AtomRadius;\n"
			"uniform mat4 mvpMatrix;\n"

			"varying vec2 pColorStart;\n"

			"void main(void)\n"
			"{\n"
			"    vec4 vNewVertex = vVertex;  //for Vertex\n"
			"    gl_PointSize = AtomRadius;\n"
			"    gl_Position = mvpMatrix * vNewVertex;\n"
			"	 pColorStart = inColorStart;\n"
			"}\n";
		vshader->compileSourceCode(vsrc);

		// r=0.00706, such value makes atom not intersect with box frame line
		QOpenGLShader *fshader = new QOpenGLShader(QOpenGLShader::Fragment, this);
		static const char *fsrc =
			"#version 120\n"
			"varying vec2 pColorStart;\n"
			"uniform sampler2D starImage;\n"
			"void main(void){\n"
			"	 vec2 p = gl_PointCoord * 2.0 - vec2(1.0);\n"
			"	 if (dot(p, p) > 0.94) discard;\n"
			"    gl_FragColor = texture2D(starImage, pColorStart+gl_PointCoord*0.125);\n"
			"}\n";
		fshader->compileSourceCode(fsrc);

		programAtomColorSignedNoDepth = new QOpenGLShaderProgram;
		programAtomColorSignedNoDepth->addShader(vshader);
		programAtomColorSignedNoDepth->addShader(fshader);
		programAtomColorSignedNoDepth->bindAttributeLocation("vVertex", 0);
		programAtomColorSignedNoDepth->bindAttributeLocation("inColorStart", 1);

		programAtomColorSignedNoDepth->link();
		programAtomColorSignedNoDepth->bind();
		programAtomColorSignedNoDepth->setUniformValue("starImage", 0);
	}

	{
		// Box Shader
		QOpenGLShader *vshader = new QOpenGLShader(QOpenGLShader::Vertex, this);
		const char *vsrc =
			"#version 150\n"
			"in vec4 vertex;\n"
			"in vec4 Color;\n"
			"out vec4 color;\n"
			"uniform mat4 matrix;\n"
			"void main() {\n"
			"    gl_Position = matrix * vertex;\n"
			"    color = Color;\n"
			"}\n";
		vshader->compileSourceCode(vsrc);

		QOpenGLShader *fshader = new QOpenGLShader(QOpenGLShader::Fragment, this);
		const char *fsrcBox =
			"#version 150\n"
			"in vec4 color;\n"
			"void main() {\n"
			"    gl_FragColor = color;\n"
			"}\n";
		fshader->compileSourceCode(fsrcBox);

		programColorSigned = new QOpenGLShaderProgram;
		programColorSigned->addShader(vshader);
		programColorSigned->addShader(fshader);
		programColorSigned->bindAttributeLocation("vertex", 0);
		programColorSigned->bindAttributeLocation("Color", 1);
		programColorSigned->link();
		programColorSigned->bind();
	}

	// deflut shader
	{
		QOpenGLShader *vshader = new QOpenGLShader(QOpenGLShader::Vertex, this);
		const char *vsrc =
			"#version 150\n"
			"in vec4 vertex;\n"
			"uniform mat4 matrix;\n"
			"void main() {\n"
			"    gl_Position = matrix * vertex;\n"
			"}\n";
		vshader->compileSourceCode(vsrc);

		QOpenGLShader *fshader = new QOpenGLShader(QOpenGLShader::Fragment, this);
		const char *fsrc =
			"#version 150\n"
			"uniform vec4 color;\n"
			"void main() {\n"
			"	gl_FragColor = color; \n"
			"}\n";
		fshader->compileSourceCode(fsrc);

		programPolyColorUni = new QOpenGLShaderProgram;
		programPolyColorUni->addShader(vshader);
		programPolyColorUni->addShader(fshader);
		programPolyColorUni->bindAttributeLocation("vertex", 0);
		programPolyColorUni->link();
		programPolyColorUni->bind();
	}

	// deflut shader
	{
		QOpenGLShader *vshader = new QOpenGLShader(QOpenGLShader::Vertex, this);
		const char *vsrc =
			"#version 150\n"
			"in vec4 vertex;\n"
			"uniform mat4 matrix;\n"
			"void main() {\n"
			"    gl_Position = matrix * vertex;\n"
			"}\n";
		vshader->compileSourceCode(vsrc);

		QOpenGLShader *fshader = new QOpenGLShader(QOpenGLShader::Fragment, this);
		const char *fsrc =
			"#version 150\n"
			"uniform vec4 color;\n"
			"void main() {\n"
			"	gl_FragColor = color; \n"
			"}\n";
		fshader->compileSourceCode(fsrc);

		programPolyColorUni = new QOpenGLShaderProgram;
		programPolyColorUni->addShader(vshader);
		programPolyColorUni->addShader(fshader);
		programPolyColorUni->bindAttributeLocation("vertex", 0);
		programPolyColorUni->link();
		programPolyColorUni->bind();
	}

    //loadObj("../../dev/res/sphere_check.obj");
}

void StructGLWidget::paintGL()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	camera.setToIdentity();
	cameraAxis.setToIdentity();
	double ratio = (double)WindowWidth / WindowHeight;

	// Height Base
	World2WindowRatio = WindowHeight / outWorldSize;
	Window2WorldRatio = outWorldSize / WindowHeight;

	GLfloat halfHeight = outWorldSize * 0.5;
	GLfloat halfDepth = outWorldDepth * 0.5;
	camera.ortho(-ratio * halfHeight, +ratio * halfHeight,
		-halfHeight, +halfHeight, -halfDepth, halfDepth);
	// Height Base

	QMatrix4x4 m;
	m = camera;
	m.translate(xMove, yMove, -10.0f);
	m.rotate(xRot / 16.0f, 1.0f, 0.0f, 0.0f);
	m.rotate(yRot / 16.0f, 0.0f, 1.0f, 0.0f);
	m.rotate(zRot / 16.0f, 0.0f, 0.0f, 1.0f);
	m.translate(-center[0], -center[1], -center[2]);

	// Star 

	vboAtom.bind();
	texture64->bind();

	GLfloat radius = outAtomRadius * World2WindowRatio;
	GLfloat AtomDepth = outAtomRadius / outWorldDepth;
	GLint AtomNumber = vboAtom.size() / 5 / sizeof(GLfloat);

	QOpenGLShaderProgram *programAtom;
	if (AtomNumber > 10000) {
		programAtom = programAtomColorSignedNoDepth;
	}
	else {
		programAtom = programAtomColorSignedDepth;
	}

	programAtom->bind();
	programAtom->setUniformValue("mvpMatrix", m);
	programAtom->setUniformValue("AtomRadius", radius * 2);
	programAtom->setUniformValue("AtomDepth", AtomDepth);
	programAtom->enableAttributeArray(0);
	programAtom->enableAttributeArray(1);
	programAtom->setAttributeBuffer(0, GL_FLOAT, 0, 3, 5 * sizeof(GLfloat));
	programAtom->setAttributeBuffer(1, GL_FLOAT, 3 * sizeof(GLfloat), 2, 5 * sizeof(GLfloat));
	glDrawArrays(GL_POINTS, 0, AtomNumber);

	if (outDrawBox) {
		// Box 	
		vboDomain.bind();
		programColorSigned->bind();

		programColorSigned->setUniformValue("matrix", m);
		programColorSigned->enableAttributeArray(0);
		programColorSigned->enableAttributeArray(1);
		programColorSigned->setAttributeBuffer(0, GL_FLOAT, 0, 3, 6 * sizeof(GLfloat));
		programColorSigned->setAttributeBuffer(1, GL_FLOAT, 3 * sizeof(GLfloat), 3, 6 * sizeof(GLfloat));

		glLineWidth(2);
		glDrawArrays(GL_LINES, 0, 24);
	}

	if (outDrawAxis) {
		vboAxis.bind();
		glDisable(GL_DEPTH_TEST);
		m = cameraAxis;
		m.translate(-0.85, -0.85, -0.85);
		m.scale(0.15, 0.15, 0.15f);
		m.ortho(-ratio, +ratio, -1.0, +1.0, -1.0, 1.0);
		m.rotate(xRot / 16.0f, 1.0f, 0.0f, 0.0f);
		m.rotate(yRot / 16.0f, 0.0f, 1.0f, 0.0f);
		m.rotate(zRot / 16.0f, 0.0f, 0.0f, 1.0f);

		programColorSigned->setUniformValue("matrix", m);
		programColorSigned->enableAttributeArray(0);
		programColorSigned->enableAttributeArray(1);
		programColorSigned->setAttributeBuffer(0, GL_FLOAT, 0, 3, 6 * sizeof(GLfloat));
		programColorSigned->setAttributeBuffer(1, GL_FLOAT, 3 * sizeof(GLfloat), 3, 6 * sizeof(GLfloat));

		glLineWidth(4);
		glDrawArrays(GL_LINES, 0, 6);
		glEnable(GL_DEPTH_TEST);
	}
	
	//drawObj(m);
}

int StructGLWidget::drawObj(QMatrix4x4 m) {

    glLineWidth(1);
    programPolyColorUni->bind();
    programPolyColorUni->setUniformValue("matrix", m);
    programPolyColorUni->enableAttributeArray(0);
    //
    //for (auto ivboPolyColorUni : vboPolyColorUni) {
    //	ivboPolyColorUni.bind();
    //	programPolyColorUni->setAttributeBuffer(0, GL_FLOAT, 0, 3, 3 * sizeof(GLfloat));
    //
    //	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    //	programPolyColorUni->setUniformValue("color", QVector4D(0.0f, 0.0f, 0.0f, 1.0f));
    //	glDrawArrays(GL_TRIANGLES, 0, ivboPolyColorUni.size() / 3 / sizeof(GLfloat));
    //
    //	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    //	glEnable(GL_POLYGON_OFFSET_FILL);
    //	glPolygonOffset(1.0f, 1.0f);
    //	programPolyColorUni->setUniformValue("color", QVector4D(1.0f, 1.0f, 1.0f, 1.0f));
    //	glDrawArrays(GL_TRIANGLES, 0, ivboPolyColorUni.size() / 3 / sizeof(GLfloat));
    //	glDisable(GL_POLYGON_OFFSET_FILL);
    //}

	return 0;
}

void StructGLWidget::createDefalutConfig()
{
	texture64 = new QOpenGLTexture(QImage(QString(":/texture/atom64")).mirrored());

	outDrawBox = 1;
	outDrawAxis = 1;

	double box[9] = {
		5.4, 0.0 ,0.0,
		0.0, 5.4, 0.0,
		0.0, 0.0, 5.4,
	};
	double lo[3] = { -1.0, -1.0, -1.0 };
	double pos[] = {
		-0.1, -0.1, -0.1,		-0.1, -0.1, +3.5,
		-0.1, +3.5, -0.1,		-0.1, +3.5, +3.5,
		+3.5, -0.1, -0.1,		+3.5, -0.1, +3.5,
		+3.5, +3.5, -0.1,		+3.5, +3.5, +3.5,
		+3.5, +1.7, +1.7,		-0.1, +1.7, +1.7,
		+1.7, +3.5, +1.7,		+1.7, -0.1, +1.7,
		+1.7, +1.7, +3.5,		+1.7, +1.7, -0.1,
	};
	int type[] = {
		23, 23, 23, 23, 23, 23,
		23, 23, 23, 23, 23, 23,
		23, 23,
	};


	// create Config
	const int num = 14;

	UIConfigMax = 2;
	UIConfig = (AtomConfigData**)malloc(2 * sizeof(AtomConfigData*));
	UIConfig[Orig] = new AtomConfigData(1);
	UIConfig[View] = new AtomConfigData(1);
	AtomConfigData* iconfig = UIConfig[0];

	iconfig->ntype = 1;
    iconfig->eleName.push_back("Cu");
    iconfig->eleNum.push_back(num);
	iconfig->atomResize(num);
	memcpy(iconfig->type, type, num * sizeof(int));
	memcpy(iconfig->pos, pos, num * 3 * sizeof(double));
	memcpy(iconfig->boxlo, lo, sizeof(lo));
	memcpy(iconfig->basis[0], box, 9 * sizeof(double));
	iconfig->updateBasis();

	outColorBarlo = 0;
	outColorBarhi = 64;
	setConfig(View, iconfig, false);

	// create Axis
	GLfloat Box[] = {
		0, 0, 0, 1, 0, 0,
		1, 0, 0, 1, 0, 0,

		0, 0, 0, 0, 1, 0,
		0, 1, 0, 0, 1, 0,

		0, 0, 0, 0, 0, 1,
		0, 0, 1, 0, 0, 1,
	};
	if (false == vboAxis.isCreated()) {
		vboAxis.create();
	}
	vboAxis.bind();
	vboAxis.allocate(Box, sizeof(Box));
}

void StructGLWidget::growUIConfig() {
	UIConfigMax++;
	UIConfig = (AtomConfigData**)realloc(UIConfig, UIConfigMax * sizeof(AtomConfigData*));
	UIConfig[UIConfigMax - 1] = new AtomConfigData(1);
}


void StructGLWidget::resizeGL(int width, int height)
{
	WindowHeight = height;
	WindowWidth = width;

	//glViewport((width - side) / 2, (height - side) / 2, side, side);
}

void StructGLWidget::mousePressEvent(QMouseEvent *event)
{
	lastPos = event->pos();
}

void StructGLWidget::mouseReleaseEvent(QMouseEvent *)
{
	emit clicked();
}

void StructGLWidget::mouseMoveEvent(QMouseEvent *event)
{
	int dx = event->x() - lastPos.x();
	int dy = event->y() - lastPos.y();

	if (event->buttons() & Qt::LeftButton) {
		rotateBy(8 * dy, 0, 8 * dx);
	}
	else if (event->buttons() & Qt::MidButton) {
		moveBy(dx*Window2WorldRatio, -dy*Window2WorldRatio);
	}

	lastPos = event->pos();
}

void StructGLWidget::wheelEvent(QWheelEvent *event) {

	double dx = event->delta();

	if (event->modifiers() == Qt::ControlModifier) {
        setAtomSize(outAtomRadius * pow(0.96, dx / 50.0));
        return;
	}
	else {
		outWorldSize *= pow(0.9, dx / 50.0);
	}

	update();
}


#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}
#define set_vector3d(u, x, y, z) {u[0] = x;u[1] = y;u[2] = z;}
#define plus_vector3(u, v, w){u[0] = v[0] + w[0];u[1] = v[1] + w[1];u[2] = v[2] + w[2];}
#define minu_vector3(u, v, w){u[0] = v[0] - w[0];u[1] = v[1] - w[1];u[2] = v[2] - w[2];}

#define ToF(a) static_cast<GLfloat>(a)

#include "AtomConfig.h"

void StructGLWidget::setConfig(int current, AtomConfigData* pdata, bool setRange) {

	int size;
	size = UIConfigMax;
	if (current >= size) {
		growUIConfig();
		UIConfigCurrent = size;
	}
	else {
		UIConfigCurrent = current;
	}
	AtomConfigData* iconfig = UIConfig[UIConfigCurrent];
	iconfig->copy(pdata);

	if (setRange) {
		outColorBarlo = -1;
		outColorBarhi = iconfig->ntype;
	}	
	ConfigToVBO();
}


#define MAXLINE 512

#define AddVData											\
	if (vi >= vmax) {										\
		vmax *= 2;											\
		v = (GLfloat*)realloc(v, vmax * sizeof(GLfloat));	\
	}														\
	if(pvalue == NULL) return 1;							\
	v[vi++] = atof(pvalue);				

#define AddFData 											\
	if (fi >= fmax) {										\
		fmax *= 2;											\
		f = (GLint*)realloc(f, fmax * sizeof(GLint));		\
	}														\
	if(pvalue == NULL) return 1;							\
	f[fi++] = atoi(pvalue);		


int StructGLWidget::loadObj(QString pfile) {

	QByteArray t = pfile.toLatin1();

	int vi = 0, fi = 0;
	int vmax = 256, fmax = 256;	

	GLint *f = (GLint*)malloc(fmax * sizeof(GLint));
	GLfloat *v = (GLfloat*)malloc(vmax * sizeof(GLfloat));

	FILE* pf = fopen(t.data(), "r");

	if (pf == NULL) {
		return 1;
	}


	char line[MAXLINE];
	char *pvalue, *Ptr0;
	while (fgets(line, MAXLINE, pf) != NULL) {

		if (line[0] == '#' || line[0] == '\n') continue;
		Ptr0 = &line[1];

		if (line[0] == 'v') {
			pvalue = strtok(Ptr0, " \t\n\r\f"); AddVData;
			pvalue = strtok(NULL, " \t\n\r\f"); AddVData;
			pvalue = strtok(NULL, " \t\n\r\f"); AddVData;
		}
		else if (line[0] == 'f') {
			pvalue = strtok(Ptr0, " \t\n\r\f"); AddFData
			pvalue = strtok(NULL, " \t\n\r\f"); AddFData
			pvalue = strtok(NULL, " \t\n\r\f"); AddFData
		}
	}

	fclose(pf);

	GLfloat *data = (GLfloat*)malloc(fi * 3 * sizeof(GLfloat));

	int i, idx;
	for (i = 0; i < fi; i++) {
		idx = f[i];
		data[3 * i + 0] = v[3 * idx - 3] * 1 + 1.8;
		data[3 * i + 1] = v[3 * idx - 2] * 1 + 1.8;;
		data[3 * i + 2] = v[3 * idx - 1] * 1 + 1.8;;
	}

	vboPolyColorUni.push_back(QOpenGLBuffer());
	QOpenGLBuffer &ivbo = vboPolyColorUni.back();

	if(false == ivbo.isCreated()) 
		ivbo.create();
	ivbo.bind();
	ivbo.allocate(data, fi * 3 * sizeof(GLfloat));

	free(f);
	free(v);
	free(data);	

	return 0;
}

void StructGLWidget::ConfigToVBO()
{
	AtomConfigData* iconfig = UIConfig[UIConfigCurrent];

	// 1.1 memory malloc for QOpenGLBuffer
	const int num = iconfig->num;
	if (vbobufmax < num * 5) {
		vbobufmax = num * 5;
		vbobuf = (GLfloat*)realloc(vbobuf, vbobufmax * sizeof(GLfloat));
	}

	// 2.2 evaluate all atom data
	GLint idata;
	GLfloat *ivbo, cdata;

	double *ipos;
	const int* color = iconfig->type;
	GLfloat cdelta = outColorBarhi - outColorBarlo;

	for (int i = 0; i < num; i++) {
		ivbo = &vbobuf[i * 5];
		ipos = &iconfig->pos[i * 3];

		set_vector3(ivbo, ipos);

		cdata = (color[i] - outColorBarlo) / cdelta * 64;
		idata = static_cast<int>(cdata + 0.5);

		idata = idata > 0 ? idata : 0;
		idata = idata < 63 ? idata : 63;

		ivbo[3] = (idata & 7) / 8.0;
		ivbo[4] = (idata >> 3) / 8.0;
	}

	// 2.3 prepare vbo for atom data
	if (false == vboAtom.isCreated()) {
		vboAtom.create();
	}
    vboAtom.bind();
	vboAtom.allocate(vbobuf, num * 5 * sizeof(GLfloat));


	// 2.1. get box basis

	double* dlo = iconfig->boxlo;
	double* dbox = iconfig->basis[0];

	GLfloat box[12];
	for (int i = 0; i < 12; i++) {
		box[i] = static_cast<GLfloat>(dbox[i]);
	}

	GLfloat x[3] = { ToF(box[0]), ToF(box[1]), ToF(box[2]), };
	GLfloat y[3] = { ToF(box[3]), ToF(box[4]), ToF(box[5]), };
	GLfloat z[3] = { ToF(box[6]), ToF(box[7]), ToF(box[8]), };
	GLfloat lo[3] = { ToF(dlo[0]), ToF(dlo[1]), ToF(dlo[2]), };

	center[0] = ToF(lo[0] + (x[0] + y[0] + z[0]) * 0.5);
	center[1] = ToF(lo[1] + (x[1] + y[1] + z[1]) * 0.5);
	center[2] = ToF(lo[2] + (x[2] + y[2] + z[2]) * 0.5);

	// 2.2. set domain frame,  evaluate corner vertex

	GLfloat corner[8][3];
	set_vector3d(corner[0], 0, 0, 0);
	set_vector3(corner[1], x);
	plus_vector3(corner[2], x, y);
	set_vector3(corner[3], y);

	for (int i = 0; i < 4; i++) {
		plus_vector3(corner[i], corner[i], lo);
		plus_vector3(corner[4 + i], corner[i], z);
	}

	GLfloat Box[24][6];
	memset(Box, 0, sizeof(Box));

	// 2.3. set black edges

	int idx = 0;
	set_vector3(Box[idx], corner[0]); idx++; set_vector3(Box[idx], corner[1]); idx++;
	set_vector3(Box[idx], corner[1]); idx++; set_vector3(Box[idx], corner[2]); idx++;
	set_vector3(Box[idx], corner[2]); idx++; set_vector3(Box[idx], corner[3]); idx++;
	set_vector3(Box[idx], corner[3]); idx++; set_vector3(Box[idx], corner[0]); idx++;

	set_vector3(Box[idx], corner[0]); idx++; set_vector3(Box[idx], corner[4]); idx++;
	set_vector3(Box[idx], corner[1]); idx++; set_vector3(Box[idx], corner[5]); idx++;
	set_vector3(Box[idx], corner[2]); idx++; set_vector3(Box[idx], corner[6]); idx++;
	set_vector3(Box[idx], corner[3]); idx++; set_vector3(Box[idx], corner[7]); idx++;

	set_vector3(Box[idx], corner[4]); idx++; set_vector3(Box[idx], corner[5]); idx++;
	set_vector3(Box[idx], corner[5]); idx++; set_vector3(Box[idx], corner[6]); idx++;
	set_vector3(Box[idx], corner[6]); idx++; set_vector3(Box[idx], corner[7]); idx++;
	set_vector3(Box[idx], corner[7]); idx++; set_vector3(Box[idx], corner[4]); idx++;

	// 2.3 prepare vbo for box data
	if (false == vboDomain.isCreated()) {
		vboDomain.create();
	}
    vboDomain.bind();
	vboDomain.allocate(Box[0], 144 * sizeof(GLfloat));
}
