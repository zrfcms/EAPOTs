#include "EAPlotPage.h"
#include "EAPFrame.h"
#include "EAPIO.h"
#include "AtomConfig.h"

#include <QFileDialog>
#include <QMdiSubWindow>
#include "FileBrowserPage.h"
#include <QMessageBox>

#include <QLegendMarker>
#include <QGraphicsLayout>
#include <QColorDialog>
#include <QDoubleSpinBox>
#include <QtDataVisualization>



using namespace QtDataVisualization;

using namespace EAPUI_NS;


EAPlotPage::EAPlotPage(QWidget *parent, EAPUI* ptr)
	: QWidget(parent), UiPtr(ptr)
{
	ui.setupUi(this);

    PlotFileOpenDir = "../res/Resource";
}

EAPlotPage::~EAPlotPage()
{
	ui.mdiArea->closeAllSubWindows();
}


EAPlotBackground::EAPlotBackground(QWidget *parent, EAPUI* ptr)
    : QWidget(parent), UiPtr(ptr)
{
    ui.setupUi(this);
    connect(ui.EAMButton,       &QPushButton::clicked, frame->ui.actionPlotEAM, &QAction::triggered);
    connect(ui.FSButton,        &QPushButton::clicked, frame->ui.actionPlotFs,  &QAction::triggered);
    connect(ui.MEAMButton,      &QPushButton::clicked, frame->ui.actionPlotMEAM,  &QAction::triggered);
    connect(ui.TersoffButton,   &QPushButton::clicked, frame->ui.actionPlotTersoff,  &QAction::triggered);
    connect(ui.BrennerButton,   &QPushButton::clicked, frame->ui.actionPlotBrenner,  &QAction::triggered);
    connect(ui.SWButton,        &QPushButton::clicked, frame->ui.actionPlotSW,  &QAction::triggered);

    connect(ui.SurfButton,      &QPushButton::clicked, frame->ui.actionPlotSurf, &QAction::triggered);
}

void EAPlotPage::CreateSubWindow(const QString& Title, QWidget* widget)
{
	QMdiSubWindow *subWindow = new QMdiSubWindow(ui.mdiArea);

	subWindow->setWindowTitle(Title);
	subWindow->setWidget(widget);
	ui.mdiArea->addSubWindow(subWindow);
    subWindow->setAttribute(Qt::WA_DeleteOnClose);
    subWindow->setWindowState(Qt::WindowMaximized);

    connect(subWindow, &QObject::destroyed, this, [=](){
        if (ui.mdiArea->subWindowList().count()) return;
        CreateSubWindow("Plotting guide", new EAPlotBackground(this, eapui));
    });
}

#define SelectAndPlot(Type, FUNC)                                           \
QStringList Files = QFileDialog::getOpenFileNames(NULL,                     \
    tr("load Plot files"), PlotFileOpenDir, Type ";;ALL files (*.*)");      \
                                                                            \
if (!Files.size()) return;                                                  \
PlotFileOpenDir = QFileInfo(Files[0]).absolutePath();                       \
for (auto ifile : Files){                                                   \
    FUNC(ifile);                                                            \
}

#define AddSubPlot(FILE, PlotItem) {                                        \
    frame->PageRaise(MainPage::EAPlot);                                     \
    auto plot = new PlotItem;                                               \
    if (plot->chartViews.size()){                                           \
        CreateSubWindow(QFileInfo(FILE).fileName(), plot);                  \
        plot->mdiArea->tileSubWindows();                                    \
    } else {                                                                \
        delete plot;                                                        \
        QMessageBox::warning(this, tr("File format error"),                 \
        io->ErrMsg.back(), QMessageBox::Ok, QMessageBox::Ok);               \
    }                                                                       \
}



void EAPlotPage::createPlotEAM(QString ifile){
    AddSubPlot(ifile, PlotEAM(EAPlot->ui.mdiArea, ifile, false, eapui));
}

void EAPlotPage::createPlotFS(QString ifile){
    AddSubPlot(ifile, PlotEAM(EAPlot->ui.mdiArea, ifile, true, eapui));
}

void EAPlotPage::createPlotMEAM(QString lib, QString meam){
    AddSubPlot(lib, PlotMEAM(EAPlot->ui.mdiArea, lib, meam, eapui));
}
void EAPlotPage::loadMEAM() {

    frame->PageRaise(MainPage::EAPlot);
    QString lib = QFileDialog::getOpenFileName(NULL,
        tr("load MEAM library file"), PlotFileOpenDir,
        "MEAM library files (*.library *.lib *.meam);;""ALL files (*.*)");

    if (lib == "") return;
    PlotFileOpenDir = QFileInfo(lib).absolutePath();

    QString meam = QFileDialog::getOpenFileName(NULL,
        tr("load MEAM meam file"), PlotFileOpenDir,
        "MEAM library files (*.meam);;""ALL files (*.*)");

    if (meam == ""){
        meam = "NULL";
    } else{
        PlotFileOpenDir = QFileInfo(lib).absolutePath();
    }

    createPlotMEAM(lib, meam);
}

void EAPlotPage::createPlotTersoff(QString ifile){
    AddSubPlot(ifile, PlotTersoff(EAPlot->ui.mdiArea, ifile, eapui));
}

void EAPlotPage::createPlotBrenner(QString ifile){
    AddSubPlot(ifile, PlotTersoff(EAPlot->ui.mdiArea, ifile, eapui));
}

void EAPlotPage::createPlotSW(QString ifile){
    AddSubPlot(ifile, PlotSW(EAPlot->ui.mdiArea, ifile, eapui));
}


void EAPlotPage::createPlotSurf(QString ifile){
    frame->PageRaise(MainPage::EAPlot);

    QDialog* dialog = new QDialog();
    new QPlotSubPage3D(dialog, ifile, eapui);
    dialog->setWindowTitle(ifile);
    QRect rect = frame->geometry();
    dialog->setWindowFlags(dialog->windowFlags() | Qt::WindowMinMaxButtonsHint);
    dialog->setGeometry(rect.x() + 20, rect.y() + 20, rect.width() - 40, rect.height() - 40);
    dialog->show();
}

void EAPlotPage::init()
{
	bool Closable = true;
    ui.mdiArea->setTabsClosable(Closable);
	ui.mdiArea->setViewMode(QMdiArea::TabbedView);
    //ui.mdiArea->setTabShape(QTabWidget::Triangular);

// #ifdef _DEBUG
// 	{
//  QString lib = PlotFileOpenDir + "/Fe3C.library";
//  QString meam = PlotFileOpenDir + "/Fe3C.meam";
//  CreateSubWindow(QFileInfo(lib).fileName(),
//      new PlotMEAM(EAPlot->ui.mdiArea, lib, meam, eapui));
// 	}
// #endif    

    connect(frame->ui.actionPlotEAM, &QAction::triggered, this, [=]{
        SelectAndPlot("EAM Files (*.eam *.alloy)", createPlotEAM);
    });
    connect(frame->ui.actionPlotFs,  &QAction::triggered, this, [=]{
        SelectAndPlot("FS/TB Files (*.fs *.tb)", createPlotFS);
    });

    connect(frame->ui.actionPlotMEAM,  &QAction::triggered, this, &EAPlotPage::loadMEAM);

    connect(frame->ui.actionPlotTersoff,  &QAction::triggered, this, [=]{
        SelectAndPlot("Tersoff Files (*.tersoff)", createPlotTersoff);
    });
    connect(frame->ui.actionPlotBrenner,  &QAction::triggered, this, [=]{
        SelectAndPlot("Brenner Files (*.brenner)", createPlotBrenner);
    });
    connect(frame->ui.actionPlotSW,  &QAction::triggered, this, [=]{
        SelectAndPlot("SW Files (*.sw)", createPlotSW);
    });

    connect(frame->ui.actionPlotSurf, &QAction::triggered, this, [=]{
        SelectAndPlot("Check Data (*.log *.json)", createPlotSurf);
    });

    CreateSubWindow("Plotting guide", new EAPlotBackground(this, eapui));
}




void QWChartView::mousePressEvent(QMouseEvent *event)
{
    //Left mouse button pressed, record beginPoint
//    QChartView::mousePressEvent(event);
    if (event->button() == Qt::LeftButton)
        beginPoint = event->pos();
    else if (event->button() == Qt::MiddleButton) {
        MiddleButtonPressed = true;
        MiddlePoint = event->pos();
    }
    QChartView::mousePressEvent(event);
}

void QWChartView::mouseMoveEvent(QMouseEvent *event)
{
    //Mouse move Event
    QPoint  point;
    point = event->pos();

    if (MiddleButtonPressed) {
        QPoint delta = MiddlePoint - point;
        chart()->scroll(delta.x(), -delta.y());
        MiddlePoint = point;
    }
    else {
        emit mouseMovePoint(point);
    }

    QChartView::mouseMoveEvent(event);
}

void QWChartView::mouseReleaseEvent(QMouseEvent *event)
{
    //    QChartView::mouseReleaseEvent(event);
    if (event->button() == Qt::LeftButton)
    {
        //Release the left mouse button, get the endPoint of the rectangular frame, and zoom
        endPoint = event->pos();
        QRectF  rectF;
        rectF.setTopLeft(this->beginPoint);
        rectF.setBottomRight(this->endPoint);

        //        rectF.setTop(this->chart()->rect().top());
        //        rectF.setBottom(this->chart()->rect().bottom());

        //        rectF.setLeft(this->beginPoint.rx());
        //        rectF.setRight(this->endPoint.rx());

        this->chart()->zoomIn(rectF);
    }
    else if (event->button() == Qt::MiddleButton) {
        MiddleButtonPressed = false;
    }
    QChartView::mouseReleaseEvent(event);
}

void QWChartView::mouseDoubleClickEvent(QMouseEvent *event) {

    if (event->button() == Qt::LeftButton) {
        chart()->zoomReset();
        chart()->resetTransform();
    }
    QChartView::mouseDoubleClickEvent(event);
}

void QWChartView::wheelEvent(QWheelEvent *event) {
    if (event->orientation() == Qt::Vertical) {
        if (event->angleDelta().y() > 0) {
            chart()->zoom(1.2);
        }
        else {
            chart()->zoom(0.8);
        }
    }
    QChartView::wheelEvent(event);
}

void QWChartView::keyPressEvent(QKeyEvent *event)
{
    //Button control
    switch (event->key()) {
    case Qt::Key_Plus:  //+
        chart()->zoom(1.2);
        break;
    case Qt::Key_Minus:
        chart()->zoom(0.8);
        break;
    case Qt::Key_Left:
        chart()->scroll(10, 0);
        break;
    case Qt::Key_Right:
        chart()->scroll(-10, 0);
        break;
    case Qt::Key_Up:
        chart()->scroll(0, -10);
        break;
    case Qt::Key_Down:
        chart()->scroll(0, 10);
        break;
    case Qt::Key_PageUp:
        chart()->scroll(0, 50);
        break;
    case Qt::Key_PageDown:
        chart()->scroll(0, -50);
        break;
    case Qt::Key_Home:
        chart()->zoomReset();
        //        chart()->resetTransform();//
        //        chart()->zoomIn(chart()->plotArea()); //
        break;
    default:
        QGraphicsView::keyPressEvent(event);
        //        break;
    }
    //    QGraphicsView::keyPressEvent(event);
}

QWChartView::QWChartView(QWidget *parent) :QChartView(parent)
{

    MiddleButtonPressed = false;

    this->setDragMode(QGraphicsView::RubberBandDrag);
    //    this->setRubberBand(QChartView::RectangleRubberBand);//Set to rectangular selection
    //    this->setRubberBand(QChartView::VerticalRubberBand);
    //    this->setRubberBand(QChartView::HorizontalRubberBand);

    this->setMouseTracking(true);//must open
}

QWChartView::~QWChartView()
{

}












#define NewAction(Icon, Title)													\
    new QAction(QIcon(QString::fromUtf8(Icon)), QStringLiteral(Title), this)

QPlotSubPage2D::QPlotSubPage2D(QWidget *parent, EAPUI* ptr)
    : QWidget(parent), UiPtr(ptr)
{

    mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(0, 0, 0, 0);

    mdiArea = new QMdiArea(this);
    mdiArea->setTabsMovable(true);
    mainLayout->addWidget(mdiArea);

    toolBar = new QToolBar(this);
    toolBar->setIconSize(QSize(22, 22));


    Act_TabMode = NewAction(":/image/icon/tabwidget", "Tab");
    Act_TabMode->setCheckable(true);
    connect(Act_TabMode, &QAction::triggered, this, [=]() {
        if (Act_TabMode->isChecked()) {
            mdiArea->setViewMode(QMdiArea::TabbedView);
            Act_Stack->setEnabled(false);
            Act_Tile->setEnabled(false);
            Act_Frameless->setEnabled(false);
        } else {
            mdiArea->setViewMode(QMdiArea::SubWindowView);
            Act_Stack->setEnabled(true);
            Act_Tile->setEnabled(true);
            Act_Frameless->setEnabled(true);
        }
    });
    toolBar->addAction(Act_TabMode);


    Act_Tile = NewAction(":/image/icon/tile", "Tile");
    connect(Act_Tile, &QAction::triggered, mdiArea, &QMdiArea::tileSubWindows);
    toolBar->addAction(Act_Tile);

    Act_Stack = NewAction(":/image/icon/stack", "Stack");
    connect(Act_Stack, &QAction::triggered, mdiArea, &QMdiArea::cascadeSubWindows);
    toolBar->addAction(Act_Stack);

    Act_Frameless = NewAction(":/image/icon/frameless", "Frameless");
    Act_Frameless->setCheckable(true);
    Act_Frameless->setChecked(true);
    connect(Act_Frameless, &QAction::triggered, this, [=]() {
        bool Frameless = Act_Frameless->isChecked();
        QList<QMdiSubWindow *> list = mdiArea->subWindowList();

        for (auto iSub : list) {
            iSub->setWindowFlag(Qt::FramelessWindowHint, Frameless);
        }
    });
    toolBar->addAction(Act_Frameless);


    Act_Previous = NewAction(":/image/icon/arrowLeft", "Previous");
    connect(Act_Previous, &QAction::triggered, mdiArea, &QMdiArea::activatePreviousSubWindow);
    toolBar->addAction(Act_Previous);

    Act_Next = NewAction(":/image/icon/arrowRight", "Next");
    connect(Act_Next, &QAction::triggered, mdiArea, &QMdiArea::activateNextSubWindow);
    toolBar->addAction(Act_Next);

    Act_CloseAll = NewAction(":/image/icon/delete", "DeleteAll");
    connect(Act_CloseAll, &QAction::triggered, mdiArea, &QMdiArea::closeAllSubWindows);
    toolBar->addAction(Act_CloseAll);

    mainLayout->insertWidget(0, toolBar);
}

QPlotSubPage2D::~QPlotSubPage2D() {

}


enum {
    YMIN = 1 << 0,
    YMAX = 1 << 1,
};

void QPlotSubPage2D::LegendMarkerClicked()
{
    QLegendMarker* marker = qobject_cast<QLegendMarker*> (sender());

    switch (marker->type()) {
    case QLegendMarker::LegendMarkerTypeXY: //QLineSeries
    {
        marker->series()->setVisible(!marker->series()->isVisible()); //isVisible
        marker->setVisible(true);
        qreal alpha = 1.0;
        if (!marker->series()->isVisible())
            alpha = 0.5;

        QColor color;
        QBrush brush = marker->labelBrush();
        color = brush.color();
        color.setAlphaF(alpha);
        brush.setColor(color);
        marker->setLabelBrush(brush);

        brush = marker->brush();
        color = brush.color();
        color.setAlphaF(alpha);
        brush.setColor(color);
        marker->setBrush(brush);

        QPen pen = marker->pen();
        color = pen.color();
        color.setAlphaF(alpha);
        pen.setColor(color);
        marker->setPen(pen);
        break;
    }
    default:
        break;
    }
}


void QPlotSubPage2D::CreateSubWindow(QChart* chart, const QString& xlabel, const QString& ylabel, const AxisLimit& x, const AxisLimit& y) {

    chart->createDefaultAxes();
    auto axisx = qobject_cast<QValueAxis*>(chart->axes(Qt::Horizontal, chart->series()[0]).first());
    auto axisy = qobject_cast<QValueAxis*>(chart->axes(Qt::Vertical, chart->series()[0]).first());

    axisx->setRange(x.lo, x.hi);
    axisx->setLabelFormat("%.1f");
    axisx->setGridLineVisible(true);
    axisx->setTitleText(xlabel);
    axisx->setTickCount(7);
    axisx->setMinorTickCount(1);

    axisy->setRange(y.lo, y.hi);
    axisy->setLabelFormat("%.1f");
    axisy->setGridLineVisible(true);
    axisy->setTitleText(ylabel);
    axisy->setTickCount(7);
    axisy->setMinorTickCount(1);


    chart->setContentsMargins(-20, -30, -20, -20);
    chart->setBackgroundRoundness(0);

    QWChartView* chartView = new QWChartView(this);
    chartViews.append(chartView);
    chartView->setChart(chart);

    connect(chartView, &QWChartView::mouseMovePoint, this, [=](QPoint point) {
        QWChartView* ChartView = qobject_cast<QWChartView*>(sender());
        QPointF pt = ChartView->chart()->mapToValue(point);
        frame->statusBar()->showMessage(QString::asprintf("X=%f,Y=%f", pt.x(), pt.y()));
    });

    foreach(QLegendMarker* iMarker, chart->legend()->markers()) {
        connect(iMarker, &QLegendMarker::clicked, this, &QPlotSubPage2D::LegendMarkerClicked);
    }

    QMdiSubWindow *subWindow = new QMdiSubWindow(mdiArea);
    subWindow->setWindowTitle(ylabel);
    subWindow->setWidget(chartView);
    subWindow->setMinimumSize(200, 150);
    subWindow->setContentsMargins(10,10,10,10);
    subWindow->setWindowFlag(Qt::FramelessWindowHint, true);

    mdiArea->addSubWindow(subWindow);
}


QSplineSeries* QPlotSubPage2D::creatSeries(QChart* chart, const QString& Name) {
    QSplineSeries *series = new QSplineSeries();
    series->setName(Name);
    chart->addSeries(series);
    return series;
}

void QPlotSubPage2D::getSeriesRange(QLineSeries* series, qreal& lo, qreal& hi){

    qreal ymin = lo, ymax = hi;
    for(int i = 0; i < series->count(); i++){
        qreal y = series->at(i).y();
        ymin = fmin(ymin, y);
        ymax = fmax(ymax, y);
    }
    lo = ymin;
    hi = ymax;
}




void QPlotSubPage2D::addHorizontal(QChart* chart, qreal y, qreal xlo, qreal xhi){
    QLineSeries *series = new QLineSeries();
    series->setPen(QPen(QBrush(Qt::green),2,Qt::DashDotDotLine));
    series->append(xlo, y);
    series->append(xhi, y);
    chart->addSeries(series);
}

#define PACK(Chart, Label, X, Y)                        \
QSplineSeries* series = creatSeries(Chart, Label);      \
for (int ii = 0; ii < Np; ii++){                        \
    series->append(X, Y);                               \
}                                                       \
getSeriesRange(series, lo, hi);



PlotEAM::PlotEAM(QWidget *parent, QString file, bool pfsFlag, EAPUI* ptr)
    : QPlotSubPage2D(parent, ptr)
    , fsFlag(pfsFlag)
{
    frho = nullptr;
    rhor = nullptr;
    z2r = nullptr;

    xlim.resize(3);
    ylim.resize(3);
    xlim[2].customlo = xlim[1].customlo = 1.5;

    if (read_data(file)) return;
    Np = MIN(nrho, 200);
    Np = MIN(nr, 200);

    int n = elts.size();

    qreal fembmult = 3.0;
    size_t rsample = SIZE_T(2.5 / dr);

    // 2. get sampling point features
    qreal rhomax = 0, phimax = 0;
    qreal embmax = 0, embmin = 0;

    for (int i = 0; i < n; i++) {
        int jlo = fsFlag ? 0 : i;
        int jhi = fsFlag ? n : i + 1;

        for (int j = jlo; j < jhi; j++) {
            rhomax = MAX(rhomax, rhor[i][j][rsample]);
        }
        for (int j = 0; j <= i; j++) {
            phimax = MAX(phimax, z2r[i][j][rsample]);
        }
    }

    int Rsample1 = INT(14 * rhomax / drho);
    int Rsample2 = INT(Rsample1*fembmult);

    for (int i = 0; i < n; i++) {
        if (Rsample1 < nrho) embmax = MAX(embmax, frho[i][Rsample1]);
        if (Rsample1 < nrho) embmin = MIN(embmin, frho[i][Rsample1]);
        if (Rsample2 < nrho) embmax = MAX(embmax, frho[i][Rsample2]);
        if (Rsample2 < nrho) embmin = MIN(embmin, frho[i][Rsample2]);
    }
    embmax *= embmax > 0 ? 1.1 : 0.9;
    embmin *= embmin < 0 ? 1.1 : 0.9;

    xlim[0].set(0.0, 14 * rhomax * fembmult).update();
    xlim[1].set(0.0, cut).update();
    xlim[2].set(0.0, cut).update();

    qreal lo, hi;
    int Rrat = nrho/Np, rrat = nr/Np;
    qreal Rdx = drho * Rrat, rdx = dr * rrat;

    QChart *Chart1 = new QChart();
    QChart *Chart2 = new QChart();
    QChart *Chart3 = new QChart();

    addHorizontal(Chart1, 0, -10, xlim[0].hi+10);
    addHorizontal(Chart2, 0, -10, xlim[1].hi+10);
    addHorizontal(Chart3, 0, -10, xlim[1].hi+10);

    lo = hi = 0;
    for (int i = 0; i < n; i++) {
        PACK(Chart1, elts[i], ii*Rdx, frho[i][ii*Rrat+1]);
    }
    ylim[0].set(embmin, embmax).update();

    lo = hi = 0;
    for (int i = 0; i < n; i++) {
        int jlo = fsFlag ? 0 : i;
        int jhi = fsFlag ? n : i + 1;

        for (int j = jlo; j < jhi; j++) {
            QString label = elts[i]+'-'+elts[j];
            PACK(Chart2, label, ii*rdx, rhor[i][j][ii*rrat+1]);
        }
    }
    ylim[1].set(0.0, rhomax * 1.2).update();

    lo = hi = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++) {
            QString label = elts[i]+'-'+elts[j];
            PACK(Chart3, label, ii*rdx, z2r[i][j][ii*rrat+1]);
        }
    }
    if (lo < 0) {
        lo = MIN(-0.02, lo);
        ylim[2].set(lo * 1.2, -lo * 1.2).update();
    } else {
        ylim[2].set(lo * 0.8, phimax * 1.2).update();
    }

    CreateSubWindow(Chart1, "rhot", "Femb", xlim[0], ylim[0]);
    CreateSubWindow(Chart2, "r", "rho", xlim[1], ylim[1]);
    CreateSubWindow(Chart3, "r", "phi", xlim[2], ylim[2]);

    mdiArea->tileSubWindows();
}

PlotEAM::~PlotEAM() {
    if (frho) MatMemory::destroy(frho);
    if (rhor) MatMemory::destroy(rhor);
    if (z2r) MatMemory::destroy(z2r);
}


#define MAXLINE 1024

void PlotEAM::grab(FILE *fptr, int n, double *list)
{
    char *ptr;
    char line[MAXLINE];

    int i = 0;
    while (i < n) {
        fgets(line, MAXLINE, fptr);
        ptr = strtok(line, " \t\n\r\f");
        list[i++] = atof(ptr);
        while ((ptr = strtok(NULL, " \t\n\r\f"))) list[i++] = atof(ptr);
    }
}

int PlotEAM::read_data(QString pfile) {
    FILE *fptr;
    char line[MAXLINE];

    fptr = fopen(pfile.toLocal8Bit().data(), "r");
    if (fptr == NULL) {
        return io->error(FLERR, QString("file %1 open error").arg(pfile));
    }

    fgets(line, MAXLINE, fptr);
    fgets(line, MAXLINE, fptr);
    fgets(line, MAXLINE, fptr);
    fgets(line, MAXLINE, fptr);

    elts = QString(line).split(QRegExp("\\W+"),QString::SkipEmptyParts);
    elts.erase(elts.begin());

    fgets(line, MAXLINE, fptr);
    int nwords = sscanf(line, "%d %lg %d %lg %lg",
        &nrho, &drho, &nr, &dr, &cut);
    if ((nwords != 5) || (nrho <= 0) || (nr <= 0) || (dr <= 0.0))
        return io->error(FLERR, QString("EAM List format error"));

    int n = elts.size();

    if (frho) MatMemory::destroy(frho);
    if (rhor) MatMemory::destroy(rhor);
    if (z2r) MatMemory::destroy(z2r);

    MatMemory::create(frho, SIZE_T(n), SIZE_T(nrho) + 1);
    MatMemory::create(rhor, SIZE_T(n), SIZE_T(n), SIZE_T(nr) + 1);
    MatMemory::create(z2r,  SIZE_T(n), SIZE_T(n), SIZE_T(nr) + 1);

    int i, j;
    for (i = 0; i < n; i++) {
        fgets(line, MAXLINE, fptr);
        grab(fptr, nrho, &frho[i][1]);

        int jlo = fsFlag ? 0 : i;
        int jhi = fsFlag ? n : i + 1;
        for (int j = jlo; j < jhi; j++) {
            grab(fptr, nr, &rhor[i][j][1]);
        }
    }

    for (i = 0; i < n; i++) {
        for (j = 0; j <= i; j++) {
            grab(fptr, nr, &z2r[i][j][1]);
        }
    }
    // close the potential file
    fclose(fptr);

    return 0;
}

#undef PACK
#define PACK(Chart, Label, X, Y)                         \
QSplineSeries* series = creatSeries(Chart, Label);      \
for (int ii = 0; ii <= Np; ii++){                       \
    series->append(X, Y);                               \
}                                                       \
getSeriesRange(series, lo, hi);

#define IDX(i,j,k) (i*n2+j*n+k)
#define Val(iParam, itri) pyParamVec[iParam*n3 + itri]
#ifndef PI
#define PI 3.14159265358979323
#endif
#define EPS 0.9999


double f2(double A, double eps, double B, double sigma, double p, double q, double a, double r) {
    if (r >= a * sigma * EPS || r < 1e-10) return 0;

    double sr = sigma / r;
    double powitem = B * pow(sr, p) - pow(sr, q);
    double expitem = exp(sigma / (r - a * sigma));
    return A * eps * powitem * expitem;
}

double f3(double lam, double eps, double g1, double s1, double a1, double g2, double s2, double a2, double r) {
    if (r >= a1 * s1 * EPS || r >= a2 * s2 * EPS) return 0;

    double expitem1 = exp(g1 * s1 / (r - a1 * s1));
    double expitem2 = exp(g2 * s2 / (r - a2 * s2));
    return lam * eps * expitem1 * expitem2;
}

double gT(double cost0, double t) {
    double delta = cos(t) - cost0;
    return delta * delta;
}

PlotSW::PlotSW(QWidget *parent, QString file, EAPUI* ptr)
    : QPlotSubPage2D(parent, ptr)
{
    Np = 100;
    xlim.resize(3);
    ylim.resize(3);
    double sample0 = xlim[0].customlo = 1.0;
    double sample1 = xlim[1].customlo = 1.25;

    if (read_data(file)) return;
    size_t n = SIZE_T(elts.size());
    size_t n2 = n * n, n3 = n * n * n;

    // 2. get cutoff
    double f2max = 0, f3max = 0, cut = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
        {
            const size_t itri = IDX(i, j, j);
            double A = Val(6, itri), eps = Val(0, itri);
            double B = Val(7, itri), sigma = Val(1, itri);
            double p = Val(8, itri), q = Val(9, itri), a = Val(2, itri);
            f2max = fmax(f2max, f2(A, eps, B, sigma, p, q, a, sample0));
        }

        for (size_t k = 0; k < n; k++) {
            const size_t tri1 = IDX(i, j, j);
            const size_t tri2 = IDX(i, k, k);

            double lam = Val(3, tri1), eps = Val(0, tri1);
            double g1 = Val(4, tri1), s1 = Val(1, tri1), a1 = Val(2, tri1);
            double g2 = Val(4, tri2), s2 = Val(1, tri2), a2 = Val(2, tri2);
            f3max = fmax(f3max, f3(lam, eps, g1, s1, a1, g2, s2, a2, sample1));

            cut = fmax(cut, a1 * s1);
            cut = fmax(cut, a2 * s2);
        }
    }

    xlim[0].set(0.0, cut).update();
    xlim[1].set(0.0, cut).update();
    xlim[2].set(0.0, 2 * PI).update();

    // 3. pack image data
    qreal lo, hi;
    double dr = (xlim[0].hi - 0.0) / Np;
    double dt = (xlim[2].hi - 0.0) / Np;

    QChart *Chart1 = new QChart();
    QChart *Chart2 = new QChart();
    QChart *Chart3 = new QChart();

    addHorizontal(Chart1, 0, -10, xlim[0].hi+10);
    addHorizontal(Chart2, 0, -10, xlim[1].hi+10);
    addHorizontal(Chart3, 0, -10, xlim[1].hi+10);


    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
        const size_t itri = IDX(i, j, j);
        QString label = elts[i]+elts[j];

        double A = Val(6, itri), eps = Val(0, itri);
        double B = Val(7, itri), sigma = Val(1, itri);
        double p = Val(8, itri), q = Val(9, itri), a = Val(2, itri);
        PACK(Chart1, label, ii*dr, f2(A, eps, B, sigma, p, q, a, ii*dr));
    }
    if (lo < 0) {
        lo = fmin(-0.02, lo);
        ylim[0].set(lo * 1.1, -lo * 2.2).update();
    } else {
        ylim[0].set(0.0, f2max).update();
    }


    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++)
    for (size_t k = 0; k < n; k++) {
        const size_t tri1 = IDX(i, j, j);
        const size_t tri2 = IDX(i, k, k);
        QString label = elts[i]+elts[j]+elts[k];

        double lam = Val(3, tri1), eps = Val(0, tri1);
        double g1 = Val(4, tri1), s1 = Val(1, tri1), a1 = Val(2, tri1);
        double g2 = Val(4, tri2), s2 = Val(1, tri2), a2 = Val(2, tri2);
        PACK(Chart2, label, ii*dr, f3(lam, eps, g1, s1, a1, g2, s2, a2, ii*dr));
    }
    ylim[1].set(fmin(lo, 0), f3max).update();

    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++)
    for (size_t k = 0; k < n; k++) {
        const int itri = IDX(i, j, k);
        QString label = elts[i]+elts[j]+elts[k];

        double cost0 = Val(5, itri);
        PACK(Chart3, label, ii*dt, gT(cost0, ii*dt));
    }
    ylim[2].set(0.0, hi * 1.1).update();

    CreateSubWindow(Chart1, "r", "2-body", xlim[0], ylim[0]);
    CreateSubWindow(Chart2, "r", "3-body", xlim[1], ylim[1]);
    CreateSubWindow(Chart3, "theta", "g(theta)", xlim[2], ylim[2]);

    mdiArea->tileSubWindows();
}

int PlotSW::read_data(QString fileName){
    int nParam = 11;
    int params_per_line = nParam + 3;

    QString data;
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)){
        data = file.readAll();
        file.close();
    }

    QList<Param> params;
    QStringList lines = data.split('\n');
    for (int i = 0; i < lines.size(); i++) {

        QString line = lines[i];
        if(line.contains('#') || line == "") {
            continue;
        }

        QStringList words = line.split(QRegExp("\\s+"), QString::SkipEmptyParts);

        // concatenate additional lines until have params_per_line words

        while (words.size() < params_per_line) {
            i++;
            if(i >= lines.size()) break;
            words.append(lines[i].split(QRegExp("\\s+"), QString::SkipEmptyParts));
        }

        if (words.size() != params_per_line)
            return io->error(FLERR,"Incorrect format in Stillinger-Weber potential file");

        // ielement,jelement,kelement = 1st args
        // if all 3 args are in element list, then parse this line
        // else skip to next entry in file

        if(!elts.contains(words[0])) elts.append(words[0]);
        if(!elts.contains(words[1])) elts.append(words[1]);
        if(!elts.contains(words[2])) elts.append(words[2]);

        Param iparam;
        iparam.i         = elts.indexOf(words[0]);
        iparam.j         = elts.indexOf(words[1]);
        iparam.k         = elts.indexOf(words[2]);
        for(int ii = 0; ii < nParam; ii++){
            iparam.v[ii]  = words[ii+3].toDouble();
        }

        if (iparam.v[0] < 0.0 || iparam.v[1] < 0.0 ||
            iparam.v[2] < 0.0 || iparam.v[3] < 0.0 ||
            iparam.v[4] < 0.0 || iparam.v[6] < 0.0 ||
            iparam.v[7] < 0.0 || iparam.v[8] < 0.0 ||
            iparam.v[9] < 0.0 || iparam.v[10] < 0.0)
            return io->error(FLERR,"Illegal Stillinger-Weber parameter");
        params.append(iparam);
    }

    int n = elts.size();
    int n2 = n*n, n3 = n*n*n;

    pyParamVec.resize(nParam * n3, 0.0);
    foreach(const Param& iparam, params) {
        int i = iparam.i;
        int j = iparam.j;
        int k = iparam.k;

        const int itri = IDX(i, j, k);
        for (int idx = 0; idx < nParam; idx++){
            pyParamVec[idx*n3 + itri] = iparam.v[idx];
        }
    }
    return 0;
}


double fR(double A, double lam, double R, double D, double r) {
    if (r > R + D) return 0;

    double res = A * exp(-lam * r);

    if (r > R - D) {
        double ang = PI * (r - R) / (2 * D);
        return res * 0.5 * (1 - sin(ang));
    } else {
        return res;
    }
}

double gT(double g, double c, double d, double cost0, double t) {

    double delta = cos(t) - cost0;
    double c2 = c * c, d2 = d * d;

    double res = 1 + c2 / d2;
    res -= c2 / (d2 + delta * delta);

    return g * res;
}


PlotTersoff::PlotTersoff(QWidget *parent, QString file, EAPUI* ptr)
    : QPlotSubPage2D(parent, ptr)
{
    Np = 100;
    xlim.resize(3);
    ylim.resize(3);
    double sample0 = xlim[0].customlo = 1.25;
    double sample1 = xlim[1].customlo = 1.25;

    if (read_data(file)) return;
    size_t n = SIZE_T(elts.size());
    size_t n2 = n * n, n3 = n * n * n;

    // 2. get cutoff
    double fAmax = 0, fBmin = 0, cut = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
        const size_t itri = IDX(i, j, j);
        double R = Val(10, itri), D = Val(11, itri);
        double A = Val(13, itri), k1 = Val(12, itri);
        double B = -Val(9, itri), k2 = Val(8, itri);

        fAmax = fmax(fAmax, fR(A, k1, R, D, sample0));
        fBmin = fmin(fBmin, fR(B, k2, R, D, sample1));

        for (size_t k = 0; k < n; k++) {
            const size_t itri = IDX(i, j, k);
            cut = fmax(cut, Val(10, itri) + Val(11, itri));
        }
    }

    xlim[0].set(0.0, cut).update();
    xlim[1].set(0.0, cut).update();
    xlim[2].set(0.0, 2 * PI).update();

    // 3. pack image data
    qreal lo, hi;
    double dr = (xlim[0].hi - 0.0) / Np;
    double dt = (xlim[2].hi - 0.0) / Np;

    QChart *Chart1 = new QChart();
    QChart *Chart2 = new QChart();
    QChart *Chart3 = new QChart();

    addHorizontal(Chart1, 0, -10, xlim[0].hi+10);
    addHorizontal(Chart2, 0, -10, xlim[1].hi+10);
    addHorizontal(Chart3, 0, -10, xlim[1].hi+10);


    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
        const size_t itri = IDX(i, j, j);
        QString label = elts[i]+elts[j];

        double R = Val(10, itri), D = Val(11, itri);
        double A = Val(13, itri), k1 = Val(12, itri);
        PACK(Chart1, label, ii*dr, fR(A, k1, R, D, ii * dr));
    }
    ylim[0].set(fmin(lo, 0), fAmax).update();


    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
        const size_t itri = IDX(i, j, j);
        QString label = elts[i]+elts[j];

        double R = Val(10, itri), D = Val(11, itri);
        double B = -Val(9, itri), k2 = Val(8, itri);
        PACK(Chart2, label, ii*dr, fR(B, k2, R, D, ii * dr));
    }
    ylim[1].set(fBmin, fmax(hi, 0)).update();


    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++)
    for (size_t k = 0; k < n; k++) {
        const size_t itri = IDX(i, j, k);
        QString label = elts[i]+elts[j]+elts[k];

        double g = Val(1, itri), c = Val(3, itri);
        double d = Val(4, itri), cost0 = Val(5, itri);
        PACK(Chart3, label, ii*dt, gT(g, c, d, cost0, ii * dt));
    }
    ylim[2].set(0.0, hi * 1.1).update();

    CreateSubWindow(Chart1, "r", "fR(r)", xlim[0], ylim[0]);
    CreateSubWindow(Chart2, "r", "fA(r)", xlim[1], ylim[1]);
    CreateSubWindow(Chart3, "theta", "g(theta)", xlim[2], ylim[2]);

    mdiArea->tileSubWindows();
}

int PlotTersoff::read_data(QString fileName){
    int nParam = 14;
    int params_per_line = nParam + 3;

    QString data;
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)){
        data = file.readAll();
        file.close();
    }

    QList<Param> params;
    QStringList lines = data.split('\n');
    for (int i = 0; i < lines.size(); i++) {

        QString line = lines[i];
        if(line.contains('#') || line == "") {
            continue;
        }

        QStringList words = line.split(QRegExp("\\s+"), QString::SkipEmptyParts);

        // concatenate additional lines until have params_per_line words

        while (words.size() < params_per_line) {
            i++;
            if(i >= lines.size()) break;
            words.append(lines[i].split(QRegExp("\\s+"), QString::SkipEmptyParts));
        }

        if (words.size() != params_per_line)
            return io->error(FLERR,"Incorrect format in Tersoff potential file");

        // ielement,jelement,kelement = 1st args
        // if all 3 args are in element list, then parse this line
        // else skip to next entry in file

        if(!elts.contains(words[0])) elts.append(words[0]);
        if(!elts.contains(words[1])) elts.append(words[1]);
        if(!elts.contains(words[2])) elts.append(words[2]);

        Param iparam;
        iparam.i         = elts.indexOf(words[0]);
        iparam.j         = elts.indexOf(words[1]);
        iparam.k         = elts.indexOf(words[2]);
        for(int ii = 0; ii < nParam; ii++){
            iparam.v[ii]  = words[ii+3].toDouble();
        }

        if (iparam.v[3] < 0.0 || iparam.v[4] < 0.0 ||
            iparam.v[6] < 0.0 || iparam.v[7] < 0.0 ||
            iparam.v[8] < 0.0 || iparam.v[9] < 0.0 ||
            iparam.v[10] < 0.0 || iparam.v[11] < 0.0 ||
            iparam.v[12] < 0.0 || iparam.v[13] < 0.0 ||
            iparam.v[11] > iparam.v[10] || iparam.v[2] < 0.0 ||
            (iparam.v[0] != 3.0 && iparam.v[0] != 1.0))
            return io->error(FLERR,"Illegal Stillinger-Weber parameter");
        params.append(iparam);
    }

    int n = elts.size();
    int n2 = n*n, n3 = n*n*n;

    pyParamVec.resize(nParam * n3, 0.0);
    foreach(const Param& iparam, params) {
        int i = iparam.i;
        int j = iparam.j;
        int k = iparam.k;

        const int itri = IDX(i, j, k);
        for (int idx = 0; idx < nParam; idx++){
            pyParamVec[idx*n3 + itri] = iparam.v[idx];
        }
    }

    return 0;
}








QPlotSubPage3D::QPlotSubPage3D(QWidget *parent, const QString& file, EAPUI* ptr)
    : QWidget(parent), UiPtr(ptr)
{
    CreateQLinearGradient();
    mainLayout = new QHBoxLayout(parent);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    splitter = new QSplitter(Qt::Horizontal);

    ui.setupUi(splitter);

    readData(file);
    iniGraph3D();
    UpdateQLinearGradient();

    splitter->addWidget(graphContainer);
    splitter->addWidget(ui.verticalGroupBox);
    mainLayout->addWidget(splitter);

    CreateConnect();

    //graph3D->scene()->activeLight()->setAutoPosition(false);
}

QPlotSubPage3D::~QPlotSubPage3D() {
    //delete graph3D;
    //delete dataArray;
    //delete graphContainer;
}


void QPlotSubPage3D::CreateQLinearGradient() {
    Gradient.push_back(QLinearGradient(0, 0, 100, 0));
    Gradient[0].setColorAt(1.0, QColor(155, 0, 0));
    Gradient[0].setColorAt(0.9, QColor(255, 0, 0));
    Gradient[0].setColorAt(0.7, QColor(252, 255, 0));
    Gradient[0].setColorAt(0.5, QColor(0, 255, 0));
    Gradient[0].setColorAt(0.3, QColor(0, 255, 255));
    Gradient[0].setColorAt(0.1, QColor(0, 0, 255));
    Gradient[0].setColorAt(0.0, QColor(0, 0, 155));

    Gradient.push_back(QLinearGradient(0, 0, 100, 0));
    Gradient[1].setColorAt(1.0, Qt::black);
    Gradient[1].setColorAt(0.67, Qt::blue);
    Gradient[1].setColorAt(0.33, Qt::red);
    Gradient[1].setColorAt(0.0, Qt::yellow);
}


void QPlotSubPage3D::UpdateQLinearGradient(){
    QPixmap pm(160, 20);
    QPainter pmp(&pm);
    pmp.setPen(Qt::NoPen);

    pmp.setBrush(QBrush(Gradient[0]));
    pmp.drawRect(0, 0, 160, 20);
    ui.Grad1Button->setIcon(QIcon(pm));
    ui.Grad1Button->setIconSize(QSize(160, 20));

    pmp.setBrush(QBrush(Gradient[1]));
    pmp.drawRect(0, 0, 160, 20);
    ui.Grad2Button->setIcon(QIcon(pm));
    ui.Grad2Button->setIconSize(QSize(160, 20));
}

void QPlotSubPage3D::CreateConnect() {

    connect(ui.ViewCombo, static_cast<void (QComboBox:: *)
        (int index)>(&QComboBox::currentIndexChanged), graph3D, [=](int index) {
            graph3D->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPreset(index));
        }
    );

    auto updateCameraPosition = [=]() {
        int xRot = ui.HSlider->value();
        int yRot = ui.VSlider->value();
        int zoom = ui.ZoomSlider->value();
        graph3D->scene()->activeCamera()->setCameraPosition(xRot, yRot, zoom);
    };

    connect(ui.HSlider, &QSlider::valueChanged, this, updateCameraPosition);
    connect(ui.VSlider, &QSlider::valueChanged, this, updateCameraPosition);
    connect(ui.ZoomSlider, &QSlider::valueChanged, this, updateCameraPosition);

    connect(ui.ThemeCombo, static_cast<void (QComboBox:: *)
        (int index)>(&QComboBox::currentIndexChanged), graph3D, [=](int index) {
            Q3DTheme *currentTheme = graph3D->activeTheme();
            currentTheme->setType(Q3DTheme::Theme(index));
        });

    connect(ui.BarStyleCombo, static_cast<void (QComboBox:: *)
        (int index)>(&QComboBox::currentIndexChanged), this, [=](int index) {
            QAbstract3DSeries::Mesh aMesh;
            aMesh = QAbstract3DSeries::Mesh(index + 1);
            series->setMesh(aMesh);
        });

    connect(ui.SelectionCombo, static_cast<void (QComboBox:: *)
        (int index)>(&QComboBox::currentIndexChanged), this, [=](int index) {

            switch (index) {
            case 0:	graph3D->setSelectionMode(QAbstract3DGraph::SelectionNone);	break;
            case 1:	graph3D->setSelectionMode(QAbstract3DGraph::SelectionItem);	break;
            case 2:	graph3D->setSelectionMode(QAbstract3DGraph::SelectionItemAndRow | QAbstract3DGraph::SelectionSlice); break;
            case 3:	graph3D->setSelectionMode(QAbstract3DGraph::SelectionItemAndColumn | QAbstract3DGraph::SelectionSlice);
            default: break;
            }
        });

    connect(ui.FontSizeSpin, static_cast<void (QSpinBox:: *)
        (int index)>(&QSpinBox::valueChanged), this, [=](int arg1) {
            QFont font = graph3D->activeTheme()->font();
            font.setPointSize(arg1);
            graph3D->activeTheme()->setFont(font);
        });

    connect(ui.DrawModeCombo, static_cast<void (QComboBox:: *)
        (int index)>(&QComboBox::currentIndexChanged), series, [=](int index) {

            if (index == 0)
                series->setDrawMode(QSurface3DSeries::DrawWireframe);
            else if (index == 1)
                series->setDrawMode(QSurface3DSeries::DrawSurface);
            else
                series->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);
        });

#define connectDoubleSpinBox(Axis)                                                                                              \
    connect(ui.Axis ## loSpin, static_cast<void (QDoubleSpinBox:: *)(double)>(&QDoubleSpinBox::valueChanged),                   \
        axis ## Axis, [=] (){axis ## Axis->setRange(FLOAT(ui.Axis ## loSpin->value()), FLOAT(ui.Axis ## hiSpin->value())); });	\
    connect(ui.Axis ## hiSpin, static_cast<void (QDoubleSpinBox:: *)(double)>(&QDoubleSpinBox::valueChanged),                   \
        axis ## Axis, [=]() {axis ## Axis->setRange(FLOAT(ui.Axis ## loSpin->value()), FLOAT(ui.Axis ## hiSpin->value())); });

    connectDoubleSpinBox(X);
    connectDoubleSpinBox(Y);
    connectDoubleSpinBox(Z);

    connect(ui.ZloSpin, static_cast<void (QDoubleSpinBox:: *)(double)>(&QDoubleSpinBox::valueChanged),
        this, &QPlotSubPage3D::updateSeriesZValue);
    connect(ui.ZhiSpin, static_cast<void (QDoubleSpinBox:: *)(double)>(&QDoubleSpinBox::valueChanged),
        this, &QPlotSubPage3D::updateSeriesZValue);

    /*********************************************************************************************/

    graph3D->activeTheme()->setBackgroundEnabled(false);
    connect(ui.BackgroundChk, &QCheckBox::clicked, graph3D, [=](bool checked) {
        graph3D->activeTheme()->setBackgroundEnabled(checked); });

    ui.GridChk->setChecked(true);
    graph3D->activeTheme()->setGridEnabled(true);
    connect(ui.GridChk, &QCheckBox::clicked, graph3D, [=](bool checked) {
        graph3D->activeTheme()->setGridEnabled(checked); });

    graph3D->setShadowQuality(QAbstract3DGraph::ShadowQualityNone);
    connect(ui.ShadowChk, &QCheckBox::clicked, graph3D, [=](bool checked) {
        if (checked)
            graph3D->setShadowQuality(QAbstract3DGraph::ShadowQualityMedium);
        else
            graph3D->setShadowQuality(QAbstract3DGraph::ShadowQualityNone);
        });

    ui.SmoothChk->setChecked(true);
    series->setMeshSmooth(true);
    connect(ui.SmoothChk, &QCheckBox::clicked, series, [=](bool checked) {
        series->setMeshSmooth(checked); });

    graph3D->axisY()->setReversed(false);
    connect(ui.ReverseChk, &QCheckBox::clicked, graph3D, [=](bool checked) {
        graph3D->axisY()->setReversed(checked); });

    ui.ItemLabelChk->setChecked(true);
    series->setItemLabelVisible(true);
    connect(ui.ItemLabelChk, &QCheckBox::clicked, series, [=](bool checked) {
        series->setItemLabelVisible(checked); });

    ui.AxisTitleChk->setChecked(true);
    graph3D->axisX()->setTitleVisible(true);
    graph3D->axisY()->setTitleVisible(true);
    graph3D->axisZ()->setTitleVisible(true);
    connect(ui.AxisTitleChk, &QCheckBox::clicked, graph3D, [=](bool checked) {
        graph3D->axisX()->setTitleVisible(checked);
        graph3D->axisY()->setTitleVisible(checked);
        graph3D->axisZ()->setTitleVisible(checked);
    });

    series->setFlatShadingEnabled(false);
    connect(ui.FlatShadingChk, &QCheckBox::clicked, graph3D, [=](bool checked) {
        series->setFlatShadingEnabled(checked); });

    graph3D->activeTheme()->setLabelBackgroundEnabled(false);
    connect(ui.AxisBackgroundChk, &QCheckBox::clicked, graph3D, [=](bool checked) {
        graph3D->activeTheme()->setLabelBackgroundEnabled(checked); });


    connect(ui.OrthoProjectionChk, &QCheckBox::clicked, graph3D,
            &QAbstract3DGraph::setOrthoProjection);


    /*********************************************************************************************/

    connect(ui.BarColorButton, &QPushButton::clicked, this, [=]() {
        QColor  color = series->baseColor();
        color = QColorDialog::getColor(color);
        if (color.isValid()) {
            series->setBaseColor(color);
            series->setColorStyle(Q3DTheme::ColorStyleUniform);
        }
    });

    connect(ui.Grad1Button, &QCheckBox::clicked, series, [=]() {
        series->setBaseGradient(Gradient[0]);
        series->setColorStyle(Q3DTheme::ColorStyleRangeGradient);
    });

    connect(ui.Grad2Button, &QCheckBox::clicked, series, [=]() {
        series->setBaseGradient(Gradient[1]);
        series->setColorStyle(Q3DTheme::ColorStyleRangeGradient);
    });
}


void QPlotSubPage3D::updateAxisRange() {
    axisX->setRange(FLOAT(ui.XloSpin->value()), FLOAT(ui.XhiSpin->value()));
    axisY->setRange(FLOAT(ui.YloSpin->value()), FLOAT(ui.YhiSpin->value()));
    axisZ->setRange(FLOAT(ui.ZloSpin->value()), FLOAT(ui.ZhiSpin->value()));
}

QVector<qreal> QPlotSubPage3D::loadValue(const QJsonArray& array){
    QVector<qreal> v;
    v.resize(Nxy);
    for (int i = 0; i < Nxy; i++){
        v[i] = array[i].toDouble();
    }
    return v;
}

void QPlotSubPage3D::updateSeriesZValue() {

    int idx;
    qreal Zmax = ui.ZhiSpin->value();
    qreal Zmin = ui.ZloSpin->value();

    for (int i = 0; i < Ny; i++) {
        QSurfaceDataRow *Row = dataArray->at(i);
        if (Row->count() < Nx) Row->resize(Nx);

        for (int j = 0; j < Nx; j++) {
            idx = i * Nx + j;
            qreal iz = z[idx];
            if (iz > Zmax) iz = Zmax;
            if (iz < Zmin) iz = Zmin;
            (*Row)[j].setPosition(QVector3D(FLOAT(x[idx]), FLOAT(iz), FLOAT(y[idx])));
        }
    }

}

void getRange(const QVector<qreal>& val, double&min, double&max){

    min =  1e100;
    max = -1e100;
    foreach(qreal x, val){
        min = MIN(x, min);
        max = MAX(x, max);
    }
}

PlotSurfDialog::PlotSurfDialog(QWidget *parent)
    : QDialog(parent) {
    ui.setupUi(this);
}

void QPlotSubPage3D::readData(const QString& pfile){

    QJsonObject obj = EAPIO::loadJsonObject(pfile);

    if (QJsonObject() == obj){
        QFile file(pfile);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text)){
            while (!file.atEnd()){
                QString line = file.readLine();
                auto words = line.split(QRegExp("\\s+"), QString::SkipEmptyParts);
                foreach(const QString& word, words){
                     z.append(word.toDouble());
                }
            }
            file.close();

            PlotSurfDialog *Dialog = new PlotSurfDialog(this);

            int NN = INT(sqrt(DOUBLE(z.size())));
            lx = ly = 1.0;
            Nx = Ny = NN;
            Nxy = Nx * Ny;
            Dialog->ui.Nx->setValue(Nx);
            Dialog->ui.Ny->setValue(Ny);
            Dialog->ui.Rx->setValue(lx);
            Dialog->ui.Ry->setValue(ly);

            if (Dialog->exec() == QDialog::Accepted) {
                int nx = Dialog->ui.Nx->value();
                int ny = Dialog->ui.Ny->value();

                if(nx*ny > z.size()){
                    QMessageBox::warning(this, tr("Invalid parameter setting"),
                        tr("The number of input is greater than the number of points in the file"),
                        QMessageBox::Ok, QMessageBox::Ok);
                    nx = ny = NN;
                }
                Nx = nx;
                Ny = ny;
                Nxy = Nx * Ny;
                lx = Dialog->ui.Rx->value();
                ly = Dialog->ui.Ry->value();
            }
            delete Dialog;

            x.resize(Nxy);
            y.resize(Nxy);
            for(int i = 0; i < Ny; i++){
                for(int j = 0; j < Nx; j++){
                    x[i*Nx + j] = lx * j / Nx;
                    y[i*Nx + j] = ly * i / Ny;
                }
            }
        }

    }
    else{
        QVector<int> nx, ny;
        QStringList Major, Minor;
        QJsonObject::const_iterator it, jt;

        for (it = obj.constBegin(); it != obj.constEnd(); it++) {

            QJsonObject iobj = it.value().toObject();

            if (!iobj.contains("size") ||
                !iobj.contains("X")    ||
                !iobj.contains("Y")    ||
                !iobj.contains("lx")   ||
                !iobj.contains("ly") ){
                continue;
            }

            QJsonArray size = iobj["size"].toArray();
            if (size.size() < 2) continue;
            int inx = size[1].toInt();
            int iny = size[0].toInt();
            int inxy = inx * iny;

            for (jt = iobj.constBegin(); jt != iobj.constEnd(); jt++) {
                if (!jt.value().isArray()) {
                    continue;
                }
                if (jt.key() == "X" || jt.key() == "Y") {
                    continue;
                }

                QJsonArray array = jt.value().toArray();
                if(array.size() >= inxy){
                    Major.append(it.key());
                    Minor.append(jt.key());
                    nx.append(inx);
                    ny.append(iny);
                }
            }
        }
        if (!Major.empty()){
            int idx = 0;
            QStringList Keys = Major;
            for(int i = 0; i < Keys.size(); i++){
                Keys[i] = Keys[i] + '/' + Minor[i];
            }

            auto select = EAPIO::selectDialog(tr("Select a drawn surface"), this, Keys);
            if (!select.empty()) idx = select[0];

            Nx = nx[idx];
            Ny = ny[idx];
            Nxy = Nx * Ny;
            QJsonObject sobj = obj[Major[idx]].toObject();

            x = loadValue(sobj["X"].toArray());
            y = loadValue(sobj["Y"].toArray());
            z = loadValue(sobj[Minor[idx]].toArray());

            lx = sobj["lx"].toDouble();
            ly = sobj["ly"].toDouble();
        }
    }


    if (z.size() == 0){
        QMessageBox::warning(this, tr("warning"),
              tr("No valid data in the file"), QMessageBox::Ok, QMessageBox::Ok);

        Nx = Ny = 2;
        x << 0 << 1 << 0 << 1;
        y << 0 << 0 << 1 << 1;
        z << 0 << 0 << 0 << 0;
        lx = 1;
        ly = 1;
    }
}


void QPlotSubPage3D::iniGraph3D() {

    qreal vmin, vmax;    

    graph3D = new Q3DSurface();
    graphContainer = QWidget::createWindowContainer(graph3D, splitter);

    axisX = new QValue3DAxis;
    axisX->setTitle("Axis X");
    graph3D->setAxisX(axisX);

    axisY = new QValue3DAxis;
    axisY->setTitle("Axis Y");
    graph3D->setAxisZ(axisY);

    axisZ = new QValue3DAxis;
    axisZ->setTitle("Axis Z");
    graph3D->setAxisY(axisZ);

    proxy = new QSurfaceDataProxy();
    series = new QSurface3DSeries(proxy);
    series->setItemLabelFormat("(@xLabel @zLabel @yLabel)");
    series->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);

    ui.XloSpin->setValue(0); ui.XhiSpin->setValue(lx);
    ui.YloSpin->setValue(0); ui.YhiSpin->setValue(ly);

    getRange(z, vmin, vmax);
    ui.ZloSpin->setValue(vmin); ui.ZhiSpin->setValue(vmax);
    updateAxisRange();

    graph3D->addSeries(series);

    //	graph3D->axisX()->setLabelAutoRotation(30);
    //	graph3D->removeSeries(m_heightMapSeries);
    //	graph3D->addSeries(m_sqrtSinSeries);
    dataArray = new QSurfaceDataArray();
    dataArray->reserve(Ny);
    for (int i = 0; i < Ny; i++) {
        dataArray->append(new QSurfaceDataRow(Nx));
    }
    updateSeriesZValue();

    proxy->resetArray(dataArray);
    series->setBaseGradient(Gradient[0]);
    series->setColorStyle(Q3DTheme::ColorStyleRangeGradient);
}




