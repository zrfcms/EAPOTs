#pragma once

#include "UiPtr.h"
#include "ui_StructGLPage.h"
#include "ui_DefineTransformationWidget.h"
#include "ui_DefineDisplacementWidget.h"
#include "ui_PeriodicWarpWidget.h"
#include "ui_TriclinicOptimization.h"
#include "ui_FindCrystalSymmetries.h"
#include "ui_AtomTypeModifyWidget.h"
#include <vector>
#include <QSpinBox>

namespace EAPUI_NS {

#define NPTR 4

	struct CMDSTRC
	{
		QString fullname;
		QString shortname;
		void* ptr[NPTR];

		int num;
		int mode;
	};


	class CMD
	{
	public:
		CMD();
		~CMD();

		enum CMDTYPE {
			TDOUBLE, TINT, TSTR
		};

		QVector<CMDSTRC> cmdlist;
		QMap<QString, int> fullmap;
		QMap<QString, int> shortmap;

		void add(const char* pfullname, const char* pshortname,
			double* p0, double* p1 = NULL, double* p2 = NULL, double* p3 = NULL);

		void eval(QString str);
	};


	class ModificationWidget : public QWidget
	{
		Q_OBJECT
	public:
        explicit ModificationWidget(class StructGLPage *parent, QString id);
		~ModificationWidget() {};

		virtual void update(LoadConfig_NS::AtomConfigData* config) = 0;
		
		QString name;
		StructGLPage *page;
		LoadConfig_NS::AtomConfigData* config;
	};


	class StructGLPage : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
		Ui_StructGLPage ui;

		explicit StructGLPage(QWidget *parent, EAPUI* ptr);

		~StructGLPage();
	signals:

	public slots:
		void StrucGLCMD();
		void SelectImportFile();
		void ImportFile(const QString&);
		void ExportFile();
	public:
		void init();
		void updateMod(ModificationWidget*);

	private:
		class CMD* cmd;
		QString OpenFileDir;
        QStringList ModiferName;

	public:
        QTextBrowser *uiTextBrowser;
        QVector<ModificationWidget*> Mod;
        ModificationWidget* ModificationListCreate(int type);
        void ModificationListMove(int);
        void ModificationListCurrentDelete();
        void ModificationListCurrentRowChanged(int idx);
	};


    class AtomTypeItem : public QWidget
    {
        Q_OBJECT
    public:
        explicit AtomTypeItem(QWidget *parent);
        ~AtomTypeItem() {}
        QHBoxLayout* layout;
        QClickLabel* ele;
        QLabel* id, *num;
        QPushButton* modify;
    };

    class AtomTypeModifyWidget : public ModificationWidget
    {
        Q_OBJECT
    public:
        Ui_AtomTypeModifyWidget ui;
        explicit AtomTypeModifyWidget(StructGLPage *parent,
            LoadConfig_NS::AtomConfigData* config, QString id);
        ~AtomTypeModifyWidget() {};

        void update(LoadConfig_NS::AtomConfigData* config);
    public slots:
    };


	class DefineTransformationWidget : public ModificationWidget
	{
		Q_OBJECT
	public:
		Ui_DefineTransformationWidget ui;
		explicit DefineTransformationWidget(StructGLPage *parent,
            LoadConfig_NS::AtomConfigData* config, QString id);
		~DefineTransformationWidget();

		void update(LoadConfig_NS::AtomConfigData* config);

	signals:
	public slots:
	};

	class DefineDisplacementWidget : public ModificationWidget
	{
		Q_OBJECT
	public:
		Ui_DefineDisplacementWidget ui;
		explicit DefineDisplacementWidget(StructGLPage *parent,
            LoadConfig_NS::AtomConfigData* config, QString id);
		~DefineDisplacementWidget();

		void updateRandomValue();
		void updateAtomPosSize();
		void update(LoadConfig_NS::AtomConfigData* config);
	signals:
	public slots:
	};

	class PeriodicWarpWidget : public ModificationWidget
	{
		Q_OBJECT
	public:
		Ui_PeriodicWarpWidget ui;
		explicit PeriodicWarpWidget(StructGLPage *parent,
            LoadConfig_NS::AtomConfigData* config, QString id);
		~PeriodicWarpWidget() {};

		void update(LoadConfig_NS::AtomConfigData* config);
	signals:
	public slots:
	};

	class TriclinicOptimizationWidget : public ModificationWidget
	{
		Q_OBJECT
	public:
		Ui_TriclinicOptimization ui;
		explicit TriclinicOptimizationWidget(StructGLPage *parent,
            LoadConfig_NS::AtomConfigData* config, QString id);
		~TriclinicOptimizationWidget() {};

		void update(LoadConfig_NS::AtomConfigData* config);
	signals:
	public slots:
	};

	class FindCrystalSymmetriesWidget : public ModificationWidget
	{
		Q_OBJECT
	public:
		Ui_FindCrystalSymmetriesWidget ui;
		explicit FindCrystalSymmetriesWidget(StructGLPage *parent,
            LoadConfig_NS::AtomConfigData* config, QString id);
		~FindCrystalSymmetriesWidget() {};

		void update(LoadConfig_NS::AtomConfigData* config);
	signals:
	public slots:
	};

	class ReplicateWidget : public ModificationWidget {
		Q_OBJECT
	public:

		explicit ReplicateWidget(StructGLPage *parent,
            LoadConfig_NS::AtomConfigData* config, QString id);
		~ReplicateWidget() {};

		void update(LoadConfig_NS::AtomConfigData* config);

	public:
		QGridLayout *gridLayout;

		QLabel *Xlabel;
		QLabel *Ylabel;
		QLabel *Zlabel;

		QSpinBox *XspinBox;
		QSpinBox *YspinBox;
		QSpinBox *ZspinBox;

		QLabel *toplabel;
		QLabel *downlabel;

	signals:
	public slots:
	};

}
