#include "EAPlotPage.h"
#include "math.h"
#include "memory.h"
#include "EAPIO.h"
#include <algorithm>

using namespace EAPUI_NS;

static const double MY_PI = 3.14159265358979323846; // pi

static inline bool isone(const double f) {
  return fabs(f-1.0) < 1e-20;
}


bool PlotMEAM::str_to_lat(const char* str, bool single, lattice_t& lat)
{
    if (strcmp(str,"fcc") == 0) lat = FCC;
    else if (strcmp(str,"bcc") == 0) lat = BCC;
    else if (strcmp(str,"hcp") == 0) lat = HCP;
    else if (strcmp(str,"dim") == 0) lat = DIM;
    else if (strcmp(str,"dia") == 0) lat = DIA;
    else if (strcmp(str,"dia3") == 0) lat = DIA3;
    else if (strcmp(str,"lin") == 0) lat = LIN;
    else if (strcmp(str,"zig") == 0) lat = ZIG;
    else if (strcmp(str,"tri") == 0) lat = TRI;
    else {
        if (single)
          return false;

        if (strcmp(str,"b1")  == 0) lat = B1;
        else if (strcmp(str,"c11") == 0) lat = C11;
        else if (strcmp(str,"l12") == 0) lat = L12;
        else if (strcmp(str,"b2")  == 0) lat = B2;
        else if (strcmp(str,"ch4")  == 0) lat = CH4;
        else if (strcmp(str,"lin")  == 0) lat =LIN;
        else if (strcmp(str,"zig")  == 0) lat = ZIG;
        else if (strcmp(str,"tri")  == 0) lat = TRI;
        else return false;
    }
    return true;
}

double femb(double A, double E, double rho) {
    if (rho < 1e-10) return 0;
    return A * E * rho * log(rho);
}

double rho(double rho0, double beta, double re, double r) {
    return rho0 * exp(-beta * (r / re - 1));
}

PlotMEAM::PlotMEAM(QWidget *parent, QString lib, QString meam, EAPUI* ptr)
    : QPlotSubPage2D(parent, ptr)
    , lattce_s{0,}
    , ielt_meam{ 0, }
    , z{ 0, }, atwt{ 0, }

    , alpha_s{ 0, }
    , beta0_meam{0,}, beta1_meam{0,}
    , beta2_meam{0,}, beta3_meam{0,}
    , alat_s{ 0, }, Ec_s{ 0, }, A_meam{ 0, }

    , t0_meam{0,}, t1_meam{0,}
    , t2_meam{0,}, t3_meam{0,}
    , rho0_meam{0,}, ibar_meam{0,}
{
    phir = phirar = phirar1 = phirar2 = phirar3 = phirar4 = phirar5 = phirar6 = NULL;

    neltypes = 0;
    for (int i = 0; i < maxelt; i++) {
        A_meam[i] = rho0_meam[i] = beta0_meam[i] =
            beta1_meam[i] = beta2_meam[i] = beta3_meam[i] =
            t0_meam[i] = t1_meam[i] = t2_meam[i] = t3_meam[i] =
            rho_ref_meam[i] = ibar_meam[i] = ielt_meam[i] = 0.0;
        for (int j = 0; j < maxelt; j++) {
            lattce_meam[i][j] = FCC;
            Ec_meam[i][j] = re_meam[i][j] = alpha_meam[i][j] = delta_meam[i][j] = ebound_meam[i][j] = attrac_meam[i][j] = repuls_meam[i][j] = 0.0;
            nn2_meam[i][j] = zbl_meam[i][j] = eltind[i][j] = 0;
        }
    }


    Np = 100;
    xlim.resize(3);
    ylim.resize(3);
    xlim[0].customhi = 2.0;
    xlim[1].customlo = xlim[2].customlo = 1.5;
    std::vector<double> dump_sample(3, 1.5);

    if (read_data(lib, meam)) return;
    meam_setup_done(&cutmax);
    size_t n = SIZE_T(elts.size());
    size_t n2 = n * n;

    // 2. get cutoff
    double Rhomax = 0, PhiMax = 0, PhiMin = 0, cut = 0;
    for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++) {

        double rho0 = rho0_meam[i], re = re_meam[i][i];
        Rhomax = fmax(Rhomax, rho(rho0, beta0_meam[i], re, dump_sample[1]));
        Rhomax = fmax(Rhomax, rho(rho0, beta1_meam[i], re, dump_sample[1]));
        Rhomax = fmax(Rhomax, rho(rho0, beta2_meam[i], re, dump_sample[1]));
        Rhomax = fmax(Rhomax, rho(rho0, beta3_meam[i], re, dump_sample[1]));

        double phi = phi_meam(dump_sample[2], i, j);
        PhiMax = fmax(PhiMax, phi);
        PhiMin = fmin(PhiMin, phi);
    }

    xlim[0].set(0.0, 2.0).update();
    xlim[1].set(0.0, cutmax).update();
    xlim[2].set(0.0, cutmax).update();

#define PACK(Chart, Label, X, Y) {                          \
    QSplineSeries* series = creatSeries(Chart, Label);      \
    for (int ii = 0; ii <= Np; ii++){                       \
        series->append(X, Y);                               \
    }                                                       \
    getSeriesRange(series, lo, hi);                         \
}

    // 3. pack image data
    qreal lo, hi;
    double pdR = (xlim[0].hi - 0.0) / Np;
    double pdr = (xlim[1].hi - 0.0) / Np;

    QChart *Chart1 = new QChart();
    QChart *Chart2 = new QChart();
    QChart *Chart3 = new QChart();

    addHorizontal(Chart1, 0, -10, xlim[0].hi+10);
    addHorizontal(Chart2, 0, -10, xlim[1].hi+10);
    addHorizontal(Chart3, 0, -10, xlim[1].hi+10);

    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
        QString label = elts[i]+"-"+elts[j];
        PACK(Chart1, elts[i]+elts[j], ii * pdR, femb(A_meam[i], Ec_meam[i][j], ii * pdR));
    }
    ylim[0].set(1.1*fmin(lo, 0), fmax(hi, 0)).update();

    lo = hi = 0;
    for (size_t i = 0; i < n; i++){
        double rho0 = rho0_meam[i], re = re_meam[i][i];
        PACK(Chart2, elts[i]+"-1", ii * pdr, rho(rho0, beta0_meam[i], re, ii * pdr));
        PACK(Chart2, elts[i]+"-2", ii * pdr, rho(rho0, beta1_meam[i], re, ii * pdr));
        PACK(Chart2, elts[i]+"-3", ii * pdr, rho(rho0, beta2_meam[i], re, ii * pdr));
        PACK(Chart2, elts[i]+"-4", ii * pdr, rho(rho0, beta3_meam[i], re, ii * pdr));
    }
    ylim[1].set(fmin(lo, 0), Rhomax).update();

    lo = hi = 0;
    for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
        QString label = elts[i]+"-"+elts[j];
        PACK(Chart3, label, ii * pdr, phi_meam(ii * pdr, i, j));
    }
    ylim[2].set(fmin(PhiMin, 0), fmax(PhiMax, 0)).update();

#undef PACK
    CreateSubWindow(Chart1, "rho", "emb(rho)", xlim[0], ylim[0]);
    CreateSubWindow(Chart2, "r", "rho(r)", xlim[1], ylim[1]);
    CreateSubWindow(Chart3, "r", "phi(r)", xlim[2], ylim[2]);


    mdiArea->tileSubWindows();
}

static QStringList keywords = {
  "Ec","alpha","rho0","delta","lattce",
  "attrac","repuls","nn2","Cmin","Cmax","rc","delr",
  "augt1","gsmooth_factor","re","ialloy",
  "mixture_ref_t","erose_form","zbl",
  "emb_lin_neg","bkgd_dyn", "theta"
};


int PlotMEAM::read_data(QString lib, QString meam){
    QString data;
    QFile file(lib);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)){
        data = file.readAll();
        file.close();
    };
    QStringList lines = data.split('\n');

    // allocate parameter arrays
    int params_per_line = 19;

    lattice_t lat[maxelt];
    // read each set of params from global MEAM file
    // one set of params can span multiple lines
    // store params if element name is in element list
    // if element name appears multiple times, only store 1st entry


    for (int ii = 0; ii < lines.size(); ii++) {

        QString line = lines[ii];
        if(line.contains('#') || line == "") {
            continue;
        }

        line.replace(QRegExp("'"), " ");
        QStringList words = line.split(QRegExp("\\s+"), QString::SkipEmptyParts);

        // concatenate additional lines until have params_per_line words

        while (words.size() < params_per_line) {
            ii++;
            if(ii >= lines.size()) break;
            words.append(lines[ii].split(QRegExp("\\s+"), QString::SkipEmptyParts));
        }

        if (words.size() != params_per_line){
            return io->error(FLERR,"Incorrect format in MEAM potential file");
        }

        // concatenate additional lines until have params_per_line words
        // words = ptrs to all words in line
        // strip single and double quotes from words
        if(!elts.contains(words[0])) {
            elts.append(words[0]);
        } else {
            continue;
        }
        int i = elts.size() - 1;

        // map lat string to an integer

        if (!PlotMEAM::str_to_lat(words[1].toLatin1().data(), true, lat[i]))
            return io->error(FLERR,"Unrecognized lattice type in MEAM file 1");

        // store parameters
        z[i] = words[2].toDouble();
        ielt_meam[i] = words[3].toInt();
        atwt[i] = words[4].toDouble();
        alpha_s[i] = words[5].toDouble();
        beta0_meam[i] = words[6].toDouble();
        beta1_meam[i] = words[7].toDouble();
        beta2_meam[i] = words[8].toDouble();
        beta3_meam[i] = words[9].toDouble();
        alat_s[i] = words[10].toDouble();
        Ec_s[i] = words[11].toDouble();
        A_meam[i] = words[12].toDouble();
        t0_meam[i] = words[13].toDouble();
        t1_meam[i] = words[14].toDouble();
        t2_meam[i] = words[15].toDouble();
        t3_meam[i] = words[16].toDouble();
        rho0_meam[i] = words[17].toDouble();
        ibar_meam[i] = words[18].toDouble();

        if (!isone(t0_meam[i]))
            return io->error(FLERR,"Unsupported parameter in MEAM potential file: t0!=1");

        // z given is ignored: if this is mismatched, we definitely won't do what the user said -> fatal error
        if (z[i] != PlotMEAM::get_Zij(lat[i]))
            return io->error(FLERR,"Mismatched parameter in MEAM potential file: z!=lat");

        if(elts.size() >= maxelt) break;
    }

    // pass element parameters to MEAM package

    meam_setup_global(elts.size(), lat, ielt_meam, atwt, alpha_s,
        beta0_meam, beta1_meam, beta2_meam, beta3_meam, alat_s, Ec_s, A_meam,
        t0_meam, t1_meam, t2_meam, t3_meam, rho0_meam, ibar_meam);

    // done if user param file is NULL
    if (meam == "NULL") return 0;

    QFile mfile(meam);
    if (mfile.open(QIODevice::ReadOnly | QIODevice::Text)){
        data = mfile.readAll();
        mfile.close();
    };
    lines = data.split('\n');

    // read settings
    // pass them one at a time to MEAM package
    // match strings to list of corresponding ints

    int which;
    double value;
    lattice_t latt;
    int nindex,index[3];

    int nparams;
    QStringList params;

    for (int ii = 0; ii < lines.size(); ii++) {
        QString line = lines[ii];
        if(line.contains('#') || line == "") {
            continue;
        }

        // words = ptrs to all words in line
        line.replace(QRegExp("[=(), '\t\n\r\f]"), " ");
        params = line.split(QRegExp("\\s+"), QString::SkipEmptyParts);
        nparams = params.size();

        if (!keywords.contains(params[0])){
            return io->error(FLERR, QString("Keyword %1 in MEAM parameter file not recognized").arg(params[0]));
        }
        which = keywords.indexOf(params[0]);

        nindex = nparams - 2;
        for (int i = 0; i < nindex; i++)
            index[i] = params[i+1].toInt() - 1;

        // map lattce_meam value to an integer

        if (which == 4) {
             if (!PlotMEAM::str_to_lat(params[nparams-1].toLatin1().data(), false, latt))
                 return io->error(FLERR,"Unrecognized lattice type in MEAM file 2");
             value = latt;
        }
        else value = params[nparams-1].toDouble();

        // pass single setting to MEAM package
        int errorflag = 0;
        meam_setup_param(which,value,nindex,index,&errorflag);
        if (errorflag) {
             return io->error(FLERR, QString("MEAM library error %1").arg(errorflag));
        }
    }

    return 0;
}



















inline double square(const double& x) { return x * x; }

inline double cube(const double& x) { return x * x * x; }

static inline bool iszero(const double f) {
    return fabs(f) < 1e-20;
}


template <typename TYPE, int maxi, int maxj>
static inline void setall2d(TYPE(&arr)[maxi][maxj], const TYPE v) {
    for (int i = 0; i < maxi; i++)
        for (int j = 0; j < maxj; j++)
            arr[i][j] = v;
}

template <typename TYPE, int maxi, int maxj, int maxk>
static inline void setall3d(TYPE(&arr)[maxi][maxj][maxk], const TYPE v) {
    for (int i = 0; i < maxi; i++)
        for (int j = 0; j < maxj; j++)
            for (int k = 0; k < maxk; k++)
                arr[i][j][k] = v;
}

void PlotMEAM::meam_setup_global(int nelt, lattice_t* lat, int* ielement, double* /*atwt*/, double* alpha,
    double* b0, double* b1, double* b2, double* b3, double* alat, double* esub,	double* asub,
    double* t0, double* t1, double* t2, double* t3, double* rozero,	int* ibar)
{

    int i;
    double tmplat[maxelt];

    this->neltypes = nelt;

    for (i = 0; i < nelt; i++) {
        this->lattce_meam[i][i] = lat[i];

        this->ielt_meam[i] = ielement[i];
        this->alpha_meam[i][i] = alpha[i];
        this->beta0_meam[i] = b0[i];
        this->beta1_meam[i] = b1[i];
        this->beta2_meam[i] = b2[i];
        this->beta3_meam[i] = b3[i];
        tmplat[i] = alat[i];
        this->Ec_meam[i][i] = esub[i];
        this->A_meam[i] = asub[i];
        this->t0_meam[i] = t0[i];
        this->t1_meam[i] = t1[i];
        this->t2_meam[i] = t2[i];
        this->t3_meam[i] = t3[i];
        this->rho0_meam[i] = rozero[i];
        this->ibar_meam[i] = ibar[i];

        switch (this->lattce_meam[i][i]) {
        case FCC:
            this->re_meam[i][i] = tmplat[i] / sqrt(2.0);
            break;
        case BCC:
            this->re_meam[i][i] = tmplat[i] * sqrt(3.0) / 2.0;
            break;
        case HCP:
        case DIM:
        case CH4:
        case LIN:
        case ZIG:
        case TRI:
            this->re_meam[i][i] = tmplat[i];
            break;
        case DIA:
        case DIA3:
            this->re_meam[i][i] = tmplat[i] * sqrt(3.0) / 4.0;
            break;
            //default:
            //           error
        }
    }

    // Set some defaults
    this->rc_meam = 4.0;
    this->delr_meam = 0.1;
    setall2d(this->attrac_meam, 0.0);
    setall2d(this->repuls_meam, 0.0);
    setall3d(this->Cmax_meam, 2.8);
    setall3d(this->Cmin_meam, 2.0);
    setall2d(this->ebound_meam, (2.8 * 2.8) / (4.0 * (2.8 - 1.0)));
    setall2d(this->delta_meam, 0.0);
    setall2d(this->nn2_meam, 0);
    setall2d(this->zbl_meam, 1);
    this->gsmooth_factor = 99.0;
    this->augt1 = 1;
    this->ialloy = 0;
    this->mix_ref_t = 0;
    this->emb_lin_neg = 0;
    this->bkgd_dyn = 0;
    this->erose_form = 0;
    // for trimer, zigzag, line refernece structure, sungkwang
    setall2d(this->stheta_meam, 1.0); // stheta = sin(theta/2*pi/180) where theta is 180, so 1.0
    setall2d(this->ctheta_meam, 0.0); // stheta = cos(theta/2*pi/180) where theta is 180, so 0
}


void PlotMEAM::meam_checkindex(int num, int lim, int nidx, int* idx /*idx(3)*/, int* ierr)
{
    //: idx[0..2]
    *ierr = 0;
    if (nidx < num) {
        *ierr = 2;
        return;
    }

    for (int i = 0; i < num; i++) {
        if ((idx[i] < 0) || (idx[i] >= lim)) {
            *ierr = 3;
            return;
        }
    }
}

//     The "which" argument corresponds to the index of the "keyword" array
//     in pair_meam.cpp:
//
//     0 = Ec_meam
//     1 = alpha_meam
//     2 = rho0_meam
//     3 = delta_meam
//     4 = lattce_meam
//     5 = attrac_meam
//     6 = repuls_meam
//     7 = nn2_meam
//     8 = Cmin_meam
//     9 = Cmax_meam
//     10 = rc_meam
//     11 = delr_meam
//     12 = augt1
//     13 = gsmooth_factor
//     14 = re_meam
//     15 = ialloy
//     16 = mixture_ref_t
//     17 = erose_form
//     18 = zbl_meam
//     19 = emb_lin_neg
//     20 = bkgd_dyn
//     21 = theta


void PlotMEAM::meam_setup_param(int which, double value, int nindex, int* index /*index(3)*/, int* errorflag)
{
    //: index[0..2]
    int i1, i2;
    lattice_t vlat;
    *errorflag = 0;

    switch (which) {
        //     0 = Ec_meam
    case 0:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->Ec_meam[index[0]][index[1]] = value;
        break;

        //     1 = alpha_meam
    case 1:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->alpha_meam[index[0]][index[1]] = value;
        break;

        //     2 = rho0_meam
    case 2:
        meam_checkindex(1, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->rho0_meam[index[0]] = value;
        break;

        //     3 = delta_meam
    case 3:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->delta_meam[index[0]][index[1]] = value;
        break;

        //     4 = lattce_meam
    case 4:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        vlat = (lattice_t)(int)value;

        this->lattce_meam[index[0]][index[1]] = vlat;
        break;

        //     5 = attrac_meam
    case 5:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->attrac_meam[index[0]][index[1]] = value;
        break;

        //     6 = repuls_meam
    case 6:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->repuls_meam[index[0]][index[1]] = value;
        break;

        //     7 = nn2_meam
    case 7:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        i1 = std::min(index[0], index[1]);
        i2 = std::max(index[0], index[1]);
        this->nn2_meam[i1][i2] = (int)value;
        break;

        //     8 = Cmin_meam
    case 8:
        meam_checkindex(3, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->Cmin_meam[index[0]][index[1]][index[2]] = value;
        break;

        //     9 = Cmax_meam
    case 9:
        meam_checkindex(3, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->Cmax_meam[index[0]][index[1]][index[2]] = value;
        break;

        //     10 = rc_meam
    case 10:
        this->rc_meam = value;
        break;

        //     11 = delr_meam
    case 11:
        this->delr_meam = value;
        break;

        //     12 = augt1
    case 12:
        this->augt1 = (int)value;
        break;

        //     13 = gsmooth
    case 13:
        this->gsmooth_factor = value;
        break;

        //     14 = re_meam
    case 14:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        this->re_meam[index[0]][index[1]] = value;
        break;

        //     15 = ialloy
    case 15:
        this->ialloy = (int)value;
        break;

        //     16 = mixture_ref_t
    case 16:
        this->mix_ref_t = (int)value;
        break;

        //     17 = erose_form
    case 17:
        this->erose_form = (int)value;
        break;

        //     18 = zbl_meam
    case 18:
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        i1 = MIN(index[0], index[1]);
        i2 = MAX(index[0], index[1]);
        this->zbl_meam[i1][i2] = (int)value;
        break;

        //     19 = emb_lin_neg
    case 19:
        this->emb_lin_neg = (int)value;
        break;

        //     20 = bkgd_dyn
    case 20:
        this->bkgd_dyn = (int)value;
        break;

        //     21 = theta
        // see alloyparams(void) in meam_setup_done.cpp
    case 21:
        // const double PI = 3.141592653589793238463;
        meam_checkindex(2, neltypes, nindex, index, errorflag);
        if (*errorflag != 0)
            return;
        i1 = MIN(index[0], index[1]);
        i2 = MAX(index[0], index[1]);
        // we don't use theta, instead stheta and ctheta
        this->stheta_meam[i1][i2] = sin(value / 2 * MY_PI / 180.0);
        this->ctheta_meam[i1][i2] = cos(value / 2 * MY_PI / 180.0);
        break;

    default:
        *errorflag = 1;
    }
}

void PlotMEAM::meam_setup_done(double* cutmax)
{
    int nv2, nv3, m, n, p;

    //     Force cutoff
    this->cutforce = this->rc_meam;
    this->cutforcesq = this->cutforce * this->cutforce;

    //     Pass cutoff back to calling program
    *cutmax = this->cutforce;

    //     Augment t1 term
    for (int i = 0; i < maxelt; i++)
        this->t1_meam[i] = this->t1_meam[i] + this->augt1 * 3.0 / 5.0 * this->t3_meam[i];

    //     Compute off-diagonal alloy parameters
    alloyparams();

    // indices and factors for Voight notation
    nv2 = 0;
    nv3 = 0;
    for (m = 0; m < 3; m++) {
        for (n = m; n < 3; n++) {
            this->vind2D[m][n] = nv2;
            this->vind2D[n][m] = nv2;
            nv2 = nv2 + 1;
            for (p = n; p < 3; p++) {
                this->vind3D[m][n][p] = nv3;
                this->vind3D[m][p][n] = nv3;
                this->vind3D[n][m][p] = nv3;
                this->vind3D[n][p][m] = nv3;
                this->vind3D[p][m][n] = nv3;
                this->vind3D[p][n][m] = nv3;
                nv3 = nv3 + 1;
            }
        }
    }

    this->v2D[0] = 1;
    this->v2D[1] = 2;
    this->v2D[2] = 2;
    this->v2D[3] = 1;
    this->v2D[4] = 2;
    this->v2D[5] = 1;

    this->v3D[0] = 1;
    this->v3D[1] = 3;
    this->v3D[2] = 3;
    this->v3D[3] = 3;
    this->v3D[4] = 6;
    this->v3D[5] = 3;
    this->v3D[6] = 1;
    this->v3D[7] = 3;
    this->v3D[8] = 3;
    this->v3D[9] = 1;

    nv2 = 0;
    for (m = 0; m < this->neltypes; m++) {
        for (n = m; n < this->neltypes; n++) {
            this->eltind[m][n] = nv2;
            this->eltind[n][m] = nv2;
            nv2 = nv2 + 1;
        }
    }

    //     Compute background densities for reference structure
    compute_reference_density();

    //     Compute pair potentials and setup arrays for interpolation
    this->nr = 1000;
    this->dr = 1.1 * this->rc_meam / this->nr;
    compute_pair_meam();
}

// ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
// Fill off-diagonal alloy parameters
void PlotMEAM::alloyparams(void)
{

    int i, j, k;
    double eb;

    // Loop over pairs
    for (i = 0; i < this->neltypes; i++) {
        for (j = 0; j < this->neltypes; j++) {
            // Treat off-diagonal pairs
            // If i>j, set all equal to i<j case (which has aready been set,
            // here or in the input file)
            if (i > j) {
                this->re_meam[i][j] = this->re_meam[j][i];
                this->Ec_meam[i][j] = this->Ec_meam[j][i];
                this->alpha_meam[i][j] = this->alpha_meam[j][i];
                this->lattce_meam[i][j] = this->lattce_meam[j][i];
                this->nn2_meam[i][j] = this->nn2_meam[j][i];
                // theta for lin,tri,zig references
                this->stheta_meam[i][j] = this->stheta_meam[j][i];
                this->ctheta_meam[i][j] = this->ctheta_meam[j][i];
                // If i<j and term is unset, use default values (e.g. mean of i-i and
                // j-j)
            }
            else if (j > i) {
                if (iszero(this->Ec_meam[i][j])) {
                    if (this->lattce_meam[i][j] == L12)
                        this->Ec_meam[i][j] =
                        (3 * this->Ec_meam[i][i] + this->Ec_meam[j][j]) / 4.0 - this->delta_meam[i][j];
                    else if (this->lattce_meam[i][j] == C11) {
                        if (this->lattce_meam[i][i] == DIA)
                            this->Ec_meam[i][j] =
                            (2 * this->Ec_meam[i][i] + this->Ec_meam[j][j]) / 3.0 - this->delta_meam[i][j];
                        else
                            this->Ec_meam[i][j] =
                            (this->Ec_meam[i][i] + 2 * this->Ec_meam[j][j]) / 3.0 - this->delta_meam[i][j];
                    }
                    else
                        this->Ec_meam[i][j] = (this->Ec_meam[i][i] + this->Ec_meam[j][j]) / 2.0 - this->delta_meam[i][j];
                }
                if (iszero(this->alpha_meam[i][j]))
                    this->alpha_meam[i][j] = (this->alpha_meam[i][i] + this->alpha_meam[j][j]) / 2.0;
                if (iszero(this->re_meam[i][j]))
                    this->re_meam[i][j] = (this->re_meam[i][i] + this->re_meam[j][j]) / 2.0;
            }
        }
    }

    // Cmin[i][k][j] is symmetric in i-j, but not k.  For all triplets
    // where i>j, set equal to the i<j element.  Likewise for Cmax.
    for (i = 1; i < this->neltypes; i++) {
        for (j = 0; j < i; j++) {
            for (k = 0; k < this->neltypes; k++) {
                this->Cmin_meam[i][j][k] = this->Cmin_meam[j][i][k];
                this->Cmax_meam[i][j][k] = this->Cmax_meam[j][i][k];
            }
        }
    }

    // ebound gives the squared distance such that, for rik2 or rjk2>ebound,
    // atom k definitely lies outside the screening function ellipse (so
    // there is no need to calculate its effects).  Here, compute it for all
    // triplets [i][j][k] so that ebound[i][j] is the maximized over k
    for (i = 0; i < this->neltypes; i++) {
        for (j = 0; j < this->neltypes; j++) {
            for (k = 0; k < this->neltypes; k++) {
                eb = (this->Cmax_meam[i][j][k] * this->Cmax_meam[i][j][k]) / (4.0 * (this->Cmax_meam[i][j][k] - 1.0));
                this->ebound_meam[i][j] = std::max(this->ebound_meam[i][j], eb);
            }
        }
    }
}







//----------------------------------------------------------------------c
// Compute background density for reference structure of each element
void PlotMEAM::compute_reference_density(void)
{
    int a, Z, Z2, errorflag;
    double gam, Gbar, shp[3];
    double rho0, rho0_2nn, arat, scrn;

    // loop over element types
    for (a = 0; a < this->neltypes; a++) {
        Z = get_Zij(this->lattce_meam[a][a]);
        if (this->ibar_meam[a] <= 0)
            Gbar = 1.0;
        else {
            get_shpfcn(this->lattce_meam[a][a], this->stheta_meam[a][a], this->ctheta_meam[a][a], shp);
            gam = (this->t1_meam[a] * shp[0] + this->t2_meam[a] * shp[1] + this->t3_meam[a] * shp[2]) / (Z * Z);
            Gbar = G_gam(gam, this->ibar_meam[a], errorflag);
        }

        //     The zeroth order density in the reference structure, with
        //     equilibrium spacing, is just the number of first neighbors times
        //     the rho0_meam coefficient...
        rho0 = this->rho0_meam[a] * Z;

        //     ...unless we have unscreened second neighbors, in which case we
        //     add on the contribution from those (accounting for partial
        //     screening)
        if (this->nn2_meam[a][a] == 1) {
            Z2 = get_Zij2(this->lattce_meam[a][a], this->Cmin_meam[a][a][a],
                this->Cmax_meam[a][a][a], this->stheta_meam[a][a], arat, scrn);
            rho0_2nn = this->rho0_meam[a] * exp(-this->beta0_meam[a] * (arat - 1));
            rho0 = rho0 + Z2 * rho0_2nn * scrn;
        }

        this->rho_ref_meam[a] = rho0 * Gbar;
    }
}

void PlotMEAM::compute_pair_meam(void)
{

    double r, b2nn, phi_val;
    int j, a, b, nv2;
    double astar, frac, phizbl;
    int n, Z1, Z2;
    double arat, rarat, scrn, scrn2;
    double phiaa, phibb /*unused:,phitmp*/;
    double C, s111, s112, s221, S11, S22;

    // check for previously allocated arrays and free them
    if (this->phir != NULL)
        MatMemory::destroy(this->phir);
    if (this->phirar != NULL)
        MatMemory::destroy(this->phirar);
    if (this->phirar1 != NULL)
        MatMemory::destroy(this->phirar1);
    if (this->phirar2 != NULL)
        MatMemory::destroy(this->phirar2);
    if (this->phirar3 != NULL)
        MatMemory::destroy(this->phirar3);
    if (this->phirar4 != NULL)
        MatMemory::destroy(this->phirar4);
    if (this->phirar5 != NULL)
        MatMemory::destroy(this->phirar5);
    if (this->phirar6 != NULL)
        MatMemory::destroy(this->phirar6);

    // allocate memory for array that defines the potential
    MatMemory::create(this->phir, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phir");

    // allocate coeff memory

    MatMemory::create(this->phirar, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phirar");
    MatMemory::create(this->phirar1, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phirar1");
    MatMemory::create(this->phirar2, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phirar2");
    MatMemory::create(this->phirar3, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phirar3");
    MatMemory::create(this->phirar4, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phirar4");
    MatMemory::create(this->phirar5, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phirar5");
    MatMemory::create(this->phirar6, (this->neltypes * (this->neltypes + 1)) / 2, this->nr, "pair:phirar6");

    // loop over pairs of element types
    nv2 = 0;
    for (a = 0; a < this->neltypes; a++) {
        for (b = a; b < this->neltypes; b++) {
            // loop over r values and compute
            for (j = 0; j < this->nr; j++) {
                r = j * this->dr;

                this->phir[nv2][j] = phi_meam(r, a, b);

                // if using second-nearest neighbor, solve recursive problem
                // (see Lee and Baskes, PRB 62(13):8564 eqn.(21))
                if (this->nn2_meam[a][b] == 1) {
                    Z1 = get_Zij(this->lattce_meam[a][b]);
                    Z2 = get_Zij2(this->lattce_meam[a][b], this->Cmin_meam[a][a][b],
                        this->Cmax_meam[a][a][b], this->stheta_meam[a][b], arat, scrn);

                    //     The B1, B2,  and L12 cases with NN2 have a trick to them; we need to
                    //     compute the contributions from second nearest neighbors, like a-a
                    //     pairs, but need to include NN2 contributions to those pairs as
                    //     well.
                    if (this->lattce_meam[a][b] == B1 || this->lattce_meam[a][b] == B2 ||
                        this->lattce_meam[a][b] == L12 || this->lattce_meam[a][b] == DIA) {
                        rarat = r * arat;

                        //               phi_aa
                        phiaa = phi_meam(rarat, a, a);
                        Z1 = get_Zij(this->lattce_meam[a][a]);
                        Z2 = get_Zij2(this->lattce_meam[a][a], this->Cmin_meam[a][a][a],
                            this->Cmax_meam[a][a][a], this->stheta_meam[a][a], arat, scrn);
                        phiaa += phi_meam_series(scrn, Z1, Z2, a, a, rarat, arat);

                        //               phi_bb
                        phibb = phi_meam(rarat, b, b);
                        Z1 = get_Zij(this->lattce_meam[b][b]);
                        Z2 = get_Zij2(this->lattce_meam[b][b], this->Cmin_meam[b][b][b],
                            this->Cmax_meam[b][b][b], this->stheta_meam[b][b], arat, scrn);
                        phibb += phi_meam_series(scrn, Z1, Z2, b, b, rarat, arat);

                        if (this->lattce_meam[a][b] == B1 || this->lattce_meam[a][b] == B2 ||
                            this->lattce_meam[a][b] == DIA) {
                            //     Add contributions to the B1 or B2 potential
                            Z1 = get_Zij(this->lattce_meam[a][b]);
                            Z2 = get_Zij2(this->lattce_meam[a][b], this->Cmin_meam[a][a][b],
                                this->Cmax_meam[a][a][b], this->stheta_meam[a][b], arat, scrn);
                            this->phir[nv2][j] = this->phir[nv2][j] - Z2 * scrn / (2 * Z1) * phiaa;
                            Z2 = get_Zij2(this->lattce_meam[a][b], this->Cmin_meam[b][b][a],
                                this->Cmax_meam[b][b][a], this->stheta_meam[a][b], arat, scrn2);

                            this->phir[nv2][j] = this->phir[nv2][j] - Z2 * scrn2 / (2 * Z1) * phibb;

                        }
                        else if (this->lattce_meam[a][b] == L12) {
                            //     The L12 case has one last trick; we have to be careful to
                            //     compute
                            //     the correct screening between 2nd-neighbor pairs.  1-1
                            //     second-neighbor pairs are screened by 2 type 1 atoms and
                            //     two type
                            //     2 atoms.  2-2 second-neighbor pairs are screened by 4 type
                            //     1
                            //     atoms.
                            C = 1.0;
                            get_sijk(C, a, a, a, &s111);
                            get_sijk(C, a, a, b, &s112);
                            get_sijk(C, b, b, a, &s221);
                            S11 = s111 * s111 * s112 * s112;
                            S22 = pow(s221, 4);
                            this->phir[nv2][j] = this->phir[nv2][j] - 0.75 * S11 * phiaa - 0.25 * S22 * phibb;
                        }

                    }
                    else {
                        this->phir[nv2][j] += phi_meam_series(scrn, Z1, Z2, a, b, r, arat);
                    }
                }

                // For Zbl potential:
                // if astar <= -3
                //   potential is zbl potential
                // else if -3 < astar < -1
                //   potential is linear combination with zbl potential
                // endif
                if (this->zbl_meam[a][b] == 1) {
                    astar = this->alpha_meam[a][b] * (r / this->re_meam[a][b] - 1.0);
                    if (astar <= -3.0)
                        this->phir[nv2][j] = zbl(r, this->ielt_meam[a], this->ielt_meam[b]);
                    else if (astar > -3.0 && astar < -1.0) {
                        frac = fcut(1 - (astar + 1.0) / (-3.0 + 1.0));
                        phizbl = zbl(r, this->ielt_meam[a], this->ielt_meam[b]);
                        this->phir[nv2][j] = frac * this->phir[nv2][j] + (1 - frac) * phizbl;
                    }
                }
            }

            // call interpolation
            interpolate_meam(nv2);

            nv2 = nv2 + 1;
        }
    }
}



double PlotMEAM::fcut(const double xi) {
    double a;
    if (xi >= 1.0)
        return 1.0;
    else if (xi <= 0.0)
        return 0.0;
    else {
        // ( 1.d0 - (1.d0 - xi)**4 )**2, but with better codegen
        a = 1.0 - xi;
        a *= a; a *= a;
        a = 1.0 - a;
        return a * a;
    }
}

double PlotMEAM::erose(const double r, const double re, const double alpha, const double Ec, const double repuls,
    const double attrac, const int form)
{
    double astar, a3;
    double result = 0.0;

    if (r > 0.0) {
        astar = alpha * (r / re - 1.0);
        a3 = 0.0;
        if (astar >= 0)
            a3 = attrac;
        else if (astar < 0)
            a3 = repuls;

        if (form == 1)
            result = -Ec * (1 + astar + (-attrac + repuls / r) * cube(astar)) * exp(-astar);
        else if (form == 2)
            result = -Ec * (1 + astar + a3 * cube(astar)) * exp(-astar);
        else
            result = -Ec * (1 + astar + a3 * cube(astar) / (r / re)) * exp(-astar);
    }
    return result;
}

double PlotMEAM::embedding(const double A, const double Ec, const double rhobar, double& dF) const
{
    const double AEc = A * Ec;

    if (rhobar > 0.0) {
        const double lrb = log(rhobar);
        dF = AEc * (1.0 + lrb);
        return AEc * rhobar * lrb;
    }
    else {
        if (this->emb_lin_neg == 0) {
            dF = 0.0;
            return 0.0;
        }
        else {
            dF = -AEc;
            return -AEc * rhobar;
        }
    }
}
void PlotMEAM::get_sijk(double C, int i, int j, int k, double* sijk)
{
    double x;
    x = (C - this->Cmin_meam[i][j][k]) / (this->Cmax_meam[i][j][k] - this->Cmin_meam[i][j][k]);
    *sijk = fcut(x);
}


//-----------------------------------------------------------------------------
// Compute ZBL potential
//
double PlotMEAM::zbl(const double r, const int z1, const int z2)
{
    int i;
    const double c[] = { 0.028171, 0.28022, 0.50986, 0.18175 };
    const double d[] = { 0.20162, 0.40290, 0.94229, 3.1998 };
    const double azero = 0.4685;
    const double cc = 14.3997;
    double a, x;
    // azero = (9pi^2/128)^1/3 (0.529) Angstroms
    a = azero / (pow(z1, 0.23) + pow(z2, 0.23));
    double result = 0.0;
    x = r / a;
    for (i = 0; i <= 3; i++) {
        result = result + c[i] * exp(-d[i] * x);
    }
    if (r > 0.0)
        result = result * z1 * z2 / r * cc;
    return result;
}

//-----------------------------------------------------------------------------
// Compute G(gamma) based on selection flag ibar:
//   0 => G = sqrt(1+gamma)
//   1 => G = exp(gamma/2)
//   2 => not implemented
//   3 => G = 2/(1+exp(-gamma))
//   4 => G = sqrt(1+gamma)
//  -5 => G = +-sqrt(abs(1+gamma))
//
double PlotMEAM::G_gam(const double gamma, const int ibar, int& errorflag) const
{
    double gsmooth_switchpoint;

    switch (ibar) {
    case 0:
    case 4:
        gsmooth_switchpoint = -gsmooth_factor / (gsmooth_factor + 1);
        if (gamma < gsmooth_switchpoint) {
            //         e.g. gsmooth_factor is 99, {:
            //         gsmooth_switchpoint = -0.99
            //         G = 0.01*(-0.99/gamma)**99
            double G = 1 / (gsmooth_factor + 1) * pow((gsmooth_switchpoint / gamma), gsmooth_factor);
            return sqrt(G);
        }
        else {
            return sqrt(1.0 + gamma);
        }
    case 1:
        return exp(gamma / 2.0);
    case 3:
        return 2.0 / (1.0 + exp(-gamma));
    case -5:
        if ((1.0 + gamma) >= 0) {
            return sqrt(1.0 + gamma);
        }
        else {
            return -sqrt(-1.0 - gamma);
        }
    }
    errorflag = 1;
    return 0.0;
}

const double PlotMEAM::phi_meam_series(const double scrn, const int Z1, const int Z2, const int a, const int b, const double r, const double arat)
{
    double phi_sum = 0.0;
    double b2nn, phi_val;
    if (scrn > 0.0) {
        b2nn = -Z2 * scrn / Z1;
        for (int n = 1; n <= 10; n++) {
            phi_val = pow(b2nn, n) * phi_meam(r * pow(arat, n), a, b);
            if (iszero(phi_val)) {
                // once either term becomes zero at some point, all folliwng will also be zero
                // necessary to avoid numerical error (nan or infty) due to exponential decay in phi_meam
                break;
            }
            phi_sum += phi_val;
        }
    }
    return phi_sum;
}

//------------------------------------------------------------------------------c
// Calculate density functions, assuming reference configuration
void PlotMEAM::get_densref(double r, int a, int b, double* rho01, double* rho11, double* rho21, double* rho31,
    double* rho02, double* rho12, double* rho22, double* rho32)
{
    double a1, a2;
    double s[3];
    lattice_t lat;
    int Zij, Zij2nn;
    double rhoa01nn, rhoa02nn;
    double rhoa01, rhoa11, rhoa21, rhoa31;
    double rhoa02, rhoa12, rhoa22, rhoa32;
    double arat, scrn, denom;
    double C, s111, s112, s221, S11, S22;

    a1 = r / this->re_meam[a][a] - 1.0;
    a2 = r / this->re_meam[b][b] - 1.0;

    rhoa01 = this->rho0_meam[a] * exp(-this->beta0_meam[a] * a1);
    rhoa11 = this->rho0_meam[a] * exp(-this->beta1_meam[a] * a1);
    rhoa21 = this->rho0_meam[a] * exp(-this->beta2_meam[a] * a1);
    rhoa31 = this->rho0_meam[a] * exp(-this->beta3_meam[a] * a1);
    rhoa02 = this->rho0_meam[b] * exp(-this->beta0_meam[b] * a2);
    rhoa12 = this->rho0_meam[b] * exp(-this->beta1_meam[b] * a2);
    rhoa22 = this->rho0_meam[b] * exp(-this->beta2_meam[b] * a2);
    rhoa32 = this->rho0_meam[b] * exp(-this->beta3_meam[b] * a2);

    lat = this->lattce_meam[a][b];

    Zij = get_Zij(lat);

    *rho11 = 0.0;
    *rho21 = 0.0;
    *rho31 = 0.0;
    *rho12 = 0.0;
    *rho22 = 0.0;
    *rho32 = 0.0;

    switch (lat) {
    case FCC:
        *rho01 = 12.0 * rhoa02;
        *rho02 = 12.0 * rhoa01;
        break;
    case BCC:
        *rho01 = 8.0 * rhoa02;
        *rho02 = 8.0 * rhoa01;
        break;
    case B1:
        *rho01 = 6.0 * rhoa02;
        *rho02 = 6.0 * rhoa01;
        break;
    case DIA:
    case DIA3:
        *rho01 = 4.0 * rhoa02;
        *rho02 = 4.0 * rhoa01;
        *rho31 = 32.0 / 9.0 * rhoa32 * rhoa32;
        *rho32 = 32.0 / 9.0 * rhoa31 * rhoa31;
        break;
    case HCP:
        *rho01 = 12 * rhoa02;
        *rho02 = 12 * rhoa01;
        *rho31 = 1.0 / 3.0 * rhoa32 * rhoa32;
        *rho32 = 1.0 / 3.0 * rhoa31 * rhoa31;
        break;
    case DIM:
        get_shpfcn(DIM, 0, 0, s);
        *rho01 = rhoa02;
        *rho02 = rhoa01;
        *rho11 = s[0] * rhoa12 * rhoa12;
        *rho12 = s[0] * rhoa11 * rhoa11;
        *rho21 = s[1] * rhoa22 * rhoa22;
        *rho22 = s[1] * rhoa21 * rhoa21;
        *rho31 = s[2] * rhoa32 * rhoa32;
        *rho32 = s[2] * rhoa31 * rhoa31;
        break;
    case C11:
        *rho01 = rhoa01;
        *rho02 = rhoa02;
        *rho11 = rhoa11;
        *rho12 = rhoa12;
        *rho21 = rhoa21;
        *rho22 = rhoa22;
        *rho31 = rhoa31;
        *rho32 = rhoa32;
        break;
    case L12:
        *rho01 = 8 * rhoa01 + 4 * rhoa02;
        *rho02 = 12 * rhoa01;
        if (this->ialloy == 1) {
            *rho21 = 8. / 3. * square(rhoa21 * this->t2_meam[a] - rhoa22 * this->t2_meam[b]);
            denom = 8 * rhoa01 * square(this->t2_meam[a]) + 4 * rhoa02 * square(this->t2_meam[b]);
            if (denom > 0.)
                *rho21 = *rho21 / denom * *rho01;
        }
        else
            *rho21 = 8. / 3. * (rhoa21 - rhoa22) * (rhoa21 - rhoa22);
        break;
    case B2:
        *rho01 = 8.0 * rhoa02;
        *rho02 = 8.0 * rhoa01;
        break;
    case CH4:
        *rho01 = 4.0 * rhoa02; //in assumption that 'a' represent carbon
        *rho02 = rhoa01;       //in assumption that 'b' represent hydrogen

        get_shpfcn(DIM, 0, 0, s); //H
        *rho12 = s[0] * rhoa11 * rhoa11;
        *rho22 = s[1] * rhoa21 * rhoa21;
        *rho32 = s[2] * rhoa31 * rhoa31;

        get_shpfcn(CH4, 0, 0, s); //C
        *rho11 = s[0] * rhoa12 * rhoa12;
        *rho21 = s[1] * rhoa22 * rhoa22;
        *rho31 = s[2] * rhoa32 * rhoa32;
        break;
    case LIN:
        *rho01 = rhoa02 * Zij;
        *rho02 = rhoa01 * Zij;

        get_shpfcn(LIN, this->stheta_meam[a][b], this->ctheta_meam[a][b], s);
        *rho12 = s[0] * rhoa11 * rhoa11;
        *rho22 = s[1] * rhoa21 * rhoa21;
        *rho32 = s[2] * rhoa31 * rhoa31;
        *rho11 = s[0] * rhoa12 * rhoa12;
        *rho21 = s[1] * rhoa22 * rhoa22;
        *rho31 = s[2] * rhoa32 * rhoa32;
        break;
    case ZIG:
        *rho01 = rhoa02 * Zij;
        *rho02 = rhoa01 * Zij;

        get_shpfcn(ZIG, this->stheta_meam[a][b], this->ctheta_meam[a][b], s);
        *rho12 = s[0] * rhoa11 * rhoa11;
        *rho22 = s[1] * rhoa21 * rhoa21;
        *rho32 = s[2] * rhoa31 * rhoa31;
        *rho11 = s[0] * rhoa12 * rhoa12;
        *rho21 = s[1] * rhoa22 * rhoa22;
        *rho31 = s[2] * rhoa32 * rhoa32;
        break;
    case TRI:
        *rho01 = rhoa02;
        *rho02 = rhoa01 * Zij;

        get_shpfcn(TRI, this->stheta_meam[a][b], this->ctheta_meam[a][b], s);
        *rho12 = s[0] * rhoa11 * rhoa11;
        *rho22 = s[1] * rhoa21 * rhoa21;
        *rho32 = s[2] * rhoa31 * rhoa31;
        s[0] = 1.0;
        s[1] = 2.0 / 3.0;
        s[2] = 1.0 - 0.6 * s[0];

        *rho11 = s[0] * rhoa12 * rhoa12;
        *rho21 = s[1] * rhoa22 * rhoa22;
        *rho31 = s[2] * rhoa32 * rhoa32;
        break;


        // default:
        //        call error('Lattice not defined in get_densref.')
    }

    if (this->nn2_meam[a][b] == 1) {


        Zij2nn = get_Zij2(lat, this->Cmin_meam[a][a][b], this->Cmax_meam[a][a][b],
            this->stheta_meam[a][b], arat, scrn);

        a1 = arat * r / this->re_meam[a][a] - 1.0;
        a2 = arat * r / this->re_meam[b][b] - 1.0;

        rhoa01nn = this->rho0_meam[a] * exp(-this->beta0_meam[a] * a1);
        rhoa02nn = this->rho0_meam[b] * exp(-this->beta0_meam[b] * a2);

        if (lat == L12) {
            //     As usual, L12 thinks it's special; we need to be careful computing
            //     the screening functions
            C = 1.0;
            get_sijk(C, a, a, a, &s111);
            get_sijk(C, a, a, b, &s112);
            get_sijk(C, b, b, a, &s221);
            S11 = s111 * s111 * s112 * s112;
            S22 = s221 * s221 * s221 * s221;
            *rho01 = *rho01 + 6 * S11 * rhoa01nn;
            *rho02 = *rho02 + 6 * S22 * rhoa02nn;

        }
        else {
            //     For other cases, assume that second neighbor is of same type,
            //     first neighbor may be of different type

            *rho01 = *rho01 + Zij2nn * scrn * rhoa01nn;

            //     Assume Zij2nn and arat don't depend on order, but scrn might
            Zij2nn = get_Zij2(lat, this->Cmin_meam[b][b][a], this->Cmax_meam[b][b][a],
                this->stheta_meam[a][b], arat, scrn);
            *rho02 = *rho02 + Zij2nn * scrn * rhoa02nn;
        }
    }
}



void PlotMEAM::get_tavref(double* t11av, double* t21av, double* t31av, double* t12av, double* t22av, double* t32av,
    double t11, double t21, double t31, double t12, double t22, double t32, double r, int a, int b, lattice_t latt)
{
    double rhoa01, rhoa02, a1, a2, rho01 /*,rho02*/;

    //     For ialloy = 2, no averaging is done
    if (ialloy == 2) {
        *t11av = t11;
        *t21av = t21;
        *t31av = t31;
        *t12av = t12;
        *t22av = t22;
        *t32av = t32;
    }
    else switch (latt) {
    case FCC:
    case BCC:
    case DIA:
    case DIA3:
    case HCP:
    case B1:
    case DIM:
    case B2:
    case CH4:
    case LIN:
    case ZIG:
    case TRI:
        //     all neighbors are of the opposite type
        *t11av = t12;
        *t21av = t22;
        *t31av = t32;
        *t12av = t11;
        *t22av = t21;
        *t32av = t31;
        break;
    default:
        a1 = r / this->re_meam[a][a] - 1.0;
        a2 = r / this->re_meam[b][b] - 1.0;
        rhoa01 = this->rho0_meam[a] * exp(-this->beta0_meam[a] * a1);
        rhoa02 = this->rho0_meam[b] * exp(-this->beta0_meam[b] * a2);
        if (latt == L12) {
            rho01 = 8 * rhoa01 + 4 * rhoa02;
            *t11av = (8 * t11 * rhoa01 + 4 * t12 * rhoa02) / rho01;
            *t12av = t11;
            *t21av = (8 * t21 * rhoa01 + 4 * t22 * rhoa02) / rho01;
            *t22av = t21;
            *t31av = (8 * t31 * rhoa01 + 4 * t32 * rhoa02) / rho01;
            *t32av = t31;
        }
        else {
            //      call error('Lattice not defined in get_tavref.')
        }
    }
}


void PlotMEAM::interpolate_meam(int ind)
{
    int j;
    double drar;

    // map to coefficient space

    this->nrar = this->nr;
    drar = this->dr;
    this->rdrar = 1.0 / drar;

    // phir interp
    for (j = 0; j < this->nrar; j++) {
        this->phirar[ind][j] = this->phir[ind][j];
    }
    this->phirar1[ind][0] = this->phirar[ind][1] - this->phirar[ind][0];
    this->phirar1[ind][1] = 0.5 * (this->phirar[ind][2] - this->phirar[ind][0]);
    this->phirar1[ind][this->nrar - 2] =
        0.5 * (this->phirar[ind][this->nrar - 1] - this->phirar[ind][this->nrar - 3]);
    this->phirar1[ind][this->nrar - 1] = 0.0;
    for (j = 2; j < this->nrar - 2; j++) {
        this->phirar1[ind][j] = ((this->phirar[ind][j - 2] - this->phirar[ind][j + 2]) +
            8.0 * (this->phirar[ind][j + 1] - this->phirar[ind][j - 1])) /
            12.;
    }

    for (j = 0; j < this->nrar - 1; j++) {
        this->phirar2[ind][j] = 3.0 * (this->phirar[ind][j + 1] - this->phirar[ind][j]) -
            2.0 * this->phirar1[ind][j] - this->phirar1[ind][j + 1];
        this->phirar3[ind][j] = this->phirar1[ind][j] + this->phirar1[ind][j + 1] -
            2.0 * (this->phirar[ind][j + 1] - this->phirar[ind][j]);
    }
    this->phirar2[ind][this->nrar - 1] = 0.0;
    this->phirar3[ind][this->nrar - 1] = 0.0;

    for (j = 0; j < this->nrar; j++) {
        this->phirar4[ind][j] = this->phirar1[ind][j] / drar;
        this->phirar5[ind][j] = 2.0 * this->phirar2[ind][j] / drar;
        this->phirar6[ind][j] = 3.0 * this->phirar3[ind][j] / drar;
    }
}



int PlotMEAM::get_Zij(const lattice_t latt)
{
    switch (latt) {
    case FCC:	return 12;
    case BCC:	return 8;
    case HCP:	return 12;
    case DIA:
    case DIA3:	return 4;
    case DIM:	return 1;
    case B1:	return 6;
    case C11:	return 10;
    case L12:	return 12;
    case B2:	return 8;
    case CH4:	return 4;	// DYNAMO currenly implemented this way while it needs two Z values, 4 and 1
    case LIN:
    case ZIG:
    case TRI:	return 2;
        // call error('Lattice not defined in get_Zij.')
    }
    return 0;
}

//-----------------------------------------------------------------------------
// Number of second neighbors for the reference structure
//   a = distance ratio R1/R2 (a2nn in dynamo)
//   numscr = number of atoms that screen the 2NN bond
//   S = second neighbor screening function (xfac, a part of b2nn in dynamo)
//
int PlotMEAM::get_Zij2(const lattice_t latt, const double cmin, const double cmax,
    const double stheta, double& a, double& S)
{

    double C, x, sijk;
    int Zij2 = 0, numscr = 0;

    switch (latt) {

    case FCC:
        Zij2 = 6;
        a = sqrt(2.0);
        numscr = 4;
        break;

    case BCC:
        Zij2 = 6;
        a = 2.0 / sqrt(3.0);
        numscr = 4;
        break;

    case HCP:
        Zij2 = 6;
        a = sqrt(2.0);
        numscr = 4;
        break;

    case B1:
        Zij2 = 12;
        a = sqrt(2.0);
        numscr = 2;
        break;

    case DIA: // 2NN
        Zij2 = 12;
        a = sqrt(8.0 / 3.0);
        numscr = 1;
        if (cmin < 0.500001) {
            //          call error('can not do 2NN MEAM for dia')
        }
        break;

    case DIA3: // 3NN
        Zij2 = 12;
        a = sqrt(11.0 / 3.0);
        numscr = 4;
        if (cmin < 0.500001) {
            //          call error('can not do 2NN MEAM for dia')
        }
        break;

    case CH4: //does not have 2nn structure so it returns 0
    case LIN: //line
    case DIM:
        //        this really shouldn't be allowed; make sure screening is zero
        a = 1.0;
        S = 0.0;
        return 0;

    case TRI: //TRI
        Zij2 = 1;
        a = 2.0 * stheta;
        numscr = 2;
        break;

    case ZIG: //zig-zag
        Zij2 = 2;
        a = 2.0 * stheta;
        numscr = 1;
        break;

    case L12:
        Zij2 = 6;
        a = sqrt(2.0);
        numscr = 4;
        break;

    case B2:
        Zij2 = 6;
        a = 2.0 / sqrt(3.0);
        numscr = 4;
        break;
    case C11:
        // unsupported lattice flag C11 in get_Zij
        break;
    default:
        // unknown lattic flag in get Zij
        //        call error('Lattice not defined in get_Zij.')
        break;
    }

    // Compute screening for each first neighbor
    if (latt == DIA3) { // special case for 3NN diamond structure
        C = 1.0;
    }
    else {
        C = 4.0 / (a * a) - 1.0;
    }
    x = (C - cmin) / (cmax - cmin);
    sijk = fcut(x);
    // There are numscr first neighbors screening the second neighbors
    S = pow(sijk, numscr);
    return Zij2;
}

int PlotMEAM::get_Zij2_b2nn(const lattice_t latt, const double cmin, const double cmax, double& S)
{

    double x, sijk, C;
    int numscr = 0, Zij2 = 0;
    switch (latt) {
    case ZIG: //zig-zag for b11s and b22s term
    case TRI: //trimer for b11s
        Zij2 = 2;
        numscr = 1;
        break;
    default:
        // unknown lattic flag in get Zij
        //        call error('Lattice not defined in get_Zij.')
        break;
    }
    C = 1.0;
    x = (C - cmin) / (cmax - cmin);
    sijk = fcut(x);
    S = pow(sijk, numscr);
    return Zij2;
}

void PlotMEAM::get_shpfcn(const lattice_t latt, const double sthe, const double cthe, double(&s)[3])
{
    switch (latt) {
    case FCC:
    case BCC:
    case B1:
    case B2:
        s[0] = 0.0;
        s[1] = 0.0;
        s[2] = 0.0;
        break;
    case HCP:
        s[0] = 0.0;
        s[1] = 0.0;
        s[2] = 1.0 / 3.0;
        break;
    case CH4: // CH4 actually needs shape factor for diamond for C, dimer for H
    case DIA:
    case DIA3:
        s[0] = 0.0;
        s[1] = 0.0;
        s[2] = 32.0 / 9.0;
        break;
    case DIM:
        s[0] = 1.0;
        s[1] = 2.0 / 3.0;
        //        s(3) = 1.d0 // this should be 0.4 unless (1-legendre) is multiplied in the density calc.
        s[2] = 0.40; // this is (1-legendre) where legendre = 0.6 in dynamo is accounted.
        break;
    case LIN: //linear, theta being 180
        s[0] = 0.0;
        s[1] = 8.0 / 3.0; // 4*(co**4 + si**4 - 1.0/3.0) in zig become 4*(1-1/3)
        s[2] = 0.0;
        break;
    case ZIG: //zig-zag
    case TRI: //trimer e.g. H2O
        s[0] = 4.0 * pow(cthe, 2);
        s[1] = 4.0 * (pow(cthe, 4) + pow(sthe, 4) - 1.0 / 3.0);
        s[2] = 4.0 * (pow(cthe, 2) * (3 * pow(sthe, 4) + pow(cthe, 4)));
        s[2] = s[2] - 0.6 * s[0]; //legend in dyn, 0.6 is default value.
        break;
    default:
        s[0] = 0.0;
        //        call error('Lattice not defined in get_shpfcn.')
    }
}


double PlotMEAM::phi_meam(double r, int a, int b)
{
    /*unused:double a1,a2,a12;*/
    double t11av, t21av, t31av, t12av, t22av, t32av;
    double G1, G2, s1[3], s2[3], rho0_1, rho0_2;
    double Gam1, Gam2, Z1, Z2;
    double rhobar1, rhobar2, F1, F2, dF;
    double rho01, rho11, rho21, rho31;
    double rho02, rho12, rho22, rho32;
    double scalfac, phiaa, phibb;
    double Eu;
    double arat, scrn, scrn2;
    int Z12, errorflag;
    int n, Z1nn, Z2nn;
    lattice_t latta /*unused:,lattb*/;
    double rho_bkgd1, rho_bkgd2;
    double b11s, b22s;

    double phi_m = 0.0;

    // Equation numbers below refer to:
    //   I. Huang et.al., Modelling simul. Mater. Sci. Eng. 3:615

    // get number of neighbors in the reference structure
    //   Nref[i][j] = # of i's neighbors of type j
    Z1 = get_Zij(this->lattce_meam[a][a]);
    Z2 = get_Zij(this->lattce_meam[b][b]);
    Z12 = get_Zij(this->lattce_meam[a][b]);

    get_densref(r, a, b, &rho01, &rho11, &rho21, &rho31, &rho02, &rho12, &rho22, &rho32);

    // if densities are too small, numerical problems may result; just return zero
    if (rho01 <= 1e-14 && rho02 <= 1e-14)
        return 0.0;

    // calculate average weighting factors for the reference structure
    if (this->lattce_meam[a][b] == C11) {
        if (this->ialloy == 2) {
            t11av = this->t1_meam[a];
            t12av = this->t1_meam[b];
            t21av = this->t2_meam[a];
            t22av = this->t2_meam[b];
            t31av = this->t3_meam[a];
            t32av = this->t3_meam[b];
        }
        else {
            scalfac = 1.0 / (rho01 + rho02);
            t11av = scalfac * (this->t1_meam[a] * rho01 + this->t1_meam[b] * rho02);
            t12av = t11av;
            t21av = scalfac * (this->t2_meam[a] * rho01 + this->t2_meam[b] * rho02);
            t22av = t21av;
            t31av = scalfac * (this->t3_meam[a] * rho01 + this->t3_meam[b] * rho02);
            t32av = t31av;
        }
    }
    else {
        // average weighting factors for the reference structure, eqn. I.8
        get_tavref(&t11av, &t21av, &t31av, &t12av, &t22av, &t32av, this->t1_meam[a], this->t2_meam[a],
            this->t3_meam[a], this->t1_meam[b], this->t2_meam[b], this->t3_meam[b], r, a, b,
            this->lattce_meam[a][b]);
    }

    // for c11b structure, calculate background electron densities
    if (this->lattce_meam[a][b] == C11) {
        latta = this->lattce_meam[a][a];
        if (latta == DIA) {
            rhobar1 = square((Z12 / 2) * (rho02 + rho01))
                + t11av * square(rho12 - rho11)
                + t21av / 6.0 * square(rho22 + rho21)
                + 121.0 / 40.0 * t31av * square(rho32 - rho31);
            rhobar1 = sqrt(rhobar1);
            rhobar2 = square(Z12 * rho01) + 2.0 / 3.0 * t21av * square(rho21);
            rhobar2 = sqrt(rhobar2);
        }
        else {
            rhobar2 = square((Z12 / 2) * (rho01 + rho02))
                + t12av * square(rho11 - rho12)
                + t22av / 6.0 * square(rho21 + rho22)
                + 121.0 / 40.0 * t32av * square(rho31 - rho32);
            rhobar2 = sqrt(rhobar2);
            rhobar1 = square(Z12 * rho02) + 2.0 / 3.0 * t22av * square(rho22);
            rhobar1 = sqrt(rhobar1);
        }
    }
    else {
        // for other structures, use formalism developed in Huang's paper
        //
        //     composition-dependent scaling, equation I.7
        //     If using mixing rule for t, apply to reference structure; else
        //     use precomputed values
        if (this->mix_ref_t == 1) {
            if (this->ibar_meam[a] <= 0)
                G1 = 1.0;
            else {
                get_shpfcn(this->lattce_meam[a][a], this->stheta_meam[a][a], this->ctheta_meam[a][a], s1);
                Gam1 = (s1[0] * t11av + s1[1] * t21av + s1[2] * t31av) / (Z1 * Z1);
                G1 = G_gam(Gam1, this->ibar_meam[a], errorflag);
            }
            if (this->ibar_meam[b] <= 0)
                G2 = 1.0;
            else {
                get_shpfcn(this->lattce_meam[b][b], this->stheta_meam[b][b], this->ctheta_meam[b][b], s2);
                Gam2 = (s2[0] * t12av + s2[1] * t22av + s2[2] * t32av) / (Z2 * Z2);
                G2 = G_gam(Gam2, this->ibar_meam[b], errorflag);
            }
            rho0_1 = this->rho0_meam[a] * Z1 * G1;
            rho0_2 = this->rho0_meam[b] * Z2 * G2;
        }
        Gam1 = (t11av * rho11 + t21av * rho21 + t31av * rho31);
        if (rho01 < 1.0e-14)
            Gam1 = 0.0;
        else
            Gam1 = Gam1 / (rho01 * rho01);

        Gam2 = (t12av * rho12 + t22av * rho22 + t32av * rho32);
        if (rho02 < 1.0e-14)
            Gam2 = 0.0;
        else
            Gam2 = Gam2 / (rho02 * rho02);

        G1 = G_gam(Gam1, this->ibar_meam[a], errorflag);
        G2 = G_gam(Gam2, this->ibar_meam[b], errorflag);
        if (this->mix_ref_t == 1) {
            rho_bkgd1 = rho0_1;
            rho_bkgd2 = rho0_2;
        }
        else {
            if (this->bkgd_dyn == 1) {
                rho_bkgd1 = this->rho0_meam[a] * Z1;
                rho_bkgd2 = this->rho0_meam[b] * Z2;
            }
            else {
                rho_bkgd1 = this->rho_ref_meam[a];
                rho_bkgd2 = this->rho_ref_meam[b];
            }
        }
        rhobar1 = rho01 / rho_bkgd1 * G1;
        rhobar2 = rho02 / rho_bkgd2 * G2;
    }

    // compute embedding functions, eqn I.5

    F1 = embedding(this->A_meam[a], this->Ec_meam[a][a], rhobar1, dF);
    F2 = embedding(this->A_meam[b], this->Ec_meam[b][b], rhobar2, dF);


    // compute Rose function, I.16
    Eu = erose(r, this->re_meam[a][b], this->alpha_meam[a][b], this->Ec_meam[a][b], this->repuls_meam[a][b],
        this->attrac_meam[a][b], this->erose_form);

    // calculate the pair energy
    if (this->lattce_meam[a][b] == C11) {
        latta = this->lattce_meam[a][a];
        if (latta == DIA) {
            phiaa = phi_meam(r, a, a);
            phi_m = (3 * Eu - F2 - 2 * F1 - 5 * phiaa) / Z12;
        }
        else {
            phibb = phi_meam(r, b, b);
            phi_m = (3 * Eu - F1 - 2 * F2 - 5 * phibb) / Z12;
        }
    }
    else if (this->lattce_meam[a][b] == L12) {
        phiaa = phi_meam(r, a, a);
        //       account for second neighbor a-a potential here...
        Z1nn = get_Zij(this->lattce_meam[a][a]);
        Z2nn = get_Zij2(this->lattce_meam[a][a], this->Cmin_meam[a][a][a],
            this->Cmax_meam[a][a][a], this->stheta_meam[a][b], arat, scrn);


        phiaa += phi_meam_series(scrn, Z1nn, Z2nn, a, a, r, arat);
        phi_m = Eu / 3.0 - F1 / 4.0 - F2 / 12.0 - phiaa;

    }
    else if (this->lattce_meam[a][b] == CH4) {
        phi_m = (5 * Eu - F1 - 4 * F2) / 4;

    }
    else if (this->lattce_meam[a][b] == ZIG) {
        if (a == b) {
            phi_m = (2 * Eu - F1 - F2) / Z12;
        }
        else {
            Z1 = get_Zij(this->lattce_meam[a][b]);
            Z2 = get_Zij2_b2nn(this->lattce_meam[a][b], this->Cmin_meam[a][a][b], this->Cmax_meam[a][a][b], scrn);
            b11s = -Z2 / Z1 * scrn;
            Z2 = get_Zij2_b2nn(this->lattce_meam[a][b], this->Cmin_meam[b][b][a], this->Cmax_meam[b][b][a], scrn2);
            b22s = -Z2 / Z1 * scrn2;

            phiaa = phi_meam(2.0 * this->stheta_meam[a][b] * r, a, a);
            phibb = phi_meam(2.0 * this->stheta_meam[a][b] * r, b, b);
            phi_m = (2.0 * Eu - F1 - F2 + phiaa * b11s + phibb * b22s) / Z12;
        }

    }
    else if (this->lattce_meam[a][b] == TRI) {
        if (a == b) {
            phi_m = (3.0 * Eu - 2.0 * F1 - F2) / Z12;
        }
        else {
            Z1 = get_Zij(this->lattce_meam[a][b]);
            Z2 = get_Zij2_b2nn(this->lattce_meam[a][b], this->Cmin_meam[a][a][b], this->Cmax_meam[a][a][b], scrn);
            b11s = -Z2 / Z1 * scrn;
            phiaa = phi_meam(2.0 * this->stheta_meam[a][b] * r, a, a);
            phi_m = (3.0 * Eu - 2.0 * F1 - F2 + phiaa * b11s) / Z12;
        }

    }
    else {
        // potential is computed from Rose function and embedding energy
        phi_m = (2 * Eu - F1 - F2) / Z12;
    }

    // if r = 0, just return 0
    if (iszero(r)) {
        phi_m = 0.0;
    }

    return phi_m;
}
