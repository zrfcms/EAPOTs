#pragma once

#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <QOpenGLBuffer>
#include <QMatrix4x4>

#include <vector>
#include "AtomConfig.h"

QT_FORWARD_DECLARE_CLASS(QOpenGLShaderProgram);
QT_FORWARD_DECLARE_CLASS(QOpenGLTexture);

enum ConfigType { Orig, View };

class StructGLWidget : public QOpenGLWidget, protected QOpenGLFunctions
{
	Q_OBJECT

public:
	explicit StructGLWidget(QWidget *parent = 0);
	~StructGLWidget();

	QSize minimumSizeHint() const override;
	QSize sizeHint() const override;


	void rotateBy(int xAngle, int yAngle, int zAngle);
	void moveBy(GLfloat x, GLfloat y);
    void setAtomSize(double r);

signals:
	void clicked();
    void atomSizeChanged(double r);

protected:
	void initializeGL() override;
	void paintGL() override;
	void resizeGL(int width, int height) override;

	void mousePressEvent(QMouseEvent *event) override;
	void mouseMoveEvent(QMouseEvent *event) override;
	void mouseReleaseEvent(QMouseEvent *event) override;
	void wheelEvent(QWheelEvent *event) override;

public:
	
	double outAtomRadius;
	double outWorldSize;
	double outWorldDepth;
	double outColorBarlo;
	double outColorBarhi;
	int outDrawBox;
	int outDrawAxis;

	int loadObj(QString file);
	int drawObj(QMatrix4x4 m);	

private:
	void createDefalutConfig();
	void createOpenGLShaderProgram();

	QPoint lastPos;
	int xRot, yRot, zRot;

	GLfloat xMove;
	GLfloat yMove;

	GLdouble World2WindowRatio;
	GLdouble Window2WorldRatio;
	GLint WindowWidth;
	GLint WindowHeight;

#define NUM_STARS 14

	QMatrix4x4 camera, cameraAxis;
	GLfloat center[3];
	QOpenGLTexture *texture64;

private:


	QOpenGLBuffer vboAtom;
	QOpenGLBuffer vboDomain;
	QOpenGLBuffer vboAxis;

	QOpenGLShaderProgram *programAtomColorSignedDepth;
	QOpenGLShaderProgram *programAtomColorSignedNoDepth;

	QVector<QOpenGLBuffer> vboColorSigned;
	QOpenGLShaderProgram *programColorSigned;

	QVector<QOpenGLBuffer> vboPolyColorUni;
	QOpenGLShaderProgram *programPolyColorUni;


public:
	int vboColorSignedCurrent;
	int vboPolyColorUniCurrent;

	// Config
public:
	void ConfigToVBO();

	int UIConfigMax;
	int UIConfigCurrent;
	LoadConfig_NS::AtomConfigData** UIConfig;

	void growUIConfig();
	void setConfig(int idx, LoadConfig_NS::AtomConfigData* pdata, bool setRange = true);

	int vbobufmax;
	GLfloat* vbobuf;
};
