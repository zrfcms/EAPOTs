#pragma once

#include "UiPtr.h"
#include <QAction>
#include <QToolBar>
#include "imageTypes.h"

#include "ui_EAPlotPage.h"
#include "ui_PlotSurfDialog.h"
#include "ui_Graph3DControl.h"
#include "ui_EAPlotBackground.h"


#include <QSplitter>
#include <QValueAxis>
#include <QChartView>
#include <QSplineSeries>

#include <Q3DSurface>
#include <QSurface3DSeries>
#include <QSurfaceDataProxy>

QT_CHARTS_USE_NAMESPACE
using namespace QtDataVisualization;

namespace EAPUI_NS {


    class MatMemory {
    public:

        template <typename TYPE>
        static TYPE **create(TYPE **&array, size_t n1, size_t n2, const char* = NULL) {
            size_t nbytes = sizeof(TYPE) * n1 * n2;
            TYPE *data = (TYPE *)malloc(nbytes);
            nbytes = sizeof(TYPE *) * n1;
            array = (TYPE **)malloc(nbytes);

            size_t n = 0;
            for (size_t i = 0; i < n1; i++) {
                array[i] = &data[n];
                n += n2;
            }
            return array;
        };

        template <typename TYPE>
        static TYPE ***create(TYPE ***&array, size_t n1, size_t n2, size_t n3, const char* = NULL) {
            size_t nbytes = sizeof(TYPE) * n1 * n2 * n3;
            TYPE *data = (TYPE *)malloc(nbytes);
            nbytes = sizeof(TYPE *) * n1 * n2;
            TYPE **plane = (TYPE **)malloc(nbytes);
            nbytes = sizeof(TYPE **) * n1;
            array = (TYPE ***)malloc(nbytes);

            size_t i, j;
            size_t m, n = 0;
            for (i = 0; i < n1; i++) {
                m = i * n2;
                array[i] = &plane[m];
                for (j = 0; j < n2; j++) {
                    plane[m + j] = &data[n];
                    n += n3;
                }
            }
            return array;
        };

        template <typename TYPE>
        static void destroy(TYPE **&array)
        {
            if (array == NULL) return;
            free(array[0]);
            free(array);
            array = NULL;
        }

        template <typename TYPE>
        static void destroy(TYPE ***&array)
        {
            if (array == NULL) return;
            free(array[0][0]);
            free(array[0]);
            free(array);
            array = NULL;
        }
    };

    class EAPlotBackground : public QWidget, public UiPtr
    {
        Q_OBJECT
    public:
        Ui_EAPlotBackground ui;
        explicit EAPlotBackground(QWidget *parent, EAPUI* ptr);

    };

	class EAPlotPage : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
		Ui_EAPlotPage ui;
		explicit EAPlotPage(QWidget *parent, EAPUI* ptr);
		~EAPlotPage();
		void init();
		void CreateSubWindow(const QString& Title, QWidget* widget);

	signals:

	public slots:
        void loadMEAM();

        void createPlotEAM(QString);
        void createPlotFS(QString);
        void createPlotMEAM(QString, QString);
        void createPlotTersoff(QString);
        void createPlotBrenner(QString);
        void createPlotSW(QString);
        void createPlotSurf(QString);

	public:
        QString PlotFileOpenDir;
    };


    class QWChartView : public QChartView
    {
        Q_OBJECT

    private:
        bool MiddleButtonPressed;
        QPoint  MiddlePoint;
        QPoint  beginPoint;		// Select the starting point of the rectangular area
        QPoint  endPoint;		// Select the end of the rectangular area

    protected:
        //    bool viewportEvent(QEvent *event);
        void mousePressEvent(QMouseEvent *event);		// Left mouse button pressed
        void mouseMoveEvent(QMouseEvent *event);		// Mouse move
        void mouseReleaseEvent(QMouseEvent *event);		// Left mouse button
        void mouseDoubleClickEvent(QMouseEvent *event);
        void keyPressEvent(QKeyEvent *event);			// Key event
        void wheelEvent(QWheelEvent *event);

    public:
        explicit QWChartView(QWidget *parent = 0);
        ~QWChartView();

    signals:
        void mouseMovePoint(QPoint point);				// Mouse movement signal, fired in mouseMoveEvent () event
    };


	class QPlotSubPage2D : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
		explicit QPlotSubPage2D(QWidget *parent, EAPUI* ptr);
		~QPlotSubPage2D();

	public:
		QToolBar* toolBar;
		QVBoxLayout* mainLayout;
		QMdiArea* mdiArea;

		QAction *Act_TabMode;

		QAction *Act_Tile;
		QAction *Act_Stack;
		QAction *Act_Frameless;

		QAction *Act_Previous;
		QAction *Act_Next;
		QAction *Act_CloseAll;

	public:
        int Np;
        QVector<class QWChartView*> chartViews;

	protected:

        typedef EAPOT_NS::AxisLimit AxisLimit;
        QVector<AxisLimit> xlim, ylim;

	public:

        void addHorizontal(QChart*, qreal y, qreal xlo, qreal xhi);

        void CreateSubWindow(QChart*, const QString& xlabel, const QString& ylabel, const AxisLimit& x, const AxisLimit& y);

        QSplineSeries* creatSeries(QChart*, const QString& Name);

        void getSeriesRange(QLineSeries*, qreal& lo, qreal& hi);

		void LegendMarkerClicked();

	};

	class PlotEAM : public QPlotSubPage2D
	{
		Q_OBJECT
	public:
        explicit PlotEAM(QWidget *parent, QString, bool fsFlag, EAPUI* ptr);
		~PlotEAM();        

        bool fsFlag;
        int nrho, nr;
        double drho, dr, cut;
        double **frho, ***rhor, ***z2r;

    public:
        QStringList elts;

        void grab(FILE *fptr, int n, double *list);
        int read_data(QString);
	};

    class PlotSW : public QPlotSubPage2D
    {
        struct Param {
            double v[11];
            int i,j,k;
        };

        Q_OBJECT
    public:
        explicit PlotSW(QWidget *parent, QString, EAPUI* ptr);

    public:
        QStringList elts;
        std::vector<double> pyParamVec;
        int read_data(QString file);
    };

    class PlotTersoff : public QPlotSubPage2D
    {
        struct Param {
            double v[14];
            int i,j,k;
        };

        Q_OBJECT
    public:
        explicit PlotTersoff(QWidget *parent, QString, EAPUI* ptr);

    public:
        QStringList elts;
        std::vector<double> pyParamVec;
        int read_data(QString file);
    };

#define maxelt 5

    class PlotMEAM : public QPlotSubPage2D
    {

        Q_OBJECT
    public:
        explicit PlotMEAM(QWidget *parent, QString, QString, EAPUI* ptr);

    public:
        typedef enum { FCC, BCC, HCP, DIM, DIA, DIA3, B1, C11, L12, B2, CH4, LIN, ZIG, TRI } lattice_t;

    public:
        double cutmax;

    private:
        static bool str_to_lat(const char* str, bool single, lattice_t& lat);
        void meam_setup_global(int nelt, lattice_t* lat, int* ielement, double* atwt, double* alpha,
            double* b0, double* b1, double* b2, double* b3, double* alat, double* esub, double* asub,
            double* t0, double* t1, double* t2, double* t3, double* rozero, int* ibar);

        void meam_checkindex(int num, int lim, int nidx, int* idx, int* ierr);
        void meam_setup_param(int which, double value, int nindex, int* index /*index(3)*/, int* errorflag);
        void meam_setup_done(double* cutmax);
        void alloyparams(void);

        void compute_pair_meam(void);
        void compute_reference_density();

        double fcut(const double xi);
        double erose(const double r, const double re, const double alpha, const double Ec,
            const double repuls, const double attrac, const int form);
        void get_sijk(double C, int i, int j, int k, double* sijk);

        int get_Zij(const lattice_t latt);
        int get_Zij2(const lattice_t latt, const double cmin, const double cmax,
            const double stheta, double& a, double& S);
        int get_Zij2_b2nn(const lattice_t latt, const double cmin, const double cmax, double& S);
        void get_shpfcn(const lattice_t latt, const double sthe, const double cthe, double(&s)[3]);

        double embedding(const double A, const double Ec, const double rhobar, double& dF) const;
        double G_gam(const double gamma, const int ibar, int& errorflag) const;
        static double zbl(const double r, const int z1, const int z2);
        const double phi_meam_series(const double scrn, const int Z1, const int Z2, const int a, const int b, const double r, const double arat);

        void get_densref(double r, int a, int b, double* rho01, double* rho11, double* rho21, double* rho31,
            double* rho02, double* rho12, double* rho22, double* rho32);

        void get_tavref(double* t11av, double* t21av, double* t31av, double* t12av, double* t22av, double* t32av,
            double t11, double t21, double t31, double t12, double t22, double t32, double r, int a, int b, lattice_t latt);
        void interpolate_meam(int);

        double phi_meam(double r, int a, int b);

    protected:

        double cutforce, cutforcesq;

        double Ec_meam[maxelt][maxelt], re_meam[maxelt][maxelt];
        double A_meam[maxelt], alpha_meam[maxelt][maxelt], rho0_meam[maxelt];
        double delta_meam[maxelt][maxelt];
        double beta0_meam[maxelt], beta1_meam[maxelt];
        double beta2_meam[maxelt], beta3_meam[maxelt];
        double t0_meam[maxelt], t1_meam[maxelt];
        double t2_meam[maxelt], t3_meam[maxelt];
        double rho_ref_meam[maxelt];
        int ibar_meam[maxelt], ielt_meam[maxelt];
        lattice_t lattce_meam[maxelt][maxelt];
        int nn2_meam[maxelt][maxelt];
        int zbl_meam[maxelt][maxelt];
        int eltind[maxelt][maxelt];
        int neltypes;

        double** phir;
        double** phirar, ** phirar1, ** phirar2, ** phirar3, ** phirar4, ** phirar5, ** phirar6;

        double attrac_meam[maxelt][maxelt], repuls_meam[maxelt][maxelt];

        double Cmin_meam[maxelt][maxelt][maxelt];
        double Cmax_meam[maxelt][maxelt][maxelt];
        double rc_meam, delr_meam, ebound_meam[maxelt][maxelt];
        int augt1, ialloy, mix_ref_t, erose_form;
        int emb_lin_neg, bkgd_dyn;
        double gsmooth_factor;

        int vind2D[3][3], vind3D[3][3][3];                  // x-y-z to Voigt-like index
        int v2D[6], v3D[10];                                // multiplicity of Voigt index (i.e. [1] -> xy+yx = 2

        int nr, nrar;
        double dr, rdrar;

        double stheta_meam[maxelt][maxelt];
        double ctheta_meam[maxelt][maxelt];

        int lattce_s[maxelt];
        double z[maxelt], atwt[maxelt];			// note that z was unused
        double alpha_s[maxelt];
        double alat_s[maxelt], Ec_s[maxelt];
    public:

        QStringList elts;
        int read_data(QString lib, QString meam);
    };








    // get number in X and Y axis for surf data
    class PlotSurfDialog : public QDialog
    {
        Q_OBJECT
    public:
        Ui_PlotSurfDialog ui;

        explicit PlotSurfDialog(QWidget *parent);
        ~PlotSurfDialog() {}
    };


	class QPlotSubPage3D : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
		Ui_Graph3DControl ui;

		explicit QPlotSubPage3D(QWidget *parent, const QString& file, EAPUI* ptr);
		~QPlotSubPage3D();

	public:
		void UpdateQLinearGradient();
		void CreateQLinearGradient();
		void CreateConnect();
        void readData(const QString& pfile);
        void iniGraph3D();

		void updateAxisRange();
        void updateSeriesZValue();
        QVector<qreal> loadValue(const QJsonArray& array);

		QHBoxLayout *mainLayout;
		QSplitter *splitter;

        QWidget             *graphContainer;    //
        Q3DSurface          *graph3D;           // graph3D
        QSurface3DSeries    *series;            // series
        QSurfaceDataProxy   *proxy;             // Data agent

		QList<QLinearGradient> Gradient;

		QValue3DAxis *axisX, *axisY, *axisZ;

        qreal lx, ly;
        int Nx, Ny, Nxy;
        QVector<qreal> x, y, z;
        QSurfaceDataArray *dataArray;
	};
}
