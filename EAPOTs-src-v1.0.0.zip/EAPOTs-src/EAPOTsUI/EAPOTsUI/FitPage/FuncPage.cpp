#include "FuncPage.h"
#include "EAPIO.h"
#include "EAPFrame.h"
#include "ui_CrossPage.h"
#include "ui_SinglePage.h"

#include <QQmlContext>
#include <QQuickItem>
#include <QQuickWidget>

#include <QTimer>
#include <QFileDialog>
#include <QJsonDocument>
#include <QQmlEngine>
#include "EAPSetPage.h"
#include "EAExtraWidget.h"

using namespace EAPUI_NS;

#define _Get(Item) EAPIO::Get(ui->Item)

#define AddItem(u) v.push_back({ #u, ui->u, EAPIO::GetWidgetType(ui->u) });


FuncPage::FuncPage(QWidget *parent, EAPUI* ptr) :
    QWidget(parent), UiPtr(ptr){
}


CrossPage::CrossPage(QWidget *parent, EAPUI* ptr) :
    FuncPage(parent, ptr),
    ui(new Ui::CrossPage)
{
    ui->setupUi(this);
}

CrossPage::~CrossPage(){

}


void CrossPage::Initialize() {

    /*--------------------------------------add actions--------------------------------------------*/
    // Single mode: input potential file
    connect(ui->FunSingleFileButton1, &QPushButton::clicked, this, [=]() {
        QString strFile = QFileDialog::getOpenFileName(this,
            tr("load EAM file"), ui->FunSingleFileEdit1->text(), tr("EAM file (*.eam *.alloy *)"));

        if (!strFile.isEmpty())
            ui->FunSingleFileEdit1->setText(strFile);
        });

    connect(ui->FunSingleFileButton2, &QPushButton::clicked, this, [=]() {
        QString strFile = QFileDialog::getOpenFileName(this,
            tr("load EAM file"), ui->FunSingleFileEdit2->text(), tr("EAM file (*.eam *.alloy *)"));

        if (!strFile.isEmpty())
            ui->FunSingleFileEdit2->setText(strFile);
        });

    // Alloy mode: input potential file
    connect(ui->FunAlloyFileButton, &QPushButton::clicked, this, [=]() {
        QString strFile = QFileDialog::getOpenFileName(this,
            tr("load EAM file"), ui->FunAlloyFileEdit->text(), tr("EAM file (*.eam *.alloy *)"));

        if (!strFile.isEmpty())
            ui->FunAlloyFileEdit->setText(strFile);
        });

    // CheckBox action: open transform
    connect(ui->FunInitTransChk, &QCheckBox::stateChanged, this, [=](int state) {
        ui->FunInitTransEdit->setEnabled(state == Qt::Checked);
        });

    connect(ui->FunOutEle1Edit, &QLineEdit::editingFinished, setPage, &EAPSetPage::ElementChange);
    connect(ui->FunOutEle2Edit, &QLineEdit::editingFinished, setPage, &EAPSetPage::ElementChange);

    /*-------------------------------------ComboBox Event------------------------------------------*/
    // Set input mode: single/alloy
    connect(ui->FunModeComb,
        static_cast<void (QComboBox:: *)(int index)>(&QComboBox::currentIndexChanged),
        this, [=](int i) {this->ui->FunModeStack->setCurrentIndex(i); });

    QStringList list;
    for (auto val : setPage->CrossInitFunc) {
        list << QApplication::translate("EAPFrameClass", val.toLatin1(), Q_NULLPTR);
    }
    ui->FunInitTypeComb->insertItems(0, list);
    ui->FunInitTypeComb->setCurrentIndex(3);
}


QVector<JsonKey> CrossPage::JsonKeyInitialize() {

    QVector<JsonKey> v;

    AddItem(FunModeComb);
    AddItem(FunAlloyEleEdit1);
    AddItem(FunAlloyEleEdit2);
    AddItem(FunAlloyFileEdit);
    AddItem(FunSingleFileEdit1);
    AddItem(FunSingleFileEdit2);

    AddItem(FunOutNrhoEdit);
    AddItem(FunOutDrhoEdit);
    AddItem(FunOutNrEdit);
    AddItem(FunOutDrEdit);
    AddItem(FunOutCutEdit);
    AddItem(FunOutEle1Edit);
    AddItem(FunOutEle2Edit);

    AddItem(FunInitTypeComb);
    AddItem(FunInitTransChk);
    AddItem(FunInitTransEdit);
    AddItem(FunInitParmEdit);
    AddItem(FunInitEle1Comb);
    AddItem(FunInitEle2Comb);

    return v;
}


void CrossPage::FunPageExtraJsonSettings(const QJsonObject & mainobj) {

    if (io->ImportEnable(mainobj, "FunPage")) {

        QJsonObject obj = mainobj["FunPage"].toObject();
        if (obj.contains("FunSingleFileEdit1"))
            ui->FunSingleFileEdit1->setText(frame->ResDir.absoluteFilePath(ui->FunSingleFileEdit1->text()));
        if (obj.contains("FunSingleFileEdit2"))
            ui->FunSingleFileEdit2->setText(frame->ResDir.absoluteFilePath(ui->FunSingleFileEdit2->text()));
        if (obj.contains("FunAlloyFileEdit"))
            ui->FunAlloyFileEdit->setText(frame->ResDir.absoluteFilePath(ui->FunAlloyFileEdit->text()));
    }
}


void CrossPage::getEleName(QStringList& vec) {

    vec.clear();
    vec.push_back(ui->FunOutEle1Edit->text());
    vec.push_back(ui->FunOutEle2Edit->text());

}

void SinglePage::createFuncParamPage(){

    QString QmlDir = "../config/Single/";
    QStackedWidget* stackedWidget = ui->stackedWidget;

    for (auto ifunc : setPage->CrossInitFunc){

        ui->FunInitTypeComb->addItem(ifunc);

        QWidget* page = new QWidget();
        QGridLayout* gridLayout = new QGridLayout(page);
        gridLayout->setContentsMargins(0, 0, 0, 0);

        QQuickWidget* quickWidget = new QQuickWidget(page);
        quickWidget->rootContext()->setContextProperty("setPage", setPage);

        quickWidget->setObjectName("QML"+ifunc);
        quickWidget->setResizeMode(QQuickWidget::SizeRootObjectToView);

        //quickWidget->setAttribute(Qt::WA_TranslucentBackground, true);

        quickWidget->setAttribute(Qt::WA_AlwaysStackOnTop, true);
        quickWidget->setClearColor(Qt::transparent);

        //quickWidget->engine()->addImportPath(QmlDir); addPluginPath

        QString qmlName = ifunc.replace('/', '_');
        if (qmlName == "meam_second") qmlName = "meam_first";
        //qmlName = "eam_voter1";

        QString qmlPath = QmlDir + QString("%1.qml").arg(qmlName);

        quickWidget->setSource(QUrl::fromLocalFile(qmlPath));        

        connect(frame, SIGNAL(fontChangeSlot()), quickWidget->rootObject(), SLOT(setFont()));

        gridLayout->addWidget(quickWidget, 0, 0, 1, 1);
        stackedWidget->addWidget(page);
    }

    // https://doc.qt.io/qt-5/qtqml-cppintegration-interactqmlfromcpp.html
    // QQuickItem *object = quickWidget->rootObject();
    // QObject *rect = object->findChild<QObject*>("rect");
    // if (rect) rect->setProperty("color", "red");
}


SinglePage::SinglePage(QWidget *parent, EAPUI* ptr) :
    FuncPage(parent, ptr),
    ui(new Ui::SinglePage)
{
    ui->setupUi(this);

    ui->reloadButton->setVisible(eapui->BetaMode);
    createFuncParamPage();

    connect(ui->reloadButton, &QPushButton::clicked, this, [=](){
        ui->FunInitTypeComb->clear();
        int cur = ui->stackedWidget->currentIndex();

        for(int i = ui->stackedWidget->count(); i >= 0; i--){
            QWidget* widget = ui->stackedWidget->widget(i);
            ui->stackedWidget->removeWidget(widget);
            widget->deleteLater();
        }

        createFuncParamPage();
        ui->FunInitTypeComb->setCurrentIndex(cur);
    });

    connect(ui->SelectElementButton, &QPushButton::clicked, this, [=](){
        PeriodicTableDialog* dialog = new PeriodicTableDialog(this);

        connect(dialog->buttonBox, SIGNAL(accepted()), dialog, SLOT(accept()));
        connect(dialog->buttonBox, SIGNAL(rejected()), dialog, SLOT(reject()));

        if (dialog->exec() == QDialog::Accepted){
            QStringList list = dialog->periodicTable->getSelection();
            if(list.size() > 0) ui->FunOutEleEdit->setText(list[0]);
        }
        delete dialog;
    });

    if (eapui->FitMode == EAPUI::BCN){
        ui->reloadButton->setVisible(eapui->BetaMode);
        ui->SelectElementButton->setHidden(true);
        ui->FunOutEleEdit->setText("BN");
        ui->FunOutEleEdit->setEnabled(false);
        ui->FunOutEleEdit->setReadOnly(true);
        ui->FunOutEleEdit->setAlignment(Qt::AlignHCenter);
    }

    /*  connect(ui->testButton, &QPushButton::clicked, this, [=](){
        QQuickWidget* quickWidget = getCurrentExtraParamWidget();
        QQuickItem *object = quickWidget->rootObject();

        QVariant ret, msg = "{\"dump\":[\"5000\",\"0.01\",\"5000\",\"0.0015\",\"7.0\"],"
                            "\"structure\":\"../fcc.lamps\",\"a0\":\"3.6150\"}";
        QMetaObject::invokeMethod(object, "get", Q_RETURN_ARG(QVariant, ret));
        QMetaObject::invokeMethod(object, "set", Q_ARG(QVariant, msg));

    });   */

    connect(ui->FunInitTypeComb, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
        ui->stackedWidget, &QStackedWidget::setCurrentIndex);
}

SinglePage::~SinglePage(){
}

QQuickWidget* SinglePage::getCurrentExtraParamWidget(){
    int i = ui->stackedWidget->currentIndex();
    QString func = setPage->CrossInitFunc[i];
    QQuickWidget* widget = ui->stackedWidget->findChild<QQuickWidget*>("QML"+func);

    //qDebug() << set->CrossInitFunc[i] << widget;
    return widget;
}


void SinglePage::Initialize() {

}


QVector<JsonKey> SinglePage::JsonKeyInitialize() {
    QVector<JsonKey> v;
    AddItem(FunInitTypeComb);
    AddItem(FunOutEleEdit);

    QWidget* w = qobject_cast<QWidget*>(this);
    v.push_back({"funcExtraParam", w, QJson});
    return v;
}



void SinglePage::getEleName(QStringList& vec) {

    vec.clear();
    vec.push_back(ui->FunOutEleEdit->text());
}

QJsonObject SinglePage::exportJson(){
    QVariant arg;
    QQuickItem *object = getCurrentExtraParamWidget()->rootObject();
    QMetaObject::invokeMethod(object, "get", Q_RETURN_ARG(QVariant, arg));

    QJsonDocument jsonDocument = QJsonDocument::fromJson(arg.toString().toLatin1());
    if(jsonDocument.isNull())    {
        io->error(FLERR, "Json data return from Pair xml is not readable");
    }

    return jsonDocument.object();
}

void SinglePage::importJson(const QJsonObject& obj){

    QVariant arg = QJsonDocument(obj).toJson(QJsonDocument::Indented);
    QQuickItem *object = getCurrentExtraParamWidget()->rootObject();
    QMetaObject::invokeMethod(object, "set", Q_ARG(QVariant, arg));


}



