#pragma once

#include "UiPtr.h"
#include "ui_CrossSetPage.h"
#include "CrossSetTarEAM.h"
#include "FuncPage.h"

namespace EAPUI_NS {

    class EAPSetPage : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
		Ui_CrossSetPage ui;
        explicit EAPSetPage(QWidget *parent, EAPUI* ptr);

        ~EAPSetPage();
        FuncPage* func;
        void init(QJsonObject &rootObj);

	signals:

	public slots:
		void RunPageRaise();

	public:
		void JsonKeyInitialize();
        void ImportJson(const QJsonObject &obj);
        void ExportJson(QJsonObject &obj);

		void FunPageInitialize();
		void TarPageInitialize();
		void MinPageInitialize();
		void OthPageInitialize();
		void RunPageInitialize();

		void getEleName(int Nneed, QStringList& vec);

	public:

		// Add a new MD target		
		void AddTarRowMDFiles();
		class TarMDItem* CreateTarRowMD(QString path);
		inline class TarMDItem* GetTarMDItem(const int i) {
			QListWidgetItem *listItem = ui.TarMDList->item(i);
			class TarMDItem *item = qobject_cast<class TarMDItem *>(ui.TarMDList->itemWidget(listItem));
			return item;
		}
		void MDSelectionChanged();

        QJsonArray ExportJsonMD();

	};
}
