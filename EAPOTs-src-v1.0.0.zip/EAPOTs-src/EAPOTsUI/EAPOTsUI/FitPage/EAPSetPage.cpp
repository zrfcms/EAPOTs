#include "EAPSetPage.h"
#include "EAPFrame.h"
#include "EAPIO.h"

#include <QJsonValue>
#include <QJsonArray>
#include <QFileDialog>

using namespace EAPUI_NS;

#define CheckConfig(KEY)                         \
if (!rootObj.contains(#KEY)) {                   \
    io->error(FLERR, QString("rootObj dose not " \
        "contain %1 information!").arg(#KEY));   \
}

#define GetConfig(KEY)                           \
CheckConfig(KEY)                                 \
KEY.clear();                                     \
foreach (ivalue, data[#KEY].toArray()) {         \
    KEY.append(ivalue.toString());               \
}


QStringList EAPSetPage::CrossInitFunc;
QStringList EAPSetPage::CheckStyle;
QStringList EAPSetPage::ThermoStyle;
QStringList EAPSetPage::ThermoFmt;
QStringList EAPSetPage::AlgoStyleFull;
QStringList EAPSetPage::AlgoStyleShort;
QStringList EAPSetPage::AlgoStyleInfo;

QVector<QVector<int>> EAPSetPage::TherStylePresetVec;
QVector<QVector<int>> EAPSetPage::CheckStylePresetVec;


void setPythonHighlighter(QPlainTextEdit* edit)
{

}


EAPSetPage::EAPSetPage(QWidget *parent, EAPUI* ptr, const QJsonObject& rootObj)
	: QWidget(parent)
	, UiPtr(ptr)
{
    ui.setupUi(this);

    QVector<QPlainTextEdit*> edits = {
        ui.OthInitEdit, ui.OthPairEdit, ui.OthComEdit,
        ui.OthCostEdit, ui.OthCheckEdit, ui.OthFiniEdit
    };

    foreach (auto edit, edits){

        pythonHighlighter.append(new PythonHighlighter(edit->document()));

        QFont font = edit->font();
        font.setFamily("Source Code Pro");
        edit->setFont(font);

        QFontMetrics metrics(edit->font());
        edit->setTabStopDistance(4 * metrics.width(' '));
    }

    QStringList keys = {
        "EAPData", "CheckStyle", "ThermoStyle", "ThermoFmt",
        "CheckStylePresetVec", "TherStylePresetVec",
        "AlgoStyleFull", "AlgoStyleShort", "AlgoStyleInfo",
    };

    foreach (QString str, keys) {
        if (!rootObj.contains(str)) {
            io->error(FLERR, QString("rootObj dose not contain %1 information!").arg(str));
        }
    }

    QJsonValue value, ivalue, jvalue;
    QJsonObject data = rootObj["EAPData"].toObject();

    GetConfig(ThermoStyle);
    GetConfig(CheckStyle);
    GetConfig(ThermoFmt);
    GetConfig(AlgoStyleFull);
    GetConfig(AlgoStyleShort);
    GetConfig(AlgoStyleInfo);
    GetConfig(CrossInitFunc);
    GetConfig(ThermoStyle);

    CheckConfig(CheckStylePresetVec);
    CheckStylePresetVec.clear();
    foreach (ivalue, data["CheckStylePresetVec"].toArray()) {
        QVector<int> vec;
        foreach (jvalue, ivalue.toArray()) {
            vec.append(jvalue.toInt());
        }
        CheckStylePresetVec.append(vec);
    }

    CheckConfig(TherStylePresetVec);
    TherStylePresetVec.clear();
    foreach (ivalue, data["TherStylePresetVec"].toArray()) {
        QVector<int> vec;
        foreach (jvalue, ivalue.toArray()) {
            vec.append(jvalue.toInt());
        }
        TherStylePresetVec.append(vec);
    }
}


EAPSetPage::~EAPSetPage(){
    foreach (auto iHighlighte, pythonHighlighter){
        if (iHighlighte) delete iHighlighte;
    }
    pythonHighlighter.clear();
}


void EAPSetPage::init(QJsonObject &rootObj) {

	/*--------------------------------------add actions--------------------------------------------*/
	// Set Page Select
	connect(ui.SetChangeFunButton, &QPushButton::clicked, frame->ui.actionFun, &QAction::triggered);
	connect(ui.SetChangeTarButton, &QPushButton::clicked, frame->ui.actionTar, &QAction::triggered);
	connect(ui.SetChangeMinButton, &QPushButton::clicked, frame->ui.actionMin, &QAction::triggered);
	connect(ui.SetChangeOthButton, &QPushButton::clicked, frame->ui.actionOth, &QAction::triggered);
	connect(ui.SetChangeRunButton, &QPushButton::clicked, frame->ui.actionRun, &QAction::triggered);

	/*-------------------------------------Action processing----------------------------------------*/

    connect(frame->ui.actionFun, &QAction::triggered, this, &EAPSetPage::FunPageRaise);
    connect(frame->ui.actionTar, &QAction::triggered, this, &EAPSetPage::TarPageRaise);
    connect(frame->ui.actionMin, &QAction::triggered, this, &EAPSetPage::MinPageRaise);
    connect(frame->ui.actionOth, &QAction::triggered, this, &EAPSetPage::OthPageRaise);
    connect(frame->ui.actionRun, &QAction::triggered, this, &EAPSetPage::RunPageRaise);

    func->Initialize();
	TarPageInitialize();
	MinPageInitialize();
	OthPageInitialize();
	RunPageInitialize();

    if (rootObj.contains("appdir")) {
        QDir dir(rootObj["appdir"].toString());
        ui.OthEAPOTEdit->setText(dir.absolutePath());
    }

    if (rootObj.contains("chkdir")) {
        QDir dir(rootObj["chkdir"].toString());
        ui.OthLAMMPSEdit->setText(dir.absolutePath());
    }

    EAPSetPage::FunPageRaise();
}

#define SetUnChecked()                      \
ui.SetChangeFunButton->setChecked(false);   \
ui.SetChangeTarButton->setChecked(false);   \
ui.SetChangeMinButton->setChecked(false);   \
ui.SetChangeOthButton->setChecked(false);   \
ui.SetChangeRunButton->setChecked(false);   \
frame->PageRaise(MainPage::EAMFit);

void EAPSetPage::FunPageRaise() {
    SetUnChecked();
    ui.SetPage->setCurrentIndex(0);
    ui.SetChangeFunButton->setChecked(true);
}
void EAPSetPage::TarPageRaise() {
    SetUnChecked();
    ui.SetPage->setCurrentIndex(1);
    ui.SetChangeTarButton->setChecked(true);
}
void EAPSetPage::MinPageRaise() {
    SetUnChecked();
    ui.SetPage->setCurrentIndex(2);
    ui.SetChangeMinButton->setChecked(true);
}
void EAPSetPage::OthPageRaise() {
    SetUnChecked();
    ui.SetPage->setCurrentIndex(3);
    ui.SetChangeOthButton->setChecked(true);
}
void EAPSetPage::RunPageRaise() {
    SetUnChecked();
    ui.SetPage->setCurrentIndex(4);
    ui.SetChangeRunButton->setChecked(true);
}


void EAPSetPage::TarPageInitialize() {

    /*-------------------------------------add actions----------------------------------------------*/
    connect(ui.TarAddButton, &QPushButton::clicked, frame->ui.actionAddTarMDJson, &QAction::triggered);

    /*-------------------------------------Action processing----------------------------------------*/
    connect(frame->ui.actionAddTarMDJson, &QAction::triggered, this, [=]() {
        frame->PageRaise(MainPage::EAMFit);
        AddTarRowMDFiles();
    });

    connect(ui.TarMDList, &QListWidget::itemSelectionChanged, this, &EAPSetPage::MDSelectionChanged);
    connect(ui.TargetAttrView->ui.ReferenceButton, &QPushButton::clicked, this, &EAPSetPage::MDRefButtomOnClicked);

}


MinAlgoWidgetItem::MinAlgoWidgetItem(QWidget* parent, const QString& type)
    : QWidget(parent)
    , item(MinAlgoListItem(type)) {
    item.widget = this;
}


#define AddLineEdit(Title, line, value) {            \
    QLabel* label = new QLabel(this);                \
    label->setText(tr(Title));                       \
    ui.gridLayout->addWidget(label, line, 0, 1, 1);  \
                                                     \
    QLineEdit* edit = new QLineEdit(this);           \
    edit->setMinimumSize(QSize(0, 22));              \
    edit->setText(value);                            \
    ui.gridLayout->addWidget(edit,  line, 1, 1, 1);  \
    lineEdits.append(edit);                          \
    edit->setProperty("name", Title);                \
}


MinAlgoWidgetItemNormal::MinAlgoWidgetItemNormal(QWidget* parent, const QString& type)
    : MinAlgoWidgetItem(parent, type)
{
    ui.setupUi(this);

    int idx = EAPSetPage::AlgoStyleFull.indexOf(type);

    int line = 4;
    auto AddEdit = [=, &line](const char* Title, const char* JsonKey, QString value) {
        QLabel* label = new QLabel(this);
        label->setText(tr(Title));
        ui.gridLayout->addWidget(label, line, 0, 1, 1);

        QLineEdit* edit = new QLineEdit(this);
        edit->setMinimumSize(QSize(0, 22));
        edit->setText(value);
        edit->setProperty("JsonKey", JsonKey);
        ui.gridLayout->addWidget(edit,  line, 1, 1, 1);
        lineEdits.append(edit);
        line++;
    };

    if (type == "Powell conjugate gradient"){
        ui.MinSetTolIterEdit->setText("20");
        ui.MinSetTolEvalEdit->setText("5000");

        line = 4;
        AddEdit("dmax",  "setMinDmax", "5e-3");
    }
    if (type == "Conjugate gradient"){
        ui.MinSetTolIterEdit->setText("20");
        ui.MinSetTolEvalEdit->setText("1000");

        line = 4;
        AddEdit("dmax",  "setMinDmax", "1e-2");
        AddEdit("delta", "setMinDelta", "1e-8");
    }
    else if (type == "Particle swarm/taka"){
        line = 4;
        AddEdit("seed",  "setRandomSeed", "1");
        AddEdit("particle", "setParticleSwarmTakaParticles", "50");
    }
    else if (type == "Simulated annealing/b"){
        line = 4;
        AddEdit("seed",  "setRandomSeed", "1");
    }
    else if (type == "Differential evolution/a"){
        ui.MinSetTolIterEdit->setText("40");
        ui.MinSetTolEvalEdit->setText("5000");

        line = 4;
        AddEdit("seed",  "setRandomSeed", "1");
        AddEdit("gene",  "setDifferentialEvolutionGeneNum", "20");
        AddEdit("range", "setDifferentialEvolutionInitRange", "0.4");
        AddEdit("mut",   "setDifferentialEvolutionMutRat", "0.8");
        AddEdit("cross", "setDifferentialEvolutionCrossRat", "0.7");
    }

    ui.infoLabel->setText(EAPSetPage::AlgoStyleInfo[idx]);
}

QStringList MinAlgoWidgetItemNormal::SkipList = {
    "MinSetTolEEdit",
    "MinSetToldEEdit",
    "MinSetTolIterEdit",
    "MinSetTolEvalEdit",

    "MinAlgoTypeComb",
    "MinAlgoTypeShort"
};

void MinAlgoWidgetItemNormal::importJson(const QJsonObject& obj){


    EAPIO::SetJsonKey(obj, "MinSetTolEEdit", ui.MinSetTolEEdit);
    EAPIO::SetJsonKey(obj, "MinSetToldEEdit", ui.MinSetToldEEdit);
    EAPIO::SetJsonKey(obj, "MinSetTolIterEdit", ui.MinSetTolIterEdit);
    EAPIO::SetJsonKey(obj, "MinSetTolEvalEdit", ui.MinSetTolEvalEdit);

    foreach (QLineEdit* iEdit, lineEdits){
        EAPIO::SetJsonKey(obj, iEdit->property("JsonKey").toString(), iEdit);
    }
}

QJsonObject MinAlgoWidgetItemNormal::exportJson(){
    QJsonObject obj;

    QString fullName = item.text();
    int idx = EAPSetPage::AlgoStyleFull.indexOf(fullName);

    obj.insert("MinAlgoTypeComb", fullName);
    obj.insert("MinAlgoTypeShort", EAPSetPage::AlgoStyleShort[idx]);

    obj.insert("MinSetTolEEdit", ui.MinSetTolEEdit->text());
    obj.insert("MinSetToldEEdit", ui.MinSetToldEEdit->text());
    obj.insert("MinSetTolIterEdit", ui.MinSetTolIterEdit->text());
    obj.insert("MinSetTolEvalEdit", ui.MinSetTolEvalEdit->text());

    foreach (QLineEdit* iEdit, lineEdits) {
       obj.insert(iEdit->property("JsonKey").toString(), iEdit->text());
    }

    return obj;
}

#define GetMinAlgoTypeListCurrentItem()                                                         \
    MinAlgoListItem* item = static_cast<MinAlgoListItem*>(ui.MinAlgoTypeList->currentItem());   \
    if (item == NULL) return;

void EAPSetPage::MinPageInitialize() {
	/*------------------------------------ComboBox initialization-----------------------------------*/
    QStringList list = { "Add Algorithms..." };
    for (auto val : setPage->AlgoStyleFull) {
        list << QApplication::translate("EAPFrameClass", val.toLatin1(), Q_NULLPTR);
	}
    ui.MinAlgoTypeComb->insertItems(0, list);
    ui.MinAlgoTypeComb->setCurrentIndex(0);
    ui.MinAlgoTypeComb->insertSeparator(1);
    minAlgoDefaultWidget = ui.MinScrollArea->widget();


    connect(ui.MinAlgoTypeComb,static_cast<void (QComboBox:: *)(int index)>
        (&QComboBox::currentIndexChanged), this, [=](int) {
        if (ui.MinAlgoTypeComb->currentIndex() == 0) return;

        MinAlgoListCreate(ui.MinAlgoTypeComb->currentText());
        ui.MinAlgoTypeList->setCurrentRow(ui.MinAlgoTypeList->count()-1);

        ui.MinAlgoTypeComb->setCurrentIndex(0);
    });

    connect(ui.MinAlgoTypeList, &QListWidget::currentRowChanged, this, [=](int) {

        MinAlgoListItem* item = static_cast<MinAlgoListItem*>(ui.MinAlgoTypeList->currentItem());

        ui.MinScrollArea->takeWidget();
        QWidget* widget = item ? item->widget : minAlgoDefaultWidget;
        ui.MinScrollArea->setWidget(widget);
    });

    connect(ui.MinAlgoDeleteButton, &QPushButton::clicked, this, [=](int) {
        int idx = ui.MinAlgoTypeList->currentRow();
        if (idx < 0) return;

        MinAlgoListItem* item = (MinAlgoListItem*)ui.MinAlgoTypeList->takeItem(idx);

        if (idx >= ui.MinAlgoTypeList->count()) idx--;
        ui.MinAlgoTypeList->setCurrentRow(idx);

        delete item->widget;
    });

    connect(ui.MinAlgoUpButton, &QPushButton::clicked, this,   [=](int) { MinAlgoListMove(-1);});

    connect(ui.MinAlgoDownButton, &QPushButton::clicked, this, [=](int) { MinAlgoListMove(1);});
}

MinAlgoWidgetItem* EAPSetPage::MinAlgoListCreate(const QString& type){

    MinAlgoWidgetItemNormal* widget =
            new MinAlgoWidgetItemNormal(this, type);
    widget->item.setSizeHint(QSize(0, 30));

    ui.MinAlgoTypeList->addItem(&widget->item);
    return widget;
}

void EAPSetPage::MinAlgoListMove(int dir){

    int oldIdx = ui.MinAlgoTypeList->currentRow();
    int newIdx = oldIdx + dir;

    if (newIdx < 0 || newIdx >= ui.MinAlgoTypeList->count()) return;

    MinAlgoListItem* item = (MinAlgoListItem*)ui.MinAlgoTypeList->takeItem(oldIdx);

    ui.MinAlgoTypeList->insertItem(newIdx, item);
    ui.MinAlgoTypeList->setCurrentRow(newIdx);

}

void EAPSetPage::OthPageInitialize() {

	connect(ui.OthEAPOTButton, &QPushButton::clicked, this, [=]() {
		QString strFile = QFileDialog::getOpenFileName(this,
			tr("load EAPOT"), ui.OthEAPOTEdit->text(), tr("EAPOT (*)"));

        if (!strFile.isEmpty()) ui.OthEAPOTEdit->setText(strFile);
    });

    connect(ui.OthLAMMPSButton, &QPushButton::clicked, this, [=]() {
		QString strFile = QFileDialog::getOpenFileName(this,
			tr("load LAMMPS"), ui.OthEAPOTEdit->text(), tr("LAMMPS (*)"));

        if (!strFile.isEmpty()) ui.OthLAMMPSEdit->setText(strFile);
    });

	connect(ui.OthTaskDirButton, &QPushButton::clicked, this, [=]() {
		QString strFile = QFileDialog::getExistingDirectory(this,
			tr("load task dir"), ui.OthTaskDirEdit->text(),
			QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

		if (!strFile.isEmpty())
			ui.OthTaskDirEdit->setText(strFile);
    });
}



void EAPSetPage::RunPageInitialize() {

	/*-------------------------------------add actions----------------------------------------------*/
	// Run Page Button action: dump once, submit task and write script
	connect(ui.RunRunOnceButton, &QPushButton::clicked, frame->ui.actionRunOnce, &QAction::triggered);
	connect(ui.RunRunWriteOnceButton, &QPushButton::clicked, frame->ui.actionRunWriteOnce, &QAction::triggered);

	connect(ui.RunRunFitButton, &QPushButton::clicked, frame->ui.actionRunFit, &QAction::triggered);
	connect(ui.RunRunWriteFitButton, &QPushButton::clicked, frame->ui.actionRunWriteFit, &QAction::triggered);

	/*-------------------------------------add actions----------------------------------------------*/

	// CheckBox action: dump as file, image and check
	connect(ui.RunImageChk, &QCheckBox::stateChanged, this, [=](int state) {
		bool enable = state == Qt::Checked;
		ui.RunImageEdit->setEnabled(enable);
		ui.RunImageWEdit->setEnabled(enable);
		ui.RunImageHEdit->setEnabled(enable);
    });
	connect(ui.RunCheckChk, &QCheckBox::stateChanged, this, [=](int state) {
		bool enable = state == Qt::Checked;
		ui.RunCheckEdit->setEnabled(enable);
		ui.RunCheckComb->setEnabled(enable);
		ui.RunCheckButton->setEnabled(enable);
    });

	/*-------------------------------------Pop-up page----------------------------------------------*/
	// Pop-up page for setting Check options
	connect(ui.RunCheckButton, &QPushButton::clicked, this, [=]() {
        QVector<bool> b = EAPIO::CheckButtonDialog(CheckStyle, tr("Check Style Select"), this);
		if (!b.empty()) {
            ui.RunCheckComb->setEditText(EAPIO::SpaceString(CheckStyle, b));
		};
    });

	// Pop-up page for setting Thermo options
	connect(ui.RunTherStyleButton, &QPushButton::clicked, this, [=]() {
        QVector<bool> b = EAPIO::CheckButtonDialog(ThermoStyle, tr("Thermo Style Select"), this);
		if (!b.empty()) {
            ui.RunTherStyleComb->setEditText(EAPIO::SpaceString(ThermoStyle, b));
			// Remember to edit the Thermo format input box
            ui.RunTherFormatEdit->setText(EAPIO::SpaceString(ThermoFmt, b));
		};
    });

	/*-------------------------------------add actions----------------------------------------------*/
	// Set the Thermo format variable
	connect(ui.RunTherStyleComb,
		static_cast<void (QComboBox:: *)(int index)>(&QComboBox::currentIndexChanged),
		this, [=](int i) {
        if (i > TherStylePresetVec.size()) return;
        QString str = EAPIO::SpaceString(ThermoFmt, TherStylePresetVec[i]);
        this->ui.RunTherFormatEdit->setText(str);
    });

	/*------------------------------------ComboBox initialization-----------------------------------*/
	QStringList Stylelist;

	// ComboBox: Check system
	Stylelist.clear();
	ui.RunCheckComb->clear();

    for (auto &val : CheckStylePresetVec) {
        Stylelist << EAPIO::SpaceString(CheckStyle, val);
	}
	ui.RunCheckComb->insertItems(0, Stylelist);

	// ComboBox: Thermo variable
	Stylelist.clear();
	ui.RunTherStyleComb->clear();

    for (auto &val : TherStylePresetVec) {
        Stylelist << EAPIO::SpaceString(ThermoStyle, val);
	}
	ui.RunTherStyleComb->insertItems(0, Stylelist);
	ui.RunTherStyleComb->setCurrentIndex(1);
	/*----------------------------------------------------------------------------------------------*/
}



#define AddItem(u) v.push_back({ #u, ui.u, EAPIO::GetWidgetType(ui.u) });

void EAPSetPage::JsonKeyInitialize() {

	QVector<JsonKey> v;
    frame->JsonKeyVec.push_back(func->JsonKeyInitialize());

	v.clear();
	frame->JsonKeyVec.push_back(v);

	v.clear();
	frame->JsonKeyVec.push_back(v);

    v.clear();
    AddItem(OthInitEdit);
	AddItem(OthPairEdit);
	AddItem(OthComEdit);
	AddItem(OthCostEdit);
    AddItem(OthCheckEdit);
	AddItem(OthFiniEdit);
	frame->JsonKeyVec.push_back(v);

	v.clear();
	AddItem(RunFileEdit);

	AddItem(RunImageChk);
	AddItem(RunImageEdit);
	AddItem(RunImageWEdit);
	AddItem(RunImageHEdit);

	AddItem(RunCheckChk);
	AddItem(RunCheckEdit);
	AddItem(RunCheckComb);

	AddItem(RunTherStepEdit);
	AddItem(RunTherStyleComb);
	AddItem(RunTherFormatEdit);
	frame->JsonKeyVec.push_back(v);
}

void EAPSetPage::ImportJson(const QJsonObject &obj) {


    if (io->ImportEnable(obj, "FunPage")) EAPIO::ImportJsonKeys(obj, "FunPage", frame->JsonKeyVec[0]);
    if (io->ImportEnable(obj, "OthPage")) EAPIO::ImportJsonKeys(obj, "OthPage", frame->JsonKeyVec[3]);
    if (io->ImportEnable(obj, "RunPage")) EAPIO::ImportJsonKeys(obj, "RunPage", frame->JsonKeyVec[4]);

    func->FunPageExtraJsonSettings(obj);

    if (obj.contains("Targets")){
        // 1.1 remove
        int rows = ui.TarMDList->count();
        for (int i = rows - 1; i >= 0; i--) {
            QListWidgetItem *listItem = ui.TarMDList->item(i);
            TarMDItem *item = qobject_cast<TarMDItem *>(ui.TarMDList->itemWidget(listItem));
            ui.TarMDList->removeItemWidget(listItem);
            ui.TarMDList->takeItem(i);
            delete listItem;
            delete item;
        }

        // 1.2 add Targets
        QJsonValue Tars = obj["Targets"];
        if (Tars.isArray()) {
            foreach(const QJsonValue& tar, Tars.toArray()){
                TarMDItem *item = CreateTarRowMD(QString());
                item->ImportJson(tar.toObject());
            }

            if(ui.TarMDList->count()){
                ui.TarMDList->setCurrentRow(ui.TarMDList->count()-1);
            }
        }
    }

    if (obj.contains("MinPage")){
        // 2.1 remove
        ui.MinAlgoTypeList->setCurrentRow(-1);
        int rows = ui.MinAlgoTypeList->count();
        for (int i = rows - 1; i >= 0; i--) {
            MinAlgoListItem* item = (MinAlgoListItem*)ui.MinAlgoTypeList->takeItem(i);
            delete item->widget;
        }

        // 2.2 add Targets
        QJsonValue minsets = obj["MinPage"];
        if (minsets.isArray()) {
            foreach(const QJsonValue& val, minsets.toArray()){
                QJsonObject minset = val.toObject();
                auto* widget = MinAlgoListCreate(minset["MinAlgoTypeComb"].toString());
                ui.MinAlgoTypeList->setCurrentRow(ui.MinAlgoTypeList->count()-1);
                widget->importJson(minset);
            }
        }
    }
}


void EAPSetPage::ExportJson(QJsonObject &obj) {

    EAPIO::ExportJsonKeys(obj, "FunPage", frame->JsonKeyVec[0]);
    EAPIO::ExportJsonKeys(obj, "OthPage", frame->JsonKeyVec[3]);
    EAPIO::ExportJsonKeys(obj, "RunPage", frame->JsonKeyVec[4]);

    obj.insert("Targets", QJsonValue(ExportJsonMD()));

    // Minimize Algorithms
    QJsonArray jarray;
    MinAlgoListItem* item = NULL;
    int rows = ui.MinAlgoTypeList->count();
    for (int i = 0; i < rows; i++) {
        item = (MinAlgoListItem*)ui.MinAlgoTypeList->item(i);
        MinAlgoWidgetItem* widget = (MinAlgoWidgetItem*)(item->widget);
        jarray.append(widget->exportJson());
    }
    obj.insert("MinPage", QJsonValue(jarray));

    // Minimize Algorithms
    QJsonObject OthObj = obj["OthPage"].toObject();
    OthObj.insert("OthEAPOTEdit", ui.OthEAPOTEdit->text());
    OthObj.insert("OthLAMMPSEdit", ui.OthLAMMPSEdit->text());
    obj.insert("OthPage", OthObj);
}


void EAPSetPage::getEleName(QStringList& vec) {
    func->getEleName(vec);
}

QStringList EAPSetPage::getTargetsName(){

    QStringList tars;
    int rows = ui.TarMDList->count();
    for (int i = rows - 1; i >= 0; i--) {
        QListWidgetItem *listItem = ui.TarMDList->item(i);
        TarMDItem *item = qobject_cast<TarMDItem *>(ui.TarMDList->itemWidget(listItem));
        tars << item->Structure_Name.c_str();
    }
    return tars;
}


QString EAPSetPage::selectTarget(){
    QLabel* label;
    QGridLayout *gridLayout;
    QListWidget* listWidget;
    QDialogButtonBox *buttonBox;

    QDialog* Dialog = new QDialog(this);
    Dialog->resize(250, 300);

    gridLayout = new QGridLayout(Dialog);
    gridLayout->setContentsMargins(5, 5, 5, 5);

    QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);

    label = new QLabel(Dialog);
    label->setText(tr("Select a reference structure"));
    gridLayout->addWidget(label, 0, 0, 1, 1);

    listWidget = new QListWidget(Dialog);

    for (QString itar : getTargetsName()) {
        QListWidgetItem* item = new QListWidgetItem(itar);
        item->setSizeHint(QSize(0, 30));
        listWidget->insertItem(0, item);
    }
    listWidget->setCurrentRow(0);
    gridLayout->addWidget(listWidget, 1, 0, 1, 1);

    buttonBox = new QDialogButtonBox(Dialog);
    buttonBox->setOrientation(Qt::Horizontal);
    buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
    gridLayout->addWidget(buttonBox, 2, 0, 1, 1);

    QObject::connect(buttonBox, SIGNAL(accepted()), Dialog, SLOT(accept()));
    QObject::connect(buttonBox, SIGNAL(rejected()), Dialog, SLOT(reject()));

    QString res = "";
    int ret = Dialog->exec();
    if (ret == QDialog::Accepted) {
        if (listWidget->currentItem()){
            res = listWidget->currentItem()->text();
        }
    }
    delete Dialog;
    return res;
}

QString EAPSetPage::getEAPOTDir() {
    return ui.OthEAPOTEdit->text();
}

QString EAPSetPage::getLAMMPSDir() {
    return ui.OthLAMMPSEdit->text();
}

QString EAPSetPage::getTaskDir() {
    return ui.OthTaskDirEdit->text();
}




