#pragma once

#include "UiPtr.h"
#include "ui_EAPSetPage.h"
#include "ui_MinAlgoBaseWidget.h"
#include "PythonHighlighter.h"
#include "EAPSetTarView.h"
#include "FuncPage.h"

namespace EAPUI_NS {

    class EAPSetPage : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
        Ui_EAPSetPage ui;
        explicit EAPSetPage(QWidget *parent, EAPUI* ptr, const QJsonObject& rootObj);

        ~EAPSetPage();
        FuncPage* func;
        void init(QJsonObject &rootObj);

	signals:
        void ElementChange();

	public slots:
        void FunPageRaise();
        void TarPageRaise();
        void MinPageRaise();
        void OthPageRaise();
        void RunPageRaise();

	public:
		void JsonKeyInitialize();
        void ImportJson(const QJsonObject &obj);
        void ExportJson(QJsonObject &obj);
        QVector<PythonHighlighter*> pythonHighlighter;

		void FunPageInitialize();
		void TarPageInitialize();
		void MinPageInitialize();
		void OthPageInitialize();
		void RunPageInitialize();

        void getEleName(QStringList& vec);
        Q_INVOKABLE QStringList getTargetsName();
        Q_INVOKABLE QString selectTarget();

	public:

		// Add a new MD target		
		void AddTarRowMDFiles();
		class TarMDItem* CreateTarRowMD(QString path);
		inline class TarMDItem* GetTarMDItem(const int i) {
			QListWidgetItem *listItem = ui.TarMDList->item(i);
			class TarMDItem *item = qobject_cast<class TarMDItem *>(ui.TarMDList->itemWidget(listItem));
			return item;
        }

		void MDSelectionChanged();
        void MDRefButtomOnClicked();

        QJsonArray ExportJsonMD();

    public:
        QString getEAPOTDir();
        QString getLAMMPSDir();
        QString getTaskDir();

        QWidget* minAlgoDefaultWidget;
        void MinAlgoListMove(int);
        class MinAlgoWidgetItem* MinAlgoListCreate(const QString&);

        static QStringList CrossInitFunc;
        static QStringList CheckStyle;
        static QStringList ThermoStyle;
        static QStringList ThermoFmt;
        static QStringList AlgoStyleFull;
        static QStringList AlgoStyleShort;
        static QStringList AlgoStyleInfo;

        static QVector<QVector<int>> TherStylePresetVec;
        static QVector<QVector<int>> CheckStylePresetVec;

	};

    class MinAlgoListItem  : public QListWidgetItem {
    public:
        MinAlgoListItem(const QString& type) : QListWidgetItem() {
            setText(type);
        }
        QWidget* widget;
    };

    class MinAlgoWidgetItem : public QWidget
    {
    public:
        MinAlgoListItem item;
        MinAlgoWidgetItem(QWidget*, const QString&);
        virtual void importJson(const QJsonObject&) = 0;
        virtual QJsonObject exportJson() = 0;
    };

    class MinAlgoWidgetItemNormal : public MinAlgoWidgetItem
    {
    public:
        Ui_MinAlgoBaseUI ui;
        QVector<QLineEdit*> lineEdits;
        MinAlgoWidgetItemNormal(QWidget*, const QString&);
        virtual void importJson(const QJsonObject&);
        virtual QJsonObject exportJson();

        static QStringList SkipList;
    };

}
