#include "EAPFrame.h"
#include "EAPSetPage.h"
#include "EAPSetTarView.h"

#include <QDebug>
#include <QComboBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QProcess>
#include <QTimer>
#include <QScrollBar>
#include <QFileDialog>

#include <QJsonParseError>
#include <QFile>
#include <QJsonObject>
#include <QJsonArray>

#include <QtCharts>
#include "EAPIO.h"
#include "AbinitoMDTool.h"
#include "ConfigAttributeWidget.h"


using namespace EAPUI_NS;
using namespace LoadConfig_NS;

void EAPSetPage::AddTarRowMDFiles() {

	QStringList Files = QFileDialog::getOpenFileNames(this,
		tr("load structure file"), TarMDItem::OpenInitDirMD, tr("Structure (*)"));

	if (Files.isEmpty()) return;

	for (auto strFile : Files) {

		if (strFile.isEmpty()) continue;

		QFileInfo fi = QFileInfo(strFile);

		if (fi.isFile()) {
			TarMDItem::OpenInitDirMD = fi.absolutePath();
			CreateTarRowMD(strFile);
		}
	}
}

TarMDItem* EAPSetPage::CreateTarRowMD(QString path) {

	QListWidgetItem *listItem = new QListWidgetItem();
    TarMDItem *item = new TarMDItem(this, eapui, listItem, path);

	ui.TarMDList->addItem(listItem);
	ui.TarMDList->setItemWidget(listItem, item);

	connect(item->DeleteButton, &QPushButton::clicked, this, [=]() {
        ui.TarMDList->removeItemWidget(listItem);
        ui.TarMDList->takeItem(ui.TarMDList->row(listItem));
        delete listItem;
        delete item;
	});

	return item;
}

QJsonArray EAPSetPage::ExportJsonMD() {

    QJsonArray jarray;
	int rows = ui.TarMDList->count();
	for (int i = 0; i < rows; i++) {
		GetTarMDItem(i)->ExportJson(jarray);
	}
    return jarray;
}

void EAPSetPage::MDSelectionChanged() {

    QVector<MDFitData*> selectTarget;
	QListWidget *list = ui.TarMDList;

	int rows = list->count();
	for (int i = 0; i < rows; i++) {
		if (list->item(i)->isSelected()) {
			selectTarget.push_back(GetTarMDItem(i));
		}
	}
    ui.TargetAttrView->initTarget(selectTarget);
    frame->statusBar()->showMessage(QString::number(selectTarget.size()) + " targets selected");
}

void EAPSetPage::MDRefButtomOnClicked(){

    QVector<MDFitData*> vec;
    QListWidget *list = ui.TarMDList;

    for (int i = 0; i < list->count(); i++) {
        if (list->item(i)->isSelected()) break;
        vec.push_back(GetTarMDItem(i));
    }
    ui.TargetAttrView->selectReference(vec);
}









QString TarMDItem::OpenInitDirMD("../res/Target");

TarMDItem::TarMDItem(QWidget *parent, EAPUI* eapui, QListWidgetItem *plistItem, const QString& argv)
    : QWidget(parent)
    , UiPtr(eapui)
    , listItem(plistItem)
    , configAttributeView(setPage->ui.TargetAttrView)
{
	Layout = new QHBoxLayout(this);
	Layout->setSpacing(0);
	Layout->setContentsMargins(2, 2, 2, 2);

	nameEdit = new QClickLabel(this);
	Layout->addWidget(nameEdit);
	connect(nameEdit, &QClickLabel::textChanged, this, [=]() {
		Structure_Name = nameEdit->text().toLatin1().data(); });

	WeightEdit = new QLineEdit(this);
	WeightEdit->setMinimumSize(QSize(40, 0));
	WeightEdit->setMaximumSize(QSize(40, 16777215));
	Layout->addWidget(WeightEdit);
	connect(WeightEdit, &QLineEdit::editingFinished, this, [=]() {
		Global_Weight = WeightEdit->text().toDouble(); });

	DeleteButton = new QPushButton(this);
	DeleteButton->setMinimumSize(QSize(25, 23));
	DeleteButton->setMaximumSize(QSize(25, 23));
	DeleteButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_TitleBarCloseButton));
	DeleteButton->setIconSize(QSize(16, 16));

	Layout->addWidget(DeleteButton);
	listItem->setSizeHint(QSize(0, 26));

    if(!argv.isEmpty()){
        QJsonObject obj = io->loadJsonObject(argv);
        if(!obj.empty()){
            ImportJson(obj);
        }
        else{
            Global_Weight = 1.0;
            Structure_Name = QFileInfo(argv).baseName().toLatin1().data();

            nameEdit->setText(Structure_Name.c_str());
            WeightEdit->setText(QString::number(Global_Weight));

            QFile file(argv);
            bool ok = file.open(QIODevice::ReadOnly);
            if(ok){
                QByteArray byte = file.readAll().replace("\r\n", "\n");

                file.close();
                Structure_Information = byte.data();

                AtomConfigData data(1);
                AtomConfigLoad load(&data);
                load.read_head(argv.toLocal8Bit().data());

                Domain_Target[0] = data.basis[0][0];
                Domain_Target[1] = data.basis[1][1];
                Domain_Target[2] = data.basis[2][2];
                Domain_Target[3] = data.basis[1][0];
                Domain_Target[4] = data.basis[2][0];
                Domain_Target[5] = data.basis[2][1];


                MDFitData::resize(data.num);
            }
        }
    }
};


/****************************************************************************************************/
// Load Json settings
/****************************************************************************************************/

#define evalDouble(Key) if (obj.contains(#Key)) Key = obj[#Key].toDouble();
#define evalString(Key)	if (obj.contains(#Key)) Key = obj[#Key].toString().toLatin1().data();

QString TarMDItem::ImportJson(const QJsonObject &obj) {

	evalDouble(Global_Weight);
	evalString(Structure_Name);

    configAttributeView->importJson(this, obj);

	nameEdit->setText(Structure_Name.c_str());
	WeightEdit->setText(QString::number(Global_Weight));

	return "";
}

#undef evalDouble
#undef evalString

#define evalString(Key) obj.insert(#Key, Key.c_str());
#define evalDouble(Key) obj.insert(#Key, Key);

void TarMDItem::ExportJson(QJsonArray &jarray){

	QJsonObject obj;
	evalDouble(Global_Weight);
	evalString(Structure_Name);

    configAttributeView->exportJson(this, obj);

	jarray.append(QJsonValue(obj));
}

#undef _Get

