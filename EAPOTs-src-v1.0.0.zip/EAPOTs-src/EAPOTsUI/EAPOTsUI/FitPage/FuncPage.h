#pragma once

#include "UiPtr.h"
#include <QWidget>
#include <QJsonObject>
#include <QQuickWidget>

namespace Ui {
class CrossPage;
class SinglePage;
}

namespace EAPUI_NS {

    class FuncPage : public QWidget, public UiPtr
    {
        Q_OBJECT

    public:
        explicit FuncPage(QWidget *parent, EAPUI* ptr);        

        virtual void Initialize() = 0;
        virtual QVector<JsonKey> JsonKeyInitialize() = 0;
        virtual void FunPageExtraJsonSettings(const QJsonObject &){};
        virtual void getEleName(QStringList& vec) = 0;

        virtual void importJson(const QJsonObject&) = 0;
        virtual QJsonObject exportJson() = 0;
    };

    class CrossPage : public FuncPage
    {
        Q_OBJECT

    public:
        explicit CrossPage(QWidget *parent, EAPUI* ptr);
        ~CrossPage();

        void Initialize();
        QVector<JsonKey> JsonKeyInitialize();
        void FunPageExtraJsonSettings(const QJsonObject &);
        void getEleName(QStringList& vec);

    private:
        Ui::CrossPage *ui;
    };

    class SinglePage : public FuncPage
    {
        Q_OBJECT

    public:
        explicit SinglePage(QWidget *parent, EAPUI* ptr);
        ~SinglePage();

        void Initialize();
        void createFuncParamPage();
        QVector<JsonKey> JsonKeyInitialize();
        void getEleName(QStringList& vec);

        virtual void importJson(const QJsonObject&);
        virtual QJsonObject exportJson();

    private:
        Ui::SinglePage *ui;
        QJsonObject funcExtraParam;
        QQuickWidget* getCurrentExtraParamWidget();
    };

}
