#pragma once

#include "UiPtr.h"

#include <QDir>
#include <QStatusBar>
#include <QHBoxLayout>
#include <QPushButton>
#include <QListWidgetItem>
#include "AbinitoMDTool.h"
#include "EAExtraWidget.h"

namespace EAPUI_NS {

    class TarMDItem : public QWidget, public UiPtr, public LoadConfig_NS::MDFitData
	{
		Q_OBJECT
	public:
        explicit TarMDItem(QWidget *parent, EAPUI* ptr,
            QListWidgetItem *plistItemm, const QString& argv);

	signals:


	public slots:
	public:	

		QListWidgetItem *listItem;
		static QString OpenInitDirMD;

		QHBoxLayout *Layout;
		QClickLabel *nameEdit;
		QLineEdit *WeightEdit;
		QPushButton *DeleteButton;

	public:

        QString ImportJson(const QJsonObject &obj);
        void ExportJson(QJsonArray &jarray);

	private:
        class ConfigAttributeView* configAttributeView;

	};

}
