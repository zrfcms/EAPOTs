#include "AbinitioPage.h"
#include "AbinitioModify.h"
#include <QProgressDialog>
#include <EAPIO.h>

using namespace EAPUI_NS;
using namespace LoadConfig_NS;


// task verticalLayout

int AbInitioCreate::CreateTask() {

	QAbinitioModifyTask* newtask;
	QListWidget* list = cui.AbCreateList;

	int rows = list->count();
	for (int i = 0; i < rows; i++) {
		AbCreateItem *item = GetCreateItem(i);
		if (!list->item(i)->isSelected()) {
			continue;
		}

		AtomConfigData* config = &item->original;
		switch (getConfigRadioButton(i)) {
		case 0: config = &item->original; break;
		case 1: config = &item->primitive; break;
		case 2: config = &item->standard; break;
		}

		newtask = new QAbinitioModifyTask(*config);
		newtask->timestep = timestep;
		task.push_back(newtask);

		ModifyModel->appendRow(new QStandardItem(item->ui.nameEdit->text()));
	}

	if (task.size() <= 0) return 0;

	QModelIndex curIndex = ModifyModel->index(0, 0);
	ModifySelect->clearSelection();
	ModifySelect->setCurrentIndex(curIndex, QItemSelectionModel::Select);

    return static_cast<int>(task.size());
}


void AbInitioCreate::createModify(int type) {

	QWidget *widget;
	QAbinitioModifyEnum typeEnum;

	switch (type)
	{
	case 1: typeEnum = QAbinitioModifyEnum::Transform;
        widget = new QAbinitioTransformWidget(abInitio); break;
	case 2: typeEnum = QAbinitioModifyEnum::Displace;
        widget = new QAbinitioDisplaceWidget(abInitio); break;
	case 3: typeEnum = QAbinitioModifyEnum::Replicate;
        widget = new QAbinitioReplicateWidget(abInitio); break;
	default: return;
	}

	mui.verticalLayout->insertWidget(mui.verticalLayout->count() - 1, widget);

	for (auto itask : task) {
		itask->addModify(typeEnum);
		itask->update(mui.verticalLayout);
	}
}


void AbInitioCreate::AcceptModifyMode() {

	timestep++;

	QDir Export;
	QString name;
	SaveTaskItem* taskWidget;
	EAListWidget *list = cui.SaveListWidget;

    QString stime = QString::number(timestep);
	QString suffix = mui.lineEdit->text();
		
	if (!suffix.isEmpty()) {
		suffix = "." + suffix;
	}

	bool autosave = mui.AutoSaveBox->isChecked();

	if (autosave) {
		Export = cui.CreateSavePathEdit->text();
		if (!Export.exists()) {
			Export.mkdir("./");
		}
	}

    int i;
    if (autosave) io->ProgressDialogStart(0, task.size());

    for (i = 0; i < task.size(); i++) {

        name = ModifyModel->item(static_cast<int>(i), 0)->text() + suffix;
        taskWidget = new SaveTaskItem(abInitio, name, task[i]);
		taskWidget->timeLabel->setText(stime);
		list->addNewItem(taskWidget);

		if (autosave) {
			if (cui.AddOperateStepBox->isChecked()) {
				name += "." + stime;
			}
			name = Export.absoluteFilePath(name + ".POSCAR");
			AbExport(name, &task[i]->after, taskWidget->saveLabel);

            io->progress->setValue(i + 1);
            if (io->progress->wasCanceled()) break;
            QCoreApplication::processEvents();
		}
	}

    if (autosave){
        QString msg = QString("Export %1 structures into %2").arg(i).arg(Export.absolutePath());
        io->ProgressDialogFinish(false, msg);
    }

	ExitModifyMode();
}

void AbInitioCreate::RejectModifyMode() {

	for (auto itask : task) {
		delete itask;
	}

	ExitModifyMode();
}

void AbInitioCreate::ExitModifyMode() {

	task.clear();
	ModifyModel->clear();

	QWidget *widget;

	for (int i = mui.verticalLayout->count() - 2; i >= 0; i--) {
		widget = mui.verticalLayout->itemAt(i)->widget();
		mui.verticalLayout->removeWidget(widget);
		delete widget;
	}

	ui.CreateStackedWidget->setCurrentIndex(0);
    CurrentRowChanged(cui.AbCreateList->currentRow());
}

void AbInitioCreate::ModifyUpdate() {

	for (auto itask : task) {
		itask->update(mui.verticalLayout);
	}

	updateGLWidget();
}

void AbInitioCreate::updateGLWidget()
{
	QModelIndex curIndex = ModifySelect->currentIndex();
	// ModifySelect->setCurrentIndex(curIndex, QItemSelectionModel::Select);

	int idx = curIndex.row();
	ui.StructureBeforeGLWidget->setConfig(0, &task[idx]->before);
	ui.StructureAfterGLWidget->setConfig(0, &task[idx]->after);

	ui.StructureBeforeGLWidget->update();
	ui.StructureAfterGLWidget->update();
}


QAbinitioModifyTask::QAbinitioModifyTask(LoadNSData& pconfig)
	: after(1)
	, before(1)
{
	before.copy(&pconfig);
	after.copy(&before);
}

QAbinitioModifyTask::~QAbinitioModifyTask() {
    for (int i = static_cast<int>(modify.size() - 1); i >= 0; i--) {
        delete modify[i];
	}
}


void QAbinitioModifyTask::addModify(QAbinitioModifyEnum type) {
	switch (type) {
	case QAbinitioModifyEnum::Transform:
		modify.push_back(new QAbinitioTransformData(&after));
		break;
	case QAbinitioModifyEnum::Displace:
		modify.push_back(new QAbinitioDisplaceData(&after));
		break;
	case QAbinitioModifyEnum::Replicate:
		modify.push_back(new QAbinitioReplicateData(&after));
		break;
	default:
		break;
	}
}

void QAbinitioModifyTask::update(QVBoxLayout* widgets) {

	after.copy(&before);
    for (int i = 0; i < modify.size(); i++) {
		modify[i]->update(widgets->itemAt(i)->widget(), &after);
	}
	after.warpByPBC(NULL);
}


SaveTaskItem::SaveTaskItem(QWidget *parent, const QString& argv, QAbinitioModifyTask* ptask)
	: EAListWidgetItem(parent)
{
	task = ptask;

    nameEdit = new QClickLabel(this);
	nameEdit->setText(argv);
	mainLayout->insertWidget(0, nameEdit);

	timeLabel = new QLabel(this);
    timeLabel->setMinimumSize(QSize(40, 0));
    timeLabel->setMaximumSize(QSize(30, 16777215));
	timeLabel->setAlignment(Qt::AlignCenter);
	mainLayout->insertWidget(1, timeLabel);

	saveLabel = new QLabel(this);
    saveLabel->setMinimumSize(QSize(60, 0));
    saveLabel->setMaximumSize(QSize(50, 16777215));
	saveLabel->setAlignment(Qt::AlignCenter);
	saveLabel->setText("[Unsaved]");
	mainLayout->insertWidget(2, saveLabel);	
};

SaveTaskItem::~SaveTaskItem() {
	delete task;
};
