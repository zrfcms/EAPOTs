#include "AbInitioPage.h"
#include "EAPIO.h"

#include <QSize>
#include <QFileDialog>
#include "EAPFrame.h"
#include "EAPSetPage.h"
#include "EAPlotPage.h"

#include "AtomConfig.h"
#include "EAPlotPage.h"
#include "spglib/spglib.h"
#include "AbinitioModify.h"
#include "FileBrowserPage.h"
#include <QProgressDialog>
#include <QMessageBox>

using namespace EAPUI_NS;
using namespace LoadConfig_NS;

AbParseItem::AbParseItem(QWidget *parent, const QString&
             argv, AbInitioParse* pParsePage)
    : EAListWidgetItem(parent)
    , LoadVaspData()
    , parsePage(pParsePage)
{

    QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);

    nameEdit = new QClickLabel(this);
    nameEdit->setText(argv);
    nameEdit->setSizePolicy(sizePolicy);
    insertWidget(nameEdit, 4);

    GroundEnergyLabel = new QLabel(this);
    GroundEnergyLabel->setText("");
    GroundEnergyLabel->setSizePolicy(sizePolicy);
    GroundEnergyLabel->setAlignment(Qt::AlignCenter);
    insertWidget(GroundEnergyLabel, 4);

    FormationEnergyEdit = new QClickLabel(this);
    FormationEnergyEdit->setText("");
    FormationEnergyEdit->setSizePolicy(sizePolicy);
    FormationEnergyEdit->setAlignment(Qt::AlignCenter);
    insertWidget(FormationEnergyEdit, 4);

    status = new QLabel(this);
    status->setText("");
    status->setSizePolicy(sizePolicy);
    status->setAlignment(Qt::AlignCenter);
    insertWidget(status, 8);

    saveStatus = new QLabel(this);
    saveStatus->setMaximumWidth(60);
    saveStatus->setText("Unsaved");
    saveStatus->setSizePolicy(sizePolicy);
    saveStatus->setAlignment(Qt::AlignCenter);
    insertWidget(saveStatus, 2);

    connect(FormationEnergyEdit, &QClickLabel::textChanged,
            this, &AbParseItem::EformationChanged);
};

void AbParseItem::setEformation(double val){
    QString str = QString::number(parsePage->EformFlag*val);
    FormationEnergyEdit->setText(str);
}

double AbParseItem::getEformation(){
    return parsePage->EformFlag*FormationEnergyEdit->text().toDouble();
}

bool AbParseItem::CheckIfErrorOccurs(LoadErrorType err) {
    if (err != LoadErrorType::NONE) {
        const char* msg = AtomConfigLoad::error_msg(err);
        status->setText(msg);
        return true;
    }
    return false;
}



AbInitioParse::AbInitioParse(QWidget *parent, class AbInitioPage* pAbInitio)
    : QObject(parent), UiPtr(pAbInitio->eapui)
    , ui(pAbInitio->ui) {    

    EformFlag = 1;

    if (eapui->FitMode == EAPUI::SINGLE){
        EformFlag = -1;
        ui.EformLabel->setText("Ecoh");
        ui.ParseFormationEnergyCorrectionChk->setText("Cohesive Energy Correction");
    }



    OpenInitDirAbParse = ui.ParseLoadPathEdit->text();
}

void AbInitioParse::initialize(){
    QString getParseLoadPath = "get Parse Load Path";
    QString getParseSavePath = "get Parse Save Path";
    EAPIO::connectButtonDirEdit(ui.ParseLoadPathButton, getParseLoadPath, ui.ParseLoadPathEdit);
    EAPIO::connectButtonDirEdit(ui.ParseSavePathButton, getParseSavePath, ui.ParseSavePathEdit);

    connect(ui.ParseAddButton, &QPushButton::clicked, this, &AbInitioParse::AddAuto);

    connect(ui.ParseAutoLoadButton, &QPushButton::clicked, this, [=]() {
        QStringList Files = EAPIO::AutoOpenFile(ui.ParseLoadPathEdit->text(), QStringList({ "CONTCAR", "POSCAR", "*.vasp" }));

        int idx, parseErrNum = 0;
        io->ProgressDialogStart(0, Files.size());
        for (idx = 0; idx < Files.size(); idx++) {
            parseErrNum += AddOnce(Files[idx]);
            io->progress->setValue(idx + 1);
            if (io->progress->wasCanceled()) break;
            QCoreApplication::processEvents();
        }
        QString msg = QString("%1 structures have been parsed").arg(idx);
        io->ProgressDialogFinish(true, msg);

        throwErrMsgIfNeed(parseErrNum);
    });

    connect(ui.ParseExportAutoButton, &QPushButton::clicked, this, &AbInitioParse::Export);
    connect(ui.ParseExportManualButton, &QPushButton::clicked, this, [=](){

        int i = ui.AbParseList->currentRow();
        if (i < 0) return;

        QString file = QFileDialog::getSaveFileName(abInitio, tr("save json file"),
            ui.ParseSavePathEdit->text(), tr("Target Json(*.json)"));

        AbParseItem *item = GetParseItem(i);
        item->saveStatus->setText("Saved");
        item->customSavePath = file.toLocal8Bit().data();
        item->exportData(file.toLocal8Bit().data(), ui.DumpLammpsDataBox->isChecked());
        item->customSavePath = "";
    });

    connect(ui.TargetAttrView->ui.ReferenceButton, &QPushButton::clicked, this, &AbInitioParse::MDRefButtomOnClicked);
    connect(ui.AbParseList, &QListWidget::itemSelectionChanged, this, &AbInitioParse::SelectionChanged);
    connect(ui.AbParseList, &QListWidget::currentRowChanged, this, &AbInitioParse::CurrentRowChanged);

    connect(ui.ParseFormationEnergyCorrectionChk, &QPushButton::clicked, this, [=](bool checked){
        for (int i = 0; i < ui.AbParseList->count(); i++) {
            updateEnergyByFormation(GetParseItem(i));
        }        
    });
    connect(ui.ParseNormalByAtomChk, &QPushButton::clicked, this, [=](bool checked){
        for (int i = 0; i < ui.AbParseList->count(); i++) {
            updateEnergyByFormation(GetParseItem(i));
        }
    });
}


void AbInitioParse::throwErrMsgIfNeed(int n){
    if (n){
        QString msg = QString::number(n) + tr(" structures parsed may be unreliable") + "\n";
        msg += tr("MapAtomTypeNumber due to inconsistent element types in Preset Page") + "\n";
        msg += tr("OUTCARInsufficInfo due to OUTCAR File format issues\n");
        QMessageBox::warning(abInitio, tr("warning"), msg, QMessageBox::Ok, QMessageBox::Ok);
    }
}


void AbInitioParse::CurrentRowChanged(int currentRow) {

    if (currentRow < 0) return;

    AbParseItem* item = GetParseItem(currentRow);
    AtomConfigData* config = &item->config;


    ui.ParseGLWidget->setConfig(0, config);
    ui.ParseGLWidget->update();

    // Update Information PlainEdit
    QString info = "", buf;
    QPlainTextEdit* text = ui.ParseInfoTextEdit;

    for (int i = 0; i < config->ntype; i++) {
        info += buf.sprintf("%6s ", config->eleName[i].c_str());
    }
    info += buf.sprintf(" Total\n");
    for (int i = 0; i < config->ntype; i++) {
        info += buf.sprintf("%6d ", config->eleNum[i]);
    }
    info += buf.sprintf("%6d\n", config->num);

    info += buf.sprintf("Delta Energy: %.16g", item->getEformation() * item->config.num);

    text->setPlainText(info);
}


bool inSuffixList(const QString& ifile, const QStringList& suffixs){
    foreach (QString isuffix, suffixs){
        if(ifile.endsWith(isuffix)) {
            return true;
        }
    }
    return false;
}

void AbInitioParse::AddAuto(){
    QStringList StructFiles, FileExits, OUTCARLoadFailed;
    QStringList FileLoad = QFileDialog::getOpenFileNames(nullptr,
        tr("load vasp files"), OpenInitDirAbParse,
        "Vasp CONTCAR (*.CONTCAR);;"
        "Vasp OUTCAR (*.OUTCAR);;"
        "Vasp Structure (*.POSCAR *.vasp)");

    if (FileLoad.isEmpty()) return;

    QDir FileDir(OpenInitDirAbParse);
    OpenInitDirAbParse = QFileInfo(FileLoad.last()).absolutePath();

    for (auto ifile : FileDir.entryInfoList()) {
        if (!ifile.isFile()) continue;

        QString name = ifile.fileName();
        if (name[0] == '.') continue;
        FileExits << name;
    }
    QStringList structSuffix = { ".CONTCAR", ".POSCAR", ".vasp" };

    foreach (QString ifile, FileLoad) {

        if(inSuffixList(ifile, structSuffix)) {
            StructFiles.append(ifile);

        }
        else {
            QString correspondStructFile;
            QString baseName = QFileInfo(ifile).completeBaseName();

            foreach (QString isuffix, structSuffix){
                if (FileExits.contains(baseName + isuffix)){
                    correspondStructFile = baseName + isuffix;
                    break;
                }
            }

            if(correspondStructFile.isEmpty()){
                OUTCARLoadFailed.append(ifile);
            } else {
                if (!StructFiles.contains(correspondStructFile)){
                    StructFiles.append(FileDir.absoluteFilePath(correspondStructFile));
                }
            }
        }
    }

    int idx, parseErrNum = 0;
    io->ProgressDialogStart(0, StructFiles.size());
    for (idx = 0; idx < StructFiles.size(); idx++) {
        parseErrNum += AddOnce(StructFiles[idx]);
        io->progress->setValue(idx + 1);
        if (io->progress->wasCanceled()) break;
        QCoreApplication::processEvents();
    }
    QString msg = QString("%1 structures have been parsed").arg(idx);
    io->ProgressDialogFinish(true, msg);

    int OUTCARLoadFailedNum = OUTCARLoadFailed.size();
    if (OUTCARLoadFailedNum) {
        QString info1 = tr(" structures have been parsed\n");
        QString info2 = tr(" failed due to lack of structure file\n");
        msg = QString("%1 %2 %3 %4").arg(idx).arg(info1).arg(OUTCARLoadFailedNum).arg(info2);
        for (QString ierr : OUTCARLoadFailed){
            msg += ierr + '\n';
        }
        QMessageBox::warning(abInitio, tr("warning"), msg, QMessageBox::Ok, QMessageBox::Ok);
    }

    throwErrMsgIfNeed(parseErrNum);
}


int AbInitioParse::AddOnce(const QString& path) {

    // create a AbParseItem

    QFileInfo FileInfo(path);
    QString StructName = FileInfo.fileName();
    StructName.resize(StructName.lastIndexOf('.'));

    EAListWidget* list = ui.AbParseList;
    AbParseItem* item = new AbParseItem(abInitio, StructName, this);
    list->addNewItem(item);

    abInitio->setPresetPageDisabled();
    connect(list, &EAListWidget::DeleteOperate, abInitio, &AbInitioPage::tryPresetPageEnabled);

    MDFitData &target = item->target;
    AtomConfigData &config = item->config;

    target.Structure_Name = StructName.toLatin1().data();
    item->CONTCAR = path.toLocal8Bit().data();

    QString OUTCAR = path;
    OUTCAR.resize(OUTCAR.lastIndexOf('.'));
    item->OUTCAR = QString(OUTCAR + ".OUTCAR").toLocal8Bit().data();
    if (!QFileInfo(item->OUTCAR.c_str()).isFile()) {
        item->OUTCAR = "";
    }

    // 2. connect: once input Formation Energy, change Cohesive Energy
    connect(item, &AbParseItem::EformationChanged, this, [=]() {
        updateEnergyByFormation(item);
    });

    // 3. parse CONTCAR and OUTCAR, then update ParseGLWidget
    LoadErrorType parseErr = item->parse();
    if (item->CheckIfErrorOccurs(parseErr)) return 1;

    ui.ParseGLWidget->setConfig(0, &config);
    item->GroundEnergyLabel->setText(QString::number(target.initEnergy));

    // 4. update Type and Energy depending on ElePresetTable

    double FormationEnergy;
    LoadErrorType mapErr = item->updateType(abInitio->PresetType);
    if (mapErr != LoadErrorType::NONE) {
        item->CheckIfErrorOccurs(mapErr);
        FormationEnergy = 0.0;
    }
    else {
        FormationEnergy = target.initEnergy;
        for (int itype = 0; itype < config.ntype; itype++) {
            FormationEnergy -= abInitio->PresetAbInitioSpinAtomEnergy[itype] * config.eleNum[itype];
            FormationEnergy += abInitio->PresetAbInitioCohensiveEnergy[itype] * config.eleNum[itype];
        }
        FormationEnergy = FormationEnergy/config.num;
    }

    item->setEformation(FormationEnergy);

    // 5. once everything finished, set current row
    list->setCurrentRow(list->count() - 1);
    updateEnergyByFormation(item);
    item->saveStatus->setText(tr("Unsaved"));

    if (mapErr != LoadErrorType::NONE) {
        return 1;
    } else {
        return 0;
    }
}


void AbInitioParse::Export() {

    QDir Export(ui.ParseSavePathEdit->text());
    if (!Export.exists()) {
        Export.mkdir("./");
    }

    QString dir = Export.absolutePath();
    QByteArray ba = dir.toLatin1();

    QString str = "Saved", path;
    QListWidget* list = ui.AbParseList;

    int nexport = 0;
    int i, rows = list->count();
    for (i = 0; i < rows; i++) {
        if (ui.AbParseList->item(i)->isSelected()) nexport++;
    }

    io->ProgressDialogStart(0, nexport);
    nexport = 0;
    for (i = 0; i < rows; i++) {
        AbParseItem *item = GetParseItem(i);
        if (!ui.AbParseList->item(i)->isSelected()) {
            continue;
        }

        item->saveStatus->setText(str);
        item->exportData(ba.data(), ui.DumpLammpsDataBox->isChecked());

        nexport++;
        io->progress->setValue(nexport);
        if (io->progress->wasCanceled()) break;
        QCoreApplication::processEvents();
    }

    io->progress->setValue(nexport);
    QString msg = QString("Export %1 structures to %2").arg(nexport).arg(Export.absolutePath());
    if(!nexport) msg = "No structure exported. Nothing selected";
    io->ProgressDialogFinish(false, msg);
}



void AbInitioParse::SelectionChanged() {

    QVector<MDFitData*> selectTarget;
    QListWidget *list = ui.AbParseList;

    int rows = list->count();
    for (int i = 0; i < rows; i++) {
        if (list->item(i)->isSelected()) {
            selectTarget.push_back(&GetParseItem(i)->target);
        }
    }
    ui.ParseExportAutoButton->setEnabled(selectTarget.size());
    ui.ParseExportManualButton->setEnabled(selectTarget.size() == 1);
    ui.TargetAttrView->initTarget(selectTarget);
    frame->statusBar()->showMessage(QString::number(selectTarget.size()) + " items selected");
}

void AbInitioParse::MDRefButtomOnClicked(){

    QVector<MDFitData*> vec;
    QListWidget *list = ui.AbParseList;

    for (int i = 0; i < list->count(); i++) {
        if (list->item(i)->isSelected()) break;
        vec.push_back(&GetParseItem(i)->target);
    }
    ui.TargetAttrView->selectReference(vec);
}

void AbInitioParse::updateEnergyByFormation(AbParseItem *item) {

    bool norm = ui.ParseNormalByAtomChk->isChecked();
    if (ui.ParseFormationEnergyCorrectionChk->isChecked()){
        if (INT(abInitio->PresetType.size()) < item->config.ntype) {
            item->status->setText("MapAtomTypeNumber");
            return;
        }

        double Etotal = 0;
        for (int i = 0; i < item->config.ntype; i++) {
            Etotal -= abInitio->PresetPotentialCohensiveEnergy[i] * item->config.eleNum[i];
        }
        Etotal += item->getEformation() * item->config.num;
        item->target.Energy_Target = Etotal;

        if(norm) item->target.Energy_Target /= item->config.num;

    } else {
        item->updateEnergy(abInitio->PresetAbInitioSpinAtomEnergy, NULL, norm);
    }
    ui.TargetAttrView->initEnergy();
}

