#include "AbInitioPage.h"
#include "EAPIO.h"

#include <QSize>
#include <QFileDialog>
#include "EAPFrame.h"
#include "EAPSetPage.h"
#include "EAPlotPage.h"

#include "AtomConfig.h"
#include "EAPlotPage.h"
#include "spglib/spglib.h"
#include "AbinitioModify.h"
#include "FileBrowserPage.h"
#include <QProgressDialog>
#include <QMessageBox>

using namespace EAPUI_NS;
using namespace LoadConfig_NS;

#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}

#define set_minusvector3(u, v) {u[0] = -v[0];u[1] = -v[1];u[2] = -v[2];}

#define zero_vector3(u) {u[0] = 0;u[1] = 0;u[2] = 0;}

#define minu_vector3(u, v, w){u[0] = v[0] - w[0];u[1] = v[1] - w[1];u[2] = v[2] - w[2];}

#define plus_vector3(u, v, w){u[0] = v[0] + w[0];u[1] = v[1] + w[1];u[2] = v[2] + w[2];}

#define mult_vector3(u, v, r){u[0] = v[0] * r;u[1] = v[1] * r;u[2] = v[2] * r;}


AbInitioCreate::AbInitioCreate(QWidget *parent, class AbInitioPage* pAbInitio)
    : QObject(parent), UiPtr(pAbInitio->eapui)
    , ui(pAbInitio->ui)
{
    cui.setupUi(pAbInitio->ui.CreateListWidget);
    mui.setupUi(pAbInitio->ui.CreateModifyWidget);
    OpenInitDirAbCreate = "../res/ASM-Single";
}

AbInitioCreate::~AbInitioCreate(){
    QListWidget* list = cui.AbCreateList;

    int rows = list->count();
    for (int i = 0; i < rows; i++) {
        AbCreateItem *item = GetCreateItem(i);
        delete item;
    }
}

void AbInitioCreate::initialize(){
    QString getCreateSavePath = "get Create Save Path";
    EAPIO::connectButtonDirEdit(cui.CreateSavePathButton, getCreateSavePath, cui.CreateSavePathEdit);

    connect(cui.CreateAddButton, &QPushButton::clicked, this, [=]() {
        QStringList Files = QFileDialog::getOpenFileNames(nullptr,
            tr("load structure files"), OpenInitDirAbCreate,
            "Atom Structure (*.lammps *.lmp *.CONTCAR *.POSCAR *.vasp);;All Files(*.*)");
        if (Files.isEmpty()) return;

        int idx;
        io->ProgressDialogStart(0, Files.size());
        for (idx = 0; idx < Files.size(); idx++) {
            AddOnce(Files[idx]);
            io->progress->setValue(idx + 1);
            if (io->progress->wasCanceled()) break;
            QCoreApplication::processEvents();
        }
        QString msg = QString("%1 structures have been added").arg(idx);
        io->ProgressDialogFinish(true, msg);

        if (Files.size()){
            OpenInitDirAbCreate = QFileInfo(Files.last()).absolutePath();
        }
    });

    connect(cui.CreateExportAutoButton, &QPushButton::clicked, this, &AbInitioCreate::Export);
    connect(cui.CreateExportManualButton, &QPushButton::clicked, this, [=](){

        int i = cui.AbCreateList->currentRow();
        if (i < 0) return;

        QString file = QFileDialog::getSaveFileName(abInitio, tr("save POSCAR file"),
            cui.CreateSavePathEdit->text(), tr("Vasp Structure File(*.POSCAR)"));

        AbCreateItem *item = GetCreateItem(i);
        AtomConfigData* config = &item->original;
        switch (getConfigRadioButton(i)) {
        case 0: config = &item->original; break;
        case 1: config = &item->primitive; break;
        case 2: config = &item->standard; break;
        }

        AbExport(file, config, item->ui.POSCARLabel);
    });

    connect(cui.SelectAllButton, &QPushButton::clicked, cui.AbCreateList, &EAListWidget::selectAll);
    connect(cui.InverseSelectButton, &QPushButton::clicked, cui.AbCreateList, &EAListWidget::inverseSelect);

    cui.ModifyListTabWidget->hide();
    connect(cui.ModifyListButton, &QPushButton::clicked, this, [=]() {
        if (cui.ModifyListButton->isChecked()) {
            cui.ModifyListTabWidget->show();
            cui.ModifyListButton->setText("Hide List");
        }
        else {
            cui.ModifyListTabWidget->hide();
            cui.ModifyListButton->setText("Show List");
        }
    });
    connect(cui.SelectRangeButton, &QPushButton::clicked, cui.AbCreateList, [=]() {
        cui.AbCreateList->selectRange(cui.LoRangeBox->value(), cui.HiRangeBox->value());
    });
    connect(cui.OriginalButton, &QPushButton::clicked, this, [=]() {
        for (int i = 0; i < cui.AbCreateList->count(); i++) {
            if (!cui.AbCreateList->item(i)->isSelected()) continue;
            GetCreateItem(i)->ui.OriginalButton->click();
        }
    });
    connect(cui.PrimitiveButton, &QPushButton::clicked, this, [=]() {
        for (int i = 0; i < cui.AbCreateList->count(); i++) {
            if (!cui.AbCreateList->item(i)->isSelected()) continue;
            GetCreateItem(i)->ui.PrimitiveButton->click();
        }
    });
    connect(cui.StandardButton, &QPushButton::clicked, this, [=]() {
        for (int i = 0; i < cui.AbCreateList->count(); i++) {
            if (!cui.AbCreateList->item(i)->isSelected()) continue;
            GetCreateItem(i)->ui.StandardButton->click();
        }
    });

    connect(cui.AbCreateList, &QListWidget::currentRowChanged, this, &AbInitioCreate::CurrentRowChanged);

    connect(cui.CreateSavePathEdit, &QLineEdit::textChanged, fileBrowser, &FileBrowserPage::AddFileViewComboText);

    // Create Modify Page

    timestep = 0;
    mui.verticalLayout->addStretch();

    ModifyModel = new QStandardItemModel();
    ModifySelect = new QItemSelectionModel(ModifyModel);
    mui.listView->setModel(ModifyModel);
    mui.listView->setSelectionModel(ModifySelect);

    connect(ModifySelect, &QItemSelectionModel::currentChanged, this, &AbInitioCreate::updateGLWidget);

    connect(mui.CreateModeCombo, static_cast<void (QComboBox:: *)
        (int index)>(&QComboBox::currentIndexChanged), this, [=](int idx) {
        if (mui.CreateModeCombo->currentIndex()) {
            mui.CreateModeCombo->setCurrentIndex(0);
            createModify(idx);
        }
    });

    connect(cui.ModifyButton, &QPushButton::clicked, this, [=]() {
        if (CreateTask()) {
            ui.CreateStackedWidget->setCurrentIndex(1);
        }
    });

    connect(mui.AcceptButton, &QPushButton::clicked, this, &AbInitioCreate::AcceptModifyMode);
    connect(mui.RejectButton, &QPushButton::clicked, this, &AbInitioCreate::RejectModifyMode);

    // Save Task List

    connect(cui.SaveListWidget, &QListWidget::currentRowChanged, this, &AbInitioCreate::AbSaveTaskCurrentRowChanged);

    connect(cui.SaveTaskExportButton, &QPushButton::clicked, this, &AbInitioCreate::AbSaveTasksExport);
    connect(cui.SaveTaskSelectAllButton, &QPushButton::clicked, cui.SaveListWidget, &EAListWidget::selectAll);
    connect(cui.SaveTaskUnselectAllButton, &QPushButton::clicked, cui.SaveListWidget, &EAListWidget::unselectAll);
}


void AbInitioCreate::AddOnce(const QString& path) {

    // create a AbCreateItem

    QFileInfo FileInfo(path);
    QString StructName = FileInfo.fileName();
    StructName.resize(StructName.lastIndexOf('.'));

    EAListWidget* list = cui.AbCreateList;
    AbCreateItem* item = new AbCreateItem(abInitio, abInitio->statusBar, StructName);
    list->addNewItem(item);

    abInitio->setPresetPageDisabled();
    connect(list, &EAListWidget::DeleteOperate, ui.PresetPage, [=]() {
        if (ui.PresetPage->isEnabled()) return;
        if (cui.AbCreateList->count() +  ui.AbParseList->count() <= 1){
            ui.PresetPage->setEnabled(true);
    }});

    connect(item->ui.OriginalButton, &QRadioButton::clicked, this, &AbInitioCreate::AfterGLWidgetUpdate);
    connect(item->ui.PrimitiveButton, &QRadioButton::clicked, this, &AbInitioCreate::AfterGLWidgetUpdate);
    connect(item->ui.StandardButton, &QRadioButton::clicked, this, &AbInitioCreate::AfterGLWidgetUpdate);

    // 1. create AtomConfigData and load atom config

    AtomConfigData* original = &item->original;
    AtomConfigData* primitive = &item->primitive;
    AtomConfigData* standard = &item->standard;

    AtomConfigLoad load(original);
    load.read_head(path.toLocal8Bit().data());
    load.read_data();

    ui.StructureBeforeGLWidget->setConfig(0, original);

    // 2. create primitive and standard config by spglib

    bool LatticeAnalysis = cui.LatticeAnalysisCheck->checkState() == Qt::Checked;

    primitive->mult_ratio = 16.0;
    primitive->atomResize(original->num);
    primitive->copy(original);

    if (LatticeAnalysis){
        primitive->x2lamda();
        primitive->basisTranspose();
        primitive->num = spg_find_primitive(primitive->basis,
            (double(*)[3])(primitive->pos), primitive->type, primitive->num, 1.0e-4);
        item->SpaceGroupId = spg_get_international(item->SpaceGroup, primitive->basis,
            (double(*)[3])(primitive->pos), primitive->type, primitive->num, 1.0e-4);
        primitive->basisTranspose();
        primitive->updateBasis();
        primitive->lamda2x();
    }

    standard->mult_ratio = 16.0;
    standard->atomResize(original->num);
    standard->copy(original);

    if (LatticeAnalysis){
        standard->x2lamda();
        standard->basisTranspose();
        standard->num = spg_standardize_cell(standard->basis,
            (double(*)[3])(standard->pos), standard->type, standard->num, 0, 0, 1.0e-4);
        standard->basisTranspose();
        standard->updateBasis();
        standard->lamda2x();
    }

    // 3. add AtomConfigData to StructureAfterGLWidget

    ui.StructureAfterGLWidget->setConfig(0, original);
    ui.StructureAfterGLWidget->setConfig(1, primitive);
    ui.StructureAfterGLWidget->setConfig(2, standard);

    // 4. once everything finished, set current row
    list->setCurrentRow(list->count() - 1);
}




int AbInitioCreate::getConfigRadioButton(int idx) {

    if (idx < 0) {
        idx = cui.AbCreateList->currentRow();
    }

    AbCreateItem *item = GetCreateItem(idx);

    if (item->ui.OriginalButton->isChecked()) {
        return 0;
    }
    else if (item->ui.PrimitiveButton->isChecked()) {
        return 1;
    }
    else if (item->ui.StandardButton->isChecked()) {
        return 2;
    }

    return 0;
}

void AbInitioCreate::AfterGLWidgetUpdate() {
    ui.StructureAfterGLWidget->UIConfigCurrent = getConfigRadioButton();
    ui.StructureAfterGLWidget->ConfigToVBO();
    ui.StructureAfterGLWidget->update();
}

void AbInitioCreate::CurrentRowChanged(int currentRow) {

    if (currentRow < 0) return;

    AbCreateItem *item = GetCreateItem(currentRow);

    AtomConfigData* original = &item->original;
    AtomConfigData* primitive = &item->primitive;
    AtomConfigData* standard = &item->standard;

    ui.StructureBeforeGLWidget->setConfig(0, original);
    ui.StructureBeforeGLWidget->update();

    ui.StructureAfterGLWidget->setConfig(0, original);
    ui.StructureAfterGLWidget->setConfig(1, primitive);
    ui.StructureAfterGLWidget->setConfig(2, standard);

    AfterGLWidgetUpdate();

    // Update Information PlainEdit
    QString info = "", buf;
    QPlainTextEdit* text = ui.CreateInfoTextEdit;

    info += buf.sprintf("Space Group:  %s (%2d)\n",
        item->SpaceGroup, item->SpaceGroupId);
    info += buf.sprintf("      original primitive standard\n");
    info += buf.sprintf("Atoms:%8d %9d %8d",
        original->num, primitive->num, standard->num);

    text->setPlainText(info);
}


void AbInitioCreate::AbSaveTasksExport() {

    QDir Export(cui.CreateSavePathEdit->text());
    if (!Export.exists()) {
        Export.mkdir("./");
    }

    QString path, name;
    QListWidget* list = cui.SaveListWidget;
    SaveTaskItem *iWidget;
    bool addStep = cui.AddOperateStepBox->isChecked();

    int nexport = 0;
    int i, rows = list->count();
    for (i = 0; i < rows; i++) {
        QListWidgetItem *listItem = list->item(i);
        iWidget = qobject_cast<SaveTaskItem *>(list->itemWidget(listItem));
        if (iWidget->saveLabel->text() != "[Saved]" && listItem->isSelected()) {
            nexport++;
        }
    }

    io->ProgressDialogStart(0, nexport);
    nexport = 0;
    for (i = 0; i < rows; i++) {
        QListWidgetItem *listItem = list->item(i);
        iWidget = qobject_cast<SaveTaskItem *>(list->itemWidget(listItem));

        if (iWidget->saveLabel->text() == "[Saved]" || !listItem->isSelected()) {
            continue;
        }

        name = iWidget->nameEdit->text();
        if (addStep) {
            name += "." + iWidget->timeLabel->text();
        }
        path = Export.absoluteFilePath(name + ".POSCAR");
        AbExport(path, &iWidget->task->after, iWidget->saveLabel);

        nexport++;
        io->progress->setValue(nexport);
        if (io->progress->wasCanceled()) break;
        QCoreApplication::processEvents();
    }

    io->progress->setValue(nexport);
    QString msg = QString("Export %1 structures to %2").arg(nexport).arg(Export.absolutePath());
    if(!nexport) msg = "Nothing selected or they have already been exported";
    io->ProgressDialogFinish(false, msg);
}

void AbInitioCreate::AbExport(const QString& name, AtomConfigData* config, QLabel* label) {

    if (label) {
        label->setText("[Saved]");
    }
    AtomConfigLoad load(config);
    config->filetype = LoadFileType::VASP;

    abInitio->getEleArray(config->ntype, config->eleName);
    load.write(name.toLatin1().data());
};



void AbInitioCreate::Export() {

    QDir Export(cui.CreateSavePathEdit->text());
    if (!Export.exists()) {
        Export.mkdir("./");
    }

    QString str = "[Saved]", path;
    QListWidget* list = cui.AbCreateList;

    int nexport = 0;
    int i, rows = list->count();
    for (i = 0; i < rows; i++) {
        if (cui.AbCreateList->item(i)->isSelected()) nexport++;
    }

    io->ProgressDialogStart(0, nexport);
    nexport = 0;
    for (int i = 0; i < rows; i++) {
        AbCreateItem *item = GetCreateItem(i);
        if (!cui.AbCreateList->item(i)->isSelected()) {
            continue;
        }

        AtomConfigData* config = &item->original;
        switch (getConfigRadioButton(i)) {
        case 0: config = &item->original; break;
        case 1: config = &item->primitive; break;
        case 2: config = &item->standard; break;
        }

        path = Export.absoluteFilePath(item->ui.nameEdit->text() + ".POSCAR");
        AbExport(path, config, item->ui.POSCARLabel);

        nexport++;
        io->progress->setValue(nexport);
        if (io->progress->wasCanceled()) break;
        QCoreApplication::processEvents();
    }

    io->progress->setValue(nexport);
    QString msg = QString("Export %1 structures to %2").arg(nexport).arg(Export.absolutePath());
    if(!nexport) msg = "No structure exported. Nothing selected";
    io->ProgressDialogFinish(false, msg);
}

void AbInitioCreate::AbSaveTaskCurrentRowChanged() {
    EAListWidget *list = cui.SaveListWidget;
    int idx = list->currentRow();

    if (idx < 0) return;

    QListWidgetItem *listItem = list->item(idx);
    SaveTaskItem *taskWidget = qobject_cast<SaveTaskItem *>(list->itemWidget(listItem));
    QAbinitioModifyTask* task = taskWidget->task;

    AtomConfigData &before = task->before;
    AtomConfigData &after = task->after;

    ui.StructureBeforeGLWidget->setConfig(0, &before);
    ui.StructureAfterGLWidget->setConfig(0, &after);

    ui.StructureBeforeGLWidget->update();
    ui.StructureAfterGLWidget->update();

    // Update Information PlainEdit
    QString info = "", buf;
    QPlainTextEdit* text = ui.CreateInfoTextEdit;
    double *b1, *b2;

    b1 = before.basis[0]; b2 = after.basis[0];
    info += buf.sprintf("%7.2f %7.2f %7.2f    %7.2f %7.2f %7.2f\n",
        b1[0], b1[1], b1[2], b2[0], b2[1], b2[2]);

    b1 = before.basis[1]; b2 = after.basis[1];
    info += buf.sprintf("%7.2f %7.2f %7.2f -> %7.2f %7.2f %7.2f\n",
        b1[0], b1[1], b1[2], b2[0], b2[1], b2[2]);

    b1 = before.basis[2]; b2 = after.basis[2];
    info += buf.sprintf("%7.2f %7.2f %7.2f    %7.2f %7.2f %7.2f",
        b1[0], b1[1], b1[2], b2[0], b2[1], b2[2]);

    text->setPlainText(info);
}
