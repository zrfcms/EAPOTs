#include "AbInitioPage.h"
#include "EAPIO.h"

#include <QSize>
#include <QFileDialog>
#include "EAPFrame.h"
#include "EAPSetPage.h"
#include "EAPlotPage.h"

#include "AtomConfig.h"
#include "EAPlotPage.h"
#include "spglib/spglib.h"
#include "AbinitioModify.h"
#include "FileBrowserPage.h"
#include <QProgressDialog>
#include <QMessageBox>

using namespace EAPUI_NS;
using namespace LoadConfig_NS;


/*

1. The preset page must be frozen:

	1.1 If the user manually enters the forming energy,
		the change event of the preset page will reset the formation energy

	1.2 If the element type is duplicated when the user modifies the element type
		Then the atom type will never change back

*/

AbCreateItem::AbCreateItem(QWidget *parent,
	QStatusBar *pstatusBar,
    const QString& argv)
	: EAListWidgetItem(parent)
	, original(AtomConfigData(1))
	, primitive(AtomConfigData(1))
	, standard(AtomConfigData(1))
    , SpaceGroupId(0)
    , SpaceGroup("")
    , statusBar(pstatusBar)
{
	ui.setupUi(this);

	mainLayout->setSpacing(4);
	mainLayout->setContentsMargins(4, 0, 0, 0);

	insertWidget(ui.nameEdit, 6); 
	insertWidget(ui.OriginalButton, 3);
	insertWidget(ui.PrimitiveButton, 3);
	insertWidget(ui.StandardButton, 3);
	insertWidget(ui.POSCARLabel, 3);

	ui.nameEdit->setText(argv);
};








AbInitioPage::AbInitioPage(QWidget *parent, EAPUI* ptr)
    : QWidget(parent), UiPtr(ptr)
    , statusBar(frame->statusBar())
{
    ui.setupUi(this);
    createPage = new AbInitioCreate(parent, this);
    parsePage = new AbInitioParse(parent, this);

    if (eapui->FitMode == EAPUI::SINGLE){
        ui.ElePresetTable->setColumnHidden(2, true);
        ui.ElePresetTable->setColumnHidden(3, true);
        ui.ElePresetTable->setMidLineWidth(ui.ElePresetTable->width()*0.6);
    }
}

// To prevent the interface from suspended animation.
// Allow the program to process those events have not been processed
// and then return to the caller.
// QCoreApplication::processEvents();

void AbInitioPage::init() {

    ui.tabWidget->setCurrentIndex(0);

	// Create Page Init
	ui.CreateSplitter->setStretchFactor(0, 4);
    ui.CreateSplitter->setStretchFactor(1, 2);
    createPage->initialize();

	// Parse Page Init
	ui.ParseSplitter->setStretchFactor(0, 1);
    ui.ParseSplitter->setStretchFactor(1, 1);
    parsePage->initialize();


    AbPresetAddElement("Cu");
	ui.ElePresetTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    connect(ui.AtomEnergyAddButton, &QPushButton::clicked, this, [=]() {
        AbPresetAddElement("");
    });
	connect(ui.AtomEnergyDeleteButton, &QPushButton::clicked, this, [=]() {
        ui.ElePresetTable->removeRow(ui.ElePresetTable->rowCount() - 1);
        if (!eapui->BetaMode && eapui->FitMode == EAPUI::SINGLE){
            ui.AtomEnergyAddButton->setEnabled(true);
        }
        ui.AtomEnergyDeleteButton->setEnabled(ui.ElePresetTable->rowCount());
    });
    connect(ui.SelectElementButton, &QPushButton::clicked, this, [=]() {
        QTableWidgetItem * item = ui.ElePresetTable->currentItem();

        if (!item || item->row() < 0) return;

        PeriodicTableDialog* dialog = new PeriodicTableDialog(this);

        connect(dialog->buttonBox, SIGNAL(accepted()), dialog, SLOT(accept()));
        connect(dialog->buttonBox, SIGNAL(rejected()), dialog, SLOT(reject()));

        if (dialog->exec() == QDialog::Accepted){
            QStringList list = dialog->periodicTable->getSelection();
            if(list.size() > 0) ui.ElePresetTable->item(item->row(), 0)->setText(list[0]);
        }
        delete dialog;
    });

    connect(ui.tabWidget, &QTabWidget::currentChanged, this, &AbInitioPage::tryPresetPageEnabled);
}




void AbInitioPage::AbPresetAddElement(QString eleName) {

    ui.ElePresetTable->blockSignals(true);

    QString val;
    QTableWidget *table = ui.ElePresetTable;

    int rows = table->rowCount();
    int NItems = table->columnCount();

    if (eleName == ""){

        PeriodicTableDialog* dialog = new PeriodicTableDialog(this);

        connect(dialog->buttonBox, SIGNAL(accepted()), dialog, SLOT(accept()));
        connect(dialog->buttonBox, SIGNAL(rejected()), dialog, SLOT(reject()));

        if (dialog->exec() == QDialog::Accepted){
            QStringList list = dialog->periodicTable->getSelection();
            if(list.size() > 0) eleName = list[0];
        }
        delete dialog;
    }


    // set each column cell in new line
    table->insertRow(rows);
    for (int i = 0; i < NItems; i++) {
        QTableWidgetItem *item = new QTableWidgetItem();
        val = i == 0 ? eleName : "0.0";

        table->setItem(rows, i, item);
        item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
        item->setText(val);
    }

    ui.ElePresetTable->blockSignals(false);

    if (!eapui->BetaMode && eapui->FitMode == EAPUI::SINGLE){
        ui.AtomEnergyAddButton->setEnabled(false);
    }
    ui.AtomEnergyDeleteButton->setEnabled(true);
}

void AbInitioPage::getEleArray(int need, std::vector<std::string>& vec) {
	vec.clear();
	QTableWidget *table = ui.ElePresetTable;
	int rows = table->rowCount();

	if (need <= 0) need = rows;

    int min = need < rows? need : rows;
	for (int i = 0; i < min; i++) {
		vec.push_back(table->item(i, 0)->text().toLatin1().data());
	}

	if (min < need) {
		for (int i = min; i < need; i++) {
			vec.push_back("H");
		}
	}
}

void AbInitioPage::tryPresetPageEnabled(){
    if (createPage->cui.AbCreateList->count() +  ui.AbParseList->count() == 0){
        ui.PresetPage->setEnabled(true);
    }
}


void AbInitioPage::setPresetPageDisabled() {
	if (!ui.PresetPage->isEnabled()) return;

	ui.PresetPage->setEnabled(false);
	QTableWidget* table = ui.ElePresetTable;
	int rows = table->rowCount();

    PresetType.clear();
    PresetAbInitioSpinAtomEnergy.clear();
    PresetAbInitioCohensiveEnergy.clear();
    PresetPotentialCohensiveEnergy.clear();

	for (int i = 0; i < rows; i++) {
        PresetType.push_back(table->item(i, 0)->text().toLatin1().data());
        PresetAbInitioSpinAtomEnergy.push_back(table->item(i, 1)->text().toDouble());
        PresetAbInitioCohensiveEnergy.push_back(table->item(i, 2)->text().toDouble());
        PresetPotentialCohensiveEnergy.push_back(table->item(i, 3)->text().toDouble());
	}
}



