#pragma once

#include <QLabel>
#include <QDialog>
#include <QSpinBox>
#include <QCheckBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QRadioButton>
#include <QTableWidget>

#include <vector>
#include "AtomConfig.h"
#include "EAListWidget.h"
#include "EAExtraWidget.h"

typedef LoadConfig_NS::AtomConfigData LoadNSData;

namespace EAPUI_NS {

	class QAbinitioModifyWidget : public QWidget
	{
		Q_OBJECT

	public:
        explicit QAbinitioModifyWidget(class AbInitioPage *parent);
		~QAbinitioModifyWidget() {};

        class AbInitioCreate* page;
		QVBoxLayout *mainLayout;
		QGroupBox *groupBox;
	};


	class QAbinitioModifyData
	{
	public:
        explicit QAbinitioModifyData(LoadNSData*);
        virtual ~QAbinitioModifyData();

		virtual void update(QWidget *pWidget, LoadNSData* config) = 0;
	};


	// *************************************************************************************************
	// Transform
	// *************************************************************************************************
	class QAbinitioTransformData : public QAbinitioModifyData
	{
	public:
		explicit QAbinitioTransformData(LoadNSData* pconfig)
			: QAbinitioModifyData(pconfig) {};
		int flag;
		double mat[3][3];

		void update(QWidget *pWidget, LoadNSData* config);
	};
	class QAbinitioTransformWidget : public QAbinitioModifyWidget
	{
		Q_OBJECT
	public:

		QVBoxLayout *verticalLayout;
		QRadioButton *matrixButton;
		QRadioButton *mdeltaButton;
		QRadioButton *mfinalButton;
		QTableWidget *matrixWidget;

        explicit QAbinitioTransformWidget(class AbInitioPage *parent);
		~QAbinitioTransformWidget() {};
	};

	// *************************************************************************************************
	// Displace
	// *************************************************************************************************
	class QAbinitioDisplaceData : public QAbinitioModifyData
	{
	public:
		explicit QAbinitioDisplaceData(LoadNSData* pconfig)
			: QAbinitioModifyData(pconfig) {};
		int flag;
		double mat[3][3];

		void update(QWidget *pWidget, LoadNSData* config);
	};
	class QAbinitioDisplaceWidget : public QAbinitioModifyWidget
	{
		Q_OBJECT
	public:
		QVBoxLayout *verticalLayout;
		QHBoxLayout *horizontalLayout1;
		QLabel *label1;
		QLineEdit *disturbEdit;
		QLabel *label2;
		QSpinBox *spinBox;
		QHBoxLayout *horizontalLayout2;
		QCheckBox *xCheckBox;
		QCheckBox *yCheckBox;
		QCheckBox *zCheckBox;
	public:
        explicit QAbinitioDisplaceWidget(class AbInitioPage *parent);
		~QAbinitioDisplaceWidget() {};
	signals:
	public slots:
	};

	// *************************************************************************************************
	// Replicate
	// *************************************************************************************************
	class QAbinitioReplicateData : public QAbinitioModifyData
	{
	public:
		explicit QAbinitioReplicateData(LoadNSData* pconfig)
			: QAbinitioModifyData(pconfig) {};
		int flag;
		double mat[3][3];

		void update(QWidget *pWidget, LoadNSData* config);
	};
	class QAbinitioReplicateWidget : public QAbinitioModifyWidget
	{
		Q_OBJECT
	public:

		QGridLayout *gridLayout;

		QLabel *Xlabel;
		QLabel *Ylabel;
		QLabel *Zlabel;

		QSpinBox *XspinBox;
		QSpinBox *YspinBox;
		QSpinBox *ZspinBox;
	public:
        explicit QAbinitioReplicateWidget(class AbInitioPage *parent);
		~QAbinitioReplicateWidget() {};
	signals:
	public slots:
	};

	// *************************************************************************************************
	// QAbinitioModifyTask
	// *************************************************************************************************
	enum class QAbinitioModifyEnum
	{
		Transform,
		Displace,
		Replicate,
	};

	class QAbinitioModifyTask
	{
	public:
		explicit QAbinitioModifyTask(LoadNSData& pconfig);

		~QAbinitioModifyTask();

		void addModify(QAbinitioModifyEnum type);

		void update(QVBoxLayout* widgets);

		int timestep;
		LoadNSData after;
		LoadNSData before;

        QVector<QAbinitioModifyData*> modify;
	};

	class SaveTaskItem : public EAListWidgetItem
	{
		Q_OBJECT
	public:
		explicit SaveTaskItem(QWidget *parent, const QString& argv, QAbinitioModifyTask* ptask);

		~SaveTaskItem();

		QAbinitioModifyTask* task;

        QClickLabel *nameEdit;

		QLabel *timeLabel;
		QLabel *saveLabel;
	};
}
