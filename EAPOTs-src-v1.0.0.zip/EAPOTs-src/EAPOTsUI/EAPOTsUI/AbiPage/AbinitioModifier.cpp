#include "AbinitioPage.h"
#include "AbinitioModify.h"

using namespace EAPUI_NS;
using namespace LoadConfig_NS;




#define connectUpdate(widget, signal) connect(widget, signal, page, &AbInitioCreate::ModifyUpdate)

#define Mat33Loop 				\
for (int i = 0; i < 3; i++) 	\
for (int j = 0; j < 3; j++) 


QAbinitioModifyWidget::QAbinitioModifyWidget(AbInitioPage *parent)
    : QWidget(parent), page(parent->createPage)
{
	mainLayout = new QVBoxLayout(this);
	mainLayout->setContentsMargins(0, 0, 0, 0);

	groupBox = new QGroupBox(this);
	groupBox->setAlignment(Qt::AlignCenter);
	groupBox->setCheckable(true);

	connectUpdate(groupBox, &QGroupBox::clicked);
};

QAbinitioModifyData::QAbinitioModifyData(LoadNSData*){

};

QAbinitioModifyData::~QAbinitioModifyData(){

};

// *************************************************************************************************
// QAbinitioTransformWidget
// *************************************************************************************************

QAbinitioTransformWidget::QAbinitioTransformWidget(AbInitioPage *parent)
	: QAbinitioModifyWidget(parent)
{
	setMinimumSize(QSize(0, 220));
	setMaximumSize(QSize(16777215, 220));

	verticalLayout = new QVBoxLayout(groupBox);
	verticalLayout->setContentsMargins(6, 6, 6, 6);

	matrixButton = new QRadioButton(groupBox);
	matrixButton->setChecked(true);
	verticalLayout->addWidget(matrixButton);

	mdeltaButton = new QRadioButton(groupBox);
	mdeltaButton->setChecked(false);
    verticalLayout->addWidget(mdeltaButton);

	mfinalButton = new QRadioButton(groupBox);
	mfinalButton->setChecked(false);
	verticalLayout->addWidget(mfinalButton);

	matrixWidget = new QTableWidget(groupBox);
	matrixWidget->setColumnCount(3);
	matrixWidget->setRowCount(3);
	for (int i = 0; i < 3; i++) {
		matrixWidget->setHorizontalHeaderItem(i, new QTableWidgetItem());
		matrixWidget->setVerticalHeaderItem(i, new QTableWidgetItem());
		for (int j = 0; j < 3; j++) {
			matrixWidget->setItem(i, j, new QTableWidgetItem());
		}
	}
	matrixWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	matrixWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

	QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
	sizePolicy.setHorizontalStretch(0);
	sizePolicy.setVerticalStretch(0);
	sizePolicy.setHeightForWidth(matrixWidget->sizePolicy().hasHeightForWidth());
	matrixWidget->setSizePolicy(sizePolicy);
	matrixWidget->setMinimumSize(QSize(0, 120));
	matrixWidget->setMaximumSize(QSize(16777215, 120));
	verticalLayout->addWidget(matrixWidget);

	mainLayout->addWidget(groupBox);

	groupBox->setTitle(tr("Transformation"));
	matrixButton->setText(tr("Transformation Matrix"));
	mdeltaButton->setText(tr("Transform by delta:"));	
	mfinalButton->setText(tr("Transform to target box"));

	matrixWidget->horizontalHeaderItem(0)->setText("x");
	matrixWidget->horizontalHeaderItem(1)->setText("y");
	matrixWidget->horizontalHeaderItem(2)->setText("z");

	matrixWidget->verticalHeaderItem(0)->setText("a");
	matrixWidget->verticalHeaderItem(1)->setText("b");
	matrixWidget->verticalHeaderItem(2)->setText("c");

	matrixWidget->setSortingEnabled(false);

    auto matrixModeReset = [=](){
        matrixWidget->blockSignals(true);
        Mat33Loop{ matrixWidget->item(i, j)->setText("0.0"); };
        matrixWidget->item(0, 0)->setText("1.0");
        matrixWidget->item(1, 1)->setText("1.0");
        matrixWidget->item(2, 2)->setText("1.0");
        matrixWidget->blockSignals(false);
        emit matrixWidget->cellChanged(0, 0);
    };

	matrixModeReset();
	QMetaObject::connectSlotsByName(this);
	connectUpdate(matrixWidget, &QTableWidget::cellChanged);

    connect(matrixButton, &QRadioButton::clicked, this, matrixModeReset);
    connect(mdeltaButton, &QRadioButton::clicked, this, [=](){
        matrixWidget->blockSignals(true);
        Mat33Loop{ matrixWidget->item(i, j)->setText("0.0"); };
        matrixWidget->blockSignals(false);
        emit matrixWidget->cellChanged(0, 0);
    });
    connect(mfinalButton, &QRadioButton::clicked, this, [=](){
        matrixWidget->blockSignals(true);
        Mat33Loop{ matrixWidget->item(i, j)->setText(""); };
        matrixWidget->blockSignals(false);
        emit matrixWidget->cellChanged(0, 0);
    });
}


void QAbinitioTransformData::update(QWidget *pWidget, LoadNSData* config) {

	QAbinitioTransformWidget *widget = qobject_cast<QAbinitioTransformWidget*>(pWidget);

	if (!widget->groupBox->isChecked()) return;

    QString cij;
	int flag = 0;	
	double mat[3][3], move[3] = { 0,0,0 };

	Mat33Loop{
        cij = widget->matrixWidget->item(i, j)->text();
        mat[i][j] = cij.isEmpty() ? config->basis[i][j] : cij.toDouble();
	};

	flag = AtomConfigData::TransDomain | AtomConfigData::TransParticle;
	if (widget->mdeltaButton->isChecked()) flag |= AtomConfigData::TransMatDelta;
	if (widget->mfinalButton->isChecked()) flag |= AtomConfigData::TransMatFinal;

    config->Transform(mat, move, flag);

}

// *************************************************************************************************
// QAbinitioReplicateWidget
// *************************************************************************************************

QAbinitioDisplaceWidget::QAbinitioDisplaceWidget(AbInitioPage *parent)
	: QAbinitioModifyWidget(parent)
{
	setMinimumSize(QSize(0, 75));
	setMaximumSize(QSize(16777215, 75));

	verticalLayout = new QVBoxLayout(groupBox);
	verticalLayout->setSpacing(6);
	verticalLayout->setContentsMargins(6, 6, 6, 6);

	horizontalLayout1 = new QHBoxLayout();

	label1 = new QLabel(groupBox);
	label1->setMaximumSize(QSize(50, 16777215));
	horizontalLayout1->addWidget(label1);

	disturbEdit = new QLineEdit(groupBox);
	QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
	sizePolicy.setHorizontalStretch(0);
	sizePolicy.setVerticalStretch(0);
	sizePolicy.setHeightForWidth(disturbEdit->sizePolicy().hasHeightForWidth());
	disturbEdit->setSizePolicy(sizePolicy);
	disturbEdit->setMinimumSize(QSize(0, 22));
	disturbEdit->setMaximumSize(QSize(16777215, 22));
	horizontalLayout1->addWidget(disturbEdit);

	label2 = new QLabel(groupBox);
	label2->setMaximumSize(QSize(50, 16777215));
	horizontalLayout1->addWidget(label2);

	spinBox = new QSpinBox(groupBox);
	QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
	sizePolicy1.setHorizontalStretch(0);
	sizePolicy1.setVerticalStretch(0);
	sizePolicy1.setHeightForWidth(spinBox->sizePolicy().hasHeightForWidth());
	spinBox->setSizePolicy(sizePolicy1);
	spinBox->setMinimumSize(QSize(0, 22));
	horizontalLayout1->addWidget(spinBox);

	verticalLayout->addLayout(horizontalLayout1);

	horizontalLayout2 = new QHBoxLayout();
	horizontalLayout2->setSpacing(4);
	horizontalLayout2->setContentsMargins(2, 0, 2, 0);

	xCheckBox = new QCheckBox(groupBox);
	xCheckBox->setChecked(true);
	horizontalLayout2->addWidget(xCheckBox);

	yCheckBox = new QCheckBox(groupBox);
	yCheckBox->setChecked(true);
	horizontalLayout2->addWidget(yCheckBox);

	zCheckBox = new QCheckBox(groupBox);
	zCheckBox->setChecked(true);
	horizontalLayout2->addWidget(zCheckBox);

	verticalLayout->addLayout(horizontalLayout2);

	mainLayout->addWidget(groupBox);

	groupBox->setTitle(tr("Displacement"));
	label1->setText(QApplication::translate("", "Disturb", nullptr));
	disturbEdit->setText(QApplication::translate("", "0.1", nullptr));
	label2->setText(QApplication::translate("", "Seed", nullptr));
	xCheckBox->setText(QApplication::translate("", "x", nullptr));
	yCheckBox->setText(QApplication::translate("", "y", nullptr));
	zCheckBox->setText(QApplication::translate("", "z", nullptr));

	QMetaObject::connectSlotsByName(this);

	connectUpdate(xCheckBox, &QCheckBox::stateChanged);
	connectUpdate(yCheckBox, &QCheckBox::stateChanged);
	connectUpdate(zCheckBox, &QCheckBox::stateChanged);
	connectUpdate(disturbEdit, &QLineEdit::editingFinished);
	connectUpdate(spinBox, static_cast<void (QSpinBox:: *)(int)>(&QSpinBox::valueChanged));
}

void QAbinitioDisplaceData::update(QWidget *pWidget, LoadNSData* config) {
	QAbinitioDisplaceWidget *widget = qobject_cast<QAbinitioDisplaceWidget*>(pWidget);

	if (!widget->groupBox->isChecked()) return;

	int flag = 0;

	if (widget->xCheckBox->isChecked()) flag |= AtomConfigData::DispX;
	if (widget->yCheckBox->isChecked()) flag |= AtomConfigData::DispY;
	if (widget->zCheckBox->isChecked()) flag |= AtomConfigData::DispZ;

	config->AtomDisplace(
		widget->disturbEdit->text().toDouble(),
		widget->spinBox->value(),
		flag);
}

// *************************************************************************************************
// QAbinitioReplicateWidget
// *************************************************************************************************

QAbinitioReplicateWidget::QAbinitioReplicateWidget(AbInitioPage *parent)
	: QAbinitioModifyWidget(parent)
{
	setMinimumSize(QSize(0, 100));
	setMaximumSize(QSize(16777215, 100));

	gridLayout = new QGridLayout(groupBox);
	gridLayout->setSpacing(6);
	gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
	gridLayout->setContentsMargins(6, 6, 6, 6);

	Xlabel = new QLabel(groupBox);	gridLayout->addWidget(Xlabel, 0, 0, 1, 1);
	Ylabel = new QLabel(groupBox);	gridLayout->addWidget(Ylabel, 1, 0, 1, 1);
	Zlabel = new QLabel(groupBox);	gridLayout->addWidget(Zlabel, 2, 0, 1, 1);

	XspinBox = new QSpinBox(groupBox);
	XspinBox->setMinimum(1);
	XspinBox->setMaximum(65535);
	XspinBox->setValue(1);
	XspinBox->setMinimumSize(QSize(0, 22));
	gridLayout->addWidget(XspinBox, 0, 1, 1, 1);

	YspinBox = new QSpinBox(groupBox);
	YspinBox->setMinimum(1);
	YspinBox->setMaximum(65535);
	YspinBox->setValue(1);
	YspinBox->setMinimumSize(QSize(0, 22));
	gridLayout->addWidget(YspinBox, 1, 1, 1, 1);

	ZspinBox = new QSpinBox(groupBox);
	ZspinBox->setMinimum(1);
	ZspinBox->setMaximum(65535);
	ZspinBox->setValue(1);
	ZspinBox->setMinimumSize(QSize(0, 22));
	gridLayout->addWidget(ZspinBox, 2, 1, 1, 1);

	mainLayout->addWidget(groupBox);

	Xlabel->setText(QApplication::translate("", "Number of X images", nullptr));
	Ylabel->setText(QApplication::translate("", "Number of Y images", nullptr));
	Zlabel->setText(QApplication::translate("", "Number of Z images", nullptr));

	groupBox->setTitle(tr("Replicate"));

	QMetaObject::connectSlotsByName(this);

	connectUpdate(XspinBox, static_cast<void (QSpinBox:: *)(int)>(&QSpinBox::valueChanged));
	connectUpdate(YspinBox, static_cast<void (QSpinBox:: *)(int)>(&QSpinBox::valueChanged));
	connectUpdate(ZspinBox, static_cast<void (QSpinBox:: *)(int)>(&QSpinBox::valueChanged));
}

void QAbinitioReplicateData::update(QWidget *pWidget, LoadNSData* config) {

	QAbinitioReplicateWidget *widget = qobject_cast<QAbinitioReplicateWidget*>(pWidget);

	if (!widget->groupBox->isChecked()) return;

	config->Replicate(
		widget->XspinBox->value(),
		widget->YspinBox->value(),
		widget->ZspinBox->value()
	);
}
