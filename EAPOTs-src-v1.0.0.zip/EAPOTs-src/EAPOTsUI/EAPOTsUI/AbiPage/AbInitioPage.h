#pragma once

#include "ui_AbInitioPage.h"
#include "ui_AbInitioItem.h"
#include "ui_AbInitioCreateList.h"
#include "ui_AbInitioCreateModify.h"

#include "ConfigAttributeWidget.h"
#include <QStandardItemModel>
#include <QFileSystemModel>
#include <QProgressDialog>

#include <QDir>
#include <QStatusBar>
#include <QListWidgetItem>
#include "EAExtraWidget.h"
#include "AtomConfig.h"
#include "UiPtr.h"

namespace EAPUI_NS {

    class AbCreateItem : public EAListWidgetItem
    {
        Q_OBJECT
    public:
        Ui_AbStructItem ui;
        explicit AbCreateItem(QWidget *parent,
            QStatusBar *pstatusBar,	const QString& argv);

        ~AbCreateItem() {}
    signals:
    public slots:
    public:
        LoadConfig_NS::AtomConfigData original;
        LoadConfig_NS::AtomConfigData primitive;
        LoadConfig_NS::AtomConfigData standard;

        int SpaceGroupId;
        char SpaceGroup[11];
    private:
        QStatusBar *statusBar;
    };

	class AbParseItem : public EAListWidgetItem, public LoadConfig_NS::LoadVaspData
	{
		Q_OBJECT
	public:
        explicit AbParseItem(QWidget *parent, const QString& argv, class AbInitioParse*);

		QClickLabel *nameEdit;
        QLabel      *GroundEnergyLabel;
		QLabel *status;
        QLabel *saveStatus;

        QString StructName;					// Only used for transmitting
        void setEformation(double);
        double getEformation();

        ~AbParseItem() {}
		bool CheckIfErrorOccurs(LoadConfig_NS::LoadErrorType);	

    signals:
        void EformationChanged();

    private:
        class AbInitioParse* parsePage;
        QClickLabel *FormationEnergyEdit;
	};




    class AbInitioCreate : public QObject, public UiPtr
    {
        Q_OBJECT
    public:
        explicit AbInitioCreate(QWidget *parent, class AbInitioPage* pAbInitio);
        ~AbInitioCreate();
        void initialize();

        Ui_AbInitioPage& ui;
        Ui_AbInitioCreateList cui;
        Ui_AbInitioCreateModify mui;
        QString OpenInitDirAbCreate;

        void AddOnce(const QString& name);
        void Export();

    public:
        void CurrentRowChanged(int currentRow);
        void AfterGLWidgetUpdate();

        int getConfigRadioButton(int idx = -1);

        inline class AbCreateItem* GetCreateItem(const int i) {
            QListWidgetItem *listItem = cui.AbCreateList->item(i);
            AbCreateItem *item = qobject_cast<AbCreateItem *>(cui.AbCreateList->itemWidget(listItem));
            return item;
        }

    public:
        // Create Modify Page
        int timestep;
        bool CreateFromSave;
        QVector<class QAbinitioModifyTask*> task;

        QStandardItemModel* ModifyModel;
        QItemSelectionModel* ModifySelect;

        int CreateTask();
        int CreateFromSaveTask();
        void ModifyUpdate();
        void updateGLWidget();

        void createModify(int);

        void AcceptModifyMode();
        void RejectModifyMode();
        void ExitModifyMode();

    public:
        void AbExport(const QString& name, LoadConfig_NS::AtomConfigData* config, QLabel* label);
        void AbSaveTasksExport();
        void AbSaveTaskCurrentRowChanged();

    };

    class AbInitioParse : public QObject, public UiPtr
    {
        Q_OBJECT
    public:
        explicit AbInitioParse(QWidget *parent, class AbInitioPage* pAbInitio);
        void initialize();

        int EformFlag;
        Ui_AbInitioPage& ui;
        QString OpenInitDirAbParse;

        int AddOnce(const QString& name);
        void AddAuto();
        void Export();
        void throwErrMsgIfNeed(int);

    public:
        void SelectionChanged();
        void MDRefButtomOnClicked();
        void CurrentRowChanged(int currentRow);

        inline class AbParseItem* GetParseItem(const int i) {
            QListWidgetItem *listItem = ui.AbParseList->item(i);
            return qobject_cast<AbParseItem *>(ui.AbParseList->itemWidget(listItem));
        }

        void updateEnergyByFormation(AbParseItem *);
    };

	class AbInitioPage : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
		Ui_AbInitioPage ui;
        AbInitioCreate* createPage;
        AbInitioParse* parsePage;

		explicit AbInitioPage(QWidget *parent, EAPUI* ptr);
        void init();

	public:
		// Preset Page

        void AbPresetAddElement(QString ele);

        std::vector<std::string> PresetType;
        std::vector<double> PresetAbInitioSpinAtomEnergy;
        std::vector<double> PresetAbInitioCohensiveEnergy;
        std::vector<double> PresetPotentialCohensiveEnergy;

        void tryPresetPageEnabled();
		void setPresetPageDisabled();
        void getEleArray(int need, std::vector<std::string>&);

        QStatusBar *statusBar;
	};

}
