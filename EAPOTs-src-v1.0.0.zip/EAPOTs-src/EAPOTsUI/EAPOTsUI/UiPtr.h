#pragma once

#include "EAPUI.h"
#include <QObject>
#include <QJsonObject>

#define FLERR __FILE__,__LINE__
#define MIN(A,B) ((A) < (B) ? (A) : (B))
#define MAX(A,B) ((A) > (B) ? (A) : (B))

#define INT(A) static_cast<int>(A)
#define SIZE_T(A) static_cast<size_t>(A)
#define DOUBLE(A) static_cast<double>(A)
#define FLOAT(A) static_cast<float>(A)

enum WidgetType {
    QLEdit, QTEdit, QPEdit, QChkBox, QComb, QJson
};

struct JsonKey {
    QString Key;
    QWidget* Widget;
    WidgetType Type;
};

namespace EAPUI_NS {

	class UiPtr {
	public:
		UiPtr(EAPUI *ptr)
			: eapui(ptr)
			, frame(ptr->frame)
			, io(ptr->io)

            , setPage(ptr->setPage)
            , taskPage(ptr->taskPage)
			, fileBrowser(ptr->fileBrowser)
			
			, abInitio(ptr->abInitio)
			, EAPlot(ptr->EAPlot)
			, structGL(ptr->structGL)
        {}
        virtual ~UiPtr() {}

    public:
		class EAPUI *eapui;
		class EAPFrame *&frame;
		class EAPIO *&io;

        class EAPSetPage *&setPage;
        class FitTaskPage *&taskPage;

		class FileBrowserPage* &fileBrowser;
		class AbInitioPage* &abInitio;
		class EAPlotPage* &EAPlot;
		class StructGLPage* &structGL;
	};
}
