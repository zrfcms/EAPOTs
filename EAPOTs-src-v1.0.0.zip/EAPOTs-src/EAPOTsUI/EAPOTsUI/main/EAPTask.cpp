#include "EAPTask.h"
#include "EAPIO.h"
#include "EAPFrame.h"
#include "EAPSetPage.h"
#include <QDebug>
#include <QThread>
#include <QProcess>
#include <QDir>
#include <QScrollBar>
#include <QMetaEnum>
#include <QTimer>
#include <cmath>
#include <QValueAxis>
#include <QDesktopServices>

using namespace EAPUI_NS;

TaskObject::TaskObject(class FitTaskPage* ptask)
    : QProcess(ptask)
    , task(ptask)
    , isRunning(false)
{
    stateStr = "N";
	finish_time = "none";
	finish_state = "none";
	cost_time = "0.0";

	info = "none";
	thermo = "none";
	check = "none";
}


void TaskObject::CreateInfo(int mode) {

	bool CreateForce = mode & InfoMode::Force;

	if (false == isRunning && !CreateForce) return;

	bool CreateImage = mode & InfoMode::Image || CreateForce;
	bool CreateThermo = mode & InfoMode::Thermo || CreateForce;
	bool CreateCheck = mode & InfoMode::Check || CreateForce;
	bool CreateInfo = mode & InfoMode::Info || CreateForce;
    bool CreateLog = mode & InfoMode::Log || CreateForce;

    bool GetStepFileName = CreateImage || CreateThermo || CreateCheck;


	if (CreateInfo) {
		if (isRunning) {
			cost_time.sprintf("%.1f", timer.elapsed() / 1000.0);
		}

		info = "Job Id:        = " + name
            + "\njob_state      = " + stateStr
			+ "\nqtime          = " + start_time
			+ "\nfinish_time    = " + finish_time
			+ "\ncost_time      = " + cost_time
			+ "s\nfinish_state   = " + finish_state
            + "\nJoin_Path      = " + TaskDir.absolutePath();
	}

    if (GetStepFileName) {
        QJsonObject obj = EAPIO::loadJsonObject(TaskDir.absoluteFilePath("dump.log"));

        imagefile = obj.contains("image") ? obj["image"].toString() : "";
        chkfile = obj.contains("extra") ? obj["extra"].toString() : "";
	}

	if (CreateImage) {
		// Read Task Check File
        QString image_name = TaskDir.absoluteFilePath(imagefile);
		if (QFile::exists(image_name)) {
			image.load(image_name);
		}
        else{
            image = QPixmap();
        }
	}

	if (CreateCheck) {
		// Read Task Check File
        QFile file_chk(TaskDir.absoluteFilePath(chkfile));
		if (file_chk.open(QIODevice::ReadOnly | QIODevice::Text)) {
			check = file_chk.readAll();
			file_chk.close();
		}
        else{
            check = "";
        }
	}

	if (CreateThermo) {
		// Read Task Thermo File
        QFile file_ther(TaskDir.absoluteFilePath("thermo.log"));
        if (file_ther.open(QIODevice::ReadOnly | QIODevice::Text)) {
            thermo = file_ther.readAll();
            file_ther.close();
		}
	}

    if (CreateLog) {
        // Read Task Thermo File
        QFile file_log(TaskDir.absoluteFilePath("EAPOT.log"));
        if (file_log.open(QIODevice::ReadOnly | QIODevice::Text)) {
            log = file_log.readAll();
            file_log.close();
        }
        //log += readAllStandardOutput();
    }
}


FitTaskPage::FitTaskPage(QWidget *parent, EAPUI* ptr)
	: QWidget(parent)
	, UiPtr(ptr)
{
	ui.setupUi(this);
    ui.UpdatePage->setCurrentIndex(0);

    Highlighter = new PythonHighlighter(ui.UpdateLogEdit->document());
    QFont font = ui.UpdateLogEdit->font();
    font.setFamily("Source Code Pro");
    ui.UpdateLogEdit->setFont(font);
    QFontMetrics metrics(ui.UpdateLogEdit->font());
    ui.UpdateLogEdit->setTabStopDistance(4 * metrics.width(' '));


    statusModel = new ReadOnlyTableModel(512, 256);
    ui.UpdateStatusView->setModel(statusModel);
    ui.UpdateStatusView->verticalHeader()->setVisible(false);

    checkModel = new ReadOnlyTableModel(512, 64);
    ui.UpdateCheckView->setModel(checkModel);
    ui.UpdateCheckView->verticalHeader()->setVisible(false);

    // Take up resources, very slow
    // ui.UpdateStatusView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    // ui.UpdateStatusView->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);


    maxX = 10;
    maxY = 1.0;
    lineSeries = new QLineSeries();
    scatterSeries = new QScatterSeries();
    scatterSeries->setMarkerSize(12);

    chart = new QChart();
    chart->addSeries(lineSeries);
    chart->addSeries(scatterSeries);
    chart->legend()->hide();
    //chart->setTitle("Current cost function value");

    chart->createDefaultAxes();
    auto axisx = qobject_cast<QValueAxis*>(chart->axes(Qt::Horizontal, lineSeries).first());
    auto axisy = qobject_cast<QValueAxis*>(chart->axes(Qt::Vertical, lineSeries).first());

    axisx->setRange(0, maxX);
    axisy->setRange(0, maxY);
    axisx->setLabelFormat("%d");

    axisx->setGridLineVisible(true);
    axisx->setTitleText("steps");
    axisy->setGridLineVisible(true);
    axisy->setTitleText("Current cost function value");

    chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    ui.ChartLayout->addWidget(chartView);

    chart->setContentsMargins(-20, -20, -20, -25);
    setCustomFont(qApp->font());
}

void FitTaskPage::setCustomFont(const QFont& font){
    chartView->setFont(font);
    chart->setFont(font);

    auto axisx = qobject_cast<QValueAxis*>(chart->axes(Qt::Horizontal, lineSeries).first());
    auto axisy = qobject_cast<QValueAxis*>(chart->axes(Qt::Vertical, lineSeries).first());
    axisx->setLabelsFont(font);
    axisy->setLabelsFont(font);
    axisx->setTitleFont(font);
    axisy->setTitleFont(font);

    ui.UpdateInfoEdit->setFont(font);
    ui.UpdateLogEdit->setFont(font);
}


FitTaskPage::~FitTaskPage(){

    for (int i = 0; i < ui.TaskList->count(); i++){
        TaskWidgetItem *item = (TaskWidgetItem*)ui.TaskList->item(i);

        TaskObject *itask = item->taskObject;
        item->setText(itask->name + " (C)");

        if (itask->isRunning) {
            if (QProcess::Running == itask->state()) {
                itask->kill();
            }
        }
    }

    delete Highlighter;
}

void FitTaskPage::init(){

    connect(frame->ui.actionChart, &QAction::triggered, this, [=]() {
        frame->PageRaise(MainPage::EAMFit); ui.UpdatePage->setCurrentIndex(0); });
    connect(frame->ui.actionSnap,  &QAction::triggered, this, [=]() {
        frame->PageRaise(MainPage::EAMFit); ui.UpdatePage->setCurrentIndex(1); });
    connect(frame->ui.actionStat,  &QAction::triggered, this, [=]() {
        frame->PageRaise(MainPage::EAMFit); ui.UpdatePage->setCurrentIndex(2); });
    connect(frame->ui.actionChck,  &QAction::triggered, this, [=]() {
        frame->PageRaise(MainPage::EAMFit); ui.UpdatePage->setCurrentIndex(3); });
    connect(frame->ui.actionInfo,  &QAction::triggered, this, [=]() {
        frame->PageRaise(MainPage::EAMFit); ui.UpdatePage->setCurrentIndex(4); });
    connect(frame->ui.actionLog,   &QAction::triggered, this, [=]() {
        frame->PageRaise(MainPage::EAMFit); ui.UpdatePage->setCurrentIndex(5); });

	connect(ui.TaskCancelButton, &QPushButton::clicked, frame->ui.actionCancelTask, &QAction::triggered);
    connect(ui.TaskDeleteButton, &QPushButton::clicked, frame->ui.actionDeleteTask, &QAction::triggered);

	/*-------------------------------------Action processing----------------------------------------*/
	connect(frame->ui.actionRunOnce, &QAction::triggered, this, &FitTaskPage::CreateRunOnceSlot);
	connect(frame->ui.actionRunWriteOnce, &QAction::triggered, this, &FitTaskPage::WriteRunOnceSlot);

	connect(frame->ui.actionRunFit, &QAction::triggered, this, &FitTaskPage::CreateRunFitSlot);
	connect(frame->ui.actionRunWriteFit, &QAction::triggered, this, &FitTaskPage::WriteRunFitSlot);

	connect(frame->ui.actionCancelTask, &QAction::triggered, this, &FitTaskPage::CancelTaskSlot);
    connect(frame->ui.actionDeleteTask, &QAction::triggered, this, &FitTaskPage::DeleteTaskSlot);

	timer = new QTimer(this);
	connect(timer, &QTimer::timeout, this, [=]() { UpdateRefresh(0); });
    timer->start(100);

	connect(ui.UpdatePage, &QTabWidget::currentChanged, this, [=]() { UpdateRefresh(1); });
    connect(ui.TaskList, &QListWidget::currentRowChanged, this, [=](int) { UpdateRefresh(1); });
    connect(ui.TaskList, &QListWidget::itemDoubleClicked, this, [=](QListWidgetItem *pitem) {
        TaskWidgetItem *item = (TaskWidgetItem*)pitem;
        QString path = item->taskObject->TaskDir.absolutePath();
        QDesktopServices::openUrl(QUrl(path, QUrl::TolerantMode));
    });
}

int FitTaskPage::AllocNewTask(QString &path) {

	int taskidx;
	QString name, newdir;
    newdir = setPage->getTaskDir();
	QDir dir(newdir);

	if (!dir.exists()) {
		dir.mkdir(dir.absolutePath());
	}

	std::vector<int> v;

	// push every dir whose is a number into v 
	QFileInfoList list = dir.entryInfoList();
	for (int i = 0; i < list.count(); i++)
	{
		QFileInfo mfi = list.at(i);
		if (mfi.isDir()) {
			name = mfi.fileName();
			if (name[0] == '.') continue;
			if (!EAPIO::isDigitStr(name)) continue;

			// qDebug() << mfi.absoluteDir() << mfi.fileName();
			v.push_back(name.toInt());
		}
	}

	// alloc an index
	if (!v.empty()) {
		sort(v.begin(), v.end());
		taskidx = v.back() + 1;
	}
	else {
		taskidx = 0;
	}

	// create a new folder
	newdir.sprintf("%d", taskidx);
	dir.mkdir(newdir);
	dir.cd(newdir);
	path = dir.absolutePath();

	//qDebug() << StrBuff.c_str();
	return taskidx;
}


void FitTaskPage::CreateTask(QString taskpath, QString name) {

	// EAPOT path
	QDir TaskDir(taskpath), WorkDir;
    QDir EAPOTDir(setPage->getEAPOTDir());

	// Create Task, TaskProcess and name it
    Tasks.push_back(new TaskObject(this));
    TaskObject* newTask = Tasks.back();
    newTask->name = name;
    newTask->TaskDir = TaskDir;
    newTask->EAPOTPath = EAPOTDir.absolutePath();

	// send status a message
    QString msg = QString("Submit to %1 in Dir: %2").arg(newTask->EAPOTPath).arg(newTask->TaskDir.absolutePath());
    frame->statusBar()->showMessage(msg);

	// Connect the process finish event 
#define FinishSingal static_cast<void (QProcess:: *)(int, QProcess::ExitStatus)>(&QProcess::finished)
    //connect(newTask, FinishSingal, newTask, &QProcess::deleteLater);
    connect(newTask, FinishSingal, this, &FitTaskPage::TaskFinishedSlot);
    connect(newTask, &QProcess::started, this, &FitTaskPage::TaskStartedSlot);
    connect(newTask, &QProcess::errorOccurred, this, &FitTaskPage::TaskErrorSlot);
#undef  FinishSingal

    // Add an item into task list
    TaskWidgetItem *item = new TaskWidgetItem(newTask, ui.TaskList);
    item->setText(newTask->name + " (N)");
    ui.TaskList->setCurrentRow(ui.TaskList->count() - 1);
    newTask->widget = item;

	// Prepare for the task process and add name to the TaskList
    QStringList arg = {"-j", TaskDir.absoluteFilePath("EAPOT.json")};
    newTask->setWorkingDirectory(newTask->TaskDir.absolutePath());
    newTask->start(newTask->EAPOTPath, arg);
}


void FitTaskPage::TaskStartedSlot()
{
    TaskObject *itask = static_cast<TaskObject*>(sender());
    QListWidgetItem *item = itask->widget;
    if (item){
        item->setText(itask->name + " (R)");
    }

    itask->isRunning = true;
    itask->timer.start();
    itask->start_time = QTime::currentTime().toString("hh:mm:ss");
    itask->stateStr = "R";
	
}


void FitTaskPage::TaskErrorSlot(QProcess::ProcessError error)
{
    TaskObject *itask = static_cast<TaskObject*>(sender());
    QListWidgetItem *item = itask->widget;
    if (item){
        item->setText(itask->name + " (E)");
    }

    itask->isRunning = false;
    itask->finish_state = "error";
    itask->stateStr = "E";

	UpdateRefresh(TaskObject::Force);

    QString msg = "Task " +  itask->name + " error with ";
	msg += QMetaEnum::fromType<QProcess::ProcessError>().valueToKey(error);

    if (!QFile::exists(itask->EAPOTPath)) {
        msg += ": EAPOT is not exist: " + itask->EAPOTPath;
	}

	frame->statusBar()->showMessage(msg);
}


void FitTaskPage::TaskFinishedSlot(int, QProcess::ExitStatus exitStatus)
{
    TaskObject *itask = static_cast<TaskObject*>(sender());
    QListWidgetItem *item = itask->widget;
    if (item){
        item->setText(itask->name + " (C)");
    }

    itask->isRunning = false;
    itask->cost_time.sprintf("%.1f", itask->timer.elapsed() / 1000.0);
    itask->finish_time = QTime::currentTime().toString("hh:mm:ss");
    itask->finish_state = "done";
    itask->stateStr = "C";

	UpdateRefresh(TaskObject::Force);

    QString msg = "Task " +  itask->name + " finished with ";
	msg += QMetaEnum::fromType<QProcess::ExitStatus>().valueToKey(exitStatus);
	frame->statusBar()->showMessage(msg);
}


void FitTaskPage::CancelTaskSlot() {

    TaskWidgetItem *item = (TaskWidgetItem*)ui.TaskList->currentItem();
    if (!item) return;

    TaskObject *itask = item->taskObject;
    item->setText(itask->name + " (C)");

    if (itask->isRunning) {
        if (QProcess::Running == itask->state()) {
            itask->kill();
        }
    }

}

void FitTaskPage::DeleteTaskSlot() {

    CancelTaskSlot();

    int idx = ui.TaskList->currentRow();
    if (idx < 0) return;

    TaskWidgetItem *item = (TaskWidgetItem*)ui.TaskList->takeItem(idx);
    item->taskObject->widget = nullptr;
    delete item;
}

void FitTaskPage::WriteRunOnceSlot() {
    frame->PageRaise(MainPage::EAMFit);
    //set->RunPageRaise();

    QString TaskDir = QDir(setPage->getTaskDir()).absoluteFilePath("once");

    QJsonObject json;
    setPage->ExportJson(json);
    io->Json2File(TaskDir, "EAPOT.json", json);
}


void FitTaskPage::WriteRunFitSlot() {
    frame->PageRaise(MainPage::EAMFit);
    //set->RunPageRaise();

    QString TaskDir;
    AllocNewTask(TaskDir);

    QJsonObject json;
    setPage->ExportJson(json);
    io->Json2File(TaskDir, "EAPOT.json", json);
}


void FitTaskPage::CreateRunOnceSlot() {
    frame->PageRaise(MainPage::EAMFit);
    //set->RunPageRaise();

    QString TaskDir = QDir(setPage->getTaskDir()).absoluteFilePath("once");

    QJsonObject json;
    setPage->ExportJson(json);
    io->Json2File(TaskDir, "EAPOT.json", json);

    CreateTask(TaskDir, "once");
}


void FitTaskPage::CreateRunFitSlot() {
	frame->PageRaise(MainPage::EAMFit);
    //set->RunPageRaise();

    QString TaskDir;
    int idx = AllocNewTask(TaskDir);

    QJsonObject json;
    setPage->ExportJson(json);
    io->Json2File(TaskDir, "EAPOT.json", json);

    CreateTask(TaskDir, QString("%1").arg(idx));
}


void FitTaskPage::plotThermoSeries(const QString& thermo){

    struct Point {
        double x, y;
    };

    QVector<Point> point;
    double x = 0, y = 0, yMAX = maxY;
    double ymax = maxY, ymin = maxY;
    auto lines = thermo.split('\n');

    auto keys = lines[0].split(QRegExp("\\s+"), QString::SkipEmptyParts);

    if (!keys.contains("err") || !keys.contains("step")) return;
    int ierr  = keys.indexOf("err");
    int istep = keys.indexOf("step");

    for(int k = 2; k < lines.size(); k++){
        auto v = lines[k].split(QRegExp("\\s+"), QString::SkipEmptyParts);
        if (v.size() < 2) break;

        x = v[istep].toDouble();
        y = v[ierr].toDouble();
        yMAX = MAX(yMAX, y);
        point.append({ x, y });
    }

    int least = 10;
    int start, count = point.size();

    if (count > least){
        // At least 10 points
        start = static_cast<int>(count*0.3);
        start = MIN(count-least, start);

        ymin = point[0].y;
        ymax = point[start].y;

        for (Point ip : point){
            ymin = fmin(ymin, ip.y);
        }
        ymax = fmax(ymin*10, ymax);
        ymax = fmin(ymax, yMAX);
    } else {
        ymax = yMAX;
    }

    // Eliminate those points with extremely large values, otherwise the lineSeries will disappear
    lineSeries->clear();
    scatterSeries->clear();
    for (Point ip : point) {
        double ys = fmin(ip.y, ymax*5);
        lineSeries->append(ip.x, ys);
        scatterSeries->append(ip.x, ys);
    }

    chart->axes(Qt::Horizontal, lineSeries).first()->setMax(x>maxX?x:maxX);
    chart->axes(Qt::Vertical, lineSeries).first()->setMax(ymax*1.1);
}

/****************************************************************************************************/
// Absolutely refresh in the following three cases, ignoring whether the task is performed
// 1. User selects different display options
// 2. User chooses different tasks
// 3. At the end of the mission
// 
// Relative refresh when the timer is triggered
// 1. Refresh only current task, current display options
// 2. Once the task is over, it will not be refreshed.
// 
// input: Zero for Relative refresh.None-zero for Absolutely refresh
/****************************************************************************************************/

void FitTaskPage::UpdateRefresh(int updatemode) {

    TaskWidgetItem *item = (TaskWidgetItem*)ui.TaskList->currentItem();
    if (!item) return;

    TaskObject &ctask = *item->taskObject;
    if (false == ctask.isRunning && !updatemode) return;

    int mode = updatemode;

    switch (ui.UpdatePage->currentIndex()) {
    case 0:{
        mode |= TaskObject::Thermo;
        ctask.CreateInfo(mode);

        plotThermoSeries(ctask.thermo);
        break;
    }

    case 1:
        mode |= TaskObject::Image;
        ctask.CreateInfo(mode);

        if (ctask.image.isNull()){
            ui.UpdateSnapLabel->setText("No Preview\n This can be no figure output "
                "or current potential type does not support snap");
        }
        else{
            ui.UpdateSnapLabel->setPixmap(ctask.image);
        }

        break;
    case 2: {
        mode |= TaskObject::Thermo;
        ctask.CreateInfo(mode);

        statusModel->setText(ctask.thermo);

        // scrollTo last line
        QModelIndex index = statusModel->index(statusModel->getValidRowNum(), 0);
        ui.UpdateStatusView->scrollTo(index);
        break;
    }
    case 3: {
        mode |= TaskObject::Check;
        ctask.CreateInfo(mode);

        checkModel->setText(ctask.check);

        // scrollTo last line
        QModelIndex index = checkModel->index(checkModel->getValidRowNum(), 0);
        ui.UpdateCheckView->scrollTo(index);
        break;
    }
    case 4:{
        mode |= TaskObject::Info;
        ctask.CreateInfo(mode);

        ui.UpdateInfoEdit->setPlainText(ctask.info);
        break;
    }
    case 5:{
        mode |= TaskObject::Log;
        ctask.CreateInfo(mode);

        QScrollBar *scrollbar = ui.UpdateLogEdit->verticalScrollBar();
        auto curPos = scrollbar->sliderPosition();
        ui.UpdateLogEdit->setPlainText(ctask.log);
        if (scrollbar) scrollbar->setSliderPosition(curPos);
        break;
    }
    }
}

