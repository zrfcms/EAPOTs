#pragma once

#include "UiPtr.h"
#include <QDir>
#include <QProcess>
#include <QPixmap>
#include <QWidget>
#include <QTime>
#include "ui_FitTaskPage.h"
#include "EAExtraWidget.h"

#include <QChart>
#include <QChartView>
#include <QLineSeries>
#include <QScatterSeries>
#include <QListWidgetItem>

#include "PythonHighlighter.h"

using namespace QtCharts;

namespace EAPUI_NS {

    class TaskObject : public QProcess
	{
        Q_OBJECT
	public:
        explicit TaskObject(class FitTaskPage*);

		class FitTaskPage* task;
		volatile bool isRunning;

		QString name;
        QString stateStr;
		QDir TaskDir;
		QString EAPOTPath;

		QString start_time;
		QString finish_time;
		QString finish_state;
		QString cost_time;

		QString info;
		QString thermo;
		QString check;
        QString log;
        QPixmap image;

        QTime timer;
        QString chkfile, imagefile;
		void CreateInfo(int mode);	

		enum InfoMode {
			Force = 1,
			Image = 2,
			Thermo = 4,
			Check = 8,
			Info = 16,
            Log = 32,
		};

        class TaskWidgetItem* widget;
	};

    class TaskWidgetItem : public QListWidgetItem
    {
    public:
        explicit TaskWidgetItem(TaskObject* itask, QListWidget *view = nullptr)
            : QListWidgetItem(view)
            , taskObject(itask) {
        }
        ~TaskWidgetItem() {};
        class TaskObject* taskObject;

    public slots:

    };

	class FitTaskPage : public QWidget, public UiPtr {
		Q_OBJECT
	public:
		FitTaskPage(QWidget *parent, EAPUI* ptr);
        ~FitTaskPage();

		Ui_FitTaskPage ui;
		void init();

		QTimer *timer;
        PythonHighlighter* Highlighter;
        std::vector<TaskObject*> Tasks;


		// Task setttings
		int AllocNewTask(QString &path);
		void CreateTask(QString path, QString name);
        void plotThermoSeries(const QString& thermo);
		void UpdateRefresh(int);
        void setCustomFont(const QFont& font);

    public:
        // Chart
        double maxX, maxY;
        QChart *chart;
        QChartView *chartView;
        QLineSeries *lineSeries;
        QScatterSeries *scatterSeries;

    public:
        ReadOnlyTableModel* statusModel;
        ReadOnlyTableModel* checkModel;

	public slots:
		void TaskStartedSlot();
		void TaskErrorSlot(QProcess::ProcessError error);
		void TaskFinishedSlot(int exitCode, QProcess::ExitStatus exitStatus);

		void CreateRunOnceSlot();
		void CreateRunFitSlot();
		void WriteRunOnceSlot();
		void WriteRunFitSlot();
		void CancelTaskSlot();
        void DeleteTaskSlot();
	};

}
