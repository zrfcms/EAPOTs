#include "EAPFrame.h"
#include "EAPIO.h"
#include "EAPTask.h"

#include <QJsonParseError>
#include <QDialog>
#include <QFileDialog>
#include <QDialogButtonBox>

#include <QFontDialog>
#include <QSplitter>
#include "EAPSetPage.h"
#include "FileBrowserPage.h"
#include "AbInitioPage.h"
#include "StructGLPage.h"
#include "EAPlotPage.h"

#include <QtWidgets/QDockWidget>
#include <QtWidgets/QMainWindow>

using namespace EAPUI_NS;

EAPFrame::EAPFrame(QWidget *parent, EAPUI* ptr)
	: QMainWindow(parent)
	, UiPtr(ptr)
{
	ui.setupUi(this);    

	//QWidget* p = takeCentralWidget();
	//if (p) delete p;
	setWindowIcon(QIcon(":/image/icon/icon32"));


    EAPfitPage = new QWidget(this);
    QVBoxLayout* Layout = new QVBoxLayout(EAPfitPage);

    fitPageSplitter = new QSplitter(EAPfitPage);
    fitPageSplitter->setOrientation(Qt::Vertical);
    fitPageSplitter->setHandleWidth(5);

    Layout->addWidget(fitPageSplitter);
    Layout->setSpacing(0);
    Layout->setContentsMargins(0, 0, 0, 0);

    if (eapui->FitMode == EAPUI::SINGLE){
        setWindowTitle("EAPOTsUI");
    } else {
        setWindowTitle("EAPOTcUI");
    }
}

EAPFrame::~EAPFrame() {
	
}

QDockWidget* EAPFrame::addDockPage(QWidget* widget, const QString& title) {
	QDockWidget* dock = new QDockWidget();
	DockList.append(dock);
	dock->setWidget(widget);
	dock->setWindowTitle(title);
	addDockWidget(Qt::RightDockWidgetArea, dock);
	return dock;
}

void EAPFrame::PageRaise(int idx) {
	switch (FrameMode) {

	case FrameModeEnum::Tab:
		ui.MainStackedWidget->setCurrentIndex(idx);
		break;

	case FrameModeEnum::Dock:
		DockList[idx]->raise();
		break;

	default:
		break;
	}
}

void EAPFrame::PageRaise(MainPage page) {
	PageRaise(static_cast<int>(page));
};

void EAPFrame::setFrameMode(int idx) {
	setFrameMode(static_cast<FrameModeEnum>(idx));
}

void EAPFrame::setFrameMode(FrameModeEnum mode) {
	FrameMode = mode;
	switch (FrameMode) {

	case FrameModeEnum::Tab: {

        ui.MainStackedWidget->addWidget(EAPfitPage);
		ui.MainStackedWidget->addWidget(abInitio);		
		ui.MainStackedWidget->addWidget(structGL);
        ui.MainStackedWidget->addWidget(EAPlot);

        QTabWidget* TabWidget = abInitio->createPage->cui.ModifyListTabWidget;
		TabWidget->addTab(fileBrowser, "File Browser");
        TabWidget->setCurrentIndex(0);

		ui.MainStackedWidget->setCurrentIndex(0);
		ui.MainStackedWidget->show();

		for (auto iPage : DockList) {
			delete iPage;
		}
		DockList.clear();
		break;
	}

	case FrameModeEnum::Dock: {
		QDockWidget* dock;
        dock = addDockPage(EAPfitPage, "Potential Fit");

		dock = addDockPage(abInitio, "Struct Modify");
		dock->setFeatures(QDockWidget::DockWidgetClosable);

        dock = addDockPage(structGL, "Struct Edit");
        dock->setFeatures(QDockWidget::DockWidgetClosable);

        dock = addDockPage(EAPlot, "Potential Plot");

		dock = addDockPage(fileBrowser, "File Browser");


		splitDockWidget(DockList[4], DockList[0], Qt::Horizontal);
		tabifyDockWidget(DockList[0], DockList[1]);
		tabifyDockWidget(DockList[0], DockList[2]);
		tabifyDockWidget(DockList[0], DockList[3]);

		DockList[0]->raise();
		ui.MainStackedWidget->hide();
		break;
	}

	default:
		break;
	}

	PageRaise(MainPage::EAMFit);
}


void EAPFrame::init(QJsonObject &rootObj) {

	setFrameMode(FrameModeEnum::Tab);

    LoadConfigJson(rootObj);

    QString defaultProject = rootObj["defaultProject"].toString("../example/Metal-Cu-eam-voter");

	connect(ui.actionOpen, &QAction::triggered, this, [=]() { ReadSlot(""); });
    connect(ui.actionRset, &QAction::triggered, this, [=]() { ReadSlot(defaultProject); });
	connect(ui.actionSave, &QAction::triggered, this, [=]() { WriteSlot(SaveFile); });
	connect(ui.actionSaveAs, &QAction::triggered, this, [=]() { WriteSlot(""); });

	connect(ui.actionFitting, &QAction::triggered, this, [=]() {PageRaise(MainPage::EAMFit); });
    connect(ui.actionPresetting, &QAction::triggered, this, [=]() {PageRaise(MainPage::StructModify); });
    connect(ui.actionModeling, &QAction::triggered, this, [=]() {PageRaise(MainPage::StructEdit); });
    connect(ui.actionPlotting, &QAction::triggered, this, [=]() {PageRaise(MainPage::EAPlot); });

    connect(ui.actionQuit, &QAction::triggered, this, [=]() { QApplication* app; app->quit(); });

    connect(ui.actionCopy, &QAction::triggered, this, &EAPFrame::createCopyRightDialog);
    connect(ui.actionHelp, &QAction::triggered, this, &EAPFrame::createCopyRightDialog);
	connect(ui.actionSettings, &QAction::triggered, this, &EAPFrame::createSettingsDialog);
    connect(ui.actionFont, &QAction::triggered, this, [=](){
        bool ok;
        QFont font = QFontDialog::getFont(&ok,this);
        if (ok){
            if (font.pointSize() > 15) font.setPointSize(15);
            qApp->setFont(font);
            taskPage->setCustomFont(font);
            emit fontChangeSlot();
        }
    });

    ui.actionSettings->setVisible(eapui->BetaMode);
}


void EAPFrame::ReadSlot(QString strFile) {
    QFileInfo fi(strFile);
    if (!fi.exists()) {
        strFile = QFileDialog::getOpenFileName(this,
            tr("load project json file"), OpenInitDir, tr("json (*.json *.Json)"));
    }

    QJsonObject obj = io->loadJsonObject(strFile);
    if(obj == QJsonObject()) return;
    OpenInitDir = QFileInfo(strFile).absolutePath();

    setPage->ImportJson(obj);
	PageRaise(MainPage::EAMFit);
}

void EAPFrame::WriteSlot(QString strFile) {
	QFileInfo fi(strFile);

	if (!fi.exists()) {
		strFile = QFileDialog::getSaveFileName(this, 
            tr("save project json file"), OpenInitDir, "json (*.json *.Json)");
	}

	SaveFile = strFile;
	OpenInitDir = QFileInfo(strFile).absolutePath();

	QJsonObject json;
    setPage->ExportJson(json);
    io->Json2File(SaveFile, json);
}


void EAPFrame::LoadConfigJson(QJsonObject &rootObj) {
	if (rootObj.contains("resdir")) {
		QDir dir(rootObj["resdir"].toString());
		ResDir.setPath(dir.absolutePath());
	}
}


SettingsDialog::SettingsDialog(QWidget *parent)
    : QDialog(parent) {
    ui.setupUi(this);
}

SettingsDialog::~SettingsDialog()
{
}

void EAPFrame::createSettingsDialog() {
	SettingsDialog* dialog = new SettingsDialog(this);

	dialog->ui.TabViewButton->setChecked(FrameMode == FrameModeEnum::Tab);
	dialog->ui.DockViewButton->setChecked(FrameMode == FrameModeEnum::Dock);

	int ret = dialog->exec();
	if (ret == QDialog::Accepted) {
		if (dialog->ui.TabViewButton->isChecked()) {
			FrameMode = FrameModeEnum::Tab;
		}
		else if (dialog->ui.DockViewButton->isChecked()) {
			FrameMode = FrameModeEnum::Dock;
		}
		setFrameMode(FrameMode);
	}
	delete dialog;
}


CopyRightDialog::CopyRightDialog(QWidget *parent)
    : QDialog(parent) {
    ui.setupUi(this);
}

CopyRightDialog::~CopyRightDialog(){

}


/****************************************************************************************************/
// Create a CopyRightDialog, containing CopyRight
/****************************************************************************************************/
void EAPFrame::createCopyRightDialog() {
    CopyRightDialog dialog(this);
    dialog.setPalette(QPalette(QColor(255,255,255)));
    dialog.exec();
}



