#pragma once

#include "UiPtr.h"

#include <QString>
#include <QJsonObject>
#include <QDir>
#include <QLineEdit>
#include <QTextEdit>
#include <QPlainTextEdit>
#include <QCheckBox>
#include <QComboBox>
#include <QPushButton>
#include <QStringList>
#include <QWidget>
#include <QTableWidget>
#include <QProgressDialog>
#include <QStandardItemModel>

namespace EAPUI_NS {

	class EAPIO : public QObject, protected UiPtr {
		Q_OBJECT
	public:
		EAPIO(QObject *parent, class EAPUI *ptr);
        ~EAPIO() {}

        QStringList ErrMsg;
        int warning(const char*, int, const QString&);
        int error(const char*, int, const QString&);
        int statusMsg(const QString&);

        QProgressDialog* progress;
        static void Sleep(unsigned long msec);
        void ProgressDialogStart(int lo, int hi);
        void ProgressDialogFinish(bool close, const QString&);

		static bool isDigitStr(QString src);
        static QString SpaceString(const QStringList &list, const QVector<bool> &v);
        static QString SpaceString(const QStringList &list, const QVector<int> &v);

		static QStringList AutoOpenFile(const QDir& dir, const QString& suffix);
		static QStringList AutoOpenFile(const QDir& dir, const QStringList& suffix);
		static void connectButtonDirEdit(QPushButton*, QString& title, QLineEdit*);

        static WidgetType GetWidgetType(QLineEdit*) { return QLEdit; }
        static WidgetType GetWidgetType(QTextEdit*) { return QTEdit; }
        static WidgetType GetWidgetType(QPlainTextEdit*) { return QPEdit; }
        static WidgetType GetWidgetType(QCheckBox*) { return QChkBox; }
        static WidgetType GetWidgetType(QComboBox*) { return QComb; }

		static bool Get(QCheckBox *);
		static const QString Get(QLineEdit *);
		static const QString Get(QComboBox *);
		static const QString Get(QComboBox *, const QStringList&);
		static const QString Get(QTextEdit *);
		static const QString Get(QPlainTextEdit *);
		static const QString Get(QTableWidget*, int, int);

		static void ResetQStandardModel(QStandardItemModel*, const QString str = "", 
			int rlo = 0, int rhi = INT_MAX, int clo = 0, int chi = INT_MAX);
		static void ResetQStandardModelRow(QStandardItemModel*, int i, const QString str = "", 
			int clo = 0, int chi = INT_MAX);
		static void ResetQStandardModelColumn(QStandardItemModel*, int j, const QString str = "", 
			int rlo = 0, int rhi = INT_MAX);

		static int Set(const QString&, QComboBox*);
		static int Set(const QString&, QComboBox*, const QStringList&);
		static void SetJsonKey(const QJsonObject&, const QString&, QString&);
		static void SetJsonKey(const QJsonObject&, const QString&, QLineEdit*);
		static void SetJsonKey(const QJsonObject&, const QString&, QTextEdit*);
		static void SetJsonKey(const QJsonObject&, const QString&, QPlainTextEdit*);
		static void SetJsonKey(const QJsonObject&, const QString&, QCheckBox*);
		static void SetJsonKey(const QJsonObject&, const QString&, QComboBox*);
		static void SetJsonKey(const QJsonObject&, const QString&, QComboBox*, const QStringList&);
		static void SetJsonKey(const QJsonObject&, const QString&, QWidget*, WidgetType);

        bool ImportEnable(const QJsonObject&, const QString&);
		static void ImportJsonKeys(const QJsonObject &main, const QString &page, QVector<JsonKey> &idx);
		static void ExportJsonKeys(QJsonObject &main, const QString &page, QVector<JsonKey> &idx);
		static QJsonObject loadJsonObject(const QString& pfile);

        QString File2Stirng(const char*, int, QString file);
        void Stirng2File(QString dir, QString file, const QString&);
        void Stirng2File(QString dir, QString file, const QByteArray&);
        void Stirng2File(QString file, const QString&);
        void Stirng2File(QString pfile, const QByteArray&);

        void Json2File(QString dir, QString file, const QJsonObject&);
        void Json2File(QString file, const QJsonObject&);

        static inline bool QString2Bool(const QString& str) {
			return str == "true";
		}
		static inline QString Bool2QString(bool b) {
			return b ? "true" : "false";
		}

		static inline bool CheckStr2Bool(const QString& str) {
			return str == "yes";
		}
		static inline QString Bool2CheckStr(bool b) {
			return b ? "yes" : "no";
		}



		// ******************************************************************
		// pop-up dialogue box 
		// ******************************************************************
        static QVector<int> selectDialog(QString labelTxt, QWidget* parent, QStringList keys);
        static QVector<bool> CheckButtonDialog(QStringList& list, const QString &title, QWidget *parent = nullptr);
	};
}



