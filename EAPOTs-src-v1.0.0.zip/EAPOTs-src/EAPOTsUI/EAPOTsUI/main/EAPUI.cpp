#include "EAPUI.h"

#include "EAPIO.h"
#include "EAPFrame.h"
#include "EAPTask.h"

#include "EAPSetPage.h"
#include "FileBrowserPage.h"
#include "AbInitioPage.h"
#include "EAPlotPage.h"
#include "StructGLPage.h"
#include "PythonHighLighter.h"

#include <QJsonArray>
#include <QJsonParseError>

using namespace EAPUI_NS;

void addKey(QStringList& list, const QJsonArray& jarray){
    foreach (const auto& ivalue, jarray) {
        const QString& key = ivalue.toString();
        if (!list.contains(key)) list << key;
    }
}


EAPUI::EAPUI(int , char *[]){

    BetaMode = 0;
    FitMode = SINGLE;

	frame = new EAPFrame(Q_NULLPTR, this);
    io = new EAPIO(frame, this);

    QJsonObject rootObj;
    if (QFile().exists("../config/config.json")){
        rootObj = io->loadJsonObject("../config/config.json");

        QFont font = qApp->font();
        font.setPointSize(rootObj["fontsize"].toInt());
        qApp->setFont(font);

        QJsonObject HighLighter = rootObj["PythonHighLighter"].toObject();

        auto& styles = PythonHighlighter::STYLES;
        QJsonObject FormatMap = HighLighter["FormatMap"].toObject();
        for(auto iter = FormatMap.begin(); iter != FormatMap.end(); iter++) {
            const QString& ikey = iter.key();
            const auto& ifmt = iter.value().toArray();
            styles[ikey] = PythonHighlighter::format(ifmt[0].toString(), ifmt[1].toString());
        }

        addKey(PythonHighlighter::braces, HighLighter["Braces"].toArray());
        addKey(PythonHighlighter::keywords, HighLighter["Keywords"].toArray());
        addKey(PythonHighlighter::operators, HighLighter["Operators"].toArray());
    }

    if (QFile().exists("../config/debug.json")){
        QJsonObject debugObj = io->loadJsonObject("../config/debug.json");
        QString mode = debugObj["appMode"].toString("single");

        if (mode == "single") FitMode = SINGLE;
        if (mode == "cross")  FitMode = CROSS;
        if (mode == "BCN")    FitMode = BCN;
        BetaMode = 1;
    }

    setPage = new EAPSetPage(frame->fitPageSplitter, this, rootObj);
    frame->fitPageSplitter->addWidget(setPage);
    taskPage = new FitTaskPage(frame->fitPageSplitter, this);
    frame->fitPageSplitter->addWidget(taskPage);

    setPage->func = new SinglePage(setPage, this);
    setPage->ui.SetPage->insertWidget(0, setPage->func);
    setPage->ui.SetPage->setCurrentIndex(0);

	fileBrowser = new FileBrowserPage(frame, this);
	abInitio = new AbInitioPage(frame, this);
	EAPlot = new EAPlotPage(frame, this);
	structGL = new StructGLPage(frame, this);


    taskPage->init();
    setPage->init(rootObj);

	fileBrowser->init();
	abInitio->init();
	EAPlot->init();
	structGL->init();

    frame->init(rootObj);

    setPage->JsonKeyInitialize();
    frame->ui.actionRset->triggered();
};

EAPUI::~EAPUI() {

};

void loadConfiguration();
