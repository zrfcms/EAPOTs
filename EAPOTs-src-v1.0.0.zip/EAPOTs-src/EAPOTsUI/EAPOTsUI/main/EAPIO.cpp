#include "EAPIO.h"
#include "FuncPage.h"
#include "EAPFrame.h"
#include <QJsonObject>
#include <QDialog>
#include <QListWidget>
#include <QCheckBox>
#include <QFileDialog>
#include <QVBoxLayout>
#include <QDialogButtonBox>

#include <QJsonDocument>
#include <QJsonParseError>
#include <QMutex>
#include <QWaitCondition>

using namespace EAPUI_NS;

EAPIO::EAPIO(QObject *parent, EAPUI *ptr)
	: QObject(parent)
	, UiPtr(ptr) 
{
    progress = nullptr;
};

int EAPIO::warning(const char* file, int line, const QString& msg){
    QString str = QString("ERROR: %1 (%2:%3)\n").arg(msg).arg(file).arg(line);
    frame->statusBar()->showMessage(str);
    ErrMsg.append(str);
    return 1;
}

int EAPIO::error(const char* file, int line, const QString& msg){
    QString str = QString("ERROR: %1 (%2:%3)\n").arg(msg).arg(file).arg(line);
    frame->statusBar()->showMessage(str);
    ErrMsg.append(str);
    return 2;
}

int EAPIO::statusMsg(const QString& msg){
    frame->statusBar()->showMessage(msg);
    return 0;
}


void EAPIO::Sleep(unsigned long msec){
    QMutex mutex;
    mutex.lock();
    QWaitCondition().wait(&mutex, msec);
    mutex.unlock();
}

void EAPIO::ProgressDialogStart(int lo, int hi){

    if (progress) delete progress;
    progress = new QProgressDialog();

    // Set the mouse to wait
    QApplication::setOverrideCursor(Qt::WaitCursor);

    progress->setWindowTitle(tr("Note"));
    progress->setLabelText(tr("Waiting..."));
    progress->setCancelButtonText(tr("Cancel"));

    progress->setRange(lo, hi);
    progress->setModal(true);// Set as modal dialog
    progress->setAutoClose(false);
    progress->setAutoReset(false);

    progress->show();
}

void EAPIO::ProgressDialogFinish(bool close,  const QString& msg){
    progress->setWindowTitle(tr("Finish"));
    progress->setLabelText(msg);
    progress->setCancelButtonText(tr("OK"));

    QApplication::restoreOverrideCursor();
    if(close) progress->close();

    statusMsg(msg);
}




QStringList EAPIO::AutoOpenFile(const QDir& dir, const QStringList& suffixlist) {
	
	QStringList res;
	QString name, suffix;
	if (!dir.exists()) {
		return res;
	}
	
	QFileInfoList list = dir.entryInfoList();
	for (int i = 0; i < list.count(); i++)
	{
		QFileInfo fi = list.at(i);
		if (fi.isFile()) {

			name = fi.fileName();
			if (name[0] == '.') continue;

			suffix = fi.suffix();

			if (suffixlist.indexOf(suffix) < 0) continue;

			res.append(fi.absoluteFilePath());			
		}
	}

	return res;
}

QStringList EAPIO::AutoOpenFile(const QDir& dir, const QString& psuffix) {

	QStringList res;
	QString name, suffix;
	if (!dir.exists()) {
		return res;
	}

	QFileInfoList list = dir.entryInfoList();
	for (int i = 0; i < list.count(); i++)
	{
		QFileInfo fi = list.at(i);
		if (fi.isFile()) {

			name = fi.fileName();
			if (name[0] == '.') continue;

			suffix = fi.suffix();

			if (psuffix != suffix) continue;

			res.append(fi.absoluteFilePath());
		}
	}

	return res;
}

void EAPIO::connectButtonDirEdit(QPushButton* button ,QString& title,  QLineEdit* edit) {

	connect(button, &QPushButton::clicked, edit, [=]() {
		QString strFile = QFileDialog::getExistingDirectory(nullptr,
			title, edit->text());

		if (!strFile.isEmpty()) {
			edit->setText(strFile);
		}
    });
}

/****************************************************************************************************/
// Convert functions
// Convert widget information to C-style string
/****************************************************************************************************/

bool EAPIO::Get(QCheckBox *p) {
	if (p->checkState() == Qt::Checked) {
		return true;
	}
	else {
		return false;
	}
}

const QString EAPIO::Get(QLineEdit *p) {
	return p->text();
}

const QString EAPIO::Get(QComboBox *p) {
	return p->currentText();
}

const QString EAPIO::Get(QComboBox *p, const QStringList& list) {
	int idx = p->currentIndex();
	return list[idx];
}

const QString EAPIO::Get(QTextEdit *p) {
	return p->toPlainText();
}

const QString EAPIO::Get(QPlainTextEdit *p) {
	return p->toPlainText();
}

const QString EAPIO::Get(QTableWidget *p, int i, int j) {
	return p->item(i, j)->text();
}

void EAPIO::ResetQStandardModel(QStandardItemModel* model, const QString str, int rlo, int rhi, int clo, int chi) {
    rlo = MAX(0, rlo);
    rhi = MIN(rhi, model->rowCount());
    clo = MAX(0, clo);
    chi = MIN(chi, model->columnCount());

	if (rlo >= rhi) return;
	if (clo >= chi) return;

	for (int i = rlo; i < rhi; i++) {
		for (int j = clo; j < chi; j++) {
			model->item(i, j)->setText(str);
		}
	}
}

void EAPIO::ResetQStandardModelRow(QStandardItemModel* model, int i, const QString str, int clo, int chi) {
    clo = MAX(0, clo);
    chi = MIN(chi, model->columnCount());

	if (i < 0) return;
	if (i >= model->rowCount()) return;
	if (clo >= chi) return;

	for (int j = clo; j < chi; j++) {
		model->item(i, j)->setText(str);
	}	
}

void EAPIO::ResetQStandardModelColumn(QStandardItemModel* model, int j, const QString str, int rlo, int rhi) {
    rlo = MAX(0, rlo);
    rhi = MIN(rhi, model->rowCount());

	if (j < 0) return;
	if (j >= model->columnCount()) return;
	if (rlo >= rhi) return;

	for (int i = rlo; i < rhi; i++) {
		model->item(i, j)->setText(str);		
	}
}

int EAPIO::Set(const QString& str, QComboBox* comb) {

	int idx = comb->findText(str);

	if (idx >= 0) {
		comb->setCurrentIndex(idx);
	}

	return idx;
}

int EAPIO::Set(const QString& str, QComboBox* comb, const QStringList &list) {

	int idx = list.indexOf(str);

	if (idx >= 0) {
		comb->setCurrentIndex(idx);
	}

	return idx;
}

void EAPIO::SetJsonKey(const QJsonObject &obj, const QString& key, QString& value) {
	if (obj.contains(key)) {
		value = obj[key].toString();
	}
}

void EAPIO::SetJsonKey(const QJsonObject &obj, const QString& key, QLineEdit* edit) {
	if (obj.contains(key)) {
		edit->setText(obj[key].toString());
	}
}

void EAPIO::SetJsonKey(const QJsonObject& obj, const QString& key, QTextEdit* edit) {
	if (obj.contains(key)) {
		edit->setText(obj[key].toString());
	}
}

void EAPIO::SetJsonKey(const QJsonObject& obj, const QString& key, QPlainTextEdit* edit) {
	if (obj.contains(key)) {
		edit->setPlainText(obj[key].toString());
	}
}

void EAPIO::SetJsonKey(const QJsonObject& obj, const QString& key, QCheckBox* chk) {
	if (obj.contains(key)) {
		chk->setChecked(QString2Bool(obj[key].toString()));
	}
}

void EAPIO::SetJsonKey(const QJsonObject &obj, const QString& key, QComboBox* comb) {
	if (obj.contains(key)) {
		Set(obj[key].toString(), comb);
	}
}

void EAPIO::SetJsonKey(const QJsonObject &obj, const QString &key, QComboBox* comb, const QStringList& list) {
	if (obj.contains(key)) {
		Set(obj[key].toString(), comb, list);
	}
}



void EAPIO::SetJsonKey(const QJsonObject &obj, const QString &key, QWidget* w, WidgetType type) {
	if (obj.contains(key)) {

		switch (type) {
		case QLEdit:
			(qobject_cast<QLineEdit*>(w))->setText(obj[key].toString());
			return;
		case QTEdit:
			(qobject_cast<QTextEdit*>(w))->setText(obj[key].toString());
			return;
		case QPEdit:
			(qobject_cast<QPlainTextEdit*>(w))->setPlainText(obj[key].toString());
			return;
		case QChkBox:
			(qobject_cast<QCheckBox*>(w))->setChecked(QString2Bool(obj[key].toString()));
			return;
		case QComb:
			Set(obj[key].toString(), qobject_cast<QComboBox*>(w));
            return;
        case QJson:
            qobject_cast<FuncPage*>(w)->importJson(obj[key].toObject());
			return;
		}
	}
}


/****************************************************************************************************/
// Create a string separated by space
// input:  Options Strings(vector<std::string>), Options results(vector<bool>)
// output: QString separated by a space
/****************************************************************************************************/

QString EAPIO::SpaceString(const QStringList &list, const QVector<bool> &boolvec){
    QString str;

    for (int i = 0; i < list.size(); i++) {
        if (boolvec[i]) {
            if (!str.isEmpty()) str.append(' ');
            str.append(list[i]);
        }
    }

    return str;
}

/****************************************************************************************************/
// Create a string separated by space
// input:  Options Strings(vector<std::string>), Selection index(vector<int>)
// output: QString separated by a space
/****************************************************************************************************/

QString EAPIO::SpaceString(const QStringList &list, const QVector<int> &v){
    QString str;
    foreach (int i, v) {
        if (!str.isEmpty()) str.append(' ');
        str.append(list[i]);
    }
    return str;
}


bool EAPIO::isDigitStr(QString src)
{
	QByteArray ba = src.toLatin1();
	const char *s = ba.data();

	while (*s && *s >= '0' && *s <= '9') s++;

	if (*s) {
		return false;	// not an number
	}
	else {
		return true;	// is an number
	}
	return false;
}



bool EAPIO::ImportEnable(const QJsonObject &main, const QString &key) {

	if (!main.contains(key)) return false;

	QJsonValue val = main[key];
	if (!val.isObject()) {
		frame->statusBar()->showMessage("Targets value is not an Array in " + key);
		return false;
	}

	return true;
}


void EAPIO::ImportJsonKeys(const QJsonObject &main, const QString &page, QVector<JsonKey> &v) {

	QJsonObject obj = main[page].toObject();

	const int n = v.size();

	for (int i = 0; i < n; i++) {
		EAPIO::SetJsonKey(obj, v[i].Key, v[i].Widget, v[i].Type);
	}
}

void EAPIO::ExportJsonKeys(QJsonObject &main, const QString &page, QVector<JsonKey> &v) {

	QJsonObject obj;

    foreach (const JsonKey& vi, v) {

        QObject* w = vi.Widget;
        switch (vi.Type) {
        case QLEdit:
            obj.insert(vi.Key, QString(qobject_cast<QLineEdit*>(w)->text())); break;
        case QTEdit:
            obj.insert(vi.Key, QString(qobject_cast<QTextEdit*>(w)->toPlainText())); break;
        case QPEdit:
            obj.insert(vi.Key, QString(qobject_cast<QPlainTextEdit*>(w)->toPlainText())); break;
        case QChkBox:
            obj.insert(vi.Key, Bool2QString((qobject_cast<QCheckBox*>(w)->isChecked()))); break;
        case QComb:
            obj.insert(vi.Key, QString(qobject_cast<QComboBox*>(w)->currentText())); break;
        case QJson:
            obj.insert(vi.Key, (qobject_cast<FuncPage*>(w))->exportJson()); break;
        }
	}

	main.insert(page, QJsonValue(obj));
}

QJsonObject EAPIO::loadJsonObject(const QString& pfile) {
	QFile loadFile(pfile);
	if (!loadFile.open(QIODevice::ReadOnly)) {
		return QJsonObject();
	}
	QByteArray allData = loadFile.readAll();
	loadFile.close();

	QJsonParseError json_error;
	QJsonDocument ConfigJson(QJsonDocument::fromJson(allData, &json_error));
	if (json_error.error != QJsonParseError::NoError) {
		return QJsonObject();
	}
	return ConfigJson.object();
}


QString EAPIO::File2Stirng(const char* FILE, int LINE, QString pfile){
    QString data;
    QFile file(pfile);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)){
        data = file.readAll();
        file.close();
    } else{
        error(FILE, LINE, QString("file %1 open error").arg(pfile));
    }
    return data;
}


void EAPIO::Stirng2File(QString pfile, const QByteArray& str) {

	QFile file(pfile);
	if (!file.open(QFile::WriteOnly | QFile::Text))
	{
        error(FLERR, "Can not write into file:" + pfile);
		return;
	}
	file.write(str);
	file.close();
}

void EAPIO::Stirng2File(QString pfile, const QString& str) {
    QByteArray array = str.toLatin1();
    Stirng2File(pfile, array);
}

void EAPIO::Stirng2File(QString pdir, QString pfile, const QByteArray& str) {

	QDir dir;
	if (!dir.exists(pdir)) {
		dir.mkdir(pdir);
	}
	dir.cd(pdir);

	QFile file(dir.absoluteFilePath(pfile));
	if (!file.open(QFile::WriteOnly | QFile::Text))
	{
        error(FLERR, "Can not write into file:" + dir.absoluteFilePath(pfile));
		return;
	}
    file.write(str);
	file.close();
}

void EAPIO::Stirng2File(QString pdir, QString pfile, const QString& str) {

    QByteArray array = str.toLatin1();
    Stirng2File(pdir, pfile, array);
}

void EAPIO::Json2File(QString pdir, QString pfile, const QJsonObject& json){
    QByteArray array = QJsonDocument(json).toJson(QJsonDocument::Indented);
    array.replace('\n' + QString(20, ' '), " ");
    array.replace('\n' + QString(16, ' '), " ");

    array.replace('\n' + QString(16, ' ') + ']', "]");
    array.replace('\n' + QString(12, ' ') + ']', "]");
    Stirng2File(pdir, pfile, array);
}

void EAPIO::Json2File(QString pfile, const QJsonObject& json){
    QByteArray array = QJsonDocument(json).toJson(QJsonDocument::Indented);
    array.replace('\n' + QString(20, ' '), " ");
    array.replace('\n' + QString(16, ' '), " ");

    array.replace('\n' + QString(16, ' ') + ']', "]");
    array.replace('\n' + QString(12, ' ') + ']', "]");
    Stirng2File(pfile, array);
}








QVector<int> EAPIO::selectDialog(QString labelTxt, QWidget* parent, QStringList keys){
    QLabel* label;
    QGridLayout *gridLayout;
    QListWidget* listWidget;
    QDialogButtonBox *buttonBox;

    QDialog* Dialog = new QDialog(parent);
    Dialog->resize(250, 300);

    gridLayout = new QGridLayout(Dialog);
    gridLayout->setContentsMargins(5, 5, 5, 5);

    QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);

    label = new QLabel(Dialog);
    label->setText(labelTxt);
    gridLayout->addWidget(label, 0, 0, 1, 1);

    listWidget = new QListWidget(Dialog);

    for (QString itar : keys) {
        QListWidgetItem* item = new QListWidgetItem(itar);
        item->setSizeHint(QSize(0, 30));
        listWidget->addItem(item);
    }
    listWidget->setCurrentRow(0);
    gridLayout->addWidget(listWidget, 1, 0, 1, 1);

    buttonBox = new QDialogButtonBox(Dialog);
    buttonBox->setOrientation(Qt::Horizontal);
    buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
    gridLayout->addWidget(buttonBox, 2, 0, 1, 1);

    QObject::connect(buttonBox, SIGNAL(accepted()), Dialog, SLOT(accept()));
    QObject::connect(buttonBox, SIGNAL(rejected()), Dialog, SLOT(reject()));

    QString res = "";
    QVector<int> select;

    int ret = Dialog->exec();
    if (ret == QDialog::Accepted) {
        for (int i = 0; i < listWidget->count(); i++) {
            if (listWidget->item(i)->isSelected()) {
                select.push_back(i);
            }
        }
    }
    delete Dialog;
    return select;
}


/****************************************************************************************************/
// Create a CheckButtonDialog containing several Option
// input:  Options Strings(vector<std::string>), Dialog title
// output: Options results(vector<bool>)
/****************************************************************************************************/

QVector<bool> EAPIO::CheckButtonDialog(QStringList& strvec, const QString &title, QWidget *parent) {

	QDialog dialog(parent);
	QVBoxLayout layout;
	dialog.setWindowTitle(title);


	QDialogButtonBox button;
	button.setStandardButtons(QDialogButtonBox::Cancel | QDialogButtonBox::Ok);
	connect(&button, SIGNAL(accepted()), &dialog, SLOT(accept()));
	connect(&button, SIGNAL(rejected()), &dialog, SLOT(reject()));


    int NItem = strvec.size();
	QCheckBox **CheckItem = new QCheckBox *[NItem];
	for (int i = 0; i < NItem; i++) {
		CheckItem[i] = new QCheckBox;
        CheckItem[i]->setText(tr(strvec[i].toLatin1()));
		layout.addWidget(CheckItem[i]);
	}
	layout.addWidget(&button);


	dialog.resize(240, NItem * 30 + 50);
	dialog.setLayout(&layout);

	QString str;
    QVector<bool> select(NItem, false);
	if (dialog.exec() == QDialog::Accepted)
	{
		for (int i = 0; i < NItem; i++) {
			if (CheckItem[i]->checkState() == Qt::Checked) {
				select[i] = true;
			}
		}
	}
	else {
		select.clear();
	}

	delete[] CheckItem;
	return select;
}
