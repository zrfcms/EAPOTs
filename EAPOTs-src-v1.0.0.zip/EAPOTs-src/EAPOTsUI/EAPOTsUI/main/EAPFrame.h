#ifndef EAPFRAME_H
#define EAPFRAME_H

#include "UiPtr.h"
#include <QtWidgets/QMainWindow>
#include "ui_EAPFrame.h"
#include <QDir>
#include <QSplitter>
#include <QDockWidget>

#include "ui_CopyRight.h"
#include "ui_SettingsDialog.h"

namespace EAPUI_NS {

	enum class FrameModeEnum {
		Tab, Dock
	};

	enum class MainPage {
        EAMFit, StructModify, StructEdit, EAPlot
	};

	class EAPFrame : public QMainWindow, public UiPtr
	{
		Q_OBJECT
		friend class TaskThread;

	public:
		explicit EAPFrame(QWidget *parent, EAPUI* ptr);
		~EAPFrame();
		Ui_EAPFrame ui;

        void init(QJsonObject &rootObj);
		QDockWidget* addDockPage(QWidget* widget, const QString &title);
        QWidget* EAPfitPage;
        QSplitter* fitPageSplitter;

    signals:
        void fontChangeSlot();

	public slots:

		void ReadSlot(QString File);
		void WriteSlot(QString File);

	public:


		FrameModeEnum FrameMode;

		QList<QDockWidget*> DockList;
		QVector <QVector<JsonKey>> JsonKeyVec;
		QDir ResDir;

		void PageRaise(int idx);

		void PageRaise(MainPage page);

		void setFrameMode(int idx);

		void setFrameMode(FrameModeEnum mode);

	private:	

        void LoadConfigJson(QJsonObject &rootObj);

	public:

        void createCopyRightDialog();
		void createSettingsDialog();

		QString OpenInitDir;
		QString SaveFile;
	};

	class SettingsDialog : public QDialog
	{
		Q_OBJECT
	public:
		Ui_SettingsDialog ui;

		explicit SettingsDialog(QWidget *parent);
		~SettingsDialog();
	};

    class CopyRightDialog : public QDialog
    {
        Q_OBJECT
    public:
        Ui_CopyRight ui;

        explicit CopyRightDialog(QWidget *parent);
        ~CopyRightDialog();
    };

}

#endif
