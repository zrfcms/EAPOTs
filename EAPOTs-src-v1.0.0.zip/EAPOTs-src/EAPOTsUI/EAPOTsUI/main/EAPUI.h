#pragma once

namespace EAPUI_NS {

	class EAPUI
	{
	public:

		class EAPIO *io;
		class EAPFrame *frame;

        class EAPSetPage *setPage;
        class FitTaskPage *taskPage;

		class FileBrowserPage* fileBrowser;
		class AbInitioPage* abInitio;
		class EAPlotPage* EAPlot;
		class StructGLPage* structGL;

        enum FITMODE { SINGLE, CROSS, BCN } FitMode;
        int BetaMode;

		EAPUI(int narg, char *argv[]);
		~EAPUI();

	private:

		EAPUI() {};						// prohibit using the default constructor
		EAPUI(const EAPUI &) {};		// prohibit using the copy constructor
	};

}
