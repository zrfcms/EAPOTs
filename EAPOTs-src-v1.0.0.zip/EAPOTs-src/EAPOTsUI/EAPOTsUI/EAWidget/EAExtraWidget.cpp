#include "EAExtraWidget.h"
#include "UiPtr.h"

#include <QApplication>
#include <QClipboard>
#include <QSizePolicy>
#include <QPushButton>
#include <QDialogButtonBox>

PeriodicTable::PeriodicTable(QWidget *parent)
    : QWidget(parent)
{
    QGridLayout* layout = new QGridLayout(this);
    layout->setSpacing(1);
    setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);

    QStringList title = {
        "IA", "IIA", "IIIB", "IVB", "VB",
        "VIB", "VIIB", "", "VIIIB", "",
        "IB", "IIB", "IIIA", "IVA", "VA",
        "VIA", "VIIA", "O"
    };

    for(int j = 0; j < 18; j++) {
        QLabel* label = new QLabel(this);
        label->setText(title[j]);
        label->setFixedSize(35, 25);
        label->setAlignment(Qt::AlignHCenter);
        layout->addWidget(label, 0, j);
    }

    static const char *ele[] = {
        "H", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "He",
        "Li", "Be", "", "", "", "", "", "", "", "", "", "", "B", "C", "N", "O", "F", "Ne",
        "Na", "Mg", "", "", "", "", "", "", "", "", "", "", "Al", "Si", "P", "S", "Cl", "Ar",
        "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr",
        "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe",
        "Cs", "Ba", "", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn",
        "Fr", "Ra", "", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",

        "", "", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "",
        "", "", "Ac", "Th",	"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "",
    };

    static const int c[] = {
       1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2,
       3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 1, 1, 1, 6, 2,
       3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 5, 1, 1, 6, 2,
       3, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 5, 5, 1, 6, 2,
       3, 4, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 7, 5, 5, 6, 2,
       3, 4, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 7, 7, 5, 6, 2,
       3, 4, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 7, 7, 7, 6, 2,

       0, 0, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 0,
       0, 0, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 0,
    };

    QStringList backColor = {
        "background-color: rgb(255, 255, 255);",

        "background-color: rgb(150, 220, 180);",
        "background-color: rgb(150, 240, 140);",
        "background-color: rgb(255, 180, 210);",
        "background-color: rgb(140, 200, 250);",
        "background-color: rgb(255, 200, 160);",

        "background-color: rgb(170, 250, 240);",
        "background-color: rgb(210, 190, 240);",
        "background-color: rgb(255, 170, 170);",
        "background-color: rgb(255, 220, 170);",
    };

    int idx = 0, irow;
    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 18; j++) {
            idx = i * 18 + j;
            QString txt = ele[idx];
            if(txt.isEmpty()) continue;

            QPushButton *button = new QPushButton(this);
            button->setText(txt);
            button->setFixedSize(35, 35);
            button->setCheckable(true);
            button->setStyleSheet(backColor[c[idx]]);

            irow = i < 7 ? i + 1 : i + 2;
            layout->addWidget(button, irow, j);
            eleList.append(button);
        }
    }

    for(int j = 0; j < 18; j++) {
        QLabel* label = new QLabel(this);
        label->setFixedSize(35, 15);
        label->setAlignment(Qt::AlignHCenter);
        layout->addWidget(label, 8, j);
    }
}

QStringList PeriodicTable::getSelection(){
    QStringList res;
    foreach(QPushButton *button, eleList){
        if (button->isChecked()){
            res.append(button->text());
        }
    }
    return res;
}


PeriodicTableDialog::PeriodicTableDialog(QWidget *parent)
    : QDialog(parent)
{
    resize(500, 400);
    layout = new QVBoxLayout(this);
    layout->setSpacing(0);

    periodicTable = new PeriodicTable(this);
    layout->addWidget(periodicTable);

    buttonBox = new QDialogButtonBox(this);
    buttonBox->setGeometry(QRect(50, 130, 211, 32));
    buttonBox->setOrientation(Qt::Horizontal);
    buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
    layout->addWidget(buttonBox);
};


bool CopyTableView::event(QEvent *e) {
    if (e->type() == QEvent::KeyPress) {
        QKeyEvent *key_event = static_cast<QKeyEvent*>(e);
        if (key_event->matches(QKeySequence::Copy)) {

            ValidTableModel * model = qobject_cast<ValidTableModel*>(this->model());
            QItemSelectionModel * selection = this->selectionModel();
            QModelIndexList indexes = selection->selectedIndexes();

            QModelIndex idx;
            QString total, val;
            const int mm = model->getValidRowNum();
            const int nn = model->getValidColNum();

            for (int i = 0; i < mm; i++){
                idx = model->index(i, 0);
                if (model->data(idx).toString().isEmpty()) break;

                for (int j = 0; j < nn; j++){

                    idx = model->index(i, j);
                    val = model->data(idx).toString();

                    if (val.isEmpty()) break;
                    if (selection->isSelected(idx)){
                        total += val + '\t';
                    }
                }
                total += '\n';
            }
            QApplication::clipboard()->setText(total);
            return true;
        }
    }
    return QTableView::event(e);
}


ReadOnlyTableModel::ReadOnlyTableModel(int pm, int pn, QObject *parent)
    : ValidTableModel(parent) {
    m = pm;
    n = pn;
    val.resize(m*n);
}

int ReadOnlyTableModel::rowCount(const QModelIndex &) const
{
    return m;
}

int ReadOnlyTableModel::columnCount(const QModelIndex &) const
{
    return n;
}

QVariant ReadOnlyTableModel::data(const QModelIndex &index, int role) const
{
    if (role == Qt::DisplayRole){
        int idx = index.row() * n + index.column();
        return val[idx];
    }
    return QVariant();
}


void ReadOnlyTableModel::setText(QString txt){

    auto IsEmpty = [=](int i, int j){
        int cidx = i * n + j;
        if (val[cidx].isEmpty()) return true;

        val[cidx] = "";
        QModelIndex cindex = createIndex(i, j);
        emit dataChanged(cindex, cindex, {Qt::DisplayRole});
        return false;
    };


    QModelIndex index;
    QStringList words, lines = txt.split("\n", QString::SkipEmptyParts);

    int i, j, idx;
    validColNum = 0;
    validRowNum = lines.size();
    int nn, mm = MIN(validRowNum, m);

    for(i = 0; i < mm; i++){
        words = lines[i].split(QRegExp("\\s+"), QString::SkipEmptyParts);

        nn = MIN(words.size(), n);
        validColNum = MAX(nn, validColNum);

        for(j = 0; j < nn; j++){
            idx = i * n + j;
            if (val[idx] != words[j]){
                val[idx] = words[j];

                index = createIndex(i, j);
                emit dataChanged(index, index, {Qt::DisplayRole});
            }
        }

        for(j = nn; j < n; j++){
            if(IsEmpty(i,j)) continue;
        }
    }

    for(i = mm; i < m; i++) {
        if (val[i*n].isEmpty()) break;

        for(int j = 0; j < n; j++){
            if(IsEmpty(i,j)) continue;
        }
    }

}
