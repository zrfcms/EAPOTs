#include "ConfigAttributeWidget.h"

#include <QDialog>
#include <EAPIO.h>
#include <QComboBox>
#include <QScrollBar>
#include <QItemDelegate>
#include <QDialogButtonBox>
#include <QJsonArray>
#include <QListWidget>
#include <QListWidgetItem>

#include "qdebug.h"

using namespace std;
using namespace EAPUI_NS;
using namespace LoadConfig_NS;

#define set_vector3d(u, x, y, z) {u[0] = x;u[1] = y;u[2] = z;}

ControlObject::ControlObject(class ConfigAttributeView* pview, QString pname,
                             QWidget* widget, QStandardItemModel* pmodel):
    QObject(),
    name(pname),    
    virtualWidget(widget),
    model(pmodel),
    view(pview)
{

    pidx = pidxt = pidxw = MDFitData::name.size();
    if (name.endsWith('_')){
        namet = name + "Target";
        namew = name + "Weight";
        pidxt = MDFitData::getParamIdx(namet.toLatin1().data());
        pidxw = MDFitData::getParamIdx(namew.toLatin1().data());
    }
    else{
        pidx = MDFitData::getParamIdx(name.toLatin1().data());
    }
}

void ControlObject::regist(){
    unblock();
}


void ControlObject::block(){
    if(virtualWidget) virtualWidget->blockSignals(true);

    else if(model) view->disconnect(model, &QStandardItemModel::itemChanged, this, &ControlObject::getForItem);
}

void ControlObject::unblock(){
    if(virtualWidget) virtualWidget->blockSignals(false);

    else if(model) view->connect(model, &QStandardItemModel::itemChanged, this, &ControlObject::getForItem);
}

#define CAST(ifit)   (static_cast<bool*>(ifit->paramPtr[pidx]))

BOOLControl::BOOLControl(ConfigAttributeView* pview, QString pname, QCheckBox* pwidget)
    : ControlObject(pview, pname, pwidget)
    , widget(pwidget){

}

void BOOLControl::set(){

    if(view->fit.size() == 0){
        widget->setCheckState(Qt::Unchecked);
        return;
    }

    widget->setCheckState(Qt::PartiallyChecked);
    bool first = *CAST(view->fit[0]);
    for (auto* ifit : view->fit) {
        if (first != static_cast<bool>(*CAST(ifit))) return;
    }

    widget->setCheckState(first ? Qt::Checked : Qt::Unchecked);
}


void BOOLControl::regist(){
    view->connect(widget, &QCheckBox::stateChanged, view, [=] {
        if (widget->checkState() == Qt::PartiallyChecked) return;

        bool chk = widget->checkState();
        for (auto* ifit : view->fit) {
            *CAST(ifit) = chk;
        }
    });
}


void BOOLControl::importJson(MDFitData* ifit, const QJsonObject &obj){
    if (!obj.contains(name)) return;
    *CAST(ifit) = obj[name].toBool();
}

void BOOLControl::exportJson(MDFitData* ifit, QJsonObject &obj){
    obj.insert(name, *CAST(ifit));
}



GBoxControl::GBoxControl(ConfigAttributeView* pview, QString pname, QGroupBox* pwidget)
    : BOOLControl(pview, pname, nullptr)
    , groupBox(pwidget){

}

void GBoxControl::set(){

    if(view->fit.size() == 0){
        return;
    }

    groupBox->setChecked(true);
    bool first = *CAST(view->fit[0]);
    for (auto* ifit : view->fit) {
        if (first != static_cast<bool>(*CAST(ifit))) return;
    }

    groupBox->setChecked(first);
}


void GBoxControl::regist(){
    view->connect(groupBox, &QGroupBox::clicked, view, [=] {

        bool chk = groupBox->isChecked();
        for (auto* ifit : view->fit) {
            *CAST(ifit) = chk;
        }
    });
}


#undef  CAST
#define CAST(ifit)   (static_cast<double*>(ifit->paramPtr[pidx]))

DBLControl::DBLControl(ConfigAttributeView* pview, QString pname, QLineEdit* pwidget)
    : ControlObject(pview, pname, pwidget)
    , widget(pwidget){

}

void DBLControl::set(){

    if(view->fit.size() == 0){
        widget->setText("");
        return;
    }

    widget->setText("/");
    double first = *CAST(view->fit[0]);

    for (auto* ifit : view->fit) {
        if (first != *CAST(ifit)) return;
    }

    widget->setText(QString::number(first));
}

void DBLControl::regist(){
    view->connect(widget, &QLineEdit::textChanged, view, [=] {

        QString str = widget->text();
        if (str == "/") return;

        double val = str.toDouble();
        for (auto* ifit : view->fit) {
            *CAST(ifit) = val;
        }
    });
}

void DBLControl::importJson(MDFitData* ifit, const QJsonObject &obj){
    if (!obj.contains(name)) return;
    *CAST(ifit) = obj[name].toDouble();
}

void DBLControl::exportJson(MDFitData* ifit, QJsonObject &obj){
    obj.insert(name, *CAST(ifit));
}


#undef  CAST
#define CAST(ifit)   (static_cast<Vec6*>(ifit->paramPtr[pidx]))

DBLIdxControl::DBLIdxControl(ConfigAttributeView* pview, QString pname, int pi, int pj, QLineEdit* pwidget)
    : ControlObject(pview, pname, pwidget)
    , widget(pwidget)
    , i(pi), j(pj){

}

void DBLIdxControl::set(){

    if(view->fit.size() == 0){
        widget->setText("");
        return;
    }
    widget->setText("/");
    double first = CAST(view->fit[0])[i][j];
    for (auto* ifit : view->fit) {
        if (first != CAST(ifit)[i][j]) return;
    }

    widget->setText(QString::number(first));
}

void DBLIdxControl::regist(){
    view->connect(widget, &QLineEdit::textChanged, view, [=] {

        QString str = widget->text();
        if (str == "/") return;

        double val = str.toDouble();
        for (auto* ifit : view->fit) {
            CAST(ifit)[i][j] = val;
        }
    });
}


#undef  CAST
#define CAST(ifit)   (static_cast<string*>(ifit->paramPtr[pidx]))

STRControl::STRControl(ConfigAttributeView* pview, QString pname, QLineEdit* pwidget)
    : ControlObject(pview, pname, pwidget)
    , widget(pwidget){

}

void STRControl::set(){

    if(view->fit.size() == 0){
        widget->setText("");
        return;
    }

    widget->setText("/");
    string first = *CAST(view->fit[0]);

    for (auto* ifit : view->fit) {
        if (first != *CAST(ifit)) return;
    }

    widget->setText(first.c_str());
}

void STRControl::regist(){
    view->connect(widget, &QLineEdit::textChanged, view, [=] {

        QString str = widget->text();
        if (str == "/") return;

        string val = str.toLatin1().data();
        for (auto* ifit : view->fit) {
            *CAST(ifit) = val;
        }
    });
}

void STRControl::importJson(MDFitData* ifit, const QJsonObject &obj){
    if (!obj.contains(name)) return;
    *CAST(ifit) = obj[name].toString().toLatin1().data();
}

void STRControl::exportJson(MDFitData* ifit, QJsonObject &obj){
    obj.insert(name, CAST(ifit)->c_str());
}

#undef  CAST
#define CAST(ifit)   (static_cast<string*>(ifit->paramPtr[pidx]))

CombControl::CombControl(ConfigAttributeView* pview, QString pname, QComboBox* pwidget)
    : ControlObject(pview, pname, pwidget)
    , widget(pwidget){

}

void CombControl::set(){

    if(view->fit.size() == 0){
        widget->setCurrentText("");
        return;
    }

    widget->setCurrentText("/");
    string first = *CAST(view->fit[0]);

    for (auto* ifit : view->fit) {
        string val = *CAST(ifit);
        if (first != val) return;
    }

    widget->setCurrentText(first.c_str());
}


void CombControl::regist(){
    view->connect(widget, &QComboBox::currentTextChanged, view, [=] {

        QString str = widget->currentText();
        if (str == "/" || str == "") return;

        string val = str.toLatin1().data();
        for (auto* ifit : view->fit) {
            *CAST(ifit) = val;
        }
    });
}

void CombControl::importJson(MDFitData* ifit, const QJsonObject &obj){
    if (!obj.contains(name)) return;
    *CAST(ifit) = obj[name].toString().toLatin1().data();
}

void CombControl::exportJson(MDFitData* ifit, QJsonObject &obj){
    if(name.contains("Cost")) return;
    obj.insert(name, CAST(ifit)->c_str());
}



#undef  CAST
#define CAST_T(ifit) (static_cast<double*>(ifit->paramPtr[pidxt]))
#define CAST_W(ifit) (static_cast<double*>(ifit->paramPtr[pidxw]))

Vec6Control::Vec6Control(ConfigAttributeView* pview, QString pname, QStandardItemModel* pmodel)
    : ControlObject(pview, pname, NULL, pmodel){

}

void Vec6Control::set(){

    int k;
    double first;

    if(view->fit.size() == 0){
        for (int i = 0; i < model->columnCount(); i++) {
            model->item(0, i)->setText("");
            model->item(1, i)->setText("");
        }
        return;
    }


    for (int i = 0; i < model->columnCount(); i++) {

        model->item(0, i)->setText("/");
        first = CAST_T(view->fit[0])[i];
        for (k = 0; k < view->fit.size(); k++) {
            if (first != CAST_T(view->fit[k])[i]) break;
        }
        if(k == view->fit.size()){
            model->item(0, i)->setText(QString::number(first));
        }

        model->item(1, i)->setText("/");
        first = CAST_W(view->fit[0])[i];
        for (k = 0; k < view->fit.size(); k++) {
            if (first != CAST_W(view->fit[k])[i]) break;
        }
        if(k == view->fit.size()){
            model->item(1, i)->setText(QString::number(first));
        }
    }
}

void Vec6Control::getForItem(QStandardItem *item){

    int i = item->row();
    int j = item->column();
    double val = model->item(i, j)->text().toDouble();

    if (i == 0) {
        for (auto* ifit : view->fit) {
            CAST_T(ifit)[j] = val;
        }
    }
    else {
        for (auto* ifit : view->fit) {
            CAST_W(ifit)[j] = val;
        }
    }
};

void Vec6Control::importJson(MDFitData* ifit, const QJsonObject &obj){
    if (obj.contains(namet)){
       auto JarrayT = obj[namet].toArray();
       if(JarrayT.size() < NDof) return;

       for (int i = 0; i < NDof; i++) {
           CAST_T(ifit)[i] = JarrayT.at(i).toDouble();
       }
    }
    if (obj.contains(namew)){
       auto JarrayW = obj[namew].toArray();
       if(JarrayW.size() < NDof) return;

       for (int i = 0; i < NDof; i++) {
           CAST_W(ifit)[i] = JarrayW.at(i).toDouble();
       }
    }
}

void Vec6Control::exportJson(MDFitData* ifit, QJsonObject &obj){
    QJsonArray ArrayT, ArrayW;

    for (int i = 0; i < NDof; i++) {
        ArrayT.append(CAST_T(ifit)[i]);
        ArrayW.append(CAST_W(ifit)[i]);
    }
    obj.insert(namet, QJsonValue(ArrayT));
    obj.insert(namew, QJsonValue(ArrayW));
}


#undef  CAST_T
#undef  CAST_W
#define CAST(ifit)   (static_cast<Vec6*>(ifit->paramPtr[pidx]))

Mat66Control::Mat66Control(ConfigAttributeView* pview, QString pname, QStandardItemModel* pmodel)
    : ControlObject(pview, pname, NULL, pmodel){

}

void Mat66Control::set(){
    int k;
    double first;

    if(view->fit.size() == 0){
        for (int i = 0; i < model->rowCount(); i++)
        for (int j = 0; j < model->columnCount(); j++) {
            model->item(i, j)->setText("");
        }
        return;
    }

    for (int i = 0; i < model->rowCount(); i++)
    for (int j = 0; j < model->columnCount(); j++) {

        model->item(i, j)->setText("/");
        first = CAST(view->fit[0])[i][j];
        for (k = 0; k < view->fit.size(); k++) {
            if (first != CAST(view->fit[k])[i][j])  break;
        }
        if(k == view->fit.size()){
            model->item(i, j)->setText(QString::number(first));
        }
    }
}

void Mat66Control::getForItem(QStandardItem *item){

    double val = item->text().toDouble();
    for (auto* ifit : view->fit) {
        CAST(ifit)[item->row()][item->column()] = val;
    }
}

void Mat66Control::importJson(MDFitData* ifit, const QJsonObject &obj){
    if (!obj.contains(name)) return;

    auto Jarray = obj[name].toArray();
    if(Jarray.size() < NEla*NDof) return;

    for (int i = 0; i < NEla; i++)
    for (int j = 0; j < NDof; j++) {

        for (int i = 0; i < NDof; i++) {
            CAST(ifit)[i][j] = Jarray.at(i*NDof+j).toDouble();
        }
    }
}

void Mat66Control::exportJson(MDFitData* ifit, QJsonObject &obj){
    QJsonArray Array;

    for (int i = 0; i < NEla; i++)
    for (int j = 0; j < NDof; j++) {
        Array.append(CAST(ifit)[i][j]);
    }
    obj.insert(name, QJsonValue(Array));
}


#undef  CAST



AtomControl::AtomControl(ConfigAttributeView* pview, QString pname, QStandardItemModel* pmodel)
    : ControlObject(pview, pname, NULL, pmodel){
}

void AtomControl::set(){

    for (int i = 0; i < model->rowCount(); i++) {
        for (int j = 0; j < 6; j++) {
            model->item(i, j)->setText("");
        }
    }

    if (view->fit.size() != 1) {
        view->resizeAtom(0);
    } else {
        auto ifit = view->fit[0];
        view->resizeAtom(ifit->num);

        for (int i = 0; i < ifit->num; i++) {
            for (int j = 0; j < 3; j++) {
                model->item(i, j*2 + 0)->setText(QString::number(ifit->AtomForceTarget[i * 3 + j]));
                model->item(i, j*2 + 1)->setText(QString::number(ifit->AtomForceWeight[i * 3 + j]));
            }
        }
    }
}

void AtomControl::getForItem(QStandardItem *item){

    if (view->fit.size() != 1) return;

    int i = item->row();
    int j = item->column();
    auto* ifit = view->fit[0];

    QString str = model->item(i, j)->text();
    if (str.isEmpty() || i >= ifit->num) return;

    if (j % 2) {
        ifit->AtomForceWeight[i * 3 + j / 2] = str.toDouble();
    } else {
        ifit->AtomForceTarget[i * 3 + j / 2] = str.toDouble();
    }
}

void AtomControl::importJson(MDFitData* ifit, const QJsonObject &obj){
    if (!obj.contains(name)) return;

    QStringList lines = obj[name].toString().split("\n");
    QStringList headlist = lines[0].split(QRegExp("\\W+"));

    int narg = headlist.size();
    for(int i = 0; i < narg; i++) {
        if (headlist[i] == "cost_force") {
            if (i + 3 >= narg) break;            
            ifit->Force_Cost_Method[0] = headlist[i + 1].toLatin1().data();
            ifit->Force_Cost_Method[1] = headlist[i + 2].toLatin1().data();
            ifit->Force_Cost_Method[2] = headlist[i + 3].toLatin1().data();
        }
    }

    int num = lines.size() - 1;

    QStringList words = lines[num].split(QRegExp("\\s+"));
    if(words[0].size() == 0) num--;

    ifit->resize(num);
    for (int i = 0; i < num; i++) {
        words = lines[i + 1].split(QRegExp("\\s+"));
        ifit->AtomForceWeight[i * 3 + 0] = words[1].toDouble();
        ifit->AtomForceWeight[i * 3 + 1] = words[2].toDouble();
        ifit->AtomForceWeight[i * 3 + 2] = words[3].toDouble();
        ifit->AtomForceTarget[i * 3 + 0] = words[4].toDouble();
        ifit->AtomForceTarget[i * 3 + 1] = words[5].toDouble();
        ifit->AtomForceTarget[i * 3 + 2] = words[6].toDouble();
    }

    ifit->Structure_Atom_Configuration = obj[name].toString().toLatin1().data();
}

void AtomControl::exportJson(MDFitData* ifit, QJsonObject &obj){

    EString buf;
    LoadVaspData::exportToReflog(buf, ifit);
    QString buff(buf.s);
    obj.insert(name, buff);

    ifit->Structure_Atom_Configuration = buff.toLatin1().data();
}



ConfigAttributeView::ConfigAttributeView(QWidget *parent)
    : QWidget(parent)
    , atomControl(NULL)
{
    ui.setupUi(this);
	ModelInitialize();
	ViewInitialize();

    control.push_back(new DBLControl( this, "Energy_Target",        ui.EnergyTargetEdit));
    control.push_back(new DBLControl( this, "Energy_Weight",        ui.EnergyWeightEdit));
    control.push_back(new DBLControl( this, "Force_Cost_Weight",    ui.ForceWeightEdit));
    control.push_back(new CombControl(this, "Energy_Scale_Method",  ui.ScaleComb));
    control.push_back(new CombControl(this, "Box_Relax_Mode",       ui.RelaxModeCombo));
    control.push_back(new STRControl( this, "Energy_Reference",     ui.RefStructEdit));

    control.push_back(new BOOLControl(this, "Relax_AtomX",          ui.AtomRelaxXBox));
    control.push_back(new BOOLControl(this, "Relax_AtomY",          ui.AtomRelaxYBox));
    control.push_back(new BOOLControl(this, "Relax_AtomZ",          ui.AtomRelaxZBox));
    control.push_back(new BOOLControl(this, "Ref_Drive",            ui.RefDriveBox));
    control.push_back(new BOOLControl(this, "Use_MaxForce",         ui.UseMaxForceChk));

    control.push_back(new GBoxControl(this, "ActiveLatticeGroup",   ui.LatticeBox));
    control.push_back(new GBoxControl(this, "ActiveEnergyGroup",    ui.EnergyBox));
    control.push_back(new GBoxControl(this, "ActiveStressGroup",    ui.StressBox));
    control.push_back(new GBoxControl(this, "ActiveForceGroup",     ui.ForceBox));
    control.push_back(new GBoxControl(this, "ActiveMoreGroup",      ui.MoreBox));

    control.push_back(new Vec6Control(this, "Domain_", LattModel));
    control.push_back(new Vec6Control(this, "Stress_Global_", StssModel));

    control.push_back(new CombControl(this, "Force_Cost_Method[0]", ui.xComboBox)); // Json IO is implemented by atomControl
    control.push_back(new CombControl(this, "Force_Cost_Method[1]", ui.yComboBox)); // Json IO is implemented by atomControl
    control.push_back(new CombControl(this, "Force_Cost_Method[2]", ui.zComboBox)); // Json IO is implemented by atomControl

    atomControl = new AtomControl(this, "Structure_Atom_Configuration", AtomModel);
    control.push_back(atomControl);

    control.push_back(new Mat66Control(this, "Elastic_Target", ElaTModel));
    control.push_back(new Mat66Control(this, "Elastic_Weight", ElaWModel));

    control.push_back(new DBLIdxControl(this, "Elastic_Target", 6, 0, ui.BulkT));
    control.push_back(new DBLIdxControl(this, "Elastic_Target", 6, 1, ui.ShearT));
    control.push_back(new DBLIdxControl(this, "Elastic_Target", 6, 2, ui.PoissonT));
    control.push_back(new DBLIdxControl(this, "Elastic_Target", 6, 3, ui.YoungXT));
    control.push_back(new DBLIdxControl(this, "Elastic_Target", 6, 4, ui.YoungYT));
    control.push_back(new DBLIdxControl(this, "Elastic_Target", 6, 5, ui.YoungZT));

    control.push_back(new DBLIdxControl(this, "Elastic_Weight", 6, 0, ui.BulkW));
    control.push_back(new DBLIdxControl(this, "Elastic_Weight", 6, 1, ui.ShearW));
    control.push_back(new DBLIdxControl(this, "Elastic_Weight", 6, 2, ui.PoissonW));
    control.push_back(new DBLIdxControl(this, "Elastic_Weight", 6, 3, ui.YoungXW));
    control.push_back(new DBLIdxControl(this, "Elastic_Weight", 6, 4, ui.YoungYW));
    control.push_back(new DBLIdxControl(this, "Elastic_Weight", 6, 5, ui.YoungZW));

	SignalInitialize();

    // ui.AtomView might be set as unable due to the unable group before
    // so, select once to active ui.AtomView if needed
    connect(ui.ForceBox, &QGroupBox::clicked, ui.AtomView, [=](bool){
        initTarget(fit);
    });
}

ConfigAttributeView::~ConfigAttributeView() {
    for (auto icontrol : control) delete icontrol;
}

void ConfigAttributeView::ModelInitialize() {

    QStringList axis = { "xx", "yy", "zz", "xy", "xz", "yz", };
    QStringList RowLabel = { "Target", "Weight" };

	auto CreateQStandardItemModel = [](int row, int column, QWidget *parent, 
		const QStringList &axis, const QStringList &RowLabel) -> QStandardItemModel* 
	{
		QStandardItemModel* Model = new QStandardItemModel(row, column, parent);
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				Model->setItem(i, j, new QStandardItem());
			}
		}
		Model->setHorizontalHeaderLabels(axis);
		Model->setVerticalHeaderLabels(RowLabel);
		return Model;
	};


	LattModel = CreateQStandardItemModel(2, 6, this, axis, RowLabel);
	StssModel = CreateQStandardItemModel(2, 6, this, axis, RowLabel);
	AtomModel = CreateQStandardItemModel(3, 6, this, QStringList({
        "T(x)", "W(x)", "T(y)", "W(y)", "T(z)", "W(z)" }), QStringList());

    ElaWModel = CreateQStandardItemModel(6, 6, this, axis, axis);
    ElaTModel = CreateQStandardItemModel(6, 6, this, axis, axis);

	AtomSelect = new QItemSelectionModel(AtomModel);
}

#define ConnectScrollButton(TYPE)                                               \
    connect(ui.TYPE ## Button, &QPushButton::clicked, this, [=]() {             \
        ui.scrollArea->verticalScrollBar()->                                    \
            setSliderPosition(ui.TYPE ## Box->pos().y()); });                   \


void ConfigAttributeView::ViewInitialize() {

	ConnectScrollButton(Lattice);
	ConnectScrollButton(Energy);
	ConnectScrollButton(Stress);
	ConnectScrollButton(Force);
	ConnectScrollButton(More);

    //connect(ui.TYPE ## Button, &QPushButton::clicked, this, [=]() {

	enum { 
		Vertical = 1 << 0, 
		Horizontal = 1 << 1	
	};

	auto TableSizeReshapeFunc = [](QTableView* table, QStandardItemModel* Model, 
		QItemSelectionModel* Select, int flag) {
        if (Model) { table->setModel(Model); };
        if (Select) { table->setSelectionModel(Select); };
        if (flag & Vertical) {
            table->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        }
        if (flag & Horizontal) {
            table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        }
	};

	TableSizeReshapeFunc(ui.LatticeView, LattModel, NULL, Vertical | Horizontal);
	TableSizeReshapeFunc(ui.StressView, StssModel, NULL, Vertical | Horizontal);
	TableSizeReshapeFunc(ui.AtomView, AtomModel, AtomSelect, Horizontal);
	TableSizeReshapeFunc(ui.ElaWeiView, ElaWModel, NULL, Vertical | Horizontal);
	TableSizeReshapeFunc(ui.ElaTarView, ElaTModel, NULL, Vertical | Horizontal);

    ui.ElaWeiView->verticalHeader()->setVisible(false);
}

void ConfigAttributeView::updateUnit(){
    QString unit;
    switch(ui.ScaleComb->currentIndex()){
        case 0: unit = "eV"; break;
        case 1: unit = "eV/atom"; break;
        case 2: unit = "eV"; break;
        case 3: unit = "eV/atom"; break;
        case 4: unit = "eV/atom"; break;

        case 5: unit = "mJ/m2"; break;
        case 6: unit = "mJ/m2"; break;
        case 7: unit = "mJ/m2"; break;
        case 8: unit = "mJ/m2"; break;
    };

    //ui.UnitLabel->setText(unit);
}


#define GetResetEditValue()											\
    if (!fit.size()) return;										\
	QString str = ui.resetEdit->text();								\
	double val = str.toDouble();


void ConfigAttributeView::SignalInitialize() {

    for (auto& icontrol : control) {
        icontrol->regist();
    }

    connect(ui.ScaleComb, static_cast<void (QComboBox:: *)
            (int index)>(&QComboBox::currentIndexChanged),
            this, &ConfigAttributeView::updateUnit);

    connect(ui.AtomRelaxButton, &QPushButton::clicked, this, [=]() {
        bool selectAll = true;
        selectAll &= ui.AtomRelaxXBox->checkState() == Qt::Checked;
        selectAll &= ui.AtomRelaxYBox->checkState() == Qt::Checked;
        selectAll &= ui.AtomRelaxZBox->checkState() == Qt::Checked;
        Qt::CheckState state = selectAll ? Qt::Unchecked : Qt::Checked;
        ui.AtomRelaxXBox->setCheckState(state);
        ui.AtomRelaxYBox->setCheckState(state);
        ui.AtomRelaxZBox->setCheckState(state);
    });


	// 3.3 Connect Preset Buttons

	connect(ui.ResetAsZeroButton, &QPushButton::clicked, this, [=]() {
		for (int i = 0; i < 6; i++) {		
			StssModel->item(0, i)->setText("0");
        }
    });

	connect(ui.ResetAllButton, &QPushButton::clicked, this, [=]() {
        GetResetEditValue();

        if (fit.size() == 1) {
			EAPIO::ResetQStandardModel(AtomModel, str, 0, fit[0]->num);
			return;
		}

		double *t, *w;
		for (auto ifit : fit) {
			for (int i = 0; i < ifit->num; i++) {
				t = &ifit->AtomForceTarget[i * 3];
				w = &ifit->AtomForceWeight[i * 3];
				set_vector3d(t, val, val, val);
				set_vector3d(w, val, val, val);
			}
        }
    });

    connect(ui.ResetSelectButton, &QPushButton::clicked, this, [=]() {
        if (!fit.size()) return;
        QString str = ui.resetEdit->text();								\

        if (fit.size() != 1) return;
        foreach(auto& index, AtomSelect->selectedIndexes()) {
            AtomModel->setData(index, str);
        }
    });

	connect(ui.ResetWeightButton, &QPushButton::clicked, this, [=]() {
        GetResetEditValue();

		double *w;
		for (auto ifit : fit) {
			for (int i = 0; i < ifit->num; i++) {
				w = &ifit->AtomForceWeight[i * 3];
				set_vector3d(w, val, val, val);
			}
        }

        if (fit.size() == 1) atomControl->set();
    });

	connect(ui.ResetTargetButton, &QPushButton::clicked, this, [=]() {
        GetResetEditValue();

		double *t;
		for (auto ifit : fit) {
			for (int i = 0; i < ifit->num; i++) {
				t = &ifit->AtomForceTarget[i * 3];
				set_vector3d(t, val, val, val);
			}
        }

        if (fit.size() == 1) atomControl->set();
    });


    //connect(ui.UseMaxForceButton, &QPushButton::clicked, this, [=]() {
    //    GetResetEditValue();
    //
    //    int maxRow;
    //    double *t, maxVal, ival;
    //    for (auto ifit : fit) {
    //        for (int i = 0; i < ifit->num; i++) {
    //            t = &ifit->AtomForceWeight[i * 3];
    //            set_vector3d(t, 0, 0, 0);
    //        }
    //
    //        maxRow = -1;
    //        maxVal = 0.0;
    //        for (int i = 0; i < ifit->num; i++) {
    //            t = &ifit->AtomForceTarget[i * 3];
    //            ival = t[0]*t[0] + t[1]*t[1] + t[2]*t[2];
    //            if (ival > maxVal){
    //                maxVal = ival;
    //                maxRow = i;
    //            }
    //        }
    //
    //        if (maxRow >= 0){
    //            t = &ifit->AtomForceWeight[maxRow * 3];
    //            set_vector3d(t, val, val, val);
    //        }
    //    }
    //
    //
    //    if (nfit == 1) atomControl->set();
    //});
}


void ConfigAttributeView::initEnergy() {

    control[0]->block();
    control[0]->set();
    control[0]->unblock();
}

void ConfigAttributeView::selectReference(QVector<MDFitData*> list){

    QLabel* label;
    QGridLayout *gridLayout;
    QListWidget* listWidget;
    QDialogButtonBox *buttonBox;

    QDialog* Dialog = new QDialog(this);
    Dialog->resize(250, 300);

    gridLayout = new QGridLayout(Dialog);
    gridLayout->setContentsMargins(5, 5, 5, 5);

    QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);

    label = new QLabel(Dialog);
    label->setText(tr("Select a reference structure"));
    gridLayout->addWidget(label, 0, 0, 1, 1);

    listWidget = new QListWidget(Dialog);
    QListWidgetItem* item = new QListWidgetItem("none");
    item->setSizeHint(QSize(0, 30));
    listWidget->addItem(item);

    for (MDFitData* ifit : list) {
        QListWidgetItem* item = new QListWidgetItem(ifit->Structure_Name.c_str());
        item->setSizeHint(QSize(0, 30));
        listWidget->addItem(item);
    }
    listWidget->setCurrentRow(listWidget->count()-1);
    gridLayout->addWidget(listWidget, 1, 0, 1, 1);

    buttonBox = new QDialogButtonBox(Dialog);
    buttonBox->setOrientation(Qt::Horizontal);
    buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
    gridLayout->addWidget(buttonBox, 2, 0, 1, 1);

    QObject::connect(buttonBox, SIGNAL(accepted()), Dialog, SLOT(accept()));
    QObject::connect(buttonBox, SIGNAL(rejected()), Dialog, SLOT(reject()));

    int ret = Dialog->exec();
    if (ret == QDialog::Accepted) {
        if (listWidget->currentItem()){
            ui.RefStructEdit->setText(listWidget->currentItem()->text());
        }
    }
    delete Dialog;
}

void ConfigAttributeView::initTarget(QVector<MDFitData*> arg) {

	fit = arg;
    for (auto& icontrol : control) icontrol->block();
    for (auto& icontrol : control) icontrol->set();
    for (auto& icontrol : control) icontrol->unblock();
    updateUnit();
}

void ConfigAttributeView::resizeAtom(int n) {
	if (n <= AtomModel->rowCount()) return;

	for (int i = AtomModel->rowCount(); i < n; i++) {
		for (int j = 0; j < AtomModel->columnCount(); j++) {
			AtomModel->setItem(i, j, new QStandardItem());
		}
	}
}



#define evalString(Key)	if (obj.contains(#Key)) ifit->Key = obj[#Key].toString().toLatin1().data();

void ConfigAttributeView::importJson(MDFitData* ifit, const QJsonObject &obj){

    for (auto& icontrol : control) icontrol->importJson(ifit, obj);

    evalString(Structure_Information);
}

#undef  evalString

#define evalString(Key) obj.insert(#Key, ifit->Key.c_str());

void ConfigAttributeView::exportJson(MDFitData* ifit, QJsonObject &obj){

    obj.insert("type", "MD");

    for (auto& icontrol : control) icontrol->exportJson(ifit, obj);

    evalString(Structure_Information);
}
#undef  evalString





