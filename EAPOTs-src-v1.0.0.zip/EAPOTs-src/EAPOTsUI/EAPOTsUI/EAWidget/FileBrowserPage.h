#pragma once

#include "UiPtr.h"
#include "ui_FileBrowserPage.h"

#include <QStringList>
#include <QFileSystemModel>

namespace EAPUI_NS {

    class DefaultAction  : public UiPtr{
    public:
        DefaultAction(EAPUI* ptr);
        virtual void command(QString file) = 0;
    };
    class StructEditAction   : public DefaultAction{
    public:
        StructEditAction(EAPUI* ptr);
        void command(QString file);
    };
    class PlotEAMAction      : public DefaultAction{
    public:
        PlotEAMAction(EAPUI* ptr);
        void command(QString file);
    };
    class PlotFSAction       : public DefaultAction{
    public:
        PlotFSAction(EAPUI* ptr);
        void command(QString file);
    };
    class PlotTersoffAction  : public DefaultAction{
    public:
        PlotTersoffAction(EAPUI* ptr);
        void command(QString file);
    };
    class PlotBrennerAction : public DefaultAction{
    public:
        PlotBrennerAction(EAPUI* ptr);
        void command(QString file);
    };
    class PlotSWAction       : public DefaultAction{
    public:
        PlotSWAction(EAPUI* ptr);
        void command(QString file);
    };


	class FileBrowserPage : public QWidget, public UiPtr
	{
		Q_OBJECT
	public:
		Ui_FileBrowserPage ui;
		explicit FileBrowserPage(QWidget *parent, EAPUI* ptr);
		~FileBrowserPage();
		void init();

		QFileSystemModel* FileModel;
        QMap<QString, DefaultAction*> actionMap;

        typedef void(*CommandCreator)(EAPUI *, QString);
        typedef QMap<QString, CommandCreator> CommandCreatorMap;
        CommandCreatorMap command_map;

    protected:
        template <typename T> static void command_creator(EAPUI *, QString);

	signals:
		void PlotEAMslots(QStringList);
		void PlotSurfslots(QStringList);

	public slots:
        void openAction(const QModelIndex& index);

	public:
		// File Model		
		void FileViewRootPathCdUp();
		void FileViewSetRootPathWithCheck(const QString &str);
		void FileViewContextMenuRequested(const QPoint &pos);

		QStringList FileViewSelectedRequested(const QStringList&);
		QString FileViewCurrentRequested();
		void AddFileViewComboText(const QString &text);

	public:
		QStringList StructSuffix;
		QStringList EAMSuffix;
		QStringList SurfSuffix;
	};
}
