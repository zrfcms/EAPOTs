#pragma once

#include "AbinitoMDTool.h"
#include <QStandardItemModel>
#include "ui_ConfigAttributeView.h"


using namespace LoadConfig_NS;

typedef double Vec6[NDof];

class ControlObject : public QObject {
    Q_OBJECT
public:
    ControlObject(class ConfigAttributeView* pview, QString pname,
                  QWidget* widget, QStandardItemModel* = NULL);

    virtual void set() = 0;
    virtual void block();
    virtual void unblock();
    virtual void regist();
    virtual void getForItem(QStandardItem *){};

    virtual void importJson(MDFitData* ifit, const QJsonObject &obj) = 0;
    virtual void exportJson(MDFitData* ifit, QJsonObject &obj) = 0;

    size_t pidx, pidxt, pidxw;
    QString name, namet, namew;
    QWidget* virtualWidget;
    QStandardItemModel* model;
    class ConfigAttributeView* view;
};

class BOOLControl : public ControlObject
{
public:
    BOOLControl(ConfigAttributeView* pview, QString pname, QCheckBox* pwidget);
    QCheckBox* widget;

    void set();
    void regist();
    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
};

class GBoxControl : public BOOLControl
{
public:
    GBoxControl(ConfigAttributeView* pview, QString pname, QGroupBox* pwidget);
    QGroupBox* groupBox;
    void set();
    void regist();
};

class DBLControl : public ControlObject
{
public:
    DBLControl(ConfigAttributeView* pview, QString pname, QLineEdit* pwidget);
    QLineEdit* widget;

    void set();
    void regist();
    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
};

class DBLIdxControl : public ControlObject
{
public:
    DBLIdxControl(ConfigAttributeView* pview, QString pname, int i, int j, QLineEdit* pwidget);
    QLineEdit* widget;

    int i, j;
    void set();
    void regist();
    void importJson(MDFitData*, const QJsonObject &) {}
    void exportJson(MDFitData*, QJsonObject &) {}
};

class STRControl : public ControlObject
{
public:
    STRControl(ConfigAttributeView* pview, QString pname, QLineEdit* pwidget);
    QLineEdit* widget;

    void set();
    void regist();
    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
};

class CombControl : public ControlObject
{
public:
    CombControl(ConfigAttributeView* pview, QString pname, QComboBox* pwidget);
    QComboBox* widget;

    void set();
    void regist();
    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
};

class Vec6Control : public ControlObject
{
public:
    Vec6Control(ConfigAttributeView* pview, QString pname, QStandardItemModel* pmodel);

    void set();
    void getForItem(QStandardItem *item);
    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
};

class Mat66Control : public ControlObject
{
public:
    Mat66Control(ConfigAttributeView* pview, QString pname, QStandardItemModel* pmodel);

    void set();
    void getForItem(QStandardItem *item);
    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
};

class AtomControl : public ControlObject
{
public:
    AtomControl(ConfigAttributeView* pview, QString pname, QStandardItemModel* pmodel);

    void set();
    void getForItem(QStandardItem *item);
    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
};

class ConfigAttributeView : public QWidget
{
    Q_OBJECT
public:
	Ui_ConfigAttributeView ui;

    explicit ConfigAttributeView(QWidget *parent);
    ~ConfigAttributeView();

	void ModelInitialize();
	void ViewInitialize();
	void SignalInitialize();

    void importJson(MDFitData* ifit, const QJsonObject &obj);
    void exportJson(MDFitData* ifit, QJsonObject &obj);
    void updateUnit();

	QStandardItemModel* LattModel;
	QStandardItemModel* StssModel;
	QStandardItemModel* AtomModel;
	QStandardItemModel* ElaTModel;
	QStandardItemModel* ElaWModel;

	QItemSelectionModel* AtomSelect;

signals:
public slots:
public:

    void selectReference(QVector<MDFitData*>);
    void initTarget(QVector<MDFitData*>);
	void initEnergy();

    QVector<MDFitData*> fit;
	void resizeAtom(int);
    AtomControl* atomControl;

private:
	typedef void(*initFunc)(ConfigAttributeView*);
    std::vector<ControlObject*> control;
};

