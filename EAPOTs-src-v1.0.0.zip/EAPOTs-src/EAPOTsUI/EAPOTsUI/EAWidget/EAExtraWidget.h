#pragma once

#include <QWidget>
#include <QComboBox>
#include <QDebug>
#include <QLabel>
#include <QInputDialog>
#include <QMouseEvent>
#include <QTableView>
#include <QGridLayout>
#include <QDialogButtonBox>

#include "ui_PeriodicTable.h"
#include <QAbstractTableModel>

class ClickComboBox : public QComboBox
{
	Q_OBJECT

public:
	explicit ClickComboBox(QWidget *parent = nullptr) 
        : QComboBox(parent)	{
    };

private:
    void wheelEvent(QWheelEvent *) {};

signals:
	void click(int i);

public slots:

};

class PeriodicTable : public QWidget {
    Q_OBJECT
public:
    QStringList getSelection();
    QVector<QPushButton*> eleList;
    PeriodicTable(QWidget *parent = nullptr);
};

class PeriodicTableDialog : public QDialog {
    Q_OBJECT
public:
    QVBoxLayout* layout;
    QDialogButtonBox* buttonBox;
    PeriodicTable* periodicTable;
    PeriodicTableDialog(QWidget *parent = nullptr);
};


class CopyTableView : public QTableView
{
    Q_OBJECT
public:
    CopyTableView(QWidget *parent = nullptr)
        : QTableView(parent){
    }

    bool event(QEvent *e) override;
};

class ValidTableModel : public QAbstractTableModel
{
    Q_OBJECT
public:
    ValidTableModel(QObject *parent = nullptr)
        : QAbstractTableModel(parent){
    };

    int getValidRowNum() { return validRowNum; }
    int getValidColNum() { return validColNum; }

protected:
    int validRowNum, validColNum;
};


class ReadOnlyTableModel : public ValidTableModel
{
    Q_OBJECT
public:
    ReadOnlyTableModel(int pm, int pn, QObject *parent = nullptr);
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    void setText(QString txt);

protected:
    int m, n;
    QVector<QString> val;
};


class QClickLabel : public QLabel {
    Q_OBJECT
public:
    explicit QClickLabel(QWidget *parent)
        : QLabel(parent){
    }
    ~QClickLabel(){}

    void mouseDoubleClickEvent(QMouseEvent *){
        QString current = text();
        bool ok = false;

        //Qt::SplashScreen
        QString text = QInputDialog::getText(this, "Edit Dialog", "", QLineEdit::Normal, current, &ok);

        if (ok && !text.isEmpty()) {
            setText(text);
            emit textChanged();
        }
    }

signals:
    void textChanged();
public slots:

};
