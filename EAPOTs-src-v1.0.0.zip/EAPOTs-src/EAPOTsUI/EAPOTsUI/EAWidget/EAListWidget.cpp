#include "EAListWidget.h"
#include <QKeyEvent>
#include <qDebug>

EAListWidgetItem::EAListWidgetItem(QWidget *parent)
    : QWidget(parent)
{
	mainLayout = new QHBoxLayout(this);
	mainLayout->setContentsMargins(2, 2, 4, 2);
    mainLayout->setSpacing(0);

	DeleteButton = new QPushButton(this);
	DeleteButton->setMinimumSize(QSize(25, 23));
	DeleteButton->setMaximumSize(QSize(25, 23));
	DeleteButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_TitleBarCloseButton));
	DeleteButton->setIconSize(QSize(16, 16));
	mainLayout->addWidget(DeleteButton);

	iWidget = 0;
};

EAListWidgetItem::~EAListWidgetItem()
{

}


void EAListWidgetItem::insertWidget(QWidget *widget) {
	mainLayout->insertWidget(iWidget, widget);
	iWidget++;
}

void EAListWidgetItem::insertWidget(QWidget *widget, int size) {
	mainLayout->insertWidget(iWidget, widget);
	mainLayout->setStretch(iWidget, size);
	iWidget++;
}


#define ListLoopBegin()											\
	QListWidgetItem *listItem;									\
	int rows = count();											\
	for (int i = rows - 1; i >= 0; i--) {						\
		listItem = item(i);

#define ListLoopEnd()	}


EAListWidget::EAListWidget(QWidget *parent)
	: QListWidget(parent)
{
}

EAListWidget::~EAListWidget()
{
	deleteAll();
}

void EAListWidget::keyReleaseEvent(QKeyEvent *ev) {

	if (ev->key() == Qt::Key_Delete)
	{
		emit KeyDeleteRelease();
		deleteSelected();
		return;
	}
}






EAListWidgetItem * EAListWidget::addNewItem(EAListWidgetItem *iWidget) {

	QListWidgetItem *listItem = new QListWidgetItem(this);

	addItem(listItem);
	setItemWidget(listItem, iWidget);

	listItem->setSizeHint(QSize(0, 30));
	connect(iWidget->DeleteButton, &QPushButton::clicked, this, [=]() {
		removeItemWidget(listItem);
		emit DeleteOperate();
		delete listItem; delete iWidget;
    });

	return iWidget;
}

void EAListWidget::deleteItem(int i, bool reset) {

	if (i < 0 || i >= count()) return;

	QListWidgetItem *listItem = item(i);
	QWidget *iWidget = itemWidget(listItem);

	listItem = takeItem(i);
	removeItemWidget(listItem);
	delete listItem;
	delete iWidget;

	emit DeleteOperate();
	if (reset) setCurrentRow(-1);
}

void EAListWidget::deleteItem(QListWidgetItem *listItem, bool reset) {

	QWidget *iWidget = itemWidget(listItem);
	removeItemWidget(listItem);

	delete listItem;
	delete iWidget;

	emit DeleteOperate();
	if (reset) setCurrentRow(-1);
}


void EAListWidget::deleteSelected() {

    QWidget* iWidget;

	ListLoopBegin();

	if (!listItem->isSelected()) continue;

    iWidget = itemWidget(listItem);
	listItem = takeItem(i);
	removeItemWidget(listItem);
	delete listItem;
	delete iWidget;

	ListLoopEnd();
}

void EAListWidget::deleteAll() {

    QWidget* iWidget;

	ListLoopBegin();

    iWidget = itemWidget(listItem);
	listItem = takeItem(i);
	removeItemWidget(listItem);
	delete listItem;
    delete iWidget;

    ListLoopEnd();
}



void EAListWidget::selectAll() {
	ListLoopBegin();

	listItem->setSelected(true);

	ListLoopEnd();
}

void EAListWidget::inverseSelect() {
	ListLoopBegin();

	listItem->setSelected(!listItem->isSelected());

	ListLoopEnd();
}

void EAListWidget::unselectAll() {
	ListLoopBegin();

	listItem->setSelected(false);

	ListLoopEnd();
}

void EAListWidget::selectRange(int i, int j) {

	int lo = i;
	int hi = j;

	if (lo < 0) lo = 0;
	if (hi >= count()) hi = count() - 1;

	QListWidgetItem *listItem;

	for (int i = lo; i < hi; i++) {
		listItem = item(i);
		listItem->setSelected(true);
	}
}
