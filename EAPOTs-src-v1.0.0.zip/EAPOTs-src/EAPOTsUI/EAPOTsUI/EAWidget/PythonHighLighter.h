#ifndef PYTHONHIGHLIGHTER_H
#define PYTHONHIGHLIGHTER_H

#include <QSyntaxHighlighter>
#include <QRegExp>

// Started from Qt Syntax Highlighter example and then ported https://wiki.python.org/moin/PyQt/Python%20syntax%20highlighting
class PythonHighlighter : public QSyntaxHighlighter
{
public:
    explicit PythonHighlighter(QTextDocument *parent = nullptr);

    // Helper
    static QTextCharFormat format(const QString &colorName, const QString &style);

    // Syntax styles that can be shared by all languages
    typedef QMap<QString, QTextCharFormat> FormatMap;

    //static FormatMap STYLES;
    static FormatMap STYLES;
    // Python keywords
    static QStringList keywords;
    // Python operators
    static QStringList operators;
    // Python braces
    static QStringList braces;


protected:
    void highlightBlock(const QString &text) override;

private:
    struct HighlightingRule
    {
        QRegExp pattern;
        QTextCharFormat format;
        int matchIndex = 0;

        HighlightingRule() { }
        HighlightingRule(const QRegExp &r, int i, const QTextCharFormat &f) : pattern(r), format(f), matchIndex(i) { }
        HighlightingRule(const QString &p, int i, const QTextCharFormat &f) : pattern(QRegExp(p)), format(f), matchIndex(i) { }
    };

    void initialize();
    void highlightPythonBlock(const QString &text);
    bool matchMultiLine(const QString &text, const HighlightingRule &rule);

    QVector<HighlightingRule> _pythonHighlightingRules;
    HighlightingRule _triSingle, _triDouble;
};

#endif // PYTHONHIGHLIGHTER_H
