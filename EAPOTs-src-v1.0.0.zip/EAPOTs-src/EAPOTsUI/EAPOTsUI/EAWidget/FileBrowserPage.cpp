#include "FileBrowserPage.h"
#include "AbInitioPage.h"

#include <QMenu>
#include <QClipboard>

#include "EAPIO.h"
#include "EAPFrame.h"
#include "EAPlotPage.h"
#include "StructGLPage.h"
#include <QMessageBox>

using namespace EAPUI_NS;

DefaultAction::DefaultAction(EAPUI* ptr)
    : UiPtr(ptr) {

}

StructEditAction::StructEditAction(EAPUI* ptr)
    : DefaultAction(ptr){
}
void StructEditAction::command(QString file) {
    frame->PageRaise(MainPage::StructEdit);
    structGL->ImportFile(file);
}


PlotEAMAction::PlotEAMAction(EAPUI* ptr)
    : DefaultAction(ptr){
}
void PlotEAMAction::command(QString file) {
    EAPlot->createPlotEAM(file);
}


PlotFSAction::PlotFSAction(EAPUI* ptr)
    : DefaultAction(ptr){
}
void PlotFSAction::command(QString file) {
    EAPlot->createPlotFS(file);
}


PlotTersoffAction::PlotTersoffAction(EAPUI* ptr)
    : DefaultAction(ptr){
}
void PlotTersoffAction::command(QString file) {
    EAPlot->createPlotTersoff(file);
}


PlotBrennerAction::PlotBrennerAction(EAPUI* ptr)
    : DefaultAction(ptr){
}
void PlotBrennerAction::command(QString file) {
    EAPlot->createPlotBrenner(file);
}


PlotSWAction::PlotSWAction(EAPUI* ptr)
    : DefaultAction(ptr){
}
void PlotSWAction::command(QString file) {
    EAPlot->createPlotSW(file);
}



FileBrowserPage::FileBrowserPage(QWidget *parent, EAPUI* ptr)
	: QWidget(parent), UiPtr(ptr)
	, StructSuffix({ "POSCAR", "CONTCAR", "vasp", "lammps", "lmp" })
	, EAMSuffix({ "eam", "fs", "alloy" })
	, SurfSuffix({ "log" })
{
	ui.setupUi(this);

    command_map["poscar"] = &command_creator<StructEditAction>;
    command_map["contcar"] = &command_creator<StructEditAction>;
    command_map["vasp"] = &command_creator<StructEditAction>;
    command_map["lammps"] = &command_creator<StructEditAction>;
    command_map["lmp"] = &command_creator<StructEditAction>;

    command_map["eam"] = &command_creator<PlotEAMAction>;
    command_map["alloy"] = &command_creator<PlotEAMAction>;
    command_map["fs"] = &command_creator<PlotFSAction>;
    command_map["tb"] = &command_creator<PlotFSAction>;
    command_map["tersoff"] = &command_creator<PlotTersoffAction>;
    command_map["brenner"] = &command_creator<PlotBrennerAction>;
    command_map["sw"] = &command_creator<PlotSWAction>;

}

FileBrowserPage::~FileBrowserPage(){

}


void FileBrowserPage::init() {
	FileModel = new QFileSystemModel(this);
	FileModel->setReadOnly(false);

	ui.FileView->setModel(FileModel);
	ui.FileView->setColumnHidden(1, true);
	ui.FileView->setColumnHidden(2, true);
	ui.FileView->setColumnHidden(3, true);
	ui.FileView->sortByColumn(0, Qt::AscendingOrder);
	ui.FileView->header()->setSectionResizeMode(QHeaderView::ResizeToContents);
	
    QDir loadPath = abInitio->createPage->cui.CreateSavePathEdit->text();
	loadPath.cdUp();

    AddFileViewComboText(loadPath.absolutePath());
	AddFileViewComboText(loadPath.absoluteFilePath("POSCAR"));
	FileViewSetRootPathWithCheck(loadPath.absolutePath());

	// File View Page

    connect(ui.FileView, &QTreeView::doubleClicked, this, &FileBrowserPage::openAction);

	ui.FileView->setContextMenuPolicy(Qt::CustomContextMenu);
	connect(ui.FileView, &QTreeView::customContextMenuRequested, this, &FileBrowserPage::FileViewContextMenuRequested);


	connect(ui.FileViewBackButton, &QPushButton::clicked, this, &FileBrowserPage::FileViewRootPathCdUp);

	connect(ui.FileViewCombo, &QComboBox::editTextChanged, this, &FileBrowserPage::FileViewSetRootPathWithCheck);

}


template <typename T>
void FileBrowserPage::command_creator(EAPUI *eapui, QString file)
{
    T cmd(eapui);
    cmd.command(file);
}

void FileBrowserPage::openAction(const QModelIndex& index) {
	
	if (!index.isValid())return;

    QFileInfo info = FileModel->fileInfo(index);
    if (info.isDir()) {
		FileViewSetRootPathWithCheck(FileModel->filePath(index));
    } else {
        QString suffix = info.suffix().toLower();
        if (command_map.contains(suffix)){
            command_map[suffix](eapui, info.absoluteFilePath());
        } else {
            QMessageBox::warning(this, tr("Unrecognized File Format"),
            tr("Unrecognized File") + QString(": %1").arg(info.absoluteFilePath()),
            QMessageBox::Ok, QMessageBox::Ok);
        }
    }
}



#define	LoopSelectedItemsBegin()															\
QModelIndex index;																			\
QModelIndexList selectedList = ui.FileView->selectionModel()->selectedIndexes();			\
for (int i = selectedList.size() - 4; i >= 0; i -= 4) {										\
	index = selectedList[i];
#define	LoopSelectedItemsEnd()	}															\

QStringList FileBrowserPage::FileViewSelectedRequested(const QStringList& suffixlist) {

	QModelIndex index;
	QModelIndexList selectedList = ui.FileView->selectionModel()->selectedIndexes();

	if (selectedList.size() == 4) {
		QFileInfo info = FileModel->fileInfo(selectedList[0]);
		if (info.isDir()) {
			return EAPIO::AutoOpenFile(FileModel->filePath(selectedList[0]), suffixlist);
		}
	}

	QStringList res;
	for (int i = selectedList.size() - 4; i >= 0; i -= 4) {
		index = selectedList[i];

		QString path = FileModel->filePath(index);
		QFileInfo info = FileModel->fileInfo(index);

		QString suffix = info.suffix();
		if (info.isFile() && suffixlist.indexOf(suffix) >= 0) {
			res << path;
		}
	}
	return res;
}

QString FileBrowserPage::FileViewCurrentRequested() {

	QModelIndex index = ui.FileView->currentIndex();

	if (!index.isValid()) return "";
	if (FileModel->fileInfo(index).isDir()) return "";

	return FileModel->filePath(index);
}





void FileBrowserPage::FileViewContextMenuRequested(const QPoint &pos) {


	QMenu menu;
	QModelIndex curIndex = ui.FileView->indexAt(pos);
	curIndex = curIndex.sibling(curIndex.row(), 0);

	//QStandardItem* item = mModel->itemFromIndex(index);
	//QString text = item->text();
	//QVariant data = item->data(Qt::UserRole + 1);
	//...

	menu.addSeparator();

    if (curIndex.isValid()) {

        menu.addAction(QStringLiteral("Open"), this, [=]() {
            LoopSelectedItemsBegin();
            openAction(index);
            LoopSelectedItemsEnd();
        });


        menu.addAction(QStringLiteral("Delete"), this, [=](bool) {
            bool NoErrorHappens;
            LoopSelectedItemsBegin();

            NoErrorHappens = FileModel->fileInfo(index).isDir() ? FileModel->rmdir(index) : FileModel->remove(index);
            if (NoErrorHappens) continue;
            frame->statusBar()->showMessage(QStringLiteral("Failed to remove %1").arg(FileModel->filePath(index)));

            LoopSelectedItemsEnd();
		});

        menu.addAction(QStringLiteral("Copy Path"), this, [=]() {
            QClipboard *clipboard = QApplication::clipboard();
            //QString originalText = clipboard->text();
            clipboard->setText(FileModel->filePath(curIndex));
        });
    }


	menu.addSeparator();

	menu.addAction(QStringLiteral("back"), this, &FileBrowserPage::FileViewRootPathCdUp);
	menu.addAction(QStringLiteral("expand All"), ui.FileView, &QTreeView::expandAll);
	menu.addAction(QStringLiteral("collapse All"), ui.FileView, &QTreeView::collapseAll);
	menu.addAction(QStringLiteral("select All"), ui.FileView, &QTreeView::selectAll);


	menu.addSeparator();
	QAction* actSize = menu.addAction(QStringLiteral("Size"));
	actSize->setCheckable(true);
	actSize->setChecked(!ui.FileView->isColumnHidden(1));
	connect(actSize, &QAction::toggled, ui.FileView, [=](bool state) { ui.FileView->setColumnHidden(1, !state); });

	QAction* actType = menu.addAction(QStringLiteral("Type"));
	actType->setCheckable(true);
	actType->setChecked(!ui.FileView->isColumnHidden(2));
	connect(actType, &QAction::toggled, ui.FileView, [=](bool state) { ui.FileView->setColumnHidden(2, !state); });

	QAction* actDate = menu.addAction(QStringLiteral("Date"));
	actDate->setCheckable(true);
	actDate->setChecked(!ui.FileView->isColumnHidden(3));
	connect(actDate, &QAction::toggled, ui.FileView, [=](bool state) { ui.FileView->setColumnHidden(3, !state); });

	menu.addSeparator();

    //if (curIndex.isValid()) menu.addAction(QStringLiteral("Edit"), this, [=]() { Edit(); });
    //if (curIndex.isValid()) menu.addAction(QStringLiteral("Modify"), this, [=]() { Modify(true); });
    //if (curIndex.isValid()) menu.addAction(QStringLiteral("PlotEAM"), this, [=]() { PlotEAM(true); });
    //if (curIndex.isValid()) menu.addAction(QStringLiteral("PlotSurf"), this, [=]() { PlotSurf(true); });

	menu.exec(QCursor::pos());
}


void FileBrowserPage::FileViewRootPathCdUp() {

	QDir dir = FileModel->rootPath();
	if (dir.cdUp()) {
		FileViewSetRootPathWithCheck(dir.absolutePath());
	}
}

void FileBrowserPage::FileViewSetRootPathWithCheck(const QString &str) {

	if (!QFileInfo(str).isDir()) return;
	QString absDir = QDir(str).absolutePath();

	FileModel->setRootPath(absDir);
	ui.FileView->setRootIndex(FileModel->index(absDir));

	ui.FileViewCombo->blockSignals(true);
	ui.FileViewCombo->setCurrentText(absDir);
	ui.FileViewCombo->blockSignals(false);
}

void FileBrowserPage::AddFileViewComboText(const QString &str) {

	if (!QFileInfo(str).isDir()) return;
	QString absDir = QDir(str).absolutePath();
	ui.FileViewCombo->addItem(absDir);
}

