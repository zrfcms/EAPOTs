#pragma once

#include <QLabel>
#include <QLineEdit>
#include <QInputDialog>

#include <QListWidget>
#include <QHBoxLayout>
#include <QPushButton>
#include <QApplication>


class EAListWidgetItem : public QWidget {
	Q_OBJECT
public:
	explicit EAListWidgetItem(QWidget *parent);
	~EAListWidgetItem();

	QHBoxLayout *mainLayout;
	QPushButton *DeleteButton;

	int iWidget;
	void insertWidget(QWidget *widget);
	void insertWidget(QWidget *widget, int size);
private:
	QListWidgetItem *listItem;
};

class EAListWidget : public QListWidget
{
	Q_OBJECT

public:
	EAListWidget(QWidget *parent);
	~EAListWidget();

protected:
	virtual void keyReleaseEvent(QKeyEvent *ev);

signals:
	void KeyDeleteRelease();
	void DeleteOperate();

public slots:
	EAListWidgetItem *addNewItem(EAListWidgetItem *iWidget);

	void deleteItem(int i, bool reset = true);

	void deleteItem(QListWidgetItem *listItem, bool reset = true);

	void deleteSelected();

	void deleteAll();

	void selectAll();

	void inverseSelect();

	void unselectAll();

	void selectRange(int, int);

};
