#include "EAPUI.h"
#include "EAPFrame.h"

#include <QFont>
#include <QtWidgets/QApplication>

using namespace EAPUI_NS;

int main(int argc, char *argv[])
{
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QApplication a(argc, argv);
    QFont font = a.font();
    font.setFamily("Times New Roman");
    font.setPointSize(9);
    a.setFont(font);

	EAPUI ui(0, NULL);
	ui.frame->show();
	return a.exec();
}
