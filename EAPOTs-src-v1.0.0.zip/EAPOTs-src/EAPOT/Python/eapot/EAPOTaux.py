# total: n
def loopN(p, f, idx, iparm, n):
    n3, n2 = n*n*n, n*n
    for i in range(n):
        lo = iparm*n3+i*n2
        p[lo:lo+n2] = (f[idx],)*n2
        idx += 1
    return idx

# total: n * (n+1) / 2
def loopN2h(p, f, idx, iparm, n):
    n3, n2, m = n*n*n, n*n, n+1
    lo = iparm*n3
    for i in range(n):
        for j in range(i, n):
            p[lo+i*n2+j*m] = f[idx]
            idx += 1
        for j in range(0, i):
            p[lo+i*n2+j*m] = p[lo+j*n2+i*m]
    return idx

# total: n+1
def loopNg(p, c, idx, iparm, n):		
    n3, n2 = n*n*n, n*n
    lo = iparm*n3
    p[lo:lo+n3] = (c[idx],)*n3
    idx += 1
    for i in range(n):
        for j in range(n):
            p[lo+i*n2+j*n+i] = c[idx]
        idx += 1
    return idx

# total f: 5 * n + 4 * n * (n+1) / 2 = 2n^2 + 7n
# total c: 3 + 2 * (n+1) = 2n + 5
def TersoffDofMapScript(caller, ndof, vdof, nf, nc, f, c, name):
    p = asArray(vdof, shape=(ndof, ))
    n, n2, n3, m = 2, 4, 8, 3
    idx = 0
    idx = loopN(p,   f, idx, 3,  n)
    idx = loopN(p,   f, idx, 4,  n)
    idx = loopN(p,   f, idx, 5,  n)
    idx = loopN(p,   f, idx, 6,  n)
    idx = loopN(p,   f, idx, 7,  n)
    idx = loopN2h(p, f, idx, 8,  n)
    idx = loopN2h(p, f, idx, 9,  n)
    idx = loopN2h(p, f, idx, 12, n)
    idx = loopN2h(p, f, idx, 13, n)

    idx = 3
    p[0 *n3:1*n3] = (c[0],)*n3
    p[1 *n3:2*n3] = (c[1],)*n3
    p[2 *n3:3*n3] = (c[2],)*n3
    idx = loopNg(p, c, idx, 10, n)
    idx = loopNg(p, c, idx, 11, n)