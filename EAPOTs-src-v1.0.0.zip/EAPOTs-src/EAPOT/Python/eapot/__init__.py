from ctypes import *
import numpy
import os, sys
from inspect import getsourcefile

EACHKDir = os.path.dirname(__file__)
EACHKDir = os.path.dirname(EACHKDir)
EACHKDir = os.path.join(EACHKDir, 'EACHK')
sys.path.append(EACHKDir)

asArray = numpy.ctypeslib.as_array

int,   dbl    = c_int,          c_double  
pint , pdbl   = POINTER(c_int), POINTER(c_double)
p2int, p2dbl  = POINTER(pint),  POINTER(pdbl)

pvoid, p2void = c_void_p, POINTER(c_void_p)
pchar, p2char = c_char_p, POINTER(c_char_p)

def ParamLimitRatio(x, a, b, c): 
    return c*(x<a)*(x/a-1)**2 + c*(b<x)*(x/b-1)**2
def ParamlimitAbslo(x, a, b, c): 
    return c*(x<a)*(x - a)**2 + c*(b<x)*(x - b)**2

class PairEAMParam(Structure):
    _fields_ = (("nparam", c_int), ("vparam", POINTER(c_double)), 
                ("nrhot", c_int), ("nr", c_int), 
                ("nemb", c_int), ("nrho", c_int), ("nphi", c_int), 
                ("vrhot", POINTER(c_double)), ("vr", POINTER(c_double)),
                ("vemb", POINTER(c_double)), ("vrho", POINTER(c_double)), 
                ("vphi", POINTER(c_double)))

    def parse(self):
        self.param = asArray(self.vparam, shape=(self.nparam, ))
        self.rhot  = asArray(self.vrhot,  shape=(self.nrhot,  ))
        self.r     = asArray(self.vr,     shape=(self.nr,     ))

        self.emb   = asArray(self.vemb, shape=(self.nemb, self.nrhot))
        self.rho   = asArray(self.vrho, shape=(self.nrho, self.nr   ))
        self.phi   = asArray(self.vphi, shape=(self.nphi, self.nr   ))
        return self.param, self.rhot, self.r, self.emb, self.rho, self.phi

class ComputeEnergyParam(Structure):
    _fields_ = (("id", pchar), ("atomNum", int), ("energy", dbl), ("Ec", dbl), 
                ("lattice", dbl*6), ("stress", dbl*6), 
                ("energyCost", dbl), ("forceCost", dbl), ("virialCost", dbl),
                ("rhoAve", dbl), ("embAve", dbl), 
                ("tag", pint), ("type", pint), ("pos", pdbl), 

                ("penergyV", pdbl), ("pforceV", pdbl), ("pvirialV", pdbl),
                ("penergyW", pdbl), ("pforceW", pdbl), ("pvirialW", pdbl),
                ("penergyR", pdbl), ("pforceR", pdbl), ("pvirialR", pdbl))

    def parse(self):
        self.xx, self.yy, self.zz, self.xy, self.xz, self.yz = self.lattice
        self.energyVec = asArray(self.penergyV, shape=(self.atomNum, )) if self.penergyV else None
        self.energyWht = asArray(self.penergyW, shape=(self.atomNum, )) if self.penergyW else None
        self.energyRef = asArray(self.penergyR, shape=(self.atomNum, )) if self.penergyR else None

        self.forceVec  = asArray(self.pforceV,  shape=(self.atomNum, )) if self.pforceV  else None 
        self.forceWht  = asArray(self.pforceW,  shape=(self.atomNum, )) if self.pforceW  else None 
        self.forceRef  = asArray(self.pforceR,  shape=(self.atomNum, )) if self.pforceR  else None 
            
        self.virialVec = asArray(self.pvirialV, shape=(self.atomNum, )) if self.pvirialV else None 
        self.virialWht = asArray(self.pvirialW, shape=(self.atomNum, )) if self.pvirialW else None 
        self.virialRef = asArray(self.pvirialR, shape=(self.atomNum, )) if self.pvirialR else None 
        return self

    def __str__(self):
        a, s = self.lattice, self.stress
        return '%d atoms with %.4f eV, %.4f eV per atom\n'%(self.atomNum, self.energy, self.Ec)  + \
        'lattice = [%9.4f, %9.4f, %9.4f, %9.4f, %9.4f, %9.4f]\n'%(a[0], a[1], a[2], a[3], a[4], a[5]) + \
        'stress  = [%9.2e, %9.2e, %9.2e, %9.2e, %9.2e, %9.2e]\n'%(s[0], s[1], s[2], s[3], s[4], s[5]) + \
        'energy: %.5e\n Vec:%s\n Wht:%s\n Ref:%s\n'%(self.energyCost, str(self.energyVec), str(self.energyWht), str(self.energyRef)) + \
        'force:  %.5e\n Vec:%s\n Wht:%s\n Ref:%s\n'%(self.forceCost,  str(self.forceVec) , str(self.forceWht) , str(self.forceRef) ) + \
        'virial: %.5e\n Vec:%s\n Wht:%s\n Ref:%s\n'%(self.virialCost, str(self.virialVec), str(self.virialWht), str(self.virialRef))


class ComputeElasticParam(Structure):
    _fields_ = (("id", c_char_p), ("vCdata", c_double*36), ("vC", POINTER(c_double*6)), 
                ("cubic",  c_double*3),  ("hex", c_double*6), 
                ("Bulk",   c_double), ("Shear",  c_double), ("Poisson", c_double),
                ("Youngx", c_double), ("Youngy", c_double), ("Youngz",  c_double))

    def parse(self):
        self.C = asArray(cast(self.vCdata, POINTER(c_double)), shape=(6, 6))
        return self		
    def __str__(self):
        fmt = '%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\n'
        return 'Elastic Constants:\n'+                                                \
        fmt%tuple(self.C[0]) + fmt%tuple(self.C[1]) + fmt%tuple(self.C[2]) +          \
        fmt%tuple(self.C[3]) + fmt%tuple(self.C[4]) + fmt%tuple(self.C[5]) +          \
        'cubic:\t%.1f\t%.1f\t%.1f\nhex:\t'%tuple(self.cubic) + fmt%tuple(self.hex) +  \
        'Bulk, Shear, Poisson, Youngx/y/z:\n%.1f\t%.1f\t%.3f\t%.1f\t%.1f\t%.1f'%  \
        (self.Bulk, self.Shear, self.Poisson, self.Youngx, self.Youngy, self.Youngz) 

class DumpCallbackParam(Structure):
    _fields_ = (("mode", c_int), ("step", c_int), ("nparam", c_int), 
        ("param", POINTER(c_double)), ("costValue", c_double), 
        ("nfile", c_int), ("files", POINTER(c_char_p)),
        ("figure", c_char_p))

pPairEAMParam      = POINTER(PairEAMParam)
pDumpCallbackParam = POINTER(DumpCallbackParam)

pStr = lambda x: x.encode() if x else None

def Args(args): 
    pargs = list(map(lambda x:x.encode(), args))
    return (c_char_p*len(pargs))(*pargs)
    
def Dbls(dbls): 
    return (c_double*len(dbls))(*dbls)

def Ints(ints): 
    return (c_int*len(ints))(*ints)

def PythonAPIConvert(file):
    with open(file, "r") as r:
        data = r.readlines()

    t1, t2 = '    ', '        '
    typeAPIs, funcAPIs = '', '\n\n\n'
    stem, suffix = os.path.splitext(file)

    for line in data:

        script = line.strip()
        if script.startswith('#'):
            funcAPIs += t1 + script + '\n'
            typeAPIs += t2 + script + '\n'
            continue
        if script == '': continue

        script = script.replace('(APITYPE ', '').replace(')', '')

        keys = [x.strip() for x in script.split(',')]
        name = keys[1]
        argvs = [x.split(' ')[-1] for x in keys[2:]]
        types = [' '.join(x.split(' ')[:-1]) for x in keys[2:]]
        argtypes = [''] * len(argvs)

        funcAPIs += '    def ' + name + '(self, ' + ', '.join(argvs) + '):\n'

        for i in range(len(types)):
            itype = types[i]
            if   itype == 'const char**': argvs[i] = 'Args(%s)'%argvs[i]; argtypes[i] = 'p2char'
            elif itype == 'const char*':  argvs[i] = 'pStr(%s)'%argvs[i]; argtypes[i] = 'pchar'
            elif itype == 'double*':      argvs[i] = 'Dbls(%s)'%argvs[i]; argtypes[i] = 'pdbl'
            elif itype == 'int*':         argvs[i] = 'Ints(%s)'%argvs[i]; argtypes[i] = 'pint'
            elif itype == 'void*':        argtypes[i] = 'pvoid'
            elif itype == 'double':       argtypes[i] = 'dbl'
            elif itype == 'int':          argtypes[i] = 'int'
            else: 
                argtypes[i] = 'self.%sType'%types[i]
                print('Special Type: ',  itype)

        for i, (iarg, itype) in enumerate(zip(argvs, argtypes)):

            if   iarg.startswith('pPair') and itype == 'pvoid':
                funcAPIs += t2 + "if %s.type != 'pair': raise(ValueError('param %s is not a Pair'))\n"%(iarg, iarg)
                argvs[i] += '.p'
            elif iarg.startswith('pComp') and itype == 'pvoid':
                funcAPIs += t2 + "if %s.type != 'comp': raise(ValueError('param %s is not a Compute'))\n"%(iarg, iarg)
                argvs[i] += '.p'
            elif iarg.startswith('pDump') and itype == 'pvoid':
                funcAPIs += t2 + "if %s.type != 'dump': raise(ValueError('param %s is not a Dump'))\n"%(iarg, iarg)
                argvs[i] += '.p'

        funcAPIs += t2 + 'self.lib.eapot_'  + name + '(self.eapot, ' + ', '.join(argvs) + ')\n\n'
        typeAPIs += t2 + 'lib.eapot_%s.argtypes = [pvoid, %s]\n'%(name, ', '.join(argtypes))

    with open(stem + '.py', "w") as w: 
        w.write(typeAPIs)
        w.write(funcAPIs)


class EAPair(object):
    def __init__(self, p):
        self.p, self.type = pvoid(p), 'pair'

class EAComp(object):
    def __init__(self, p):
        self.p, self.type = pvoid(p), 'comp'

class EADump(object):
    def __init__(self, p):
        self.p, self.type = pvoid(p), 'dump'

class EAPOT(object):
    globalbyte = pchar(b'')

    ComputeMap = {
        'energy':  POINTER(ComputeEnergyParam),
        'elastic': POINTER(ComputeElasticParam),
    }

    @staticmethod
    def parseCompute(nparam, style, param):
        return [cast(param[i], EAPOT.ComputeMap[style[i].decode()])[0].parse() for i in range(nparam)]

    def addComputeRelax(self, struct, mode, *, rlx = [0.0, 0.0, 0.0], sufdata = 'lammps', suflog = ''):
        '''e.g:
        struct = 'cF4225A1_Ec', 
        mode   = 'aniso',
        rlx    = [0.0, 0.0, 0.0]
        '''
        id = os.path.basename(struct).replace('.', '').replace('[', '').replace(']', '')
        comp = self.addCompute(id, 'energy', '%s.%s'%(struct, sufdata))
        if len(suflog): self.setComputeEnergyRefFile(comp, '%s.%s'%(struct, suflog))
        self.setComputeEnergyRelaxBox(comp, mode, rlx)
        return comp

    def addComputeRemap(self, struct, pRlx, mode, *, sufdata = 'lammps', suflog = ''):
        '''e.g:
        struct = 'cF4[225]A1_Es_111_r2', 
        pRlx   =  icomp, 
        mode   = 'shape'
        '''
        id = os.path.basename(struct).replace('.', '').replace('[', '').replace(']', '')
        comp = self.addCompute(id, 'energy', '%s.%s'%(struct, sufdata))
        if len(suflog): self.setComputeEnergyRefFile(comp, '%s.%s'%(struct, suflog))
        self.setComputeEnergyNoRelax(comp)
        self.setComputeEnergyRemapStyle(comp, pRlx, mode)
        return comp

    @staticmethod
    def packMsg(msg):
        EAPOT.globalbyte.value = msg.encode()
        return pvoid.from_buffer(EAPOT.globalbyte).value   

    def delate(self):
        self.lib.eapot_close.argtypes = [pvoid,]
        self.lib.eapot_close(self.eapot)

    def __init__(self, args=[]):
        abspath, join = os.path.abspath, os.path.join

        self.pythonPath = os.path.dirname(__file__)
        self.projPath = abspath(join(self.pythonPath, '..', '..'))
        self.binPath = abspath(join(self.projPath, 'bin'))
        
        self.EAPOTso = abspath(join(self.binPath, 'EAPOT.so'))
        self.lib = CDLL(self.EAPOTso, RTLD_GLOBAL, winmode=RTLD_GLOBAL)
        
        #self.lib.eapot_open.argtypes = [c_int, c_char_p*narg, pvoid()]
        #self.lib.eapot_open.restype = None
        #self.lib.eapot_check.argtypes = [pvoid(), c_int, c_int]

        self.VoidCallbackType   = CFUNCTYPE(None,  pvoid, pvoid)
        self.StrCallbackType    = CFUNCTYPE(pchar, pvoid, pvoid)
        self.CompCallbackType   = CFUNCTYPE(pchar, pvoid, int, pdbl, int, p2char, p2void, pdbl)
        self.DofMapCallbackType = CFUNCTYPE(None,  pvoid, int, pdbl, int, int, pdbl, pdbl, p2char)
        self.pythonCallbackType = CFUNCTYPE(None,  pvoid, pchar, int, pchar)

        pythonapi.PyCapsule_GetPointer.restype = pvoid
        pythonapi.PyCapsule_GetPointer.argtypes = [py_object, pchar]
        
        lib = self.lib
        lib.eapot_addPair.restype    = pvoid
        lib.eapot_getPair.restype    = pvoid
        lib.eapot_addCompute.restype = pvoid
        lib.eapot_getCompute.restype = pvoid
        lib.eapot_addDump.restype    = pvoid
        lib.eapot_getDump.restype    = pvoid

        lib.eapot_printStyleAPI.argtypes = None
        lib.eapot_printStylePythonAPI.argtypes = [pchar,]

        self.opened = 1
        self.eapot = pvoid()
        args.insert(0, __file__)
        self.lib.eapot_open(len(args), Args(args), byref(self.eapot))

        # eapot.h
        lib.eapot_clear.argtypes = [pvoid, ]
        lib.eapot_setPythonCallback.argtypes = [pvoid, self.pythonCallbackType, pvoid]

        # input.h  
        lib.eapot_setEcho.argtypes = [pvoid, int, int]
        lib.eapot_setLog.argtypes = [pvoid, pchar, pchar]

        # force.h
        lib.eapot_setMass.argtypes = [pvoid, int, pdbl]
        lib.eapot_setElement.argtypes = [pvoid, int, p2char]
        lib.eapot_addPair.argtypes = [pvoid, pchar]
        lib.eapot_getPair.argtypes = [pvoid,]
        lib.eapot_getPotScript.argtypes = [pvoid, pvoid]
        lib.eapot_getPotScript.restype = pchar

        # update.h
        lib.eapot_setTimestep.argtypes = [pvoid, int]
        lib.eapot_setRandomSeed.argtypes = [pvoid, int]
        lib.eapot_setMinimizeLogFlag.argtypes = [pvoid, int]
        lib.eapot_setMinimizeStyle.argtypes = [pvoid, pchar]
        lib.eapot_runMinimize.argtypes = [pvoid, pvoid, dbl, dbl, int, int]

        # modify.h
        lib.eapot_addCompute.argtypes = [pvoid, pchar, pchar, pchar]
        lib.eapot_getCompute.argtypes = [pvoid, pchar, pchar]

        # output.h
        lib.eapot_runDumpOnce.argtypes = [pvoid,]
        lib.eapot_delThermoFormat.argtypes = [pvoid,]
        lib.eapot_addDump.argtypes = [pvoid, int, pchar, pchar, pchar]
        lib.eapot_getDump.argtypes = [pvoid, pchar, pchar]

        #  Output
        lib.eapot_deleteDump.argtypes = [pvoid, pvoid]
        lib.eapot_setPath.argtypes = [pvoid, pchar, pchar]
        lib.eapot_setLogFile.argtypes = [pvoid, pchar, pchar]
        lib.eapot_setDumpStep.argtypes = [pvoid, pvoid, int]
        lib.eapot_setThermoStep.argtypes = [pvoid, int]
        lib.eapot_setThermoKeys.argtypes = [pvoid, pchar, int, p2char]
        lib.eapot_setThermoLineStyle.argtypes = [pvoid, pchar]
        lib.eapot_setThermoPrintCost.argtypes = [pvoid, int]
        lib.eapot_setThermoBlank.argtypes = [pvoid, int]
        lib.eapot_setThermoFormatIndex.argtypes = [pvoid, int, pchar]
        lib.eapot_setThermoFormatStyle.argtypes = [pvoid, pchar, pchar]
        #  Pair styles
        lib.eapot_setPairDof.argtypes = [pvoid, pvoid, int, int]
        lib.eapot_setPairDofScript.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairDofCallback.argtypes = [pvoid, pvoid, self.DofMapCallbackType, pvoid]
        lib.eapot_setPairPotCallback.argtypes = [pvoid, pvoid, self.VoidCallbackType, pvoid]
        lib.eapot_setPairFullParams.argtypes = [pvoid, pvoid, pdbl]
        lib.eapot_setPairFreeParams.argtypes = [pvoid, pvoid, pdbl]
        lib.eapot_setPairCommByFile.argtypes = [pvoid, pvoid, int]
        lib.eapot_setPairDumpImageLimitSampleValue.argtypes = [pvoid, pvoid, int, int, dbl]
        lib.eapot_setPairDumpImageXLimit.argtypes = [pvoid, pvoid, int, dbl, dbl]
        lib.eapot_setPairDumpImageYLimit.argtypes = [pvoid, pvoid, int, dbl, dbl]
        lib.eapot_setPairEAMDumpFormat.argtypes = [pvoid, pvoid, int, dbl, int, dbl, dbl]
        lib.eapot_setPairEAMDumpNrho.argtypes = [pvoid, pvoid, int]
        lib.eapot_setPairEAMDumpNr.argtypes = [pvoid, pvoid, int]
        lib.eapot_setPairEAMDumpdrho.argtypes = [pvoid, pvoid, dbl]
        lib.eapot_setPairEAMDumpdr.argtypes = [pvoid, pvoid, dbl]
        lib.eapot_setPairEAMDumpCutoff.argtypes = [pvoid, pvoid, dbl]
        lib.eapot_setPairEAMDumpImageEmbXMult.argtypes = [pvoid, pvoid, dbl]
        lib.eapot_setPairEAMDumpImageLimitRlo.argtypes = [pvoid, pvoid, dbl]
        lib.eapot_setPairEAMDumpFileElementTitle.argtypes = [pvoid, pvoid, int, pchar]
        lib.eapot_setPairEAMOutputMode.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_enablePairEAMListTransform.argtypes = [pvoid, pvoid, int]
        lib.eapot_inputPairEAMListFromFunc.argtypes = [pvoid, pvoid, p2char]
        lib.eapot_inputPairEAMListFromFS.argtypes = [pvoid, pvoid, pchar, p2char]
        lib.eapot_inputPairEAMListFromAlloy.argtypes = [pvoid, pvoid, pchar, p2char]
        lib.eapot_setPairEAMVotermRoseSampleRange.argtypes = [pvoid, pvoid, dbl, dbl, int]
        lib.eapot_setPairEAMVotermRoseSamplePoint.argtypes = [pvoid, pvoid, int, pdbl]
        lib.eapot_setPairEAMVotermRoseAxis.argtypes = [pvoid, pvoid, int]
        lib.eapot_setPairEAMVotermRoseStructure.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairEAMVotermScreenFile.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairEAMVotermLogFile.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairEAMZXWRhoAxisLattice.argtypes = [pvoid, pvoid, int, dbl]
        lib.eapot_setPairEAMZXWRhoStructure.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairEAMZXWScreenFile.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairEAMZXWLogFile.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairEAMCrossJohnsonDof.argtypes = [pvoid, pvoid, int]
        lib.eapot_setPairEAMCrossJohnsonMode.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setPairEAMCrossCubicChain.argtypes = [pvoid, pvoid, int, pchar]
        lib.eapot_setPairEAMCrossAshwinAtomicNumber.argtypes = [pvoid, pvoid, dbl, dbl]
        lib.eapot_setPairEAMCrossAshwinZBLRange.argtypes = [pvoid, pvoid, dbl, dbl]
        lib.eapot_addPairMEAMFreeParam.argtypes = [pvoid, pvoid, int, p2char]
        lib.eapot_addPairMEAMConstParam.argtypes = [pvoid, pvoid, int, p2char]
        #  Dump styles
        lib.eapot_setDumpTimeLabel.argtypes = [pvoid, pvoid, int]
        lib.eapot_setDumpFirstFlag.argtypes = [pvoid, pvoid, int]
        lib.eapot_setDumpPadStep.argtypes = [pvoid, pvoid, int]
        lib.eapot_setDumpFileExtra.argtypes = [pvoid, pvoid, int, p2char]
        lib.eapot_setDumpImageSize.argtypes = [pvoid, pvoid, int, int]
        lib.eapot_setDumpExternalFile.argtypes = [pvoid, pvoid, pvoid]
        lib.eapot_setDumpExternalImage.argtypes = [pvoid, pvoid, pvoid]
        lib.eapot_setDumpExternalScript.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setDumpExternalCallback.argtypes = [pvoid, pvoid, self.StrCallbackType, pvoid]
        #  Compute styles
        lib.eapot_setComputeEnergyTriclinic.argtypes = [pvoid, pvoid, int]
        lib.eapot_setComputeEnergyMinimize.argtypes = [pvoid, pvoid, dbl, dbl, int, int]
        lib.eapot_setComputeEnergyDumpStep.argtypes = [pvoid, pvoid, int]
        lib.eapot_setComputeEnergyRunScript.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeEnergyInitScript.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeEnergyScreenFile.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeEnergyLogFile.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeEnergyEcho.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeEnergyEnergyAtom.argtypes = [pvoid, pvoid, int]
        lib.eapot_setComputeEnergyVirial.argtypes = [pvoid, pvoid, int, int]
        lib.eapot_setComputeEnergyRefFile.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeEnergyNoRelax.argtypes = [pvoid, pvoid]
        lib.eapot_setComputeEnergyRelaxAtom.argtypes = [pvoid, pvoid, pint]
        lib.eapot_setComputeEnergyRelaxBox.argtypes = [pvoid, pvoid, pchar, pdbl]
        lib.eapot_setComputeEnergyReload.argtypes = [pvoid, pvoid, int]
        lib.eapot_setComputeEnergyUseMaxForce.argtypes = [pvoid, pvoid, int]
        lib.eapot_setComputeEnergyRemapStyle.argtypes = [pvoid, pvoid, pvoid, pchar]
        lib.eapot_setComputeEnergyRemapCustom.argtypes = [pvoid, pvoid, pvoid, pint]
        lib.eapot_setComputeEnergyTiltLimit.argtypes = [pvoid, pvoid, int]
        lib.eapot_setComputeElasticHalfLoad.argtypes = [pvoid, pvoid, int]
        lib.eapot_setComputeElasticMethod.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeElasticMinimize.argtypes = [pvoid, pvoid, dbl, dbl, int, int]
        lib.eapot_setComputeElasticZeroCut.argtypes = [pvoid, pvoid, dbl]
        lib.eapot_setComputeElasticLoadDelta.argtypes = [pvoid, pvoid, dbl]
        lib.eapot_setComputeExternalTitle.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeExternalScript.argtypes = [pvoid, pvoid, pchar]
        lib.eapot_setComputeExternalCallback.argtypes = [pvoid, pvoid, self.CompCallbackType, pvoid]
        #  Minimize styles
        lib.eapot_setMinDmax.argtypes = [pvoid, dbl]
        lib.eapot_setMinDelta.argtypes = [pvoid, dbl]
        lib.eapot_setParticleSwarmTakaParticles.argtypes = [pvoid, int]
        lib.eapot_setSimulatedAnnealingAMode.argtypes = [pvoid, pchar]
        lib.eapot_setDifferentialEvolutionGeneNum.argtypes = [pvoid, int]
        lib.eapot_setDifferentialEvolutionInitRange.argtypes = [pvoid, dbl]
        lib.eapot_setDifferentialEvolutionMutRat.argtypes = [pvoid, dbl]
        lib.eapot_setDifferentialEvolutionCrossRat.argtypes = [pvoid, dbl]
        lib.eapot_setLineSearchMethod.argtypes = [pvoid, pchar]


    # Top APIs
    def printStyleAPI(self):
        self.lib.eapot_printStyleAPI()

    def printStylePythonAPI(self, file):
        self.lib.eapot_printStylePythonAPI(pStr(file))

    # eapot.h
    def clear(self):
    	self.lib.eapot_clear(self.eapot)
    
    def setPythonCallback(self, callback, caller):
    	self.lib.eapot_setPythonCallback(self.eapot, callback, caller)

    # input.h  
    def setEcho(self, screen, log):
    	self.lib.eapot_setEcho(self.eapot, screen, log)  

    def setLog(self, file, mode):	
    	self.lib.eapot_setLog(self.eapot, file, mode)

    # force.h
    def setMass(self, mass):
    	self.lib.eapot_setMass(self.eapot, len(mass), Dbls(mass))                           #

    def setElement(self, ele):	
    	self.lib.eapot_setElement(self.eapot, len(ele), Args(ele))                          #

    def addPair(self, style):   
        return EAPair(self.lib.eapot_addPair(self.eapot, pStr(style)))

    def getPair(self):           
        return EAPair(self.lib.eapot_getPair(self.eapot))

    def getPotScript(self, pPair):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        return (self.lib.eapot_getPotScript(self.eapot, pPair.p)).decode()

    # update.h
    def setTimestep(self, step):
    	self.lib.eapot_setTimestep(self.eapot, step)

    def setRandomSeed(self, seed):
    	self.lib.eapot_setRandomSeed(self.eapot, seed)

    def setMinimizeLogFlag(self, flag):
    	self.lib.eapot_setMinimizeLogFlag(self.eapot, flag)

    def setMinimizeStyle(self, style):
    	self.lib.eapot_setMinimizeStyle(self.eapot, pStr(style))                         #

    def runMinimize(self, pComp, etol, ftol, nstep, neval):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_runMinimize(self.eapot, pComp.p, etol, ftol, nstep, neval)
    
    # modify.h
    def addCompute(self, sid, style, key):
        '''add a Dump to Compute list''' 
        return EAComp(self.lib.eapot_addCompute(self.eapot, pStr(sid), pStr(style), pStr(key)))

    def getCompute(self, sid, style):
        '''find the pointer to Compute'''
        return EAComp(self.lib.eapot_getCompute(self.eapot, pStr(sid), pStr(style)))
    
    # output.h
    def runDumpOnce(self):
    	self.lib.eapot_runDumpOnce(self.eapot)

    def delThermoFormat(self):
    	self.lib.eapot_delThermoFormat(self.eapot)

    def addDump(self, step, sid, style, key):
        '''add a Dump to Dump list''' 
        return EADump(self.lib.eapot_addDump(self.eapot, step, pStr(sid), pStr(style), pStr(key)))

    def getDump(self, sid, style):
        '''find the pointer to Dump'''
        return EADump(self.lib.eapot_getDump(self.eapot, pStr(sid), pStr(style)))


    #  Output
    def deleteDump(self, pDump):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_deleteDump(self.eapot, pDump.p)

    def setPath(self, key, path):
        self.lib.eapot_setPath(self.eapot, pStr(key), pStr(path))

    def setLogFile(self, key, file):
        self.lib.eapot_setLogFile(self.eapot, pStr(key), pStr(file))

    def setDumpStep(self, pDump, step):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpStep(self.eapot, pDump.p, step)

    def setThermoStep(self, step):
        self.lib.eapot_setThermoStep(self.eapot, step)

    def setThermoKeys(self, style, num, keys):
        self.lib.eapot_setThermoKeys(self.eapot, pStr(style), num, Args(keys))

    def setThermoLineStyle(self, fmt):
        self.lib.eapot_setThermoLineStyle(self.eapot, pStr(fmt))

    def setThermoPrintCost(self, flag):
        self.lib.eapot_setThermoPrintCost(self.eapot, flag)

    def setThermoBlank(self, flag):
        self.lib.eapot_setThermoBlank(self.eapot, flag)

    def setThermoFormatIndex(self, i, fmt):
        self.lib.eapot_setThermoFormatIndex(self.eapot, i, pStr(fmt))

    def setThermoFormatStyle(self, key, fmt):
        self.lib.eapot_setThermoFormatStyle(self.eapot, pStr(key), pStr(fmt))

    #  Pair styles
    def setPairDof(self, pPair, nfree, nconst):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairDof(self.eapot, pPair.p, nfree, nconst)

    def setPairDofScript(self, pPair, script):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairDofScript(self.eapot, pPair.p, pStr(script))

    def setPairDofCallback(self, pPair, callback, caller):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairDofCallback(self.eapot, pPair.p, callback, caller)

    def setPairPotCallback(self, pPair, callback, caller):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairPotCallback(self.eapot, pPair.p, callback, caller)

    def setPairFullParams(self, pPair, vec):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairFullParams(self.eapot, pPair.p, Dbls(vec))

    def setPairFreeParams(self, pPair, vec):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairFreeParams(self.eapot, pPair.p, Dbls(vec))

    def setPairCommByFile(self, pPair, flag):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairCommByFile(self.eapot, pPair.p, flag)

    def setPairDumpImageLimitSampleValue(self, pPair, figidx1, figidx2, x):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairDumpImageLimitSampleValue(self.eapot, pPair.p, figidx1, figidx2, x)

    def setPairDumpImageXLimit(self, pPair, figidx, lo, hi):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairDumpImageXLimit(self.eapot, pPair.p, figidx, lo, hi)

    def setPairDumpImageYLimit(self, pPair, figidx, lo, hi):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairDumpImageYLimit(self.eapot, pPair.p, figidx, lo, hi)

    def setPairEAMDumpFormat(self, pPair, Nrho, drho, Nr, dr, cut):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpFormat(self.eapot, pPair.p, Nrho, drho, Nr, dr, cut)

    def setPairEAMDumpNrho(self, pPair, num):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpNrho(self.eapot, pPair.p, num)

    def setPairEAMDumpNr(self, pPair, num):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpNr(self.eapot, pPair.p, num)

    def setPairEAMDumpdrho(self, pPair, delta):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpdrho(self.eapot, pPair.p, delta)

    def setPairEAMDumpdr(self, pPair, delta):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpdr(self.eapot, pPair.p, delta)

    def setPairEAMDumpCutoff(self, pPair, cut):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpCutoff(self.eapot, pPair.p, cut)

    def setPairEAMDumpImageEmbXMult(self, pPair, ratio):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpImageEmbXMult(self.eapot, pPair.p, ratio)

    def setPairEAMDumpImageLimitRlo(self, pPair, lo):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpImageLimitRlo(self.eapot, pPair.p, lo)

    def setPairEAMDumpFileElementTitle(self, pPair, ele, title):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMDumpFileElementTitle(self.eapot, pPair.p, ele, pStr(title))

    def setPairEAMOutputMode(self, pPair, mode):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMOutputMode(self.eapot, pPair.p, pStr(mode))

    def enablePairEAMListTransform(self, pPair, flag):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_enablePairEAMListTransform(self.eapot, pPair.p, flag)

    def inputPairEAMListFromFunc(self, pPair, pele):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_inputPairEAMListFromFunc(self.eapot, pPair.p, Args(pele))

    def inputPairEAMListFromFS(self, pPair, file, pele):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_inputPairEAMListFromFS(self.eapot, pPair.p, pStr(file), Args(pele))

    def inputPairEAMListFromAlloy(self, pPair, file, pele):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_inputPairEAMListFromAlloy(self.eapot, pPair.p, pStr(file), Args(pele))

    def setPairEAMVotermRoseSampleRange(self, pPair, begin, end, nSample):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMVotermRoseSampleRange(self.eapot, pPair.p, begin, end, nSample)

    def setPairEAMVotermRoseSamplePoint(self, pPair, nSample, point):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMVotermRoseSamplePoint(self.eapot, pPair.p, nSample, Dbls(point))

    def setPairEAMVotermRoseAxis(self, pPair, axis):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMVotermRoseAxis(self.eapot, pPair.p, axis)

    def setPairEAMVotermRoseStructure(self, pPair, pfile):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMVotermRoseStructure(self.eapot, pPair.p, pStr(pfile))

    def setPairEAMVotermScreenFile(self, pPair, pfile):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMVotermScreenFile(self.eapot, pPair.p, pStr(pfile))

    def setPairEAMVotermLogFile(self, pPair, pfile):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMVotermLogFile(self.eapot, pPair.p, pStr(pfile))

    def setPairEAMZXWRhoAxisLattice(self, pPair, axis, a0):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMZXWRhoAxisLattice(self.eapot, pPair.p, axis, a0)

    def setPairEAMZXWRhoStructure(self, pPair, pfile):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMZXWRhoStructure(self.eapot, pPair.p, pStr(pfile))

    def setPairEAMZXWScreenFile(self, pPair, pfile):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMZXWScreenFile(self.eapot, pPair.p, pStr(pfile))

    def setPairEAMZXWLogFile(self, pPair, pfile):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMZXWLogFile(self.eapot, pPair.p, pStr(pfile))

    def setPairEAMCrossJohnsonDof(self, pPair, dof):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMCrossJohnsonDof(self.eapot, pPair.p, dof)

    def setPairEAMCrossJohnsonMode(self, pPair, mode):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMCrossJohnsonMode(self.eapot, pPair.p, pStr(mode))

    def setPairEAMCrossCubicChain(self, pPair, nchain, mode):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMCrossCubicChain(self.eapot, pPair.p, nchain, pStr(mode))

    def setPairEAMCrossAshwinAtomicNumber(self, pPair, Z1, Z2):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMCrossAshwinAtomicNumber(self.eapot, pPair.p, Z1, Z2)

    def setPairEAMCrossAshwinZBLRange(self, pPair, r1, r2):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_setPairEAMCrossAshwinZBLRange(self.eapot, pPair.p, r1, r2)

    def addPairMEAMFreeParam(self, pPair, num, params):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_addPairMEAMFreeParam(self.eapot, pPair.p, num, Args(params))

    def addPairMEAMConstParam(self, pPair, num, params):
        if pPair.type != 'pair': raise(ValueError('param pPair is not a Pair'))
        self.lib.eapot_addPairMEAMConstParam(self.eapot, pPair.p, num, Args(params))

    #  Dump styles
    def setDumpTimeLabel(self, pDump, flag):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpTimeLabel(self.eapot, pDump.p, flag)

    def setDumpFirstFlag(self, pDump, flag):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpFirstFlag(self.eapot, pDump.p, flag)

    def setDumpPadStep(self, pDump, step):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpPadStep(self.eapot, pDump.p, step)

    def setDumpFileExtra(self, pDump, n, files):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpFileExtra(self.eapot, pDump.p, n, Args(files))

    def setDumpImageSize(self, pDump, w, h):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpImageSize(self.eapot, pDump.p, w, h)

    def setDumpExternalFile(self, pDump, pDumpRef):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        if pDumpRef.type != 'dump': raise(ValueError('param pDumpRef is not a Dump'))
        self.lib.eapot_setDumpExternalFile(self.eapot, pDump.p, pDumpRef.p)

    def setDumpExternalImage(self, pDump, pDumpRef):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        if pDumpRef.type != 'dump': raise(ValueError('param pDumpRef is not a Dump'))
        self.lib.eapot_setDumpExternalImage(self.eapot, pDump.p, pDumpRef.p)

    def setDumpExternalScript(self, pDump, script):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpExternalScript(self.eapot, pDump.p, pStr(script))

    def setDumpExternalCallback(self, pDump, callback, caller):
        if pDump.type != 'dump': raise(ValueError('param pDump is not a Dump'))
        self.lib.eapot_setDumpExternalCallback(self.eapot, pDump.p, callback, caller)

    #  Compute styles
    def setComputeEnergyTriclinic(self, pComp, flag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyTriclinic(self.eapot, pComp.p, flag)

    def setComputeEnergyMinimize(self, pComp, etol, ftol, niter, nstep):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyMinimize(self.eapot, pComp.p, etol, ftol, niter, nstep)

    def setComputeEnergyDumpStep(self, pComp, dumpStep):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyDumpStep(self.eapot, pComp.p, dumpStep)

    def setComputeEnergyRunScript(self, pComp, script):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyRunScript(self.eapot, pComp.p, pStr(script))

    def setComputeEnergyInitScript(self, pComp, script):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyInitScript(self.eapot, pComp.p, pStr(script))

    def setComputeEnergyScreenFile(self, pComp, pfile):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyScreenFile(self.eapot, pComp.p, pStr(pfile))

    def setComputeEnergyLogFile(self, pComp, pfile):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyLogFile(self.eapot, pComp.p, pStr(pfile))

    def setComputeEnergyEcho(self, pComp, mode):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyEcho(self.eapot, pComp.p, pStr(mode))

    def setComputeEnergyEnergyAtom(self, pComp, atomflag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyEnergyAtom(self.eapot, pComp.p, atomflag)

    def setComputeEnergyVirial(self, pComp, atomflag, globalflag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyVirial(self.eapot, pComp.p, atomflag, globalflag)

    def setComputeEnergyRefFile(self, pComp, pfile):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyRefFile(self.eapot, pComp.p, pStr(pfile))

    def setComputeEnergyNoRelax(self, pComp):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyNoRelax(self.eapot, pComp.p)

    def setComputeEnergyRelaxAtom(self, pComp, flag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyRelaxAtom(self.eapot, pComp.p, Ints(flag))

    def setComputeEnergyRelaxBox(self, pComp, mode, sts):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyRelaxBox(self.eapot, pComp.p, pStr(mode), Dbls(sts))

    def setComputeEnergyReload(self, pComp, flag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyReload(self.eapot, pComp.p, flag)

    def setComputeEnergyUseMaxForce(self, pComp, flag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyUseMaxForce(self.eapot, pComp.p, flag)

    def setComputeEnergyRemapStyle(self, pComp, pCompRef, mode):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        if pCompRef.type != 'comp': raise(ValueError('param pCompRef is not a Compute'))
        self.lib.eapot_setComputeEnergyRemapStyle(self.eapot, pComp.p, pCompRef.p, pStr(mode))

    def setComputeEnergyRemapCustom(self, pComp, pCompRef, mode):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        if pCompRef.type != 'comp': raise(ValueError('param pCompRef is not a Compute'))
        self.lib.eapot_setComputeEnergyRemapCustom(self.eapot, pComp.p, pCompRef.p, Ints(mode))

    def setComputeEnergyTiltLimit(self, pComp, flag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeEnergyTiltLimit(self.eapot, pComp.p, flag)

    def setComputeElasticHalfLoad(self, pComp, halfFlag):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeElasticHalfLoad(self.eapot, pComp.p, halfFlag)

    def setComputeElasticMethod(self, pComp, method):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeElasticMethod(self.eapot, pComp.p, pStr(method))

    def setComputeElasticMinimize(self, pComp, etol, ftol, niter, nstep):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeElasticMinimize(self.eapot, pComp.p, etol, ftol, niter, nstep)

    def setComputeElasticZeroCut(self, pComp, cut):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeElasticZeroCut(self.eapot, pComp.p, cut)

    def setComputeElasticLoadDelta(self, pComp, delta):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeElasticLoadDelta(self.eapot, pComp.p, delta)

    def setComputeExternalTitle(self, pComp, title):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeExternalTitle(self.eapot, pComp.p, pStr(title))

    def setComputeExternalScript(self, pComp, script):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeExternalScript(self.eapot, pComp.p, pStr(script))

    def setComputeExternalCallback(self, pComp, callback, caller):
        if pComp.type != 'comp': raise(ValueError('param pComp is not a Compute'))
        self.lib.eapot_setComputeExternalCallback(self.eapot, pComp.p, callback, caller)

    #  Minimize styles
    def setMinDmax(self, dmax):
        self.lib.eapot_setMinDmax(self.eapot, dmax)

    def setMinDelta(self, delta):
        self.lib.eapot_setMinDelta(self.eapot, delta)

    def setParticleSwarmTakaParticles(self, n):
        self.lib.eapot_setParticleSwarmTakaParticles(self.eapot, n)

    def setSimulatedAnnealingAMode(self, mode):
        self.lib.eapot_setSimulatedAnnealingAMode(self.eapot, pStr(mode))

    def setDifferentialEvolutionGeneNum(self, n):
        self.lib.eapot_setDifferentialEvolutionGeneNum(self.eapot, n)

    def setDifferentialEvolutionInitRange(self, val):
        self.lib.eapot_setDifferentialEvolutionInitRange(self.eapot, val)

    def setDifferentialEvolutionMutRat(self, val):
        self.lib.eapot_setDifferentialEvolutionMutRat(self.eapot, val)

    def setDifferentialEvolutionCrossRat(self, val):
        self.lib.eapot_setDifferentialEvolutionCrossRat(self.eapot, val)

    def setLineSearchMethod(self, style):
        self.lib.eapot_setLineSearchMethod(self.eapot, pStr(style))