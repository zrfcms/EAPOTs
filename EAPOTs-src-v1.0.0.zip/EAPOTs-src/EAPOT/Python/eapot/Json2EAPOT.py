import os, sys, json

def ToPyFmt(line, tab):
    stripLines = [i.strip() for i in line.split('\n')]
    return tab + ('\n'+tab).join(stripLines) + '\n'

ElaIdx = []
for i in range(0, 6):
    for j in range(0, 6):
        ElaIdx.append((i, j, ".C[%d,%d]"%(i,j)))

ElaIdx += [ (6,0,".Bulk"),  (6,1,".Shear"),  (6,2,".Poisson"), 
            (6,3,".Youngx"), (6,4,".Youngy"), (6,5,".Youngz"),]


def getAtomNum(data:str) -> int:
    j = data.find('atoms')
    i = data[:j].rfind('\n')
    i = 0 if i < 0 else i
    svalue = data[i:j].strip()
    return int(svalue)

def isEla3Dof(w):
    key = (w[0][0], w[0][1], w[3][3])
    total = sum(list(map(sum, w))) - sum(key)
    if total > 1e-14: return False

    # Is3Dof : total number of no-zero key is zero
    return sum(list(map(lambda x: int(x<=0), key))) ==0

def isEla5Dof(w):   
    key = (w[0][0], w[0][1], w[0][2], w[2][2], w[3][3])
    total = sum(list(map(sum, w))) - sum(key)
    if total > 1e-14: return False

    # Is5Dof : total number of no-zero key is zero
    return sum(list(map(lambda x: int(x<=0), key))) ==0

def Vec2Mat6(v):
    return (v[0:6], v[6:12], v[12:18], v[18:24], v[24:30], v[30:36], v[36:42])

# ----------------- tarScript ---------------------

dbl = lambda v: ('%.15g'%v).strip()
def ID(id): return id.replace('.', '').replace('[', '').replace(']', '')

class CostKey:
    def __init__(self, w, t, v):
        self.weight = w
        self.target = t
        self.value  = v

def createTarScript(Tar, Oth):

    res, computeIds = '', []
    CostKeyList = []
    atomNum = {'':1e32, 'none':1e32}

    def addCostKey(w, t, v):
        if w > 0:
            CostKeyList.append(CostKey(w, t, v))
            return True
        return False

    for itar in Tar:
        ActiveEnergyGroup  = itar["ActiveEnergyGroup"]   
        ActiveForceGroup   = itar["ActiveForceGroup"]     
        ActiveLatticeGroup = itar["ActiveLatticeGroup"]   
        ActiveStressGroup  = itar["ActiveStressGroup"]    
    
        g, struct = itar["Global_Weight"], itar["Structure_Name"]
        id, refId = ID(struct), ID(itar["Energy_Reference"])
        computeIds.append(id)

        lmp  = itar["Structure_Information"]
        log  = itar["Structure_Atom_Configuration"]
        with open(struct+'.lammps', 'w') as w: w.write(lmp)
        with open(struct+'.log'   , 'w') as w: w.write(log)
        atomNum[id] = getAtomNum(lmp)

        # compute 
        res += '    \n'
        res += "    %s = eapot.addCompute('%s', 'energy', '%s.lammps')\n"%(id, id, struct)
        if ActiveForceGroup: res += "    eapot.setComputeEnergyRefFile(%s, '%s.log')\n"%(id, struct)
        
        relaxAtomX = itar["Relax_AtomX"]
        relaxAtomY = itar["Relax_AtomY"]
        relaxAtomZ = itar["Relax_AtomZ"]        
        refDrive   = itar["Ref_Drive"]
        RelaxMode  = itar["Box_Relax_Mode"]
        maxForce   = itar["Use_MaxForce"]

        RelaxMode  = RelaxMode if RelaxMode in ('iso', 'aniso', 'full') else 'none'
        relaxAtom  = relaxAtomX or relaxAtomY or relaxAtomZ
        relaxBox   = RelaxMode != 'none'        

        if not (relaxBox or relaxAtom): 
            res += "    eapot.setComputeEnergyNoRelax(%s)\n"%(id)
        else:             
            stress = ', '.join(map(dbl, itar["Stress_Global_Target"]))
            atomFlag = "[%d, %d, %d]"%(relaxAtomX, relaxAtomY, relaxAtomZ)            
            res += "    eapot.setComputeEnergyRelaxBox(%s, '%s', [%s])\n"%(id, RelaxMode, stress)
            res += "    eapot.setComputeEnergyRelaxAtom(%s, %s)\n"%(id, atomFlag)

        scale = itar["Energy_Scale_Method"]
        remapMethod = 'xxy' if scale == 'GSF-xy' else 'shape'
        if refDrive: res += "    eapot.setComputeEnergyRemapStyle(%s, %s, '%s')\n"%(id, refId, remapMethod)        
        if maxForce: res += "    eapot.setComputeEnergyUseMaxForce('%s', 1)\n"%(id)

        if ActiveLatticeGroup:
            t, w = itar["Domain_Target"], itar["Domain_Weight"]
            for i in range(6): addCostKey(g*w[i], t[i], '%s.lattice[%d]'%(id, i))
        
        t, w = itar["Energy_Target"], itar["Energy_Weight"]
        if ActiveEnergyGroup and w > 0.0:            
            num, nref = atomNum[id], atomNum[refId]
            rat = num/nref
            
            if scale == 'Ec':
                addCostKey(g*w, t, '%s.Ec'%(id))
            elif scale == 'E':
                addCostKey(g*w, t, '%s.energy'%(id))
            elif scale == 'E/atom':
                addCostKey(g*w, t, '-%s.Ec'%(id))
            elif scale == 'dE':
                addCostKey(g*w, t, '%s.energy-%s.energy*%.17g'%(id, refId, rat))
            elif scale == 'dE/atom':
                addCostKey(g*w, t, '-%s.Ec+%s.Ec'%(id, refId))

            elif scale == 'Es-xy':
                addCostKey(g*w, t, '8010/(%s.xx*%s.yy)*(%s.energy-%s.energy*%.17g)'%(id, id, id, refId, rat))
            elif scale == 'Es-xz':
                addCostKey(g*w, t, '8010/(%s.xx*%s.zz)*(%s.energy-%s.energy*%.17g)'%(id, id, id, refId, rat))
            elif scale == 'Es-yz':
                addCostKey(g*w, t, '8010/(%s.yy*%s.zz)*(%s.energy-%s.energy*%.17g)'%(id, id, id, refId, rat))

            elif scale == 'GSF-xy':
                addCostKey(g*w, t, '16020/(%s.xx*%s.yy)*(%s.energy-%s.energy*%.17g)'%(id, id, id, refId, rat))
            else:
                addCostKey(g*w, t, '%s.Ec'%(id))

        if ActiveStressGroup:
            t, w = itar["Stress_Global_Target"], itar["Stress_Global_Weight"]
            for i in range(6): addCostKey(g*w[i], t[i], '%s.stress[%d]'%(id, i))
            
        if ActiveForceGroup:
            addCostKey(g*itar["Force_Cost_Weight"], 0.0, "%s.forceCost"%id)
        
        if not itar["ActiveMoreGroup"]:      continue 
        if sum(itar["Elastic_Weight"]) == 0: continue

        elaId = id + 'Ela'
        computeIds.append(elaId)
        res += "    \n"
        res += "    %s = eapot.addCompute('%s', 'elastic', '%s')\n"%(elaId, elaId, id)
        res += "    eapot.setComputeElasticLoadDelta(%s, 1e-5)\n\n"%(elaId)

        t, w = Vec2Mat6(itar["Elastic_Target"]), Vec2Mat6(itar["Elastic_Weight"])

        if isEla3Dof(w):
            addCostKey(g*w[0][0], t[0][0], '%s.cubic[0]'%elaId)
            addCostKey(g*w[0][1], t[0][1], '%s.cubic[1]'%elaId)
            addCostKey(g*w[3][3], t[3][3], '%s.cubic[2]'%elaId)

        elif isEla5Dof(w):
            addCostKey(g*w[0][0], t[0][0], '%s.hex[0]'%elaId)
            addCostKey(g*w[0][1], t[0][1], '%s.hex[1]'%elaId)
            addCostKey(g*w[0][2], t[0][2], '%s.hex[2]'%elaId)
            addCostKey(g*w[2][2], t[2][2], '%s.hex[3]'%elaId)
            addCostKey(g*w[3][3], t[3][3], '%s.hex[4]'%elaId)
        else:  
            for iElaIdx in ElaIdx:
                i, j, suffix = iElaIdx[0], iElaIdx[1], iElaIdx[2]
                addCostKey(g*w[i][j], t[i][j], id+suffix)

    res += ToPyFmt(Oth["OthComEdit"], ' '*4) + '\n'
    res += "\n    cost = eapot.addCompute('cost', 'term', None)\n\n"
    res += "    sq2 = lambda w, t, v: w*(v/t-1)**2 if t else w*t**2\n"
    res += "    fmt = lambda u: '%9.3g '%u if abs(u) > 1e5 else '%5.4g '%u\n"

    res += "    def ParamLimitRatio(x, a, b, c): return c*(x<a)*(x/a-1)**2 + c*(b<x)*(x/b-1)**2\n"
    res += "    def ParamlimitAbslo(x, a, b, c): return c*(x<a)*(x - a)**2 + c*(b<x)*(x - b)**2\n"

    weight = [var.weight for var in CostKeyList]
    target = [var.target for var in CostKeyList]
    res += "    weight = [ %s ]\n"%(', '.join(map(dbl, weight)))
    res += "    target = [ %s ]\n"%(', '.join(map(dbl, target)))
    res += "    targetMsg = ''.join(map(fmt, target))\n\n"

    res += "    def computeCostScript(caller, np, p, nparam, style, param, res):\n"
    res += "        v = EAPOT.parseCompute(nparam, style, param)\n\n"

    for i, id in enumerate(computeIds):
        res += "        %-22s = v[%d]\n"%(id, i)

    res += "\n        val = [0.0]*%d\n"%(len(CostKeyList))
    res += "        total, info = 0.0, ''\n"
    for i, iKey in enumerate(CostKeyList):
        res += "        val[%d] = %s\n"%(i, iKey.value)

    res += ToPyFmt(Oth["OthCostEdit"], ' '*8) + '\n'
    res += "        res[0] = sum(map(sq2, weight, target, val)) + total\n"
    res += "        return EAPOT.packMsg(''.join(map(fmt, val)) + info)\n"

    res += "\n"
    res += "    computeCostAPI = eapot.CompCallbackType(computeCostScript)\n"
    res += "    eapot.setComputeExternalCallback(cost, computeCostAPI, None)\n"
    res += "    eapot.setComputeExternalTitle(cost, targetMsg)\n"
    
    return res


title = '''import os, sys
import traceback
eapot = None
def UserExceptHook(tp, val, tb):
    html = repr(tp) + "\\n" + repr(val) + "\\n"
    html += ''.join(traceback.format_tb(tb))

    print(html, file=sys.stderr)
    with open("EAPOT.log", 'a') as fError:
        print('Cannot execute Script file\\n', file=fError)
        print(html, file=fError)
sys.excepthook = UserExceptHook
try:    
'''

def convert(fin, fout):

    with open(fin, 'r') as r: data = json.load(r)

    res = title
    Fun, Run = data['FunPage'], data['RunPage']
    Min, Oth = data['MinPage'], data['OthPage']

    unParseKey = ["setPairEAMVotermRoseSampleRange", "Params", "pair_coeff"]
    funcType, FunExtra = Fun["FunInitTypeComb"], Fun["funcExtraParam"]

    # ----------------- globalScript ---------------------
    isfile = os.path.isfile
    abspath = os.path.abspath
    dirname = os.path.dirname    

    EAPOTProjPath  = dirname(dirname(Oth["OthEAPOTEdit"])).replace('\\', '/')
    LAMMPSProjPath = dirname(dirname(Oth["OthLAMMPSEdit"])).replace('\\', '/')

    if not isfile(Oth["OthEAPOTEdit"]):  EAPOTProjPath  =  abspath('../../').replace('\\', '/')
    if not isfile(Oth["OthLAMMPSEdit"]): LAMMPSProjPath =  abspath('../../../LAMMPS').replace('\\', '/')

    res += "    sys.path.append('%s/EACHK')\n"%EAPOTProjPath
    res += "    sys.path.append('%s/Python')\n"%EAPOTProjPath
    res += "    from eapot import pDumpCallbackParam\n\n"    
    res += "    from eapot import EAPOT, cast, pPairEAMParam\n"
    res += "    import EACHKInter\n"
    res += ToPyFmt(Oth["OthInitEdit"] + '\n', '')
    

    # ----------------- res ---------------------
    ele = Fun["FunOutEleEdit"]
    res += "    eles = ['%s',]\n"%(ele)
    res += "    eapot = EAPOT()\n"
    res += "    eapot.setElement(eles)\n\n"
    res += "    pair = eapot.addPair('%s')\n"%funcType

    # Normal  funcExtraParams
    for key in FunExtra:
        if key in unParseKey: continue
        res += "    eapot.%s(pair, %s)\n"%(key, FunExtra[key])

    if funcType in ("fs/ackland", "fs/finnis", "tb/rosato", "tb/li"):
        res += "    import numpy\n"
        res += "    exec(eapot.getPotScript(pair))\n"
        res += "    eapot.PairPotAPI = eapot.VoidCallbackType(PairPotFunc)\n"
        res += "    eapot.setPairPotCallback(pair, eapot.PairPotAPI, None)\n"
    
    # Special funcExtraParams
    RoseSampleKey = 'setPairEAMVotermRoseSampleRange'
    if funcType.startswith("eam/voter"):
        
        p = FunExtra[RoseSampleKey].replace(' ','').split(',')
        for i in range(0, len(p), 3):
            res += '    eapot.%s(pair, %s, %s, %s)\n'%(RoseSampleKey, p[i],p[i+1],p[i+2])
       
        res += "    eapot.setPairDumpImageYLimit(pair, 0, 0.0, 30.0)\n"
        res += "    eapot.setPairDumpImageLimitSampleValue(pair, 1, 3, 2.55)\n"
        res += "    eapot.setPairEAMDumpImageLimitRlo(pair, 1.0)\n"
        
    # pair_coeff for those EAM list based function type
    if "setPairEAMOutputMode" in FunExtra:
        key = FunExtra["setPairEAMOutputMode"]
        if   key == "'fs'":    res += "    eapot.inputPairEAMListFromFS(pair, None, eles)\n"
        elif key == "'alloy'": res += "    eapot.inputPairEAMListFromAlloy(pair, None, eles)\n"
    
    # custom code
    res += ToPyFmt(Oth["OthPairEdit"] + '\n', ' '*4)
    res += "    eapot.setPairFullParams(pair, [%s])\n"%(",".join(FunExtra['Params']))


    # ----------------- tarScript -----------------
    res += createTarScript(data['Targets'], Oth) + '\n'

    # ----------------- run script -----------------
    res += "    eapot.setLogFile('dump', 'dump.log')\n"
    res += "    eapot.setLogFile('thermo', 'thermo.log')\n"

    if funcType.startswith('fs') or funcType.startswith('tb'):     
        suffix, chkStyle = "eam", "eam/fs"
    elif funcType.startswith('eam'):
        suffix, chkStyle = "eam", "eam/alloy"
    elif funcType.startswith('sw'):
        suffix, chkStyle = "sw", "sw"
    elif funcType in ("bop/tersoff", "bop/brenner"):  
        suffix, chkStyle = "tersoff", "tersoff"
    elif funcType.startswith('meam'):
        suffix, chkStyle = "library", 'meam'

    # must add file dump
    res += "    file  = eapot.addDump(%s, 'file',  'file',  '%s.*.%s')\n"%(Run["RunFileEdit"], ele, suffix)
    if funcType.startswith('meam'):
        res += "    eapot.setDumpFileExtra(file, 1, ['%s.*.meam'])\n"%(ele)          

    # add image dump
    if Run["RunImageChk"] == 'true':
        res += "    image = eapot.addDump(%s, 'image', 'image', '%s.*.jpg')\n"%(Run["RunImageEdit"],ele)
        res += "    eapot.setDumpImageSize(image, %s, %s)\n\n"%(Run["RunImageWEdit"],Run["RunImageHEdit"])

    if Run["RunCheckChk"] == 'true':

        res += "    extra = eapot.addDump(%s, 'extra', 'external', '%s.log')\n"%(Run["RunCheckEdit"], ele)
        res += "    eapot.setDumpExternalFile(extra, file)\n"

        res += "    chkinter = EACHKInter.EACHKInter('%s', './chkdata/', eles, '%s')\n"%(LAMMPSProjPath, chkStyle)
        for ichk in Run["RunCheckComb"].split(' '):
            res += "    chkinter.add('%s', chkinter.ele)\n"%ichk
        res += ToPyFmt(Oth["OthCheckEdit"], '    ') + '\n'

        res += "    def DumpCallbackFunc(caller, ptr):\n"
        res += "        p = cast(ptr, pDumpCallbackParam)[0]\n"
        res += "        files = [p.files[i].decode() for i in range(p.nfile)]\n"
        res += "        msg = chkinter.run(files) if p.mode else chkinter.init(None)\n"
        res += "        return EAPOT.packMsg(msg)\n"

        res += "    DumpCallbackAPI = eapot.StrCallbackType(DumpCallbackFunc)\n"
        res += "    eapot.setDumpExternalCallback(extra, DumpCallbackAPI, None)\n\n"


    Keys = Run["RunTherStyleComb"].split(' ')
    res += "    eapot.setThermoStep(%s)\n"%Run["RunTherStepEdit"]
    res += "    eapot.setThermoKeys('custom', %d, ['%s'])\n"%(len(Keys), "', '".join(Keys))
    res += "    eapot.setThermoFormatStyle('line', '%s')\n"%Run["RunTherFormatEdit"]
    res += ToPyFmt( Oth["OthFiniEdit"], '    ') + '\n'

    for ialgo in Min:
        skipList = [           
            "MinAlgoTypeComb" ,"MinAlgoTypeShort",
            "MinSetTolEEdit", "MinSetToldEEdit",
            "MinSetTolIterEdit", "MinSetTolEvalEdit"
        ]
        res += "    eapot.setMinimizeStyle('%s')\n"%ialgo["MinAlgoTypeShort"]
        
        for key in ialgo:
            if key in skipList: continue
            if key == "seed" and int(ialgo[key]) <= 0: continue
            res += '    eapot.%s(%s)\n'%(key, ialgo[key])
        
        res += '    eapot.runMinimize(cost, %s, %s, %s, %s)\n'%(ialgo["MinSetTolEEdit"], 
        ialgo["MinSetToldEEdit"], ialgo["MinSetTolIterEdit"], ialgo["MinSetTolEvalEdit"])

    res += "\nexcept Exception: raise\n"

    with open(fout, "w") as w:
        w.write(res)
        
if __name__ == "__main__":
    sys.argv.append(r"D:\MD\EAPOTsUI\tasks\once\EAPOT.json")
    sys.argv.append('convert.py')
    convert(sys.argv[1], sys.argv[2])