#include "force.h"
#include "error.h"

#include "pair_eam_python.h"

using namespace EAPOT_NS;

#define NN 12

#define SBox 2
#define SEla 3

#define CBox 6
#define CEla 9

#define SCRIPT(...) sprintf(error->ErrCheckBuff, "    " __VA_ARGS__); pythonScript += error->ErrCheckBuff;

PairEAMAckland::PairEAMAckland(EAPOT* eapot)
	: PairEAMPython(eapot) {

	styles.push_back("eam/ackland");
	int ntypes = force->get_ntypes();

	int nemb = ntypes;
	int nrho = ntypes;
	int nphi = ntypes * (ntypes + 1) / 2;

	python_fsize = nemb + nrho + 4 * nphi;
	python_csize = 3 * nphi;

	pythonScript = 
		"def pairPhi(r, B, c0, c1, c2, a, a0, c):\n"
		"    return (c - r)**2*(c0 + c1*r + c2*r**2) * (r < c) + B*(a0 - r)**3 * numpy.exp(-a * r) * (r < a0)\n"

		"def PairPotFunc(caller, val):\n"
		"    p, rhot, r, emb, rho, phi = cast(val, pPairEAMParam)[0].parse()\n";

	int fidx = 0, cidx = python_fsize;
	for (int i = 0; i < ntypes; i++) {
		SCRIPT("emb[%d,:] = -p[%d] * numpy.sqrt(rhot)\n", i, fidx);
		fidx++;
	}
	for (int i = 0; i < ntypes; i++) {
		SCRIPT("rho[%d,:] = (r - p[%d])**2 * (r < p[%d])\n", i, fidx, fidx);
		fidx++;
	}
	int iphi = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j <= i; j++) {

			SCRIPT("phi[%d,:] = eapot.pairPhi(r, p[%d], p[%d], p[%d], p[%d], p[%d], p[%d], p[%d])\n",
				iphi++, fidx, fidx + 1, fidx + 2, fidx + 3, cidx, cidx + 1, cidx + 2);

			fidx += 4;
			cidx += 3;
		}
	}
	pythonScript += "eapot.pairPhi = pairPhi\n";
	pythonScript += "eapot.PairPotFunc = PairPotFunc\n";
};



PairFSAckland::PairFSAckland(EAPOT* eapot)
	: PairEAMPython(eapot) {

	styles.push_back("fs/ackland");
	int ntypes = force->get_ntypes();

	int nemb = ntypes;
	int nrho = ntypes * ntypes;
	int nphi = ntypes * (ntypes + 1) / 2;

	python_fsize = nemb + nrho + 4 * nphi;
	python_csize = 3 * nphi;

	pythonScript = 
		"def pairPhi(r, B, c0, c1, c2, a, a0, c):\n"
		"    return (c - r)**2*(c0 + c1*r + c2*r**2) * (r < c) + B*(a0 - r)**3 * numpy.exp(-a * r) * (r < a0)\n"

		"def PairPotFunc(caller, val):\n"
		"    p, rhot, r, emb, rho, phi = cast(val, pPairEAMParam)[0].parse()\n";

	int fidx = 0, cidx = python_fsize;
	for (int i = 0; i < ntypes; i++) {
		SCRIPT("emb[%d,:] = -p[%d] * numpy.sqrt(rhot)\n", i, fidx);
		fidx++;
	}

	int irho = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j < ntypes; j++) {
			SCRIPT("rho[%d,:] = (r - p[%d])**2 * (r < p[%d])\n", irho++, fidx, fidx);
			fidx++;
		}
	}

	int iphi = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j <= i; j++) {

			SCRIPT("phi[%d,:] = eapot.pairPhi(r, p[%d], p[%d], p[%d], p[%d], p[%d], p[%d], p[%d])\n",
				iphi++, fidx, fidx + 1, fidx + 2, fidx + 3, cidx, cidx + 1, cidx + 2);

			fidx += 4;
			cidx += 3;
		}
	}
	pythonScript += "eapot.pairPhi = pairPhi\n";
	pythonScript += "eapot.PairPotFunc = PairPotFunc\n";
};




PairFSFinnis::PairFSFinnis(EAPOT* eapot)
	: PairEAMPython(eapot) {

	styles.push_back("fs/finnis");
	int ntypes = force->get_ntypes();

	int nemb = ntypes;
	int nrho = ntypes * ntypes;
	int nphi = ntypes * (ntypes + 1) / 2;

	python_fsize = nemb + nrho + 3 * nphi;
	python_csize = 1 * nphi;

	pythonScript = 
		"def pairPhi(r, c0, c1, c2, c):\n"
		"    return (c - r)**2*(c0 + c1*r + c2*r**2) * (r < c)\n"
		"def PairPotFunc(caller, val):\n"
		"    p, rhot, r, emb, rho, phi = cast(val, pPairEAMParam)[0].parse()\n";

	int fidx = 0, cidx = python_fsize;
	for (int i = 0; i < ntypes; i++) {
		SCRIPT("emb[%d,:] = -p[%d] * numpy.sqrt(rhot)\n", i, fidx);
		fidx++;
	}

	int irho = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j < ntypes; j++) {
			SCRIPT("rho[%d,:] = (r - p[%d])**2 * (r < p[%d])\n", irho++, fidx, fidx);
			fidx++;
		}
	}

	int iphi = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j <= i; j++) {

			SCRIPT("phi[%d,:] = eapot.pairPhi(r, p[%d], p[%d], p[%d], p[%d])\n",
				iphi++, fidx, fidx + 1, fidx + 2, cidx);

			fidx += 3;
			cidx += 1;
		}
	}
	pythonScript += "eapot.pairPhi = pairPhi\n";
	pythonScript += "eapot.PairPotFunc = PairPotFunc\n";
};

void PairFSFinnis::extra_check(int type) {

	if (type == 0) {
		addMDComputeBcc();
		runMDCompute(-1, RunDump | RunEcho, 10, NbBccCost, BccChk, "nms", "dump.*.eam");

		double fChk[NN], fRef[NN] = {
			-2.0106370000000000, -2.4625173539801701, -2.8434701144091528, -3.1790962339039850,
			-3.4825254395778646, -3.7615573915854985, -4.0212740000000000, -4.2652051716137285,
			-4.4959210100762448, -4.7153617360420510, -4.9250347079603403, -5.1261386488758278,
		};
		double rChk[NN], rRef[NN] = {
			4.8082271162889993, 3.7743436162889998, 2.8654601162889999, 2.0815766162889999,
			1.4226931162890000, 0.88880961628899979,0.47992611628900050,0.19604261628900030,
			0.037159116289000121,0.00000000000000000,0.00000000000000000,0.00000000000000000,
		};
		double pChk[NN], pRef[NN] = {
			 2.4325977714999660, 2.1410148429687266, 1.6503633359999950, 1.1041313099687486,
			 0.60852835550000295, 0.23248559446876405, 0.0076556800000161570, -0.071587203531245966,
			-0.048147340499995590, -0.0022074840312245694, 0.00000000000000000, 0.00000000000000000,
		};
		chkListFunc(NN, 1.0, 0.5, NN, 1.5, 0.25, fChk, rChk, pChk, 0);

		// data from LAMMPS
		double BoxChk[SBox], BoxRef[SBox] = {
			3.0398998666989874, 5.309999640683079
		}, ElaChk[SEla], ElaRef[SEla] = {
			227.91681384065, 118.70876729617747, 42.60314853673679
		};
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		const char* name = "FSFinnis/s";
		error->add_chklog(0, name, "");
		error->check(FLERR, NN, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 0.0, 0.0);

		error->add_chklog(0, name, "");
		error->check(FLERR, SBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 3.2541090782513647e-09, 3.2541092455166151e-09);
		error->check(FLERR, SEla, ElaChk, ElaRef, 1, name, "Ela", 2e-6, 2e-6, 9.1222758579069513e-07, 2.2512669618276006e-06);
	}
	else {
		addMDComputeAlloy();
		runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");

		const char* name = "FSFinnis/c";
		error->add_chklog(0, name, "");

		double fChk[NN * 2], fRef[NN * 2] = {
			-2.0106370000000000, -2.4625173539801701, -2.8434701144091528, -3.1790962339039850,
			-3.4825254395778646, -3.7615573915854985, -4.0212740000000000, -4.2652051716137285,
			-4.4959210100762448, -4.7153617360420510, -4.9250347079603403, -5.1261386488758278,

			-3.0137890000000001, -3.6911226212063855, -4.2621412779308478, -4.7652188135806002,
			-5.2200356712921989, -5.6382829370140248, -6.0275780000000001, -6.3932119168962709,
			-6.7390370738411143, -7.0679617111912476, -7.3822452424127709, -7.6836844604256420,
		};
		double rChk[NN * 4], rRef[NN * 4] = {
			4.8082271162889993, 3.7743436162889998, 2.8654601162889999, 2.0815766162889999,
			1.4226931162890000, 0.88880961628899979,0.47992611628900050,0.19604261628900030,
			0.037159116289000121,0.00000000000000000,0.00000000000000000,0.00000000000000000,

			5.3086947876602508, 4.2191645376602489, 3.2546342876602496, 2.4151040376602495,
			1.7005737876602496, 1.1110435376602497, 0.64651328766025051, 0.30698303766025031,
			0.092452787660250141, 0.0029225376602499712, 0.00000000000000000, 0.00000000000000000,

			5.3086947876602508, 4.2191645376602489, 3.2546342876602496, 2.4151040376602495,
			1.7005737876602496, 1.1110435376602497, 0.64651328766025051, 0.30698303766025031,
			0.092452787660250141, 0.0029225376602499712, 0.00000000000000000, 0.00000000000000000,

			 5.8339349453159981,      4.6887579453159995,    3.6685809453159992,    2.7734039453159993,
			 2.0032269453159994,      1.3580499453159995,   0.83787294531600043,   0.44269594531600032,
			0.17251894531600015,    0.027341945315999889,   0.00000000000000000,   0.00000000000000000,
		};
		double pChk[NN * 3], pRef[NN * 3] = {
			2.4325977714999660, 2.1410148429687266, 1.6503633359999950, 1.1041313099687486,
			0.60852835550000295, 0.23248559446876405, 0.0076556800000161570, -0.071587203531245966,
			-0.048147340499995590, -0.0022074840312245694, 0.00000000000000000, 0.00000000000000000,

			2.6714309374999563, 2.5994301996093436, 2.1820223999999908, 1.6033494230468754,
			1.0070525250000013, 0.49627233398438525, 0.13364885000001442, -0.058678555078121232,
			-0.099071137499995798, -0.046390781640600003, 1.0958079417327131e-08, 0.00000000000000000,

			2.8796196194999482, 3.1061328829999595, 2.8151366319999882, 2.2340043033749986,
			1.5463865464999991, 0.89221122325000679, 0.36768340800001120, 0.025285387625003503,
			-0.12622333849999640, -0.12180605849997581, -0.040148847999966077, 0.00000000000000000,
		};

		chkListFunc(NN, 1.0, 0.5, NN, 1.5, 0.25, fChk, rChk, pChk, 1);
		error->check(FLERR, NN * 2, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN * 4, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN * 3, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 0.0, 0.0);

		error->add_chklog(0, name, "");

		// data from LAMMPS
		double BoxChk[CBox], BoxRef[CBox] = {
			4.106448057672889, 6.822466057397638,
			3.960923944703501, 5.769219760175219,
			3.173850379121439, 6.460767346803869,
		};

		double ElaChk[CEla], ElaRef[CEla] = {
			-33.833194033726016, 129.16592894509373, 43.06416220025712,
			  152.7275011881909, 121.27368594002907, 47.609502267698616,
			  225.2929834414373, 124.9014640003421,  34.20865421026177,
		};

		evalCompute(BoxChk, ElaChk);

		error->check(FLERR, CBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 2.7064223452651559e-09, 2.760687301486388e-09);
		error->check(FLERR, CEla, ElaChk, ElaRef, 1, name, "Ela", 2e-5, 1e-5, 4.850910839381095e-06, 1.8394091495498756e-05);
	}
}


PairTBRosato::PairTBRosato(EAPOT* eapot)
	: PairEAMPython(eapot) {

	styles.push_back("tb/rosato");
	int ntypes = force->get_ntypes();

	int nemb = ntypes;
	int nrho = ntypes * ntypes;
	int nphi = ntypes * (ntypes + 1) / 2;

	python_fsize = nemb * 0 + nrho * 2 + nphi * 2;
	python_csize = nemb * 0 + nrho * 1 + nphi * 1;

	pythonScript = 
		"def pairRho(r, z, q, r0):\n"
		"    return z*z * numpy.exp(-2*q * (r/r0-1))\n"

		"def pairPhi(r, A, p, r0):\n"
		"    return   A * numpy.exp(  -p * (r/r0-1))\n"

		"def PairPotFunc(caller, val):\n"
		"    p, rhot, r, emb, rho, phi = cast(val, pPairEAMParam)[0].parse()\n";
		
	int fidx = 0, cidx = python_fsize;

	for (int i = 0; i < ntypes; i++) {
		SCRIPT("emb[%d,:] = -numpy.sqrt(rhot)\n", i);
	}

	int irho = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j < ntypes; j++) {
			SCRIPT("rho[%d,:] = eapot.pairRho(r, p[%d], p[%d], p[%d])\n", irho++, fidx + 0, fidx + 1, cidx++);
			fidx += 2;
		}
	}

	int iphi = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j <= i; j++) {
			SCRIPT("phi[%d,:] = eapot.pairPhi(r, p[%d], p[%d], p[%d])\n", iphi++, fidx + 0, fidx + 1, cidx++);
			fidx += 2;
		}
	}
	pythonScript += "eapot.pairRho = pairRho\n";
	pythonScript += "eapot.pairPhi = pairPhi\n";
	pythonScript += "eapot.PairPotFunc = PairPotFunc\n";
};

void PairTBRosato::extra_check(int type) {
	const char* name;

	if (type == 0) {
		name = "TBRosato/s";
		addMDComputeFcc();
		runMDCompute(-1, RunDump | RunEcho, 10, CuFccCost, FccChk, "nms", "dump.*.eam");

		double fChk[NN], fRef[NN] = {
			-1.0000000000000000, -1.2247448713915889, -1.4142135623730951, -1.5811388300841898,
			-1.7320508075688772, -1.8708286933869707, -2.0000000000000000, -2.1213203435596424,
			-2.2360679774997898, -2.3452078799117149, -2.4494897427831779, -2.5495097567963922,
		};
		double rChk[NN], rRef[NN] = {
			12.314605569383234, 8.1869569741198500, 5.4428267408528637, 3.6184827921524514,
			2.4056282407126170, 1.5993021287997036, 1.0632429632709037, 0.70686181090333944,
			0.46993362474413003, 0.31241978030041251, 0.20770192636478874, 0.13808373520449083,
		};
		double pChk[NN], pRef[NN] = {
			13.575788905010741, 5.0845631975973040, 1.9043300607629101, 0.71323196101563802,
			0.26712797360823543, 0.10004789210866276, 0.037471106377210579, 0.014034116896762384,
			0.0052562215561403657, 0.0019686215563486866, 0.00073731116367790439, 0.00027614639813930018,
		};

		// data from LAMMPS
		double BoxChk[SBox], BoxRef[SBox] = { 3.6101244831035326, 4.360978164540603, };
		double ElaChk[SEla], ElaRef[SEla] = { 183.34667648795664, 132.63913603876392, 85.89250250795142 };

		chkListFunc(NN, 1.0, 0.5, NN, 1.5, 0.25, fChk, rChk, pChk, 0);
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->add_chklog(0, name, "");		
		error->check(FLERR, NN, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 0.0, 0.0);

		error->add_chklog(0, name, "");		
		error->check(FLERR, SBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 3.2050412298406898e-10, 3.2051797220097877e-10);
		error->check(FLERR, SEla, ElaChk, ElaRef, 1, name, "Ela", 4e-6, 3e-6, 3.3843941665510029e-06, 6.8827692606039864e-06);
	}
	else if (type == 1) {
		name = "TBRosato/c";
		addMDComputeAlloy();
		runMDCompute(-1, RunDump | RunEcho, 10, CuNiAlloyCost, AlloyChk, "nms", "dump.*.eam");

		double fChk[NN * 2], fRef[NN * 2] = {
			-1.0000000000000000, -1.2247448713915889, -1.4142135623730951, -1.5811388300841898,
			-1.7320508075688772, -1.8708286933869707, -2.0000000000000000, -2.1213203435596424,
			-2.2360679774997898, -2.3452078799117149, -2.4494897427831779, -2.5495097567963922,
			-1.0000000000000000, -1.2247448713915889, -1.4142135623730951, -1.5811388300841898,
			-1.7320508075688772, -1.8708286933869707, -2.0000000000000000, -2.1213203435596424,
			-2.2360679774997898, -2.3452078799117149, -2.4494897427831779, -2.5495097567963922,
		};
		double rChk[NN * 4], rRef[NN * 4] = {
			12.314605569383234, 8.1869569741202088, 5.4428267408530990, 3.6184827921524514,
			2.4056282407127232, 1.5993021287997728, 1.0632429632709037, 0.70686181090337052,
			0.46993362474415024, 0.31241978030041251, 0.20770192636479792, 0.13808373520449671,
			7.7624637190611567, 5.4707843764602426, 3.8556678365179975, 2.7173753236420684,
			1.9151360964245046, 1.3497385642379014, 0.95126095487012829, 0.67042420527661684,
			0.47249770183425105, 0.33300420313216195, 0.23469278024675438, 0.16540542306035685,
			4.9425111232685177, 3.7012870879381081, 2.7717744615368463, 2.0756924505166614,
			1.5544190946700969, 1.1640542996982033, 0.87172270161379528, 0.65280500119784457,
			0.48886459971731094, 0.36609492332050769, 0.27415667438089653, 0.20530708654976632,
			3.1805162700558727, 2.5370396401621678, 2.0237501050862816, 1.6143084337361631,
			1.2877043033534930, 1.0271781638638928, 0.81936122879381579, 0.65358946175910493,
			0.52135635603775110, 0.41587642684659082, 0.33173701711649078, 0.26462054932953061,
		};
		double pChk[NN * 3], pRef[NN * 3] = {
			13.575788905010739, 5.0845631976004517, 1.9043300607642610, 0.71323196101563802,
			0.26712797360847074, 0.10004789210875362, 0.037471106377210572, 0.014034116896776715,
			0.0052562215561457338, 0.0019686215563486861, 0.00073731116367872264, 0.00027614639813960213,
			31.622343589256168, 8.7080002764822080, 2.3979648630814885, 0.66033937781501528,
			0.18184090209356360, 0.050074423523972421, 0.013789240277601419, 0.0037972109123042964,
			0.0010456566440412054, 0.00028794761272996647, 7.9293550276741262e-05, 2.1835454914506049e-05,
			55.868550731648476, 11.102020273793356, 2.2061580718691101, 0.43840069807740667,
			0.087117588954023134, 0.017311729517050373, 0.0034401316940888970, 0.00068361200195968133,
			0.00013584519744665763, 2.6994724517033966e-05, 5.3643055878191415e-06, 1.0659777032184046e-06,
		};

		// data from LAMMPS
		double BoxChk[CBox], BoxRef[CBox] = { 
			3.581871931896561,  4.570870186896199,
			3.5851590246545433, 4.3932978043091815,
			2.8969603522580165, 4.3300703028145895,};
		double ElaChk[CEla], ElaRef[CEla] = { 
			212.57747140759852, 124.67936050183599, 124.67937337589338,
			185.87883330417307, 113.60732824030114, 113.60733282302253,
			129.17667679589474, 152.2741988513987, 136.61089943096613, };

		chkListFunc(NN, 1.0, 0.5, NN, 1.5, 0.25, fChk, rChk, pChk, 1);
		evalCompute(BoxChk, ElaChk, 3, 3, 3);

		error->add_chklog(0, name, "");
		error->check(FLERR, NN * 2, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN * 4, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN * 3, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 0.0, 0.0);

		error->add_chklog(0, name, "");
		error->check(FLERR, SBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 1.1911063482005702e-08, 1.1911071060203496e-08);
		error->check(FLERR, SEla, ElaChk, ElaRef, 1, name, "Ela", 4e-6, 3e-6, 9.2731372061520258e-07, 1.7919949025582067e-06);
	}
}




PairTBLi::PairTBLi(EAPOT* eapot)
	: PairEAMPython(eapot) {

	styles.push_back("tb/li");
	int ntypes = force->get_ntypes();

	int nemb = ntypes;
	int nrho = ntypes * ntypes;
	int nphi = ntypes * (ntypes + 1) / 2;

	python_fsize = nemb * 0 + nrho * 2 + nphi * 5;
	python_csize = nemb * 0 + nrho * 1 + nphi * 1 + 4;

	pythonScript = 
		"def pairRho(r, B, b, r0, n, rcr):\n"
		"    rs = r / r0\n"
		"    return B * (rs - rcr/r0)**n * numpy.exp(-b * (rs-1)) * (r<rcr)\n"

		"def pairPhi(r, A, c1, c2, c3, c4, r0, m, rcp):\n"
		"    rs = r / r0\n"
		"    return A * (rs - rcp/r0)**m * (1 + c1*rs + c2*rs**2 + c3*rs**3 + c4*rs**4) * (r<rcp)\n"

		"def PairPotFunc(caller, val):\n"
		"    p, rhot, r, emb, rho, phi = cast(val, pPairEAMParam)[0].parse()\n";

	int fidx = 0, cidx = python_fsize;

	SCRIPT("n, m, rcr, rcp = p[-4:]\n");

	for (int i = 0; i < ntypes; i++) {
		SCRIPT("emb[%d,:] = -numpy.sqrt(rhot)\n", i);
	}

	int irho = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j < ntypes; j++) {
			SCRIPT("rho[%d,:] = eapot.pairRho(r, p[%d], p[%d], p[%d], n, rcr)\n",
				irho++,	fidx + 0, fidx + 1, cidx++);
			fidx += 2;
		}
	}

	int iphi = 0;
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j <= i; j++) {
			SCRIPT("phi[%d,:] = eapot.pairPhi(r, p[%d], p[%d], p[%d], p[%d], p[%d], p[%d], m, rcp)\n", 
				iphi++, fidx + 0, fidx + 1, fidx + 2, fidx + 3, fidx + 4, cidx++);
			fidx += 5;
		}
	}
	pythonScript += "eapot.pairRho = pairRho\n";
	pythonScript += "eapot.pairPhi = pairPhi\n";
	pythonScript += "eapot.PairPotFunc = PairPotFunc\n";
};

void PairTBLi::extra_check(int type) {
	const char* name;

	if (type == 0) {
		name = "TBRosato/s";
		addMDComputeBcc();
		runMDCompute(-1, RunDump | RunEcho, 10, NbBccCost, BccChk, "nms", "dump.*.eam");

		double fChk[NN], fRef[NN] = {
			-1.0000000000000000, -1.2247448713915889, -1.4142135623730951, -1.5811388300841898,
			-1.7320508075688772, -1.8708286933869707, -2.0000000000000000, -2.1213203435596424,
			-2.2360679774997898, -2.3452078799117149, -2.4494897427831779, -2.5495097567963922,
		};
		double rChk[NN], rRef[NN] = {
			128.6380035340211, 82.616856988939844, 52.253197246009378, 32.491819600529027,
			19.824304317201577, 11.840581547727913, 6.9038134847117503, 3.9163502218288566,
			2.152559016940788, 1.1404481350412139, 0.57864775756874665, 0.27881519707566726,
		};
		double pChk[NN], pRef[NN] = {
			93.249933596986949, 36.960696565426943, 13.548339597961169, 4.8551049741340533,
			1.9065701113983722, 0.83894900848230847, 0.31224181088143471, 0.011002839698159106,
			-0.10617076530772049, -0.087995827431104998, -0.022939568494379049, 0.016361882913019765,
		};

		// data from LAMMPS
		double BoxChk[SBox], BoxRef[SBox] = { 3.300483610923052, 7.592732152632736 };
		double ElaChk[SEla], ElaRef[SEla] = { 247.86661273280723, 135.2095308446805, 28.96647561680528 };

		chkListFunc(NN, 1.0, 0.5, NN, 1.5, 0.25, fChk, rChk, pChk, 0);
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->add_chklog(0, name, "");
		error->check(FLERR, NN, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 0.0, 0.0);

		error->add_chklog(0, name, "");
		error->check(FLERR, SBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 9.2453656640415118e-10, 9.2453703431393745e-10);
		error->check(FLERR, SEla, ElaChk, ElaRef, 1, name, "Ela", 4e-6, 3e-6, 1.4149544989764605e-06, 2.2296581605510105e-06);
	}
	else if (type == 1) {
		name = "TBRosato/c";
		addMDComputeAlloy();
		runMDCompute(-1, RunDump | RunEcho, 10, CuNiAlloyCost, AlloyChk, "nms", "dump.*.eam");

		double fChk[NN * 2], fRef[NN * 2] = {
			-1.0000000000000000, -1.2247448713915889, -1.4142135623730951, -1.5811388300841898,
			-1.7320508075688772, -1.8708286933869707, -2.0000000000000000, -2.1213203435596424,
			-2.2360679774997898, -2.3452078799117149, -2.4494897427831779, -2.5495097567963922,
			-1.0000000000000000, -1.2247448713915889, -1.4142135623730951, -1.5811388300841898,
			-1.7320508075688772, -1.8708286933869707, -2.0000000000000000, -2.1213203435596424,
			-2.2360679774997898, -2.3452078799117149, -2.4494897427831779, -2.5495097567963922,
		};
		double rChk[NN * 4], rRef[NN * 4] = {
			23.129585932468892, 14.700467502068873, 9.2010895354022271, 5.6619278594346216,
			3.4186305125273804, 2.0206502661357897, 1.1659262480334087, 0.65452684267777794,
			0.35601223043944835, 0.18665915712347969, 0.093724243992455686, 0.044690789167183831,
			
			68.625294621204148, 43.579591004301101, 27.253789697070633, 16.756666066369675,
			10.109067298407396, 5.9701564955187516, 3.4419240458681419, 1.9306044580678496,
			1.0492196136161558, 0.54965024101843007, 0.27575583324514363, 0.13137914332351397,
			
			126.00666197141403, 79.947852316987905, 49.953384506897919, 30.685980138035411,
			18.496000947463386, 10.913569871187326, 6.2863240836223895, 3.5229230382652243,
			1.9128927363457624, 1.0012096040226015, 0.50185431066139852, 0.2388876746310219,
			
			198.4280291828976, 125.77897101504281, 78.515947919033692, 48.186422399989418,
			29.017116046733175, 17.10546815312264, 9.8436603939395937, 5.5113086681781258,
			2.989743436919845, 1.5633637364802684, 0.78289660500680436, 0.37231644379931084,
		};
		double pChk[NN * 3], pRef[NN * 3] = {
			54.806609464024945, 21.45998332605803, 7.7243480697159814, 2.6866273337326168,
			1.0048919437014403, 0.40892563789202269, 0.12522543228577931, -0.025221213108398088,
			-0.069889301395409067, -0.043755190619361936, -0.0016264180945095325, 0.017183558343230224,

			92.245893368864031, 34.884972047440712, 12.290276784495513, 4.407820759711532,
			1.8179579835064417, 0.78429608866364464, 0.19761696273351528, -0.11716761582991041,
			-0.1801292816804741, -0.08774037680793674, 0.020038608497870793, 0.056504185029811083,

			73.461960699147738, 26.262895827387794, 8.8611521123645076, 3.1995674692096543,
			1.3371697271989502, 0.46678479441000836, -0.054137735147101587, -0.25381482275536144,
			-0.17494031274832986, 0.017509468316035719, 0.14592870918370304, 0.14057662935394319,
		};

		// data from LAMMPS
		double BoxChk[CBox], BoxRef[CBox] = {
			4.163094782027111, 8.7379290427402230,
			4.403964086507844, 5.0288210908182265,
			3.346700029917610, 6.8133191140416285,
		};
		double ElaChk[CEla], ElaRef[CEla] = {
			-98.85341407802865, 142.69299995863588, 30.024304031824045,
			91.668652693957980, 89.040380714247960, 33.171327638581570,
			292.51850681456244, 173.31236603128530, 82.283029740260570, };

		chkListFunc(NN, 1.0, 0.5, NN, 1.5, 0.25, fChk, rChk, pChk, 1);
		evalCompute(BoxChk, ElaChk, 3, 3, 3);

		error->add_chklog(0, name, "");
		error->check(FLERR, NN * 2, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN * 4, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
		error->check(FLERR, NN * 3, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 0.0, 0.0);

		error->add_chklog(0, name, "");
		error->check(FLERR, SBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 1.1920229541861115e-08, 1.1920230355031756e-08);
		error->check(FLERR, SEla, ElaChk, ElaRef, 1, name, "Ela", 5e-6, 3e-6, 4.0175835743354236e-06, 4.8842001707653283e-06);
	}
}