#include "pair_eam_cross_morse.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;

PairEAMCrossMorse::PairEAMCrossMorse(EAPOT* eapot)
	: PairEAMCross(eapot) {
	styles.push_back("eam/cross/morse");
	NN = 20;

	cross_fsize = 4;
	cross_csize = 0;

	DM = aM = RM = rc = 0;
	phicr = phidr = rcn = 0;
};


double PairEAMCrossMorse::cphi(double r) {

	if (r >= rc || r >= cutmax) return 0;
	return smooth(r, phic(r), phicr, phidr);
}

void PairEAMCrossMorse::setFreeParamsStyle()
{
	int idx = 0;
	DM = cross_fvec[idx++];
	aM = cross_fvec[idx++];
	RM = cross_fvec[idx++];
	rc = cross_fvec[idx++];

	rcn = rc / NN;

	phicr = phic(rc);
	phidr = phid(rc);

	PairEAM::setFreeParamsStyle();
};

void PairEAMCrossMorse::extra_check(int) {

	const char* name = "CrossMorse";
	error->add_chklog(0, name, "");

	double BoxChk[6], BoxRef[6] = {
		3.469178615715263, 4.6011691005174225,
		3.5148151078569247, 4.1263073676164685,
		2.6906041753905807, 4.671099243059139
	};

	double ElaChk[9], ElaRef[9] = {
		216.96583843300508, 147.24147567249835, 98.48873274467807,
		237.22975876670372, 180.57747781635624, 83.01981767248229,
		250.82312796737946, 131.8443688846642, 29.864569493311183,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-9, 5e-10, 1.3092553556868159e-09, 2.2868601394747386e-09);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 6e-6, 3e-6, 5.3482910418190759e-06, 1.8117781521197434e-05);

#define N 9

	double x, phiEval[N], phiRef[N] = {
		29.472205807205018, 4.0970700830935325, 0.15328368978698328,
		-0.23484045473147341, -0.15573133196022051, -0.075192797884111484,
		-0.031659810521007935, -0.011214080189792098, -0.0022867631341735774,
	};

	for (int i = 0; i < N; i++) {
		x = 0.1281429334268537 * 5 * (i + 1.0);
		phiEval[i] = phi(1, 2, x);
	}

	error->check(FLERR, N, phiEval, phiRef, 1, name, "phi", 1e-14, 5e-15, 0, 0);

#undef N
}
