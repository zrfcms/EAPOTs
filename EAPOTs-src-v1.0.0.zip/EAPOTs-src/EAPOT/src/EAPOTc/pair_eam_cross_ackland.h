#ifdef PAIR_CLASS
PairStyle(eam/cross/ackland, PairEAMCrossAckland)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_ACKLAND_H
#define EAPOT_PAIR_EAM_CROSS_ACKLAND_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossAckland : virtual public PairEAMCross
	{
	public:
		PairEAMCrossAckland(EAPOT *eapot);
		~PairEAMCrossAckland(){};

		double cphi1(double r);
		double cphi2(double r);
		double cphi(double r);

		void setFullParamsStyle();
		void setFreeParamsStyle();

	private:

		double c, c0, c1, c2, B, a, a0;

		double a2;

	private:
		void extra_check(int);
		void partial_check();
	};

}

#endif
#endif
#endif