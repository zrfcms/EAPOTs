#ifdef PAIR_CLASS
PairStyle(eam/cross/zhouPdAgH, PairEAMCrossZhouPdAgH)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_ZHOUPDAGH_H
#define EAPOT_PAIR_EAM_CROSS_ZHOUPDAGH_H

#include "pair_eam_cross_hijazi.h"

namespace EAPOT_NS {

	class PairEAMCrossZhouPdAgH : public PairEAMCrossHijazi
	{
	public:
		PairEAMCrossZhouPdAgH(EAPOT *eapot);
		~PairEAMCrossZhouPdAgH(){};

		virtual double cphi2(double r);

		virtual double cphi(double r);

		virtual void setFullParamsStyle();
		//virtual void alter(double *arg);

	private:

		double rc, rs;
		double mrs3, mrs2;
		double rc1, rc2;

	private:
		virtual void extra_check(int);
		virtual void partial_check();
	};

}

#endif
#endif
#endif