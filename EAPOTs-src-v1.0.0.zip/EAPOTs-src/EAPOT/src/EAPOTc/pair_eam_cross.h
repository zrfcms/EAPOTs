#ifdef PAIR_CLASS
PairStyle(eam/cross, PairEAMCross)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_H
#define EAPOT_PAIR_EAM_CROSS_H

#include "pair_eam_list.h"

namespace EAPOT_NS {

	class PairEAMCross : public PairEAMList
	{
	public:

		PairEAMCross(EAPOT *eapot);
		~PairEAMCross();

		int cross_fsize;			// # of freedom  variable for differnet function form
		int cross_csize;			// # of constant variable for differnet function form

		double *cross_fvec;			// offset position in memory for freedom  variable array
		double *cross_cvec;			// offset position in memory for constant variable array

		virtual int getPyParamNum();
		virtual void fvec_allocate();

		virtual double cphi(double r);
		virtual double core_phi(int itype, int jtype, double r);
		
		virtual void extra_check(int) {};;
		virtual void partial_check() {};
		virtual void testrun(int) {};
	};

}

#endif
#endif
#endif