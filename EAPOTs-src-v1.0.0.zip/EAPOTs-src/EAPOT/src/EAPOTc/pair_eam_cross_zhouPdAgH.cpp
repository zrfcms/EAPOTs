#include "pair_eam_cross_zhouPdAgH.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;

PairEAMCrossZhouPdAgH::PairEAMCrossZhouPdAgH(EAPOT *eapot)
	: PairEAMCrossHijazi(eapot) 
{
	styles.push_back("eam/cross/zhouPdAgH");
	cross_fsize = 4;
	cross_csize = 2;

	rc = rs = 0;
	mrs3 = mrs2 = 0;
	rc1 = rc2 = 0;
};


double PairEAMCrossZhouPdAgH::cphi2(double r) {

	if (r >= cutmax) return 0;

	double dr = r - r0;
	double expmbdr = exp(-b * dr);
	double expmadr = exp(-a * dr);
	double drcs = r - rc + rs;
	double cosdrcs = cos((drcs * 3.141592653589793) / rs);

	double res = -D * (cosdrcs / 2.0 + 1.0 / 2.0) * (a * expmbdr - b * expmadr);

	return res;
}


double PairEAMCrossZhouPdAgH::cphi(double r) {

	if (r >= cutmax) return 0;
	else if (r >= rc2) return 0;
	else if (r > rc1) return cphi2(r);
	else return PairEAMCrossHijazi::cphi(r);

	return DBL_MAX;
}

void PairEAMCrossZhouPdAgH::setFullParamsStyle()
{
	rc = cross_cvec[0];
	rs = cross_cvec[1];

	rc2 = rc;
	rc1 = rc - rs;

	mrs3 = 1.0 / (rs*rs*rs);
	mrs2 = 1.0 / (rs*rs);

	setFreeParamsStyle();
};

//void PairEAMCrossZhouPdAgH::alter(double *arg)
//{
//	PairEAMCrossHijazi::alter(arg);
//
//	rc = cross_fvec[4];
//	rs = cross_fvec[5];
//
//	rc2 = rc;
//	rc1 = rc - rs;
//
//	mrs3 = 1.0 / (rs*rs*rs);
//	mrs2 = 1.0 / (rs*rs);
//};



void PairEAMCrossZhouPdAgH::extra_check(int) {

	force->init();

	// If you open the last two degrees of freedom : rc rs
	// Will cause an error
	// double rlist[] = { 1.58, 4.68, 4.7, 4.8, 4.92 };
	// CROSSZhouPdAgH | Femb(d&p)rhophi(d&p)    | max/all: 0.013050701513806051, 0.013165453514312753

	// Independent of 1/2 being recognized by the compiler as integer division, the reason is unknown

	partial_check();
	

	double tparm[] = { 0.1068, 3.305, 1.523, 2.748 };
	setFreeParams(tparm);
	const char* name = "CROSSZhouPdAgH";
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.594 ,  4.258,
		3.6404, 3.8204,
		2.8265, 4.0565,
	};

	double ElaChk[9], ElaRef[9] = {
		184.26, 125.31,  79.85,
		151.91, 108.94, 72.012,
		886.75, 330.89, 275.44,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 1.1481874693333035e-05, 3.7914796773031372e-05);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 5e-4, 2e-4, 0.00011048453640773355, 0.00058081585602891251);
}


void PairEAMCrossZhouPdAgH::partial_check() {

	double t[] = { 0.755217, 2.16562, 1.76185, 2.35349 };
	setFreeParams(t);

	double fchk[7], fref[] = {
		-1.9043717768285402e-02,
		-1.6729948336222759e-02,
		-1.2427720768086507e-02,
		-7.6543575397049184e-03,
		-3.5348979306618106e-03,
		-8.7462348442700778e-04, 
		-3.3548143420448584e-05,
	};

#define NUM 7
	double rlist[] = { 4.66, 4.7, 4.75, 4.8, 4.85, 4.9, 4.94 };

	int idx = 0;
	for (int ir = 0; ir < NUM; ir++) {
		fchk[idx++] = cphi(rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSZhouPdAgH", "Func",
		8e-14, 8e-15, 2.0602597177947414e-14, 3.6894197100270352e-14);

#undef NUM

}

/*
   0   0.00e+00        0%        0%        0%        0%
 3.54326187800000  4.42353405800000 232.479538 145.506904 115.651921
 3.59913679100000  3.79267187300000 187.537962 128.758273  78.469628
 2.83732570900000  4.04921838000000 156.762660 187.965243 120.774946

   0   2.41e+00        0%        0%        0%        0%
 3.59404255366007  4.25795036821290 184.274078 125.315116  79.854433
 3.64038210766255  3.82035613463297 151.896090 108.932304  72.013724
 2.82649451162905  4.05648390301883 886.767962 330.897526 275.469748
 3.594	            4.258	        184.26     125.31	   79.85
 3.6404	           3.8204	        151.91     108.94	  72.012
 4.8476	           3.6361	        277.37     39.126	 -13.685
 2.8265	           4.0565	        886.75     330.89	  275.44

  50   7.42e-02        0%        0%        0%        0%
 3.68281725498013  4.40501014792730 136.642208  91.110423  68.107109
 3.70349159118169  3.98624915471006 182.692951 139.509581  74.571726
 2.85996147936105  4.05832734025865 611.915715 311.705850 310.210464
 3.6828	            4.405	        136.63     91.104	  68.102
 3.7035	           3.9862	         182.7     139.52	  74.572
 5.0165	           3.6404	        360.09     38.136	  -21.39
 3.0158	            4.028	        183.16     183.04	  120.85

 100   7.42e-02        0%        0%        0%        0%
 3.68281725498013  4.40501014792730 136.642208  91.110423  68.107109
 3.70349159118169  3.98624915471006 182.692951 139.509581  74.571726
 2.85996147936105  4.05832734025865 611.915715 311.705850 310.210464
 3.6828	            4.405	        136.63     91.104	  68.102
 3.7035	           3.9862	         182.7     139.52	  74.572
 5.0165	           3.6404	        360.09     38.136	  -21.39
 3.0158	            4.028	        183.16     183.04	  120.85

 150   7.42e-02        0%        0%        0%        0%
 3.68281725498013  4.40501014792730 136.642208  91.110423  68.107109
 3.70349159118169  3.98624915471006 182.692951 139.509581  74.571726
 2.85996147936105  4.05832734025865 611.915715 311.705850 310.210464
 3.6828	            4.405	        136.63     91.104	  68.102
 3.7035	           3.9862	         182.7     139.52	  74.572
 5.0165	           3.6404	        360.09     38.136	  -21.39
 3.0158	            4.028	        183.16     183.04	  120.85

*/