#include "pair_eam_list.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

#include "option_pair.h"
using namespace EAPOT_NS;

#define MAXLINE 1024

/* ---------------------------------------------------------------------- */

PairEAMList::PairEAMList(EAPOT *eapot) : PairEAM(eapot)
{
	//nmax = 0;
	//rho = NULL;
	//fp = NULL;
	styles.push_back("eam/list");
	potModeEnum = PotModeEnum::EMPTY;
	transformFlag = 0;
	map_allocated = 0;

	map = NULL;
	type2frho = NULL;
	type2rhor = NULL;
	type2z2r = NULL;

	nfuncfl = 0;
	funcfl = NULL;
	setfl = NULL;
	fs = NULL;

	frho = NULL;
	rhor = NULL;
	z2r = NULL;

	nfrho = nrhor = nz2r = 0;
	list_rdr = list_rdrho = list_rhomax = 0;

	frho_spline = NULL;
	rhor_spline = NULL;
	z2r_spline = NULL;

	eam_fsize = 0;
	eam_csize = 0;
}


PairEAMList::~PairEAMList()
{

	if (fvec_allocated) {
		delete[] map;
		delete[] type2frho;
		map = NULL;
		type2frho = NULL;
		memory->destroy(type2rhor);
		memory->destroy(type2z2r);
	}

	if (funcfl) {
		for (int i = 0; i < nfuncfl; i++) {
			memory->destroy(funcfl[i].frho);
			memory->destroy(funcfl[i].rhor);
			memory->destroy(funcfl[i].z2r);
		}
		delete[] funcfl;
		funcfl = NULL;
	}

	if (setfl) {
		memory->destroy(setfl->frho);
		memory->destroy(setfl->rhor);
		memory->destroy(setfl->z2r);
		delete setfl;
		setfl = NULL;
	}

	if (fs) {
		memory->destroy(fs->frho);
		memory->destroy(fs->rhor);
		memory->destroy(fs->z2r);
		delete fs;
		fs = NULL;
	}

	memory->destroy(frho);
	memory->destroy(rhor);
	memory->destroy(z2r);

	memory->destroy(frho_spline);
	memory->destroy(rhor_spline);
	memory->destroy(z2r_spline);
}
/* ----------------------------------------------------------------------
// Encapsulation transformation operation on core functions
------------------------------------------------------------------------- */

double PairEAMList::emb(int type, double lr){

	if (transformFlag){
		double g, s;
		g = paramVec[2 * (size_t)type - 2];
		s = paramVec[2 * (size_t)type - 1];
		double trho = lr / s;
		return core_emb(type, trho) + g*trho;
	}
	else{
		return core_emb(type, lr);
	}
	return DBL_MAX;
}

double PairEAMList::rho(int itype, int jtype, double r){

	if (transformFlag){
		int sdof = 2 * itype - 1;
		double s = paramVec[sdof];
		return s*core_rho(itype, jtype, r);
	}
	else{
		return core_rho(itype, jtype, r);
	}
	return DBL_MAX;
}

double PairEAMList::phi(int itype, int jtype, double r){

	if (transformFlag && itype == jtype){
		double g;// , s;
		g = paramVec[2 * (size_t)itype - 2];
		//s = fvec[2 * jtype - 1];
		
		return core_phi(itype, jtype, r) - 2 * g*core_rho(itype, jtype, r);
	}
	else{
		return core_phi(itype, jtype, r);
	}
	return DBL_MAX;
}

/* ----------------------------------------------------------------------
// list core functions for interpolation
------------------------------------------------------------------------- */

double PairEAMList::core_emb(int itype, double lr){

	if (!frho_spline) return 0;

	int m;
	double p, *coeff;
	double fp, f;

	p = lr * list_rdrho + 1.0;
	m = static_cast<int> (p);
	m = MAX(1, MIN(m, list.nrho - 1));
	p -= m;
	p = MIN(p, 1.0);

	coeff = frho_spline[type2frho[itype]][m];

	if (lr > list_rhomax){
		fp = (coeff[0] * p + coeff[1]) * p + coeff[2];
		f = ((coeff[3] * p + coeff[4]) * p + coeff[5]) * p + coeff[6];
		return f + fp * (lr - list_rhomax);
	}
	else{
		return ((coeff[3] * p + coeff[4]) * p + coeff[5]) * p + coeff[6];
	}	
};


double PairEAMList::core_rho(int itype, int jtype, double r){

	int m;
	double p, *coeff;
	if (r >= cutmax || !frho_spline) return 0;

	p = r* list_rdr + 1.0;
	m = static_cast<int> (p);
	m = MIN(m, list.nr - 1);
	p -= m;
	p = MIN(p, 1.0);

	coeff = rhor_spline[type2rhor[itype][jtype]][m];
	return ((coeff[3] * p + coeff[4]) * p + coeff[5]) * p + coeff[6];
};


double PairEAMList::core_phi(int itype, int jtype, double r){

	int m;
	double p, *coeff;
	double phi, z2, recip;
	if (r >= cutmax || !frho_spline) return 0;

	p = r* list_rdr + 1.0;
	m = static_cast<int> (p);
	m = MIN(m, list.nr - 1);
	p -= m;
	p = MIN(p, 1.0);

	recip = 1.0 / r;
	coeff = z2r_spline[type2z2r[itype][jtype]][m];

	z2 = ((coeff[3] * p + coeff[4])*p + coeff[5])*p + coeff[6];
	phi = z2*recip;
	return phi;
};


/**************************************************************************************
 Differences with LAMMPS

pair_coeff										|	coeff(...)->coeff_func/set/fs(...)
|												|  	force->set_ntypes(narg - 3);
|   allocate()									|	|   style_alloc();
|   read_file(char *filename)					|	|   read_file_func/set/fs(arg[2]);
|   map & setflag								|	|	map & setflag
												|	
												|	
Pair::init()									|	Pair::init()
|												|	|
|	init_style();								|	|   init_style()
|	|												|	|	map_type2array()
|	|	file2array();							|	|   |	file2array();
|	|	array2spline();							|	|   |	array2spline();
|	|	neighbor->request();					|	
|												|	
|	cut = init_one(i,j);						|	|
|	cutsq[i][j] = cutsq[j][i] = cut*cut;		|	|
|	cutforce = MAX(cutforce, cut);				|	|


double PairEAM::init_one(int i, int j):
|
|	cutmax = m_dump.cut;
|	cutforcesq = cutmax * cutmax;


double PairEAMList::init_one(int i, int j):
|
|	if (funcfl)		cutmax = MAX(cutmax, funcfl[0:nfuncfl].cut);
|	else if (setfl)	cutmax = setfl->cut;
|	else if (fs)	cutmax = fs->cut;
|
|	cutforcesq = cutmax*cutmax;


Pair		cutforce, **cutsq, **setflag
PairEAM		m_dump.cut

**************************************************************************************/

void PairStyle::enablePairEAMListTransform(void* pPair, int flag)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam/list", 1);
	auto pair = (PairEAMList*)pPair;

	int otransformFlag = pair->transformFlag;
	pair->transformFlag = flag;

	if (otransformFlag != pair->transformFlag) {
		pair->fvec_clear();
		pair->fvec_allocate();
	}
}


void PairEAMList::map_type2array() {
	if (!map_allocated) error->all(FLERR, "All pair coeffs are not set");

	int i, j, m, n;
	int ntypes = force->get_ntypes();

	// type2frho[i] = which frho array (0 to nfrho-1) each atom type maps to
	// if atom type doesn't point to file (non-EAM atom in pair hybrid)
	// then map it to last frho array of zeroes

	for (i = 1; i <= ntypes; i++) {
		if (map[i] >= 0) type2frho[i] = map[i];
		else type2frho[i] = nfrho - 1;
	}

	// type2rhor[i][j] = which rhor array (0 to nrhor-1) each type pair maps to
	// for funcfl files, I,J mapping only depends on I
	// OK if map = -1 (non-EAM atom in pair hybrid) b/c type2rhor not used

	if (potModeEnum == PotModeEnum::FS) {
		int nelements = (int)fs->elements.size();
		for (i = 1; i <= ntypes; i++)
			for (j = 1; j <= ntypes; j++)
				type2rhor[i][j] = map[i] * nelements + map[j];
	}
	else {
		for (i = 1; i <= ntypes; i++)
			for (j = 1; j <= ntypes; j++)
				type2rhor[i][j] = map[i];
	}

	// type2z2r[i][j] = which z2r array (0 to nz2r-1) each type pair maps to
	// set of z2r arrays only fill lower triangular Nelement matrix
	// value = n = sum over rows of lower-triangular matrix until reach irow,icol
	// swap indices when irow < icol to stay lower triangular
	// if map = -1 (non-EAM atom in pair hybrid):
	//   type2z2r is not used by non-opt
	//   but set type2z2r to 0 since accessed by opt

	int irow, icol;
	for (i = 1; i <= ntypes; i++) {
		for (j = 1; j <= ntypes; j++) {
			irow = map[i];
			icol = map[j];
			if (irow == -1 || icol == -1) {
				type2z2r[i][j] = 0;
				continue;
			}
			if (irow < icol) {
				irow = map[j];
				icol = map[i];
			}
			n = 0;
			for (m = 0; m < irow; m++) n += m + 1;
			n += icol;
			type2z2r[i][j] = n;
		}
	}
}

void PairEAMList::init_style()
{
	PairEAM::init_style();

	map_type2array();

	// convert read-in file(s) to arrays and spline them
	switch (potModeEnum) {
		case PotModeEnum::FUNC:	file2array_func();	break;
		case PotModeEnum::SET:	file2array_set();	break;
		case PotModeEnum::FS:	file2array_fs();	break;
		default: ErrorAll("Illegal EAM file format(%d)", potModeEnum);
	}
	array2spline();
}

/* ----------------------------------------------------------------------
allocate all arrays
------------------------------------------------------------------------- */

void PairEAMList::fvec_allocate()
{
	eam_csize = 0;
	if (transformFlag){
		eam_fsize = force->get_ntypes() * 2;
	}
	else{
		eam_fsize = 0;
	}

	PairEAM::fvec_allocate();
}

void PairEAMList::map_alloc(){

	int n = force->get_ntypes();	//modify lammps for atom->ntypes

	if (map_allocated){
		delete[] map;
		delete[] type2frho;
		map = NULL;
		type2frho = NULL;
		memory->destroy(type2rhor);
		memory->destroy(type2z2r);
	}

	map = new int[(size_t)n + 1];
	for (int i = 1; i <= n; i++) map[i] = -1;

	type2frho = new int[(size_t)n + 1];
	memory->create(type2rhor, n + 1, n + 1, "pair:type2rhor");
	memory->create(type2z2r, n + 1, n + 1, "pair:type2z2r");

	map_allocated = 1;
}

void PairEAMList::array2spline()
{
	list_rdr = 1.0 / list.dr;
	list_rdrho = 1.0 / list.drho;

	memory->destroy(frho_spline);
	memory->destroy(rhor_spline);
	memory->destroy(z2r_spline);

	memory->create(frho_spline, nfrho, list.nrho + 1, 7, "pair:frho");
	memory->create(rhor_spline, nrhor, list.nr + 1, 7, "pair:rhor");
	memory->create(z2r_spline, nz2r, list.nr + 1, 7, "pair:z2r");

	for (int i = 0; i < nfrho; i++)
		interpolate(list.nrho, list.drho, frho[i], frho_spline[i]);

	for (int i = 0; i < nrhor; i++)
		interpolate(list.nr, list.dr, rhor[i], rhor_spline[i]);

	for (int i = 0; i < nz2r; i++)
		interpolate(list.nr, list.dr, z2r[i], z2r_spline[i]);
}

void PairEAMList::interpolate(int n, double delta, double *f, double **spline)
{
	for (int m = 1; m <= n; m++) spline[m][6] = f[m - 1];

	spline[1][5] = spline[2][6] - spline[1][6];
	spline[2][5] = 0.5 * (spline[3][6] - spline[1][6]);
	spline[n - 1][5] = 0.5 * (spline[n][6] - spline[n - 2][6]);
	spline[n][5] = spline[n][6] - spline[n - 1][6];

	for (int m = 3; m <= n - 2; m++) {
		spline[m][5] = ((spline[m - 2][6] - spline[m + 2][6]) +
			8.0*(spline[m + 1][6] - spline[m - 1][6])) / 12.0;
	}


	for (int m = 1; m <= n - 1; m++) {
		spline[m][4] = 3.0*(spline[m + 1][6] - spline[m][6]) -
			2.0*spline[m][5] - spline[m + 1][5];
		spline[m][3] = spline[m][5] + spline[m + 1][5] -
			2.0*(spline[m + 1][6] - spline[m][6]);
	}

	spline[n][4] = 0.0;
	spline[n][3] = 0.0;

	for (int m = 1; m <= n; m++) {
		spline[m][2] = spline[m][5] / delta;
		spline[m][1] = 2.0*spline[m][4] / delta;
		spline[m][0] = 3.0*spline[m][3] / delta;
	}
}

/* ----------------------------------------------------------------------
grab n values from file fp and put them in list
values can be several to a line
------------------------------------------------------------------------- */

void PairEAMList::grab(FILE *fptr, int n, double *list)
{
	char *ptr;
	char line[MAXLINE];

	int i = 0;
	while (i < n) {
		fgets(line, MAXLINE, fptr);
		ptr = strtok(line, " \t\n\r\f");
		list[i++] = atof(ptr);
		while ((ptr = strtok(NULL, " \t\n\r\f"))) list[i++] = atof(ptr);
	}
}

void PairEAMList::extra_check(int) {
	force->init();

	switch (potModeEnum) {
	case PotModeEnum::FUNC:	extra_check_func(0);break;
	case PotModeEnum::SET:	extra_check_set(0);	break;
	case PotModeEnum::FS:	extra_check_fs(0);	break;
	default: ErrorAll("Illegal EAM file format(%d)", potModeEnum);
	}
}
