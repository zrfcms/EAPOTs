#include "pair_eam_python.h"

#include "force.h"
#include "error.h"

using namespace EAPOT_NS;

PairEAMPython::PairEAMPython(EAPOT* eapot)
	: PairEAMList(eapot)
	, param { 0, NULL }
{
	styles.push_back("eam/python");
	python_fsize = 0;
	python_csize = 0;

	python_fvec = NULL;
	python_cvec = NULL;
};

PairEAMPython::~PairEAMPython() {
}

int PairEAMPython::getPyParamNum() {
	return PairEAM::getPyParamNum() + python_fsize + python_csize;
}

void PairEAMPython::fvec_allocate()
{
	add_fsize(python_fsize);
	add_csize(python_csize);
	PairEAMList::fvec_allocate();

	python_fvec = (python_fsize) ? &paramVec[eam_fsize] : NULL;
	size_t pyt_csize = (size_t)eam_csize + eam_fsize + python_fsize;
	python_cvec = (python_csize) ? &paramVec[pyt_csize] : NULL;
}

void PairEAMPython::init_style() {
	PairEAMList::init_style();
	
	arrayR.resize(list.nr);
	arrayRho.resize(list.nrho);

	for (int i = 0; i < list.nr; i++) {
		arrayR[i] = i * list.dr;
	}
	for (int i = 0; i < list.nrho; i++) {
		arrayRho[i] = i * list.drho;
	}

	if (!pythonScript.empty() && potCallback == NULL && eapot->pythonCallback) {

		std::string str = pythonScript +
			"eapot.PairPotAPI = eapot.VoidCallbackType(PairPotFunc)\n"
			"eapot.setPairPotCallback(eapot.getPair(), eapot.PairPotAPI, None)\n";
		eapot->pythonCallback(eapot->caller, FLERR, str.c_str());
	}
}

void PairEAMPython::setFreeParamsStyle()
{
	if (frho != NULL) {

		int idx = 0, ndof = python_fsize + python_csize;
		dof.resize(ndof, 0.0);
		for (int i = 0; i < python_fsize; i++) dof[idx++] = python_fvec[i];
		for (int i = 0; i < python_csize; i++) dof[idx++] = python_cvec[i];

		param.ndof = ndof;
		param.dof = dof.data();

		param.nrhot = list.nrho;
		param.nr = list.nr;
		param.nemb = nfrho;
		param.nrho = nrhor;
		param.nphi = nz2r;

		param.rhot = arrayRho.data();
		param.r = arrayR.data();
		param.emb = frho[0];
		param.rho = rhor[0];
		param.phi = z2r[0];

		if(this->potCallback)(this->potCallback)(potCaller, &param);

		for (int i = 0; i < nfrho; i++) {
			interpolate(list.nrho, list.drho, frho[i], frho_spline[i]);
		}
		for (int i = 0; i < nrhor; i++) {
			interpolate(list.nr, list.dr, rhor[i], rhor_spline[i]);
		}
		for (int i = 0; i < nz2r; i++) {
			for (int k = 0; k < list.nr; k++) z2r[i][k] *= arrayR[k];
			interpolate(list.nr, list.dr, z2r[i], z2r_spline[i]);
		}
	}

	PairEAM::setFreeParamsStyle();
};



void PairEAMPython::extra_check(int type) {

	switch (type) {
	case 0: 
	case 100:
		single_check(type); break;
	case 1: 
		cross_check_set(); break;
	case 101:
		cross_check_fs(); break;
	}
}

void PairEAMPython::single_check(int type) {
	
	addMDComputeBcc();
	runMDCompute(-1, RunDump | RunEcho, 10, NbBccCost, BccChk, "nms", "dump.*.eam");

	const char* name = type < 100 ? "SetPython/s" : "FSPython/s";
	error->add_chklog(0, name, "");

#define N 12

	double fRef[N] = {
		-3.0137890000000001, -3.6911226212063855, -4.2621412779308478, -4.7652188135806002,
		-5.2200356712921989, -5.6382829370140248, -6.0275780000000001, -6.3932119168962709,
		-6.7390370738411143, -7.0679617111912476, -7.3822452424127709, -7.6836844604256420,
	};
	double rRef[N] = {
		 5.8339349453159981,      4.6887579453159995,    3.6685809453159992,    2.7734039453159993,
		 2.0032269453159994,      1.3580499453159995,   0.83787294531600043,   0.44269594531600032,
		0.17251894531600015,    0.027341945315999889,   0.00000000000000000,   0.00000000000000000,
	};
	double pRef[N] = {
		  39.126178905975905,   19.228769106257118,   8.9469787593426364,  4.0216972130228292,
		  1.8456955310832539,  0.89900455137112090,  0.36768340800001181, 0.02528538762500358,
		-0.12622333849999598, -0.12180605849997558, -0.04014884799996609, 0.00000000000000000,
	};

	double rChk[N], pChk[N], fChk[N];
	chkListFunc(N, 1.0, 0.5, N, 1.5, 0.25, fChk, rChk, pChk, 0);
	error->check(FLERR, N, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 3.298388706732289e-15, 1.132902764912617e-14);

#undef N

#define NBox 2
#define NEla 3

	error->add_chklog(0, name, "");
	// data from LAMMPS
	double BoxChk[NBox], BoxRef[NBox] = {
		3.300799689997814, 7.57000080189445,
	}, ElaChk[NEla], ElaRef[NEla] = {
		246.6563567472333, 133.24805747150683, 28.14026027705748
	};
	evalCompute(BoxChk, ElaChk, 1, 1, 1);

	error->check(FLERR, NBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 3.6592603582876688e-08, 3.6592619304923665e-08);
	error->check(FLERR, NEla, ElaChk, ElaRef, 1, name, "Ela", 2e-6, 2e-6, 1.9770799976674741e-06, 4.1959555083990187e-06);

#undef NBox
#undef NEla
}

void PairEAMPython::cross_check_fs() {

	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");

	const char* name = "FSPython/c";
	error->add_chklog(0, name, "");

#define N 12

	double fChk[N * 2], fRef[N * 2] = {
		-2.0106370000000000, -2.4625173539801701, -2.8434701144091528, -3.1790962339039850,
		-3.4825254395778646, -3.7615573915854985, -4.0212740000000000, -4.2652051716137285,
		-4.4959210100762448, -4.7153617360420510, -4.9250347079603403, -5.1261386488758278,

		-3.0137890000000001, -3.6911226212063855, -4.2621412779308478, -4.7652188135806002,
		-5.2200356712921989, -5.6382829370140248, -6.0275780000000001, -6.3932119168962709,
		-6.7390370738411143, -7.0679617111912476, -7.3822452424127709, -7.6836844604256420,
	};
	double rChk[N * 4], rRef[N * 4] = {
		4.8082271162889993, 3.7743436162889998, 2.8654601162889999, 2.0815766162889999,
		1.4226931162890000, 0.88880961628899979,0.47992611628900050,0.19604261628900030,
		0.037159116289000121,0.00000000000000000,0.00000000000000000,0.00000000000000000,

		5.1391212433690017, 4.0681397433690005, 3.1221582433690003, 2.3011767433690000,
		1.6051952433690002, 1.0342137433690002, 0.58823224336900071, 0.26725074336900051,
		0.071269243369000243, 0.00028774336899999817, 0.00000000000000000, 0.00000000000000000,

		5.4810207809640001, 4.3729417809640010, 3.3898627809640001, 2.5317837809640000,
		1.7987047809640002, 1.1906257809640002, 0.70754678096400092, 0.34946778096400061,
		0.11638878096400032, 0.0083097809639999919, 0.00000000000000000, 0.00000000000000000,

		 5.8339349453159981,      4.6887579453159995,    3.6685809453159992,    2.7734039453159993,
		 2.0032269453159994,      1.3580499453159995,   0.83787294531600043,   0.44269594531600032,
		0.17251894531600015,    0.027341945315999889,   0.00000000000000000,   0.00000000000000000,
	};
	double pChk[N * 3], pRef[N * 3] = {
		    18.192236412119293, 8.7195003122584129,3.7862814013065216,1.5203644282475326,
		 0.62368424838636793,0.23248559446876405,0.0076556800000161570,-0.071587203531245966,
		-0.048147340499995590,-0.0022074840312245694,0.00000000000000000,0.00000000000000000,
		
		    28.527403867742340,13.820000695929522,6.1865517467970932,2.6023048852276252,
		  1.1101687173872239,0.49627233398438525,0.13364885000001442,-0.058678555078121232,
		-0.099071137499995798,-0.046390781640600003,1.0958079417327131e-08,0.00000000000000000,

		  39.126178905975905,   19.228769106257118,   8.9469787593426364,  4.0216972130228292,
		  1.8456955310832539,  0.89900455137112090,  0.36768340800001181, 0.02528538762500358,
		-0.12622333849999598, -0.12180605849997558, -0.04014884799996609, 0.00000000000000000,
	};

	chkListFunc(N, 1.0, 0.5, N, 1.5, 0.25, fChk, rChk, pChk, 1);

	error->check(FLERR, N*2, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N*4, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N*3, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 3.298388706732289e-15, 1.132902764912617e-14);

#undef N

	error->add_chklog(0, name, "");

	// data from LAMMPS
	double BoxChk[6], BoxRef[6] = {
		4.1079787762734920, 6.799076955682827,
		3.9615084316419487, 5.742817613553231,
		3.1736468356225154, 6.423657089374852,
	};

	double ElaChk[9], ElaRef[9] = {
		-35.725350795069765, 129.05560964220498, 42.93327167512971,
		 152.35084742513690, 121.20146840886379, 47.46594615062012,
		 225.04621138781695, 125.27829567744627, 34.12306786774561,
	};

	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 8.0261545282766002e-10, 1.3926139136502273e-09);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 2e-5, 1e-5, 1.9440835298286761e-06, 1.1520152028556082e-05);
}

void PairEAMPython::cross_check_set() {

	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");

	const char* name = "SetPython/c";
	error->add_chklog(0, name, "");

#define N 12

	double fChk[N * 2], fRef[N * 2] = {
		-2.0106370000000000, -2.4625173539801701, -2.8434701144091528, -3.1790962339039850,
		-3.4825254395778646, -3.7615573915854985, -4.0212740000000000, -4.2652051716137285,
		-4.4959210100762448, -4.7153617360420510, -4.9250347079603403, -5.1261386488758278,

		-3.0137890000000001, -3.6911226212063855, -4.2621412779308478, -4.7652188135806002,
		-5.2200356712921989, -5.6382829370140248, -6.0275780000000001, -6.3932119168962709,
		-6.7390370738411143, -7.0679617111912476, -7.3822452424127709, -7.6836844604256420,
	};
	double rChk[N * 2], rRef[N * 2] = {
		4.8082271162889993, 3.7743436162889998, 2.8654601162889999, 2.0815766162889999,
		1.4226931162890000, 0.88880961628899979,0.47992611628900050,0.19604261628900030,
		0.037159116289000121,0.00000000000000000,0.00000000000000000,0.00000000000000000,

		 5.8339349453159981,      4.6887579453159995,    3.6685809453159992,    2.7734039453159993,
		 2.0032269453159994,      1.3580499453159995,   0.83787294531600043,   0.44269594531600032,
		0.17251894531600015,    0.027341945315999889,   0.00000000000000000,   0.00000000000000000,
	};
	double pChk[N * 3], pRef[N * 3] = {
			18.192236412119293, 8.7195003122584129,3.7862814013065216,1.5203644282475326,
		 0.62368424838636793,0.23248559446876405,0.0076556800000161570,-0.071587203531245966,
		-0.048147340499995590,-0.0022074840312245694,0.00000000000000000,0.00000000000000000,

			28.527403867742340,13.820000695929522,6.1865517467970932,2.6023048852276252,
		  1.1101687173872239,0.49627233398438525,0.13364885000001442,-0.058678555078121232,
		-0.099071137499995798,-0.046390781640600003,1.0958079417327131e-08,0.00000000000000000,

		  39.126178905975905,   19.228769106257118,   8.9469787593426364,  4.0216972130228292,
		  1.8456955310832539,  0.89900455137112090,  0.36768340800001181, 0.02528538762500358,
		-0.12622333849999598, -0.12180605849997558, -0.04014884799996609, 0.00000000000000000,
	};

	chkListFunc(N, 1.0, 0.5, N, 1.5, 0.25, fChk, rChk, pChk, 0);

	error->check(FLERR, N * 2, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N * 2, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N * 3, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 3.298388706732289e-15, 1.132902764912617e-14);

#undef N

	error->add_chklog(0, name, "");

	// data from LAMMPS
	double BoxChk[6], BoxRef[6] = {
		4.112699556891687, 6.7606486681473354,
		3.9630762890284252, 5.694494631253283,
		3.1732357031224896, 6.355112211783286,
	};

	double ElaChk[9], ElaRef[9] = {
		-41.56457634787618, 128.69622440821414, 42.54982210563074,
		151.28695647612494, 121.05045688635987, 46.98892499147644,
		224.19515141367378, 126.35530451513833, 33.80004861656596,
	};

	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 2.4892607930500384e-09, 3.8656848694189385e-09);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 2e-5, 1e-5, 1.8292073319586564e-05, 2.4690828396825778e-05);
}


