#ifdef PAIR_CLASS
PairStyle(eam/cross/morse, PairEAMCrossMorse)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_MORSE_H
#define EAPOT_PAIR_EAM_CROSS_MORSE_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossMorse : virtual public PairEAMCross
	{
	public:
		PairEAMCrossMorse(EAPOT *eapot);
		~PairEAMCrossMorse(){};

		double cphi(double r);

		void setFreeParamsStyle();

		double DM, aM, RM, rc;
		double phicr, phidr, rcn, NN;

		inline double phic(double lr) {
			double exprm = exp(aM * (RM - lr)) - 1;
			return DM * exprm * exprm - DM;
		}
		inline double phid(double lr) {
			double expr = exp(aM * (RM - lr));
			return -2 * DM * aM * expr * (expr - 1);
		}

		inline double smooth(double r, double f, double fc, double dfc) {
			return f - fc + rcn * (1 - pow(r / rc, NN)) * dfc;
		}

	private:
		void extra_check(int);
	};

}

#endif
#endif
#endif