#include "pair_eam_cross_demk.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;


PairEAMCrossDemk::PairEAMCrossDemk(EAPOT *eapot)
: PairEAMCross(eapot){
	styles.push_back("eam/cross/demk");
	cross_fsize = 4;
	cross_csize = 0;
};


double PairEAMCrossDemk::cphi(double r){

	double D = cross_fvec[0];
	double R = cross_fvec[1];
	double a = cross_fvec[2];
	double c = cross_fvec[3];

	if (r >= c || r >= cutmax) return 0.0;
	
	double Rr = R - r;
	double Rc = R - c;
	double Rra = Rr*a;
	double Rca = Rc*a;
	double expRra = exp(Rra);
	double expRca = exp(Rca);
	double r20 = pow(r, 2.0E1);
	double c20 = 1.0 / pow(c, 2.0E1);
	double r20c20 = c20*r20;
	double mr20c20 = r20c20 - 1.0;
	double mexpRra = expRra - 1.0;
	double mexpRca = expRca - 1.0;
	double mexpRra2 = mexpRra*mexpRra;
	double mexpRca2 = mexpRca*mexpRca;
	double expmexpRca = expRca*mexpRca;
	double Da = D*a;
	double res = D*mexpRra2 - D*mexpRca2 + (Da*c*expmexpRca*mr20c20) / 10;
	return res;
}

void PairEAMCrossDemk::extra_check(int) {
	force->init();

	partial_check();
	

	double tparm[] = { 0.22, 2.75, 1.44, 4.7 };
	setFreeParams(tparm);
	const char* name = "CROSSDEMK";
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.58295597069240, 4.12560682416852,
		3.63486743843846, 3.68529797450705,
		2.93025207594688, 3.90299276266779,
	};

	double ElaChk[9], ElaRef[9] = {
		171.100984518966, 118.952133250626,	72.7784153755872,
		125.919313598368, 94.0373216890468, 60.6606273856320,
		132.853317985499, 112.463999365916,	76.9178962811648,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 4.3868309478904618e-06, 7.1006836954955264e-06);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 5e-4, 2e-4, 0.00021840359024767597, 0.00072370908389301505);
}

void PairEAMCrossDemk::partial_check(){
	double fchk[3], fref[] = {
		 0.2979198399497277, 
		-0.8812746057763626,
		-0.4182276461326336,
	};

	double rlist[] = { 0.75, 1.85, 2.95 };
	
	int nrlist = 3;
	int idx = 0;

	for (int ir = 0; ir < nrlist; ir++){
		fchk[idx++] = cphi(rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSDEMK", "Func",
		1e-13, 5e-15, 2.0496206753027098e-15, 2.5805387219174804e-15);
}
