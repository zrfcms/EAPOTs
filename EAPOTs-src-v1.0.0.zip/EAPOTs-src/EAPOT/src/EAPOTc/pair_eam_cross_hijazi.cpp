#include "pair_eam_cross_hijazi.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"


using namespace EAPOT_NS;


PairEAMCrossHijazi::PairEAMCrossHijazi(EAPOT *eapot)
	: PairEAMCross(eapot) {
	styles.push_back("eam/cross/hijazi");
	cross_fsize = 4;
	cross_csize = 0;

	D = a = b = r0 = 0;
	a2 = a3 = b2 = b3 = 0;
};


double PairEAMCrossHijazi::cphi(double r) {
	if (r >= cutmax) return 0;

	double dr = r - r0;
	double expmbdr = exp(-b * dr);
	double expmadr = exp(-a * dr);
	double res = -D * (a*expmbdr - b * expmadr);

	return res;
}


void PairEAMCrossHijazi::setFullParamsStyle()
{
	setFreeParamsStyle();
};

void PairEAMCrossHijazi::setFreeParamsStyle()
{
	D = cross_fvec[0];
	a = cross_fvec[1];
	b = cross_fvec[2];
	r0 = cross_fvec[3];

	b3 = b*b*b;
	b2 = b*b;
	a3 = a*a*a;
	a2 = a*a;

	PairEAM::setFreeParamsStyle();
};

void PairEAMCrossHijazi::extra_check(int) {

	force->init();

	partial_check();

	//% D = 0.1068  (0.1028, 0.1108)
	//% a = 3.305  (3.266, 3.345)
	//% b = 1.523  (1.499, 1.547)
	//% r0 = 2.748  (2.747, 2.75)
	double tparm[] = { 0.1068, 3.305, 1.523, 2.748 };
	setFreeParams(tparm);
	const char* name = "CROSSHijazi";
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.5861, 4.2823,
		3.6404, 3.8204,
		2.8965,  4.087,
	};

	double ElaChk[9], ElaRef[9] = {
		187.78, 130.28,  84.29,
		151.88, 108.92,  72.007,
		115.24, 110.75,  92.266,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 2.0560994234625316e-05, 6.9337186429936908e-05);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 5e-4, 2e-4, 0.00014334685493913715, 0.00070095045491880043);
}

void PairEAMCrossHijazi::partial_check() {

	double fchk[24], fref[] = {
		-4.6695314101757435e-01,
		-2.9492889580149995e-01, 
		-1.5508156046056645e-01,  
		-7.5111058427095506e-02,  
		-3.4784343303271584e-02,  
		-1.5679935442599574e-02,  
		-6.9474770342209885e-03,  
		-3.0434209624019930e-03, 
	};

#define NUM 8
	double rlist[] = { 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0 };

	int idx = 0;
	for (int ir = 0; ir < NUM; ir++) {
		fchk[idx++] = cphi(rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSHijazi", "Func",
		8e-14, 8e-15, 7.1248912712345088e-16, 2.3641429385638314e-15);

#undef NUM

}

/*
   0   0.00e+00        0%        0%        0%        0%
 3.54326187800000  4.42353405800000 232.479538 145.506904 115.651921
 3.59913679100000  3.79267187300000 187.537962 128.758273  78.469628
 2.83732570900000  4.04921838000000 145.662928 174.656182 112.223359

   0   4.57e-02        0%        0%        0%        0%
 3.59404255366007  4.25795036821290 184.274078 125.315116  79.854433
 3.64038210766255  3.82035613463297 151.896090 108.932304  72.013724
 2.89653874976751  4.08695112310314 115.251287 110.759447  92.279141
 3.594	 		    4.258	 		184.27	   125.31	   79.851
 3.6404	 		   3.8204	 		151.88	   108.92	   72.007
 4.7673	 		   3.7055	 		300.74	     31.6	  -18.348
 2.8965	 		    4.087	 		115.24	   110.75	   92.266

  50   1.16e-02        0%        0%        0%        0%
 3.59580460334353  4.28492860829189 216.099781 141.186890  95.849331
 3.63587629695300  3.84693844413457 180.250221 121.558522  87.521355
 2.90848136654544  4.12958811883840 155.760485 147.862526 122.715208
 3.5958	 		   4.2849	 		 216.1	   141.19	   95.858
 3.6359	 		   3.8469	 		180.24	   121.56	   87.527
 4.7673	 		   3.6701	 		462.05	   40.625	  -24.096
 2.9085	 		   4.1296	 		155.76	   147.86	   122.73

 100   1.16e-02        0%        0%        0%        0%
 3.59493997472246  4.28366685999529 217.163565 141.739117  96.340847
 3.63492981954096  3.84539305525438 180.398642 121.298724  87.882461
 2.90744293689547  4.12875206689829 155.926735 147.592111 122.994827
 3.5949	 		   4.2837	 		217.17	   141.74	   96.339
 3.6349	 		   3.8454	 		180.39	   121.28	   87.889
 4.7673	 		   3.6705	 		462.67	   40.625	   -23.91
 2.9074	 		   4.1288	 		155.93	    147.6	   122.99

 150   1.16e-02        0%        0%        0%        0%
 3.59493997472246  4.28366685999529 217.163565 141.739117  96.340847
 3.63492981954096  3.84539305525438 180.398642 121.298724  87.882461
 2.90744293689547  4.12875206689829 155.926735 147.592111 122.994827
 3.5949	 		   4.2837	 		217.17	   141.74	   96.339
 3.6349	 		   3.8454	 		180.39	   121.28	   87.889
 4.7673	 		   3.6705	 		462.67	   40.625	   -23.91
 2.9074	 		   4.1288	 		155.93	    147.6	   122.99

*/