#include "pair_eam_cross.h"

#include "force.h"
#include "error.h"

using namespace EAPOT_NS;

PairEAMCross::PairEAMCross(EAPOT *eapot)
: PairEAMList(eapot)
{
	styles.push_back("eam/cross");
	if (force->get_ntypes() != 2) {
		error->all(FLERR, "The current potential function type is only applicable to binary systems!");
	}

	cross_fsize = 0;
	cross_csize = 0;

	cross_fvec = NULL;
	cross_cvec = NULL;
};

PairEAMCross::~PairEAMCross()
{
};

int PairEAMCross::getPyParamNum() {
	return PairEAM::getPyParamNum() + cross_fsize + cross_csize;
}

void PairEAMCross::fvec_allocate()
{
	add_fsize(cross_fsize);
	add_csize(cross_csize);
	PairEAMList::fvec_allocate();

	cross_fvec = &paramVec[eam_fsize];
	size_t cset = (size_t)eam_fsize + eam_csize + cross_fsize;
	cross_cvec = (cross_csize) ? &paramVec[cset] : NULL;
}

double PairEAMCross::cphi(double r){
	double phi1 = PairEAMList::phi(1, 1, r);
	double phi2 = PairEAMList::phi(2, 2, r);
	return 0.5*(phi1 + phi2);
}

double PairEAMCross::core_phi(int itype, int jtype, double r){
	if (itype != jtype)
		return cphi(r);
	else
		return PairEAMList::core_phi(itype, jtype, r);
};
