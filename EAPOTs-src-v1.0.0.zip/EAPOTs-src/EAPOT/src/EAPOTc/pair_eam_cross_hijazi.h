#ifdef PAIR_CLASS
PairStyle(eam/cross/hijazi, PairEAMCrossHijazi)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_HIJAZI_H
#define EAPOT_PAIR_EAM_CROSS_HIJAZI_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossHijazi : public PairEAMCross
	{
	public:
		PairEAMCrossHijazi(EAPOT *eapot);
		~PairEAMCrossHijazi(){};

		double cphi(double r);

		virtual void setFullParamsStyle();
		virtual void setFreeParamsStyle();

	protected:

		double D, a, b, r0;

		double a2, a3, b2, b3;

	private:
		virtual void extra_check(int);
		virtual void partial_check();
	};

}

#endif
#endif
#endif