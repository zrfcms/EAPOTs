#include "pair_eam_cross_zhou2.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;

#define pow_s(x, y) (x<0?pow(-x, y):pow(x, y))
#define log_s(x) (x<0?log(-x):log(x))

PairEAMCrossZhou2::PairEAMCrossZhou2(EAPOT *eapot)
: PairEAMCross(eapot){
	styles.push_back("eam/cross/zhou2");
	cross_fsize = 10;
	cross_csize = 0;
};

double PairEAMCrossZhou2::cphi(double r){
	return dcore(&cross_fvec[0], r) - dcore(&cross_fvec[5], r);
}

double PairEAMCrossZhou2::dcore(double *c, double r){
	double A = c[0];
	double la = c[1];
	double lk = c[2];
	double re = c[3];
	double n = c[4];

	if (r >= cutmax) return 0.0;

	double rn1 = r / re - 1.0;
	double rnk = fabs(lk - r / re);
	double rnkn = pow_s(rnk, n);
	double explarn1 = exp(-la * rn1);
	double rnkn0 = rnkn + 1.0;
	double Aexplarn1 = A * explarn1;
	double mrnkn01 = 1.0 / rnkn0;
	double res = Aexplarn1 * mrnkn01;
	return res;

	return DBL_MAX;
}


void PairEAMCrossZhou2::extra_check(int type){

	const char* pyName = "EAMcPyParam";

	switch (type) {
	case 0: {
		force->init();

		partial_check();

		double tparm[] = { 0.39, 8.13, 0.31, 2.54, 19.6, 0.54, 4.33, 0.76, 2.56, 20.2 };
		setFreeParams(tparm);
		const char* name = "CROSSZHOU2";
		error->add_chklog(0, name, "");

		// data from lammps
		double BoxChk[6], BoxRef[6] = {
			3.56122697302817, 4.21950572182400,
			3.59759043829400, 3.77073701438905,
			2.91781045871721, 3.95454207675545, };

		double ElaChk[9], ElaRef[9] = {
			235.501186722320, 151.436809869819, 104.183702895005,
			155.930279094700, 93.5751882121277,	 89.0062599780021,
			95.6057677045693, 109.921475102412,	 80.0814546781908, };

		addMDComputeAlloy();
		runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
		evalCompute(BoxChk, ElaChk);

		error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 8.7159603790968714e-06, 2.7267739948210386e-05);
		error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 8e-4, 4e-4, 0.00058204819442296085, 0.0018338233314710078);
		break;
	}
	case 1: {
		double param[2][10] = {
			{ 0.11, 12, 0.36, 2.55, 18, 0.33, 2.5, 0.69, 2.5, 22 },
			{ 0.29137322165698715, 11.999501206941419, 0.36049139436078964, 2.6830860360869333,
			  18.000007281781262, 0.14082373725269823, 2.5043248421117861, 0.65486567748972113,
			  2.4170297805186904, 22.000089418885207, },
		};
		error->add_chklog(0, pyName, "");
		error->check(FLERR, 10, paramVec.data(), param[0], 1, pyName, "p0/", 5e-15, 5e-15, 0, 0);
		addMDComputeAlloy(); runMDCompute(2, 0, 10, CuNiAlloyCost, AlloyChk, "cg", "dump.*.eam");
		error->check(FLERR, 10, paramVec.data(), param[1], 1, pyName, "p1/", 5e-15, 5e-15, 0, 0);
		if (paramVec[4] == param[0][4] || paramVec[9] == param[0][9]) {
			error->all(FLERR, "after cg, n1 == n1(init) or n2 == n2(init)");
		}
		break;
	}
	case 2: {
		double param[2][10] = {
			{ 0.11, 12, 0.36, 2.55, 18, 0.33, 2.5, 0.69, 2.5, 22 },
			{ 0.29137325936951519, 11.999501204611187, 0.36049136564425899, 2.6830861851171113,
			  18.000000000000000, 0.14082373725269820, 2.5043248403548413, 0.65486575026128868,
			  2.4170297144854511, 22.000000000000000, },
		};
		error->check(FLERR, 10, paramVec.data(), param[0], 1, pyName, "p0/", 5e-15, 5e-15, 0, 0);
		addMDComputeAlloy(); runMDCompute(2, 0, 10, CuNiAlloyCost, AlloyChk, "cg", "dump.*.eam");
		error->check(FLERR, 10, paramVec.data(), param[1], 1, pyName, "p2/", 5e-15, 5e-15, 0, 0);
		if (paramVec[4] != param[0][4] || paramVec[9] != param[0][9]) {
			error->all(FLERR, "after cg, n1 != n1(init) or n2 != n2(init)");
		}
		break;
	}
	case 3: {
		double param[2][14] = {
			{ 0, 1, 0, 1, 0.11, 12, 0.36, 2.55, 18, 0.33, 2.5, 0.69, 2.5, 22 },
			{ 0.20000000000000001, 0.99532474612290467, 0.16315921506213063, 1.0046699968882871,
			  0.19659061627926111, 11.999737702611506, 0.36030284865014284, 2.6040277773722060,
			  18.000004203605901, 0.22716823479682730, 2.5027285109334763, 0.67051191805549237,
			  2.4521639042567660, 22.000049851147512, },
		};
		error->add_chklog(0, pyName, "");
		error->check(FLERR, 14, paramVec.data(), param[0], 1, pyName, "p0/", 5e-15, 5e-15, 0, 0);
		addMDComputeAlloy(); runMDCompute(2, 0, 10, CuNiAlloyCost, AlloyChk, "cg", "dump.*.eam");
		error->check(FLERR, 14, paramVec.data(), param[1], 1, pyName, "p1/", 5e-15, 5e-15, 0, 0);
		if (paramVec[2] == param[0][2] || paramVec[3] == param[0][3] ||
			paramVec[8] == param[0][8] || paramVec[13] == param[0][13]) {
			error->all(FLERR, "after cg, g2 == 0 or s2 == 1 or n1 == n1(init) or n2 == n2(init)");
		}
		break;
	}
	case 4: {
		double param[2][14] = {
			{ 0, 1, 0, 1, 0.11, 12, 0.36, 2.55, 18, 0.33, 2.5, 0.69, 2.5, 22 },
			{ 0.19999999999999998, 0.98857948999762202, 0.00000000000000000, 1.0000000000000000,
			  0.20137187626827857, 11.999788637009354, 0.36023667036214746, 2.6074429598305091,
			  18.000000000000000, 0.22838220984471147, 2.5024323846690835, 0.67018786204218528,
			  2.4525645721054157, 22.000000000000000, },
		};
		error->check(FLERR, 14, paramVec.data(), param[0], 1, pyName, "p0/", 5e-15, 5e-15, 0, 0);
		addMDComputeAlloy(); runMDCompute(2, 0, 10, CuNiAlloyCost, AlloyChk, "cg", "dump.*.eam");
		error->check(FLERR, 14, paramVec.data(), param[1], 1, pyName, "p2/", 5e-15, 5e-15, 0, 0);
		if (paramVec[2] != param[0][2] || paramVec[3] != param[0][3] ||
			paramVec[8] != param[0][8] || paramVec[13] != param[0][13]) {
			error->all(FLERR, "after cg, g2 != 0 or s2 != 1 or n1 != n1(init) or n2 != n2(init)");
		}
		break;
	}
	}
}

void PairEAMCrossZhou2::partial_check(){
	double fchk[18], fref[] = {
		216.6639570626888, 1.038178128831252, 
		0.004398026225139191, 2.929577377588592, 
		1.02256092529304, 0.3569220543215451, 
	};

	double rlist[] = { 0.75, 1.85, 2.95 };

	int nr = 3;
	int idx = 0;

	for (int ir = 0; ir < nr; ir++){		
		fchk[idx++] = dcore(&cross_fvec[0], rlist[ir]);
	}
	for (int ir = 0; ir < nr; ir++){
		fchk[idx++] = dcore(&cross_fvec[5], rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSZHOU2", "Func",
		1e-13, 5e-14, 5.5220518069800002e-15, 1.6460757474137213e-14);
}
