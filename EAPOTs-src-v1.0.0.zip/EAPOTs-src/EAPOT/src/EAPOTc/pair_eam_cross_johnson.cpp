#include "pair_eam_cross_johnson.h"

#include "error.h"
#include "force.h"
#include "float.h"
#include "option_pair.h"

using namespace EAPOT_NS;

enum { DIRECT = 0, WEIGHT, LOG, POW };

PairEAMCrossJohnson::PairEAMCrossJohnson(EAPOT *eapot)
	: PairEAMCross(eapot) {

	styles.push_back("eam/cross/johnson");
	cross_fsize = 1;
	cross_csize = 0;

	phi_mode = DIRECT;
	phi_johnson = &PairEAMCrossJohnson::phi_direct;

	w1 = w2 = 0.5;
};



void PairEAMCrossJohnson::setFullParamsStyle()
{
	setFreeParamsStyle();
};

void PairEAMCrossJohnson::setFreeParamsStyle()
{
	w1 = cross_fvec[0];

	if (2 == cross_fsize) {
		w1 = cross_fvec[1];
	}
	else {
		w2 = 2.0 - w1;
	}

	PairEAM::setFreeParamsStyle();
};

void PairStyle::setPairEAMCrossJohnsonDof(void* pPair, int dof)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam/cross/johnson", 1);
	auto pair = (PairEAMCrossJohnson*)pPair;

	int ocross_fsize = pair->cross_fsize;
	pair->cross_fsize = dof;

	if (pair->cross_fsize != 1 && pair->cross_fsize != 2) {
		ErrorAll("Illegal setPairEAMCrossJohnsonDof(%d): (dof != 1 or 2)", dof);
	}
		
	if (ocross_fsize != pair->cross_fsize) {
		pair->fvec_clear();
		pair->fvec_allocate();
	}
}
void PairStyle::setPairEAMCrossJohnsonMode(void* pPair, const char* mode)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam/cross/johnson", 1);
	auto pair = (PairEAMCrossJohnson*)pPair;

	if (strcmp(mode, "direct") == 0) {
		pair->phi_mode = DIRECT;
		pair->phi_johnson = &PairEAMCrossJohnson::phi_direct;
	}
	else if (strcmp(mode, "weight") == 0) {
		pair->phi_mode = WEIGHT;
		pair->phi_johnson = &PairEAMCrossJohnson::phi_weight;
	}
	else if (strcmp(mode, "log") == 0) {
		pair->phi_mode = LOG;
		pair->phi_johnson = &PairEAMCrossJohnson::phi_log;
	}
	else if (strcmp(mode, "pow") == 0) {
		pair->phi_mode = POW;
		pair->phi_johnson = &PairEAMCrossJohnson::phi_pow;
	}
	else {
		ErrorAll("Illegal setPairEAMCrossJohnsonMode(%s): "
			"(mode!= direct, weight, log, or pow)", mode);
	}
}


double PairEAMCrossJohnson::cphi(double r) {

	double phi1 = (this->*phi_johnson)(1, 1, r);
	double phi2 = (this->*phi_johnson)(2, 2, r);

	return w1 * phi1 + w2 * phi2;
}


double PairEAMCrossJohnson::phi_direct(int itype, int jtype, double r) {

	switch (itype) {

	case 1: {
		double d0pa = core_phi(1, 1, r);
		double res = d0pa * (1.0 / 2.0);
		return res;
	}

	case 2: {
		double d0pb = core_phi(2, 2, r);
		double res = d0pb * (1.0 / 2.0);
		return res;
	}

	default: error->all(FLERR, "Pair Type i error");
	};

	return DBL_MAX;
}


double PairEAMCrossJohnson::phi_weight(int itype, int jtype, double r) {

	switch(itype){

	case 1:{

		double d0ra = core_rho(1, 1, r);
		double d0rb = core_rho(2, 2, r);
		double d0pa = core_phi(1, 1, r);

		double res = (d0pa * d0rb * (1.0 / 2.0)) / d0ra;

		return res;
	}

	case 2:{
		double d0ra = core_rho(1, 1, r);
		double d0rb = core_rho(2, 2, r);
		double d0pb = core_phi(2, 2, r);

		double res = (d0pb * d0ra * (1.0 / 2.0)) / d0rb;

		return res;
	}

	default: error->all(FLERR, "Pair Type i error");
	};

	return DBL_MAX;
}


double PairEAMCrossJohnson::phi_log(int itype, int jtype, double r) {

	switch(itype){

	case 1:{
		double d0ra = core_rho(1, 1, r);
		double d0rb = core_rho(2, 2, r);
		double d0pa = core_phi(1, 1, r);

		double res = d0pa * (log(d0rb / d0ra) + 1.0) * (1.0 / 2.0);

		return res;
	}

	case 2:{
		double d0ra = core_rho(1, 1, r);
		double d0rb = core_rho(2, 2, r);
		double d0pb = core_phi(2, 2, r);

		double res = d0pb * (log(d0ra / d0rb) + 1.0) * (1.0 / 2.0);

		return res;
	}

	default: error->all(FLERR, "Pair Type i error");
	};

	return DBL_MAX;
}


double PairEAMCrossJohnson::phi_pow(int itype, int jtype, double r) {

	switch(itype){

	case 1:{
		double d0ra = core_rho(1, 1, r);
		double d0rb = core_rho(2, 2, r);
		double d0pa = core_phi(1, 1, r);

		double res = (d0pa * 1.0 / (d0ra * d0ra) * (d0rb * d0rb)) / (1.0
			/ (d0ra * d0ra) * (d0rb * d0rb) + 1.0);

		return res;
	}

	case 2:{
		double d0ra = core_rho(1, 1, r);
		double d0rb = core_rho(2, 2, r);
		double d0pb = core_phi(2, 2, r);

		double res = d0pb / (1.0 / (d0ra * d0ra) * (d0rb * d0rb) + 1.0);

		return res;
	}

	default: error->all(FLERR, "Pair Type i error");
	};

	return DBL_MAX;
}


void PairEAMCrossJohnson::extra_check(int) {
	force->init();

	char name[32];

	// gradient_check, gradient_check, calculation_check, calculation_check
	double refloglist[4][6] = {
		{ 6.5694532258575578e-08, 1.8043708904791345e-07, 1.1005440318486334e-05, 3.2675347523246889e-05, 0.00080755415354027147, 0.0025231632600089269, },
		{ 8.3541726869640343e-09, 4.8409829256357284e-08, 1.3562669940640196e-05, 3.7770259034643181e-05, 0.00074420288409729116, 0.0021725232219906884, },
		{ 2.5322999253063472e-08, 7.1267635459726364e-08, 9.2531722506327985e-06, 2.9311872012514163e-05, 0.00063054740405904411, 0.0020145676573187113, },
		{ 6.5256675618741156e-09, 4.0559339442580722e-08, 9.4239574277188317e-06, 2.9653448996020928e-05, 0.00059215409152882001, 0.0016420202378595733, },
	};

	double BoxRef[4][6] = {
		{
			3.55552402293161,	4.20657161395432,
			3.58946403903111,	3.75607164482402,
			2.91698870628113,	3.92611701083060,
		}, {
			3.54936501846166,	4.21452086063308,
			3.57980984570583,	3.76224579248642,
			2.92043335041072,	3.91981452705175,
		}, {
			3.56194266979235,	4.19008410223100,
			3.59825782093643,	3.74150643377905,
			2.91652041163451,	3.91176716517507,
		}, {
			3.56126404768103,	4.19063945564585,
			3.59748604596297,	3.74186805085565,
			2.91657349824344,	3.91187783739612,
		}
	};

	double ElaRef[4][9] = {
		{
			241.75136540026900,	154.60579358658500,	107.11469512001400,
			153.17720972746200,	88.24087701680490,	91.04910119705470,
			90.50067481798470,	106.92174877431200,	77.47465409204300
		}, {
			249.28354385737600,	158.40115565176000,	110.69836943672300,
			151.59612335985100,	82.47563526867050,	94.57243860964730,
			88.64921736966440,	106.49859487790300,	75.38725014817870
		}, {
			235.86206014329300,	151.62082424186600,	104.36862739571100,
			158.09898778438500,	94.97863215328750,	89.81126376667510,
			89.22944382928230,	106.18314632460500,	76.97242910594300
		}, {
			235.82758362097600,	151.60394373511100,	104.34415903692800,
			156.98018966725800,	94.05336681031740,	89.57467087488250,
			89.28413617085310,	106.21364216213600,	76.96086593503880
		}
	};

	double BoxChk[6], ElaChk[9];
	addMDComputeAlloy();

	for (phi_mode = 0; phi_mode < 4; phi_mode++) {

		switch (phi_mode) {
		case 0:strcpy(name, "CROSSJsDir"); phi_johnson = &PairEAMCrossJohnson::phi_direct; break;
		case 1:strcpy(name, "CROSSJsWei"); phi_johnson = &PairEAMCrossJohnson::phi_weight; break;
		case 2:strcpy(name, "CROSSJsLog"); phi_johnson = &PairEAMCrossJohnson::phi_log; break;
		case 3:strcpy(name, "CROSSJsPow"); phi_johnson = &PairEAMCrossJohnson::phi_pow; break;
		default: error->all(FLERR, "Illegal phi_mode type");
		}
		double *reflog = refloglist[phi_mode];
		error->add_chklog(0, name, "");

		runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
		evalCompute(BoxChk, ElaChk);

		error->check(FLERR, 6, BoxChk, BoxRef[phi_mode], 1, name, "Box", 5e-5, 2e-5, reflog[2], reflog[3]);
		error->check(FLERR, 9, ElaChk, ElaRef[phi_mode], 1, name, "Ela", 9e-4, 5e-4, reflog[4], reflog[5]);
	}

}

// gradient_check, gradient_check, calculation_check, calculation_check
//double refloglist[4][4] = {
//	{ 6.5694532258575578e-08, 1.8043708904791345e-07, 0.00016194860552165455, 0.00075937613885297456, },
//	{ 8.3541726869640343e-09, 4.8409829256357284e-08, 0.00027416701178460375, 0.00089225580883426150, },
//	{ 2.5322999253063472e-08, 7.1267635459726364e-08, 0.00027066332550965735, 0.00080908351619198536, },
//	{ 6.5256675618741156e-09, 4.0559339442580722e-08, 8.0649170588543745e-05, 0.00037019596393721296, },
//};