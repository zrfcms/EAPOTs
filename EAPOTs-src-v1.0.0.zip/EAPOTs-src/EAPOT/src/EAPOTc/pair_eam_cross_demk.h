#ifdef PAIR_CLASS
PairStyle(eam/cross/demk, PairEAMCrossDemk)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_DEMK_H
#define EAPOT_PAIR_EAM_CROSS_DEMK_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossDemk : virtual public PairEAMCross
	{
	public:
		PairEAMCrossDemk(EAPOT *eapot);
		~PairEAMCrossDemk(){};

		double cphi(double r);

	private:
		void extra_check(int);
		void partial_check();
	};

}

#endif
#endif
#endif