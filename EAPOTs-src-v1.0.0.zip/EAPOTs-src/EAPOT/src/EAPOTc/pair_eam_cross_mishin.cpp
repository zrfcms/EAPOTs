#include "pair_eam_cross_mishin.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;

PairEAMCrossMishin::PairEAMCrossMishin(EAPOT *eapot)
	: PairEAMCross(eapot) {
	styles.push_back("eam/cross/mishin");
	cross_fsize = 9;
	cross_csize = 0;

	rc = h = E1 = r0 = 0;
	a = b = sig = g1 = g2 = 0;

	mh17 = mh16 = mh13 = mh12 = mh11 = mh10 = 0;
	mh9 = mh8 = mh7 = mh6 = mh5 = mh4 = 0;
	mh3 = mh2 = a3 = a2 = b3 = b2 = 0;
};


double PairEAMCrossMishin::cphi(double r) {
	if (r >= rc || r >= cutmax) return 0;

	double drc = r - rc;
	double dr0 = r - r0;
	double drc4 = drc * drc * drc * drc;
	double drc4mh4p = drc4 * mh4 + 1.0;
	double expabdr0 = exp(-a * b * dr0);
	double expbdr0 = exp(-b * dr0);

	double res = (E1 * drc4 * mh4 * (expabdr0 + sig - a * expbdr0)) / drc4mh4p
		+ g1 * PairEAMList::core_phi(2, 2, r) + g2 * PairEAMList::core_phi(1, 1, r);

	return res;
}

void PairEAMCrossMishin::setFullParamsStyle()
{
	setFreeParamsStyle();
};

void PairEAMCrossMishin::setFreeParamsStyle()
{
	rc = cross_fvec[0];
	h = cross_fvec[1];
	E1 = cross_fvec[2];
	r0 = cross_fvec[3];
	a = cross_fvec[4];
	b = cross_fvec[5];
	sig = cross_fvec[6];

	g1 = cross_fvec[7];
	g2 = cross_fvec[8];


	mh17 = 1.0 / pow(h, 17);
	mh16 = 1.0 / pow(h, 16);
	mh13 = 1.0 / pow(h, 13);
	mh12 = 1.0 / pow(h, 12);
	mh11 = 1.0 / pow(h, 11);
	mh10 = 1.0 / pow(h, 10);
	mh9 = 1.0 / (h*h*h*h*h*h*h*h*h);
	mh8 = 1.0 / (h*h*h*h*h*h*h*h);
	mh7 = 1.0 / (h*h*h*h*h*h*h);
	mh6 = 1.0 / (h*h*h*h*h*h);
	mh5 = 1.0 / (h*h*h*h*h);
	mh4 = 1.0 / (h*h*h*h);
	mh3 = 1.0 / (h*h*h);
	mh2 = 1.0 / (h*h);
	a3 = a * a*a;
	a2 = a * a;
	b3 = b * b*b;
	b2 = b * b;

	PairEAM::setFreeParamsStyle();
};

void PairEAMCrossMishin::extra_check(int) {
	force->init();

	partial_check();
	

	double tparm[] = {
		5.2, 4.533, 6.36726e-2, 4.43591, 6.67054,
		0.34906, -16.4051, 0.5, 0.6 };
	setFreeParams(tparm);
	const char* name = "CROSSMishin";
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.95438771911132, 3.71246067355995,
		3.94230342633396, 3.28473621248770,
		3.20890650950680, 3.25118288421918,
	};

	double ElaChk[9], ElaRef[9] = {
		149.073731025880, 111.690216382193, 57.6887092903497,
		142.349114196998, 114.067697254146, 55.5164693818814,
		89.4966179651826, 144.538307417536, 83.2097671338279,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 9.0798502620014386e-06, 4.5511193702786428e-05);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 8e-4, 4e-4, 0.00060128084246595013, 0.0027468566634521923);
}

void PairEAMCrossMishin::partial_check() {
	double fchk[8], fref[] = {
		   2.0134145743976529e+01,  		
		   4.9573224275845051e+00,  		
		   1.3809460578326616e+00,   
		   4.4751813308709676e-01,   		
		   1.4326593552150241e-01,   		
		   3.4664334706887831e-02,   		
		   4.0074972650174798e-03,   		
		   2.6829706004747621e-05,  		
	};

#define NUM 8
	double rlist[] = { 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0 };

	int idx = 0;
	for (int ir = 0; ir < NUM; ir++) {		
		fchk[idx++] = cphi(rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSMishin", "Func",
		8e-14, 8e-1, 2.2938781913915381e-15, 6.6814334424495507e-15);

#undef NUM

}
