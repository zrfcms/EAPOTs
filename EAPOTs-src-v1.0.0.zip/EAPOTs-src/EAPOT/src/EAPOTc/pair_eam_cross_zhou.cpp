#include "pair_eam_cross_zhou.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

#include "option_pair.h"
using namespace EAPOT_NS;

#define pow_s(x, y) (x<0?pow(-x, y):pow(x, y))
#define log_s(x) (x<0?log(-x):log(x))


PairEAMCrossZhou::PairEAMCrossZhou(EAPOT *eapot)
: PairEAMCross(eapot){
	styles.push_back("eam/cross/zhou");
	cross_fsize = 20;
	cross_csize = 0;
};

double PairEAMCrossZhou::cphi(double r){
	double res = 0;
	res += 0.5*dcore(&cross_fvec[0],  r);
	res -= 0.5*dcore(&cross_fvec[5],  r);
	res += 0.5*dcore(&cross_fvec[10], r);
	res -= 0.5*dcore(&cross_fvec[15], r);
	return res;
}

double PairEAMCrossZhou::dcore(double *c, double r){
	double A = c[0];
	double la = c[1];
	double lk = c[2];
	double re = c[3];
	double n = c[4];

	if (r >= cutmax) return 0.0;

	double rn1 = r / re - 1.0;
	double rnk = fabs(lk - r / re);
	double rnkn = pow_s(rnk, n);
	double explarn1 = exp(-la * rn1);
	double rnkn0 = rnkn + 1.0;
	double Aexplarn1 = A * explarn1;
	double mrnkn01 = 1.0 / rnkn0;
	double res = Aexplarn1 * mrnkn01;
	return res;
}


/*----------------------------------------------------------------------------------------------------------------------------------
Description
The first is three general checks:
1. Derivative calculation and numerical derivative comparison
2. Derivative calculation value compared with matlab
3. Test calculated values compared with lammps

Then the transformation check
1. Derivative calculation and numerical derivative comparison
2. Test calculated values compared with lammps (including structural optimization)
3. Test calculated values compared with lammps (multiple transformation values, without structural optimization)
4. Element potential transformation invariance check

Then revert to closing the transformation and proceed:
1.Compared with the previous matlab version
----------------------------------------------------------------------------------------------------------------------------------*/

void PairEAMCrossZhou::extra_check(int) {

	force->init();

	partial_check();

	double tparm[] = {
		0.054476123424834988, 11.451813574611243, 0.35957173175284329, 2.3585991703602200, 17.634409440168945,
		0.322656841822722640, 2.4456346562110625, 0.69032493650479765, 2.5558911939467714, 21.549271972585601,
		0.364412093777502830, 11.837186141427459, 0.30648236090248371, 2.5282102350524180, 13.025800120912425,
		0.330272317671061800, 5.6633873353592605, 0.75330378293117461, 2.6151491289119724, 20.742288736371094, };
	setFreeParams(tparm);
	const char* name = "CROSSZHOU";
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.55374732292373,4.21530755423795,
		3.59071905365609, 3.76462075513593,
		2.92079916106387, 3.97932493494953,
	};

	double ElaChk[9], ElaRef[9] = {
		230.157225737247,148.821004829892,101.254182306653,
		132.162789009403,78.3591717330796,79.9929334490735,
		142.169973653993,139.903051010046,108.632747316452,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 9.6146954839269135e-06, 2.69357716870601e-05);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 9e-4, 6e-4, 0.00082360775161914579, 0.0023446133325977264);


	/*------------------------------------------------------------------
	// Transformation check
	-------------------------------------------------------------------*/

	double tparm1[24] = { -0.004, 1.05, 0.004, 0.95 };

	temp_memcpy(&tparm1[4], paramVec.data(), 20);
	pairStyle->enablePairEAMListTransform(force->pair, 1);

	/*------------------------------------------------------------------
	1. Test calculated values compared with lammps (including structural optimization)
	-------------------------------------------------------------------*/

	setFreeParams(tparm1);
	transform_calculation_check();

	/*------------------------------------------------------------------
	2. Test calculated values compared with lammps (multiple transformation values)
	-------------------------------------------------------------------*/

	transform_energy_check(tparm1);
}


void PairEAMCrossZhou::partial_check(){
	double fchk[12], fref[] = {
		216.6639570626888, 
		1.038178128831252, 
		0.004398026225139191,
		2.929577377588592, 

		1.02256092529304, 
		0.3569220543215451,
		2426.537503129041,
		14.06880634122468, 

		0.07149397307413423,
		30.24646735151483, 
		2.793264429098382, 
		0.2579582274141142,
	};

	double rlist[] = { 0.75, 1.85, 2.95 };

	int nr = 3, idx = 0;

	for (int ir = 0; ir < nr; ir++){		
		fchk[idx++] = dcore(&cross_fvec[0], rlist[ir]);
		
	}
	for (int ir = 0; ir < nr; ir++){		
		fchk[idx++] = dcore(&cross_fvec[5], rlist[ir]);
		
	}
	for (int ir = 0; ir < nr; ir++){		
		fchk[idx++] = dcore(&cross_fvec[10], rlist[ir]);
	
	}
	for (int ir = 0; ir < nr; ir++){		
		fchk[idx++] = dcore(&cross_fvec[15], rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSZHOU", "Func",
		1e-13, 5e-14, 5.5220518069800002e-15, 2.7659867338549096e-14);
}



