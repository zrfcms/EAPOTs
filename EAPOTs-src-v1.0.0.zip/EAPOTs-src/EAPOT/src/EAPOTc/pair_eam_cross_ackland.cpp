#include "pair_eam_cross_ackland.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;


PairEAMCrossAckland::PairEAMCrossAckland(EAPOT *eapot)
	: PairEAMCross(eapot) {
	styles.push_back("eam/cross/ackland");
	cross_fsize = 6;
	cross_csize = 1;

	c = c0 = c1 = c2 = 0;
	B = a = a0 = a2 = 0;

};

double PairEAMCrossAckland::cphi1(double r) {

	double cr = c - r;
	double cr2 = cr * cr;
	double r2 = r * r;

	double res = cr2 * (c0 + c1 * r + c2 * r2);

	return res;
}

double PairEAMCrossAckland::cphi2(double r) {

	double a0r = a0 - r;
	double Expmar = exp(-a * r);
	double a0r3 = a0r * a0r * a0r;

	double res = B * Expmar * a0r3;

	return res;
}

// phi1 = (c - r) ^ 2 * (c0 + c1 * r + c2 * r ^ 2);
// phi2 = B * (a0 - r) ^ 3 * exp(-a * r);


double PairEAMCrossAckland::cphi(double r) {
	if (r >= cutmax) return 0;

	double res = 0;

	if (r < c) res += cphi1(r);
	if (r < a0) res += cphi2(r);

	return res;
}


void PairEAMCrossAckland::setFullParamsStyle()
{
	a0 = cross_cvec[0];
	setFreeParamsStyle();
};

void PairEAMCrossAckland::setFreeParamsStyle()
{
	c = cross_fvec[0];
	c0 = cross_fvec[1];
	c1 = cross_fvec[2];
	c2 = cross_fvec[3];
	B = cross_fvec[4];
	a = cross_fvec[5];

	a2 = a * a;

	PairEAM::setFreeParamsStyle();
};

void PairEAMCrossAckland::extra_check(int) {

	force->init();

	partial_check();
	
	double tparm[] = { 4.5, 0.745, -0.5229, 0.08162, 6, 0.8, 2.8585 };
	setFreeParams(tparm);
	const char* name = "CROSSAckland";
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.6775, 4.2048,
		3.7021, 3.7856,
		2.9701, 4.0465,
	};

	double ElaChk[9], ElaRef[9] = {
		115.69, 78.952, 59.231,
		164.72,  130.3, 65.768,
		167.41, 156.55, 106.34,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 1.3034897809854458e-05, 4.6555803678456573e-05);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 5e-4, 2e-4, 0.00013252564040481897, 0.00088914437531509175);
}


void PairEAMCrossAckland::partial_check() {
#define NUM 8

	double fchk[NUM], fref[NUM] = {

		   3.9126178905975216e+01,		
		   8.9469787593426311e+00,  
		   1.8456955310833039e+00,		
		   3.6768340799999988e-01, 		
		  -1.2622333850000020e-01, 		
		  -4.0148848000000077e-02,		
		   0.0000000000000000e+00, 		
		   0.0000000000000000e+00,
	};

	double rlist[] = { 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0 };

	int idx = 0;
	for (int ir = 0; ir < NUM; ir++) {		
		fchk[idx++] = cphi(rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSAckland", "Func", 
		8e-14, 8e-15, 1.9854264631458299e-16, 1.9854264631458299e-16);

#undef NUM

}

/*
 3.54326187800000  4.42353405800000 217.004738 135.821362 107.953650
 3.59913679100000  3.79267187300000 178.318474 122.428433  74.612010
 2.83732570900000  4.04921838000000 135.107574 161.999854 104.091178

   0   7.49e-02        0%        0%        0%        0%
 3.67752009429471  4.20483177155751 115.702188  78.959391  59.228234
 3.70206967823702  3.78564934490097 164.742178 130.317032  65.775957
 2.97008667263030  4.04653182502287 167.400730 156.535764 106.326568
 3.6775				4.2048	 		115.69	  78.952	  59.231
 3.7021				3.7856	 		164.72	   130.3	  65.768
 4.9554				3.5468	 		276.54	  36.954	  21.989
 2.9701				4.0465	 		167.41	  156.55	  106.34

  50   1.48e-02        0%        0%        0%        0%
 3.59740410461210  4.24606399210601 217.589861 141.893398  96.669909
 3.63666587919358  3.80846993896678 187.163397 125.291434  90.740447
 2.90246172033959  4.12609974035857 166.080302 138.397370 116.515095
 3.5974				4.2461	 		217.61	   141.9	  96.674
 3.6367				3.8085	 		187.17	   125.3	  90.735
 4.869				3.6756	 		313.66	  47.937	  6.8552
 2.9025				4.1261	 		166.08	   138.4	  116.51

 100   1.48e-02        0%        0%        0%        0%
 3.59780328062524  4.25196338446766 217.243666 141.710542  96.515829
 3.63707745049071  3.81449651044846 187.215189 125.460608  90.643292
 2.90297558899660  4.13376366148992 166.234721 138.691602 116.523241
 3.5978				 4.252	 		217.26	  141.72	  96.508
 3.6371				3.8145	 		187.21	  125.46	  90.639
 4.8697				3.6809	 		313.61	  47.969	  -6.884
 2.903				4.1338	 		166.24	   138.7	  116.53

 150   1.48e-02        0%        0%        0%        0%
 3.59780772875298  4.25196338449146 217.236869 141.707034  96.512643
 3.63707777057861  3.81449651045377 187.215024 125.460637  90.643114
 2.90297633831235  4.13376366150663 166.234633 138.691718 116.522941
 3.5978				 4.252	 		217.26	  141.72	  96.508
 3.6371				3.8145	 		187.21	  125.46	  90.639
 4.8697				3.6809	 		313.61	  47.969	  -6.884
 2.903				4.1338	 		166.24	   138.7	  116.53
*/