#ifdef PAIR_CLASS
PairStyle(eam/cross/johnson, PairEAMCrossJohnson)
#else

#ifdef LIBAPI
LIBAPI(void, setPairEAMCrossJohnsonDof, (APITYPE void* pPair, int dof), (APINAME pPair, dof));
LIBAPI(void, setPairEAMCrossJohnsonMode, (APITYPE void* pPair, const char* mode), (APINAME pPair, mode));
#else

#ifndef EAPOT_PAIR_EAM_CROSS_JOHNSON_H
#define EAPOT_PAIR_EAM_CROSS_JOHNSON_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossJohnson : virtual public PairEAMCross
	{
		friend class PairStyle;
	public:
		PairEAMCrossJohnson(EAPOT *eapot);
		~PairEAMCrossJohnson(){};

		double cphi(double r);

		double phi_direct(int, int, double);
		double phi_weight(int, int, double);
		double phi_log(int, int, double);
		double phi_pow(int, int, double);

		typedef double (PairEAMCrossJohnson::*PhiPtr)(int, int, double);

		PhiPtr phi_johnson;

		void setFullParamsStyle();
		void setFreeParamsStyle();

	private:

		int phi_mode;

		double w1, w2;

	private:
		void extra_check(int);
	};

}

#endif
#endif
#endif