#ifdef PAIR_CLASS
PairStyle(eam/list, PairEAMList)
#else

#ifdef LIBAPI
LIBAPI(void, enablePairEAMListTransform, (APITYPE void* pPair, int flag), (APINAME pPair, flag));
LIBAPI(void, inputPairEAMListFromFunc, (APITYPE void* pPair, const char** pele), (APINAME pPair, pele));
LIBAPI(void, inputPairEAMListFromFS, (APITYPE void* pPair, const char* file, const char** pele), (APINAME pPair, file, pele));
LIBAPI(void, inputPairEAMListFromAlloy, (APITYPE void* pPair, const char* file, const char** pele), (APINAME pPair, file, pele));
#else

#ifndef EAPOT_PAIR_EAM_LIST_H
#define EAPOT_PAIR_EAM_LIST_H

#include "pair_eam.h"

#include <string>
#include <vector>

namespace EAPOT_NS {

	class PairEAMList : public PairEAM
	{
		friend class PairStyle;
	public:
		PairEAMList(EAPOT *eapot);
		~PairEAMList();

		typedef const char* CPCHAR;
		enum class PotModeEnum { EMPTY, FUNC, SET, FS } potModeEnum;
		int transformFlag;
		int map_allocated;					// 0/1 = whether arrays are allocated

		// Encapsulation transformation operation on core functions
		virtual double emb(int type, double x);
		virtual double rho(int itype, int jtype, double x);
		virtual double phi(int itype, int jtype, double x);

		// list core functions for interpolation
		virtual double core_emb(int type, double x);
		virtual double core_rho(int itype, int jtype, double x);
		virtual double core_phi(int itype, int jtype, double x);

		virtual void init_style();
		
		void map_alloc();
		void map_type2array();
		virtual void fvec_allocate();

		virtual void array2spline();
		void grab(FILE*, int, double*);
		void interpolate(int, double, double*, double**);

		virtual void extra_check(int);

	//Inheritance code
	public:
		// potentials as array data		
		int nfrho, nrhor, nz2r;
		int* map, * type2frho, ** type2rhor, ** type2z2r;	// which element each atom type maps to
		double **frho, **rhor, **z2r;						// different from LAMMMPS for memory start

		// potentials in spline form used for force computation
		PairEAMFmt list;
		double list_rdr, list_rdrho, list_rhomax;
		double ***rhor_spline, ***frho_spline, ***z2r_spline;

	protected:
		// potentials as file data                

		struct Funcfl {
			PairEAMFmt fmt;
			std::string file, element;			
			double *frho, *rhor, *z2r;
		};
		Funcfl *funcfl;
		int nfuncfl;

		void read_file_func(CPCHAR);
		void file2array_func();
		void check_function_func(int, const char*);
		void extra_check_func(int);

		struct Setfl {
			PairEAMFmt fmt;
			std::vector<std::string> elements;
			double **frho, **rhor, ***z2r;
		};
		Setfl *setfl;

		void read_file_set(CPCHAR);
		void file2array_set();
		void extra_check_set(int);

		struct Fs {
			PairEAMFmt fmt;
			std::vector<std::string> elements;
			double **frho, ***rhor, ***z2r;
		};
		Fs *fs;

		void read_file_fs(CPCHAR);
		void file2array_fs();
		void extra_check_fs(int);

	};

}

#endif
#endif
#endif