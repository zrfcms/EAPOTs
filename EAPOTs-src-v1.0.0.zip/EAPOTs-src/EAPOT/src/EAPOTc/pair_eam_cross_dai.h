#ifdef PAIR_CLASS
PairStyle(eam/cross/dai, PairEAMCrossDai)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_DAI_H
#define EAPOT_PAIR_EAM_CROSS_DAI_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossDai : virtual public PairEAMCross
	{
	public:
		PairEAMCrossDai(EAPOT *eapot);
		~PairEAMCrossDai(){};

		double cphi(double r);

		void setFullParamsStyle();
		void setFreeParamsStyle();
	private:
		double rc1, c0, c1, c2, c3, c4;
		double m;

	private:
		void extra_check(int);
		void partial_check();
	};

}

#endif
#endif
#endif