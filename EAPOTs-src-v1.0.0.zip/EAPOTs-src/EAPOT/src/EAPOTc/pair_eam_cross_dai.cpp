#include "pair_eam_cross_dai.h"
#include "float.h"

#include "memory.h"
#include "error.h"
#include "force.h"


using namespace EAPOT_NS;

PairEAMCrossDai::PairEAMCrossDai(EAPOT *eapot)
: PairEAMCross(eapot){
	styles.push_back("eam/cross/dai");
	cross_fsize = 6;
	cross_csize = 1;

	rc1 = c0 = c1 = 0;
	c2 = c3 = c4 = 0;
	m = 0;
};


double PairEAMCrossDai::cphi(double r){

	if (r >= rc1 || r >= cutmax) return 0;

	double drc1 = rc1 - r;
	double r2 = r*r;
	double r3 = r*r*r;
	double r4 = r*r*r*r;
	double d0pPow = pow(drc1, m);
	double d0pPoly = c4*r4 + c3*r3 + c2*r2 + c1*r + c0;
	return d0pPow*d0pPoly;
}


void PairEAMCrossDai::setFullParamsStyle()
{
	m = cross_cvec[0];
	setFreeParamsStyle();
};

void PairEAMCrossDai::setFreeParamsStyle()
{
	rc1 = cross_fvec[0];
	c0 = cross_fvec[1];
	c1 = cross_fvec[2];
	c2 = cross_fvec[3];
	c3 = cross_fvec[4];
	c4 = cross_fvec[5];

	PairEAM::setFreeParamsStyle();
};

void PairEAMCrossDai::extra_check(int) {
	force->init();

	partial_check();

	double tparm[] = { 5.0, 0.10852660367849, -0.0119421498558678,
		-0.0588897933253738, 0.0270942994462704, -0.00351640886741559, 4 };
	setFreeParams(tparm);
	const char* name = "CROSSDai";
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.58918284845795,	4.13238613761830,
		3.64073056867706,	3.69399165961905,
		2.95422973032434,	3.87433463267624,
	};

	double ElaChk[9], ElaRef[9] = {
		169.814849892136,	118.188852942423,	72.4078199880618,
		129.217580376693,	97.7142100040129,	60.5607563934514,
		129.367508436867,	129.105860510322,	84.1688566535025,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 4.14126086916777e-06, 6.6918306555942503e-06);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 5e-4, 2e-4, 0.00015960188260817667, 0.00070065012284412889);
}

void PairEAMCrossDai::partial_check(){
	double fchk[3], fref[] = {
		1.188231616957434300e+01, 
		6.447417065891558600e-02,
		8.171564915399056100e-03,
	};

	int nrlist = 3;
	double rlist[] = { 0.5, 1, 2.0 };
	for (int i = 0; i < nrlist; i++) rlist[i] *= 3.615 / sqrt(2);


	int idx = 0;
	for (int ir = 0; ir < nrlist; ir++){		
		fchk[idx++] = cphi(rlist[ir]);
	}

	error->check(FLERR, idx, fchk, fref, 0, "CROSSDai", "Func", 5e-15, 1e-15, 0, 0);
}


