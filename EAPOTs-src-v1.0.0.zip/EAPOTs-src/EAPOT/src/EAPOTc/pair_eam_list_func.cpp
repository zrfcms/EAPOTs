#include "pair_eam_list.h"

#include <string.h>
#include "memory.h"
#include "error.h"
#include "force.h"
#include "input.h"

#include "option_pair.h"
using namespace EAPOT_NS;

#define MAXLINE 1024

void PairStyle::inputPairEAMListFromFunc(void* pPair, const char** pele)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam/list", 1);
	auto pair = (PairEAMList*)pPair;

	pair->potModeEnum = PairEAMList::PotModeEnum::FUNC;
	if (!pair->map_allocated) pair->map_alloc();

	if (pair->funcfl) {
		for (int i = 0; i < pair->nfuncfl; i++) {
			memory->destroy(pair->funcfl[i].frho);
			memory->destroy(pair->funcfl[i].rhor);
			memory->destroy(pair->funcfl[i].z2r);
		}		
	}

	int ntypes = force->get_ntypes();		//modify lammps for atom->ntypes
	pair->funcfl = new PairEAMList::Funcfl[ntypes];

	pair->nfuncfl = 0;
	for (int i = 0; i < ntypes; i++) {
		if (!pele[i]) {
			ErrorAll("Illegal PairEAMListCoeff command: Incorrect elements[%d]", i);
			return;
		}
		pair->nfuncfl++;
		pair->read_file_func(pele[i]);
		pair->funcfl[i].file = pele[i];
	}
	//nfuncfl is already = ntypes
	for (int i = 1; i <= ntypes; i++) {
		pair->map[i] = i - 1;
	}
}



void PairEAMList::read_file_func(CPCHAR filename) {
	Funcfl *file = &funcfl[nfuncfl - 1];

	char line[MAXLINE], * ctmp;
	FILE* fptr = input->open(filename, "r");

	int nwords;
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);

	ctmp = strtok(line, " \t\n\r\f");	
	file->element = strtok(NULL, " \t\n\r\f");

	fgets(line, MAXLINE, fptr);
	PairEAMFmt& fmt = file->fmt;
	nwords = sscanf(line, "%d %lg %d %lg %lg",
		&fmt.nrho, &fmt.drho, &fmt.nr, &fmt.dr, &fmt.cut);

	if ((nwords != 5) || (fmt.nrho <= 0) || (fmt.nr <= 0) || (fmt.dr <= 0.0))
		error->all(FLERR, "Invalid EAM potential file");

	fgets(line, MAXLINE, fptr);
	memory->create(file->frho, (fmt.nrho + 1), "pair:frho");
	memory->create(file->rhor, (fmt.nr + 1), "pair:rhor");
	memory->create(file->z2r, (fmt.nr + 1), "pair:zr");

	grab(fptr, fmt.nrho, &file->frho[1]);
	grab(fptr, fmt.nr, &file->rhor[1]);
	grab(fptr, fmt.nr, &file->z2r[1]);

	fclose(fptr);
}

void PairEAMList::file2array_func() {
	int i, j, k, m, n;
	int ntypes = force->get_ntypes();
	double sixth = 1.0 / 6.0;

	nfrho = nfuncfl + 1;					// nfrho = # of funcfl files + 1 for zero array
	nrhor = nfuncfl;						// nrhor = # of funcfl files
	nz2r = nfuncfl * (nfuncfl + 1) / 2;		// nz2r = N*(N+1)/2 where N = # of funcfl files

	memory->destroy(frho);
	memory->destroy(rhor);
	memory->destroy(z2r);

	if (funcfl->frho) {
		// determine max function params from all active funcfl files
		int active;			// active means some element is pointing at it via map
		double rmax;
		list.dr = list.drho = rmax = list_rhomax = 0.0;

		for (int i = 0; i < nfuncfl; i++) {
			active = 0;
			for (j = 1; j <= ntypes; j++)
				if (map[j] == i) active = 1;
			if (active == 0) continue;
			PairEAMFmt& fmt = funcfl[i].fmt;
			list.dr = MAX(list.dr, fmt.dr);
			list.drho = MAX(list.drho, fmt.drho);
			rmax = MAX(rmax, ((size_t)fmt.nr - 1) * fmt.dr);
			list_rhomax = MAX(list_rhomax, ((size_t)fmt.nrho - 1) * fmt.drho);
		}

		// set nr,nrho from cutoff and spacings
		// 0.5 is for round-off in divide
		list.nr = static_cast<int> (rmax / list.dr + 0.5);
		list.nrho = static_cast<int> (list_rhomax / list.drho + 0.5);
	}
	else {
		list = m_dump;
		list_rhomax = ((size_t)list.nrho - 1) * list.drho;
	}

	memory->create(frho, nfrho, list.nrho, "pair:frho");
	memory->create(rhor, nrhor, list.nr + 1, "pair:rhor");
	memory->create(z2r, nz2r, list.nr + 1, "pair:z2r");

	if (!funcfl) {
		temp_memset0(frho[0], nfrho * list.nrho);
		temp_memset0(rhor[0], nrhor * list.nr);
		temp_memset0(z2r[0], nz2r * list.nr);
		return;
	}
	
	// interpolate each element's frho, rhor, pair z2r to a single grid and cutoff

	double r, p, cof1, cof2, cof3, cof4;

	n = 0;
	for (i = 0; i < nfuncfl; i++) {
		Funcfl *file = &funcfl[i];
		for (m = 0; m < list.nrho; m++) {
			r = m* list.drho;
			p = r / file->fmt.drho + 1.0;
			k = static_cast<int> (p);
			k = MIN(k, file->fmt.nrho - 2);
			k = MAX(k, 2);
			p -= k;
			p = MIN(p, 2.0);
			cof1 = -sixth*p*(p - 1.0)*(p - 2.0);
			cof2 = 0.5*(p*p - 1.0)*(p - 2.0);
			cof3 = -0.5*p*(p + 1.0)*(p - 2.0);
			cof4 = sixth*p*(p*p - 1.0);
			frho[n][m] = cof1*file->frho[k - 1] + cof2*file->frho[k] +
				cof3*file->frho[k + 1] + cof4*file->frho[k + 2];

		}
		n++;
	}

	// interpolate each file's rhor to a single grid and cutoff

	n = 0;
	for (i = 0; i < nfuncfl; i++) {
		Funcfl *file = &funcfl[i];
		for (m = 0; m < list.nr; m++) {
			r = m * list.dr;
			p = r / file->fmt.dr + 1.0;
			k = static_cast<int> (p);
			k = MIN(k, file->fmt.nr - 2);
			k = MAX(k, 2);
			p -= k;
			p = MIN(p, 2.0);
			cof1 = -sixth*p*(p - 1.0)*(p - 2.0);
			cof2 = 0.5*(p*p - 1.0)*(p - 2.0);
			cof3 = -0.5*p*(p + 1.0)*(p - 2.0);
			cof4 = sixth*p*(p*p - 1.0);
			rhor[n][m] = cof1*file->rhor[k - 1] + cof2*file->rhor[k] +
				cof3*file->rhor[k + 1] + cof4*file->rhor[k + 2];
		}
		n++;
	}

	// create a z2r array for each file against other files, only for I >= J
	// interpolate zri and zrj to a single grid and cutoff

	double zri, zrj;

	n = 0;
	for (i = 0; i < nfuncfl; i++) {
		Funcfl *ifile = &funcfl[i];
		for (j = 0; j <= i; j++) {
			Funcfl *jfile = &funcfl[j];

			for (m = 0; m < list.nr; m++) {
				r = m * list.dr;

				p = r / ifile->fmt.dr + 1.0;
				k = static_cast<int> (p);
				k = MIN(k, ifile->fmt.nr - 2);
				k = MAX(k, 2);
				p -= k;
				p = MIN(p, 2.0);
				cof1 = -sixth*p*(p - 1.0)*(p - 2.0);
				cof2 = 0.5*(p*p - 1.0)*(p - 2.0);
				cof3 = -0.5*p*(p + 1.0)*(p - 2.0);
				cof4 = sixth*p*(p*p - 1.0);
				zri = cof1*ifile->z2r[k - 1] + cof2*ifile->z2r[k] +
					cof3*ifile->z2r[k + 1] + cof4*ifile->z2r[k + 2];

				if (i == j) {
					z2r[n][m] = zri;
					continue;
				}

				p = r / jfile->fmt.dr + 1.0;
				k = static_cast<int> (p);
				k = MIN(k, jfile->fmt.nr - 2);
				k = MAX(k, 2);
				p -= k;
				p = MIN(p, 2.0);
				cof1 = -sixth*p*(p - 1.0)*(p - 2.0);
				cof2 = 0.5*(p*p - 1.0)*(p - 2.0);
				cof3 = -0.5*p*(p + 1.0)*(p - 2.0);
				cof4 = sixth*p*(p*p - 1.0);
				zrj = cof1*jfile->z2r[k - 1] + cof2*jfile->z2r[k] +
					cof3*jfile->z2r[k + 1] + cof4*jfile->z2r[k + 2];

				z2r[n][m] = (zri + zrj)*0.5;
			}
			n++;
		}
	}

	// add extra frho of zeroes for non-EAM types to point to (pair hybrid)
	// this is necessary b/c fp is still computed for non-EAM atoms

	temp_memset0(frho[nfrho - 1], list.nrho);
}

//Source of error in check: check_function()
//		p						dFemb
//set	0.067154330648861560	0.0041135638259636141
//func	0.067154330648861560	0.0041135638259608576
//err:6.7e-13
//
//
//File list function value comparison:
//		m		432						433						434						435
//set			-1.9769900138602690		-1.9732686842071090		-1.9695227846581020		-1.9657523570850861
//func	p		5.6843418860808015e-14	0						0						0
//func	frho	-1.9769900138602687		-1.9732686842071090		-1.9695227846581020		-1.9657523570850861
//
//
//Interpolation coefficient comparison:
//		0						1						2						
//set 	-1.0278902451692652e-07	4.2333915624878627e-05	0.0041107213837441679	
//func	-1.0278903561644626e-07	4.2333915639680697e-05	0.0041107213837404677	
//
//		3						4						5						6
//set 	-2.7410406537847071e-09	1.6933566249951451e-06	0.00032885771069953346	-2.7923868193621599
//func	-2.7410409497719002e-09	1.6933566255872279e-06	0.00032885771069923742	-2.7923868193621599	

void PairEAMList::extra_check_func(int) {

	const char* name;
	double t[] = { 0, 1, 0, 1, 0.07, 0.93, 0.04, 0.94 };
	setFullParams(t);

/*----------------------------------------------------------------------------------------
							File data format is consistent LV1
-----------------------------------------------------------------------------------------*/
	name = "EAMLIST/S/v1";
	check_function_func(0, name);

	double tparm[] = { 0.39, 8.13, 0.31, 2.54, 19.6, 0.54, 4.33, 0.76, 2.56, 20.2 };
	setFreeParams(tparm);
	error->add_chklog(0, name, "");

	// data from lammps
	double BoxChk[6], BoxRef[6] = {
		3.55552402293160, 4.20657161395432,
		3.58946403903111, 3.75607164482402,
		2.91698870628112, 3.92611701083060,
	};

	double ElaChk[9], ElaRef[9] = {
		241.749105354978, 154.612382035994, 107.119159559688,
		153.156758765441, 88.2221448250283, 91.0645100323817,
		90.4989559411854, 106.924542648983, 77.4896928643139,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 1.100544031576449e-05, 3.2675347509381922e-05);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 8e-4, 4e-4, 0.00067432085594045367, 0.0019510783368139281);
	pairStyle->enablePairEAMListTransform(force->pair, 0);
/*----------------------------------------------------------------------------------------
							File data format is different LV2
-----------------------------------------------------------------------------------------*/

	const char* cmd1[] = {	"../../res/pot/Cus.eam", "../../res/pot/Nis.eam" };
	pairStyle->inputPairEAMListFromFunc(force->pair, cmd1);
	init_style();

	name = "EAMLIST/S/v2";
	check_function_func(1, name);

	error->add_chklog(0, name, "");
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 3.9202232268337337e-05, 6.6908400199233497e-05);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 8e-4, 4e-4, 0.00058703059004444505, 0.0016435233773779776);
	pairStyle->enablePairEAMListTransform(force->pair, 0);

	/*----------------------------------------------------------------------------------------
							File data format is different LV3
	-----------------------------------------------------------------------------------------*/

	const char* cmd2[] = {
		"../../res/pot/Cut.eam", "../../res/pot/Nit.eam"
	};
	pairStyle->inputPairEAMListFromFunc(force->pair, cmd2);
	init_style();

	name = "EAMLIST/S/v3";
	check_function_func(2, name);

	error->add_chklog(0, name, "");
	// data from lammps
	double BoxRef3[6] = {
		3.51704035047065, 4.23933965529792,
		3.57150312247958, 3.80363231242627,
		2.85180369966979, 3.93834275749803,
	};

	double ElaRef3[9] = {
		276.386259519047, 168.274194924760, 131.801328456267,
		238.782119111161, 162.300645639235, 101.130665199951,
		59.6220245909857, 123.196962657513, 78.6316827944551,
	};

	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef3, 1, name, "Box", 5e-5, 2e-5, 4.1755265336701581e-05, 7.7110594889264245e-05);
	error->check(FLERR, 9, ElaChk, ElaRef3, 1, name, "Ela", 8e-4, 4e-4, 0.00059207938367223821, 0.0018059566680594333);
	pairStyle->enablePairEAMListTransform(force->pair, 0);

#undef NCMD
}

void PairEAMList::check_function_func(int transFlag, const char* name) {

	double v[6], r, rhot;
	double chkmax[3] = {0.0, 0.0, 0.0}; 
	double chkall[3] = { 0.0, 0.0, 0.0 };
	double cutmax = 8e-11, cutall = 8e-11;
	if (transFlag == 0) {
		cutmax = 8e-13; cutall = 8e-13;
		chkmax[0] = 0.00000000000000000000; chkall[0] = 0.00000000000000000000;
		chkmax[1] = 1.3316917836287793e-16; chkall[1] = 1.3316917836287793e-16;
		chkmax[2] = 6.595194074260168e-16;  chkall[2] = 6.595194074260168e-16;
	}
	else if (transFlag == 1) {
		chkmax[0] = 1.5903696443212842e-16; chkall[0] = 3.0539051606963842e-16;
		chkmax[1] = 2.6760325782297066e-12; chkall[1] = 2.7506127944011829e-12;
		chkmax[2] = 1.3341850873215758e-12; chkall[2] = 2.2382481870310959e-12;
	}
	else if (transFlag == 2) {
		chkmax[0] = 3.0358093423051691e-15; chkall[0] = 3.6348267389940285e-15;
		chkmax[1] = 2.6760954342586969e-12; chkall[1] = 2.7507806429701269e-12;
		chkmax[2] = 1.4829705770363125e-12; chkall[2] = 2.336535057494111e-12;
	}

	error->add_chklog(0, name, "");

#define NITEM	2
#define NCOM	2
#define AtomI	fchk[0][i]  

	double fchk[NCOM + 2][NITEM] = {
		{ 1, 2, },											// itype
		{ 42.105860257539788, 34.565372346451909, },		// rhot         
		{ -1.5171794769627023, -2.7923647275070120, },		// Femb             
	};

	// Level 3 check includes translation
	if (transFlag == 2) {
		fchk[1][0] = 30.5525;
		fchk[2][0] = -2.12854650961554;
		fchk[3][0] = 0.030579924957781012;

		fchk[2][0] += fchk[1][0] * 0.10;
		fchk[1][0] *= 1.6;
		fchk[3][0] = (fchk[3][0] + 0.10) / 1.6;

		fchk[2][1] += fchk[1][1] * 0.03;
		fchk[1][1] *= 0.7;
		fchk[3][1] = (fchk[3][1] + 0.03) / 0.7;
	}

	// Femb
	for (int i = 0; i < NITEM; i++) {
		rhot = fchk[1][i];
		v[i] = emb(static_cast<int>(AtomI), rhot);
	}
	error->check(FLERR, NCOM, v, fchk[2], 1, name, "F", cutmax, cutall, chkmax[0], chkall[0]);


#undef NITEM
#undef NCOM
#undef AtomI


#define NITEM	6
#define NCOM	5
#define AtomI	rchk[0][i]
#define AtomJ	rchk[1][i]

	double rchk[NCOM + 3][NITEM] = {
		{ 2, 1, 2, 2, 2, 1, },																														// 1 jtype
		{ 1, 1, 1, 1, 2, 2, },																														// 0 itype
		{ 4.53119999999991840, 12.390400000000003,     14.668800000000026,   2.2784000000000244,     6.1951999999999998,    19.174399999999817, },	// 2 rsq
		{ 3.33477472272109750, 0.30566272837864322,    0.30786730665995404,  7.92832011566740660,   2.01459913230545990,  0.055196725082542739, },	// 3 rho
		{ -5.4158666509558220, -0.51650669232675772,  -0.30862208503893929, -15.4150649612716620,  -2.81758113549102830,  -0.40032416555516920, },  // 4 drhoi
		{ -4.6639543317864911, -0.516506692326757720, -0.440638886386845670,-11.08840207320282000,  -2.8175811354910283,  -0.19856063039453764, },	// 5 drhoj
		{ 0.33667637741189549, -0.097980152286670605, -0.064443098085161549, 7.5414455010170673,   -0.16757405632406441, -0.019693011124784013, },	// 6  phi
		{ -2.7373903650124118,  0.14391126457333930,   0.098265408533538656, -29.722621872329839,  -0.39650495571145317,  0.078108838448673251, },	// 7 phip
	};

	// Level 3 check includes translation
	// The data source used for checking is shown at the end of the function.
	// Use in position void PairEAMList::check_function_set(const char* name)
	if (transFlag == 2) {
		for (int i = 0; i < NITEM; i++) {
			if (AtomI == 1) {
				rchk[3][i] *= 1.6;
				rchk[5][i] *= 1.6;
			}
			else {
				rchk[3][i] *= 0.7;
				rchk[5][i] *= 0.7;
			}

			if (AtomJ == 1) {
				rchk[4][i] *= 1.6;
			}
			else {
				rchk[4][i] *= 0.7;
			}
		}
		
		rchk[6][0] = -0.083978534096250335;
		rchk[6][1] = -0.15911269796239924;
		rchk[6][2] = -0.091755796415167901;
		rchk[6][3] = 6.3910457856296397;
		rchk[6][4] = -0.28845000426239198;
		rchk[6][5] = -0.028015813592657143;

		rchk[7][0] = -2.0558850699632352;
		rchk[7][1] = 0.24721260303869086;
		rchk[7][2] = 0.14234678362903797;
		rchk[7][3] = -27.848463314006587;
		rchk[7][4] = -0.22745008758199148;
		rchk[7][5] = 0.10997462645478209;
	}

#define CHECK_FUNC_R(func, pAtomI, pAtomJ, nref, iname, IDX)	\
	for (int i = 0; i < NITEM; i++) {							\
		r = sqrt(rchk[2][i]);									\
		v[i] = func(pAtomI, pAtomJ, r);							\
	}															\
	error->check(FLERR, NITEM, v, rchk[nref], 1, name, iname, cutmax, cutall, chkmax[IDX], chkall[IDX]);

	CHECK_FUNC_R(rho, static_cast<int>(AtomI), static_cast<int>(AtomJ), 3, "r", 1);
	CHECK_FUNC_R(phi, static_cast<int>(AtomI), static_cast<int>(AtomJ), 6, "p", 2);

#undef NITEM
#undef NCOM
#undef AtomI
#undef AtomJ

}


