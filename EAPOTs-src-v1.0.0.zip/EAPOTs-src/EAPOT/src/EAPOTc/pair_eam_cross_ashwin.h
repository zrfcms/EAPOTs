#ifdef PAIR_CLASS
PairStyle(eam/cross/ashwin, PairEAMCrossAshwin)
#else

#ifdef LIBAPI
LIBAPI(void, setPairEAMCrossAshwinAtomicNumber, (APITYPE void* pPair, double Z1, double Z2), (APINAME pPair, Z1, Z2));
LIBAPI(void, setPairEAMCrossAshwinZBLRange, (APITYPE void* pPair, double r1, double r2), (APINAME pPair, r1, r2));
#else

#ifndef EAPOT_PAIR_EAM_CROSS_ASHWIN_H
#define EAPOT_PAIR_EAM_CROSS_ASHWIN_H

#include "pair_eam_cross_cubic.h"

namespace EAPOT_NS {

	class PairEAMCrossAshwin : public PairEAMCrossCubic
	{
		friend class PairStyle;
	public:
		PairEAMCrossAshwin(EAPOT *eapot);
		~PairEAMCrossAshwin();

		double part1(double r);
		double part2(double r);
		double cphi(double r);

		double dpart1(int i, double r);

		virtual void init_style();
		virtual void setFreeParamsStyle();
		
		void back_image(class DumpImage* dumpimage, void* paxesf, void* paxesr, void* paxesp);

	protected:		

		double r1, r2, Z1, Z2;

		double C, rs;
		double mrs, mrs2;
		double B0, B1, B2, B3, B4, B5;
		double B[6], b[6], iBm[6][6];

		void part2B_calc(double, double);

	private:
		virtual void extra_check(int);
		virtual void partial_check();
		virtual void part2b_check();
	};

	namespace PairZBLConstants {

		// ZBL constants
		static const double C1 = 14.399758268182;
		static const double a0 = 0.529177;
		static const double crs1 = 0.88534;

		static const double c1 = 0.02817;
		static const double c2 = 0.2802;
		static const double c3 = 0.5099;
		static const double c4 = 0.1818;

		static const double d1 = -0.2016;
		static const double d2 = -0.4029;
		static const double d3 = -0.9423;
		static const double d4 = -3.2000;

		static const double d12 = d1 * d1;
		static const double d22 = d2 * d2;
		static const double d32 = d3 * d3;
		static const double d42 = d4 * d4;
	}

}

#endif
#endif
#endif