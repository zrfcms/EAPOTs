#ifdef PAIR_CLASS
PairStyle(eam/python, PairEAMPython)
PairStyle(eam/ackland, PairEAMAckland)
PairStyle(fs/ackland, PairFSAckland)
PairStyle(fs/finnis, PairFSFinnis)
PairStyle(tb/rosato, PairTBRosato)
PairStyle(tb/li, PairTBLi)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_PYTHON_H
#define EAPOT_PAIR_EAM_PYTHON_H

#include "pair_eam_list.h"
#include <string>
#include <vector>

namespace EAPOT_NS {

	struct PairEAMParam {
		int ndof;
		double* dof;

		int nrhot, nr;
		int nemb, nrho, nphi;	

		double* rhot, * r;
		double* emb, * rho, * phi;
	};

	class PairEAMPython : public PairEAMList
	{
		friend class PairStyle;
	public:

		PairEAMPython(EAPOT *eapot);
		~PairEAMPython();

		int python_fsize, python_csize;
		double *python_fvec, *python_cvec;

		int getPyParamNum();
		void fvec_allocate();

		virtual void init_style();
		void setFreeParamsStyle();
		
		virtual void extra_check(int);
		void single_check(int);
		void cross_check_fs();
		void cross_check_set();

	protected:		
		PairEAMParam param;		
		std::vector<double> arrayR, arrayRho, dof;
	};

	class PairEAMAckland : public PairEAMPython
	{
	public:
		PairEAMAckland(EAPOT* eapot);
		~PairEAMAckland() {};
	};

	class PairFSAckland : public PairEAMPython
	{
	public:
		PairFSAckland(EAPOT* eapot);
		~PairFSAckland() {};
	};

	class PairFSFinnis : public PairEAMPython
	{
	public:
		PairFSFinnis(EAPOT* eapot);
		~PairFSFinnis() {};

		void extra_check(int);
	};

	class PairTBRosato : public PairEAMPython
	{
	public:
		PairTBRosato(EAPOT* eapot);
		~PairTBRosato() {};

		void extra_check(int);
	};

	class PairTBLi : public PairEAMPython
	{
	public:
		PairTBLi(EAPOT* eapot);
		~PairTBLi() {};

		void extra_check(int);
	};
}

#endif
#endif
#endif