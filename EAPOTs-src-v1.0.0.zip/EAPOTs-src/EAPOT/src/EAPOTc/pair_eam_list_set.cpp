#include "pair_eam_list.h"

#include <string.h>
#include "memory.h"
#include "error.h"
#include "force.h"
#include "input.h"

#include "option_pair.h"
using namespace EAPOT_NS;

#define MAXLINE 1024

/* ----------------------------------------------------------------------
set coeffs for one or more type pairs
read DYNAMO setfl file
------------------------------------------------------------------------- */

void PairStyle::inputPairEAMListFromAlloy(void* pPair, const char* file, const char** pele)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam/list", 1);
	auto pair = (PairEAMList*)pPair;

	pair->potModeEnum = PairEAMList::PotModeEnum::SET;
	if (!pair->map_allocated) pair->map_alloc();

	// read EAM setfl file
	if (pair->setfl) {
		memory->destroy(pair->setfl->frho);
		memory->destroy(pair->setfl->rhor);
		memory->destroy(pair->setfl->z2r);
		delete pair->setfl;
	}
	pair->setfl = new PairEAMList::Setfl();

	pair->read_file_set(file);
	int ntypes = force->get_ntypes();
	int nelements = (int)pair->setfl->elements.size();

	// read args that map atom types to elements in potential file
	// map[i] = which element the Ith atom type is, -1 if NULL

	for (size_t i = 0; i < ntypes; i++) {
		if (!pele[i]) {
			ErrorAll("Illegal PairEAMListCoeff command: Incorrect elements[%zu]", i);
			return;
		}
		if (strcmp(pele[i], "NULL") == 0) {
			pair->map[i + 1] = -1; continue;
		}

		int j = 0;
		for (j = 0; j < nelements; j++) {			
			if (pele[i] == pair->setfl->elements[j]) break;
		}
			
		if (j < nelements) pair->map[i + 1] = j;
		else error->all(FLERR, "No matching element in EAM potential file");
	}

	// set setflag i,j for type pairs where both are mapped to elements
	// set mass of atom type if i = j

	int count = 0;
	for (int i = 1; i <= ntypes; i++) {
		for (int j = i; j <= ntypes; j++) {
			if (pair->map[i] >= 0 && pair->map[j] >= 0) {
				count++;
			}
		}
	}
	if (count == 0) error->all(FLERR, "Illegal PairEAMListCoeff command: Incorrect elements input");
}



/* ----------------------------------------------------------------------
read a multi-element DYNAMO setfl file
------------------------------------------------------------------------- */

void PairEAMList::read_file_set(CPCHAR filename)
{
	if (filename == NULL || strcmp(filename, "NULL") == 0) {
		int nele = force->get_ntypes();
		for (int i = 1; i <= nele; i++) {
			setfl->elements.push_back(force->get_elestr(i));
		}

		setfl->frho = setfl->rhor = NULL;
		setfl->z2r = NULL;
		return;
	}

	// open potential file
	char line[MAXLINE], *ctmp;
	FILE* fptr = input->open(filename, "r");

	// read and broadcast header
	// extract element names from nelements line

	int i, j, n, nwords, nelements;
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	n = strlen(line) + 1;

	// parse element title line
	nwords = sscanf(line, "%d", &nelements);
	nwords = input->count_words(line);
	if (nwords != nelements + 1)
		error->all(FLERR, "Incorrect element names in EAM potential file");

	ctmp = strtok(line, " \t\n\r\f");
	for (int i = 0; i < nelements; i++) {
		setfl->elements.push_back(strtok(NULL, " \t\n\r\f"));
	}

	// parse potential format line
	fgets(line, MAXLINE, fptr);
	PairEAMFmt& fmt = setfl->fmt;
	nwords = sscanf(line, "%d %lg %d %lg %lg",
		&fmt.nrho, &fmt.drho, &fmt.nr, &fmt.dr, &fmt.cut);

	if ((nwords != 5) || (fmt.nrho <= 0) || (fmt.nr <= 0) || (fmt.dr <= 0.0))
		error->all(FLERR, "Invalid EAM potential file");

	// allocate memory
	memory->create(setfl->frho, nelements, fmt.nrho + 1, "pair:frho");
	memory->create(setfl->rhor, nelements, fmt.nr + 1, "pair:rhor");
	memory->create(setfl->z2r, nelements, nelements, fmt.nr + 1, "pair:z2r");

	for (i = 0; i < nelements; i++) {
		fgets(line, MAXLINE, fptr);
		grab(fptr, fmt.nrho, &setfl->frho[i][1]);
		grab(fptr, fmt.nr, &setfl->rhor[i][1]);
	}

	for (i = 0; i < nelements; i++) {
		for (j = 0; j <= i; j++) {
			grab(fptr, fmt.nr, &setfl->z2r[i][j][1]);
		}
	}

	// close the potential file
	fclose(fptr);
}

/* ----------------------------------------------------------------------
copy read-in setfl potential to standard array format
------------------------------------------------------------------------- */

void PairEAMList::file2array_set()
{
	int i, j, n;
	int nelements = (int)setfl->elements.size();
	nfrho = nelements + 1;							// nfrho = # of setfl elements + 1 for zero array
	nrhor = nelements;								// nrhor = # of setfl elements
	nz2r = nelements * (nelements + 1) / 2;			// nz2r = N*(N+1)/2 where N = # of setfl elements

	memory->destroy(frho);
	memory->destroy(rhor);
	memory->destroy(z2r);

	list = setfl->frho ? setfl->fmt : m_dump;		// set function params directly from setfl file
	list_rhomax = ((size_t)list.nrho - 1) * list.drho;

	memory->create(frho, nfrho, list.nrho, "pair:frho");
	memory->create(rhor, nrhor, list.nr, "pair:rhor");
	memory->create(z2r, nz2r, list.nr, "pair:z2r");

	// copy each element's frho, rhor, pair z2r to global

	if (!setfl->frho) {
		temp_memset0(frho[0], nfrho * list.nrho);
		temp_memset0(rhor[0], nrhor * list.nr);
		temp_memset0(z2r[0], nz2r * list.nr);
		return;
	}

	n = 0;
	for (i = 0; i < nelements; i++) {
		temp_memcpy(frho[i], setfl->frho[i] + 1, list.nrho);
		temp_memcpy(rhor[i], setfl->rhor[i] + 1, list.nr);

		for (j = 0; j <= i; j++) {
			temp_memcpy(z2r[n++], setfl->z2r[i][j] + 1, list.nr);
		}
	}

	// add extra frho of zeroes for non-EAM types to point to (pair hybrid)
	// this is necessary b/c fp is still computed for non-EAM atoms
	temp_memset0(frho[nfrho - 1], list.nrho);
}


void PairEAMList::extra_check_set(int) {

	const char* name = "EAMLIST/A";
	double t[] = { 0, 1, 0, 1, };

	setFullParams(t);

	/*------------------------------------------ function check --------------------------------------------*/
#define NITEM	2

	double vCal[12], vRef[12], r, rhot;
	error->add_chklog(0, name, "");

	//  itype       rhot                 Femb                 dFemb
	double fchk[NITEM][4] = {
		{ 1, 42.105860257539788, -1.5171794769627023, 0.073560468420212285, },
		{ 2, 34.565372346451909, -2.7923647275070120, 0.0041135638259636141, },
	};

	int idx;
	for (idx = 0; idx < NITEM; idx++) {
		rhot = fchk[idx][1];
		vCal[idx] = emb((int)fchk[idx][0], rhot);		// Femb
		vRef[idx] = fchk[idx][2];			// Femb		
	}

	error->check(FLERR, idx, vCal, vRef, 1, name, "RhoPhi", 5e-15, 5e-15, 0, 0);

#undef NITEM

#define NITEM	6
	//  itype jtype     rsq                 rho                   drhoi                drhoj                   phi                    phip
	double rchk[NITEM][8] = {
		{ 2, 1, 4.5311999999999184, 3.33477472272109750, -5.41586665095582200, -4.663954331786491100, 0.3385863193671754800, -2.7247186269403589, },
		{ 1, 1, 12.390400000000003, 0.30566272837864322, -0.51650669232675772, -0.516506692326757720, -0.097980152286670605, 0.14391126457333930, },
		{ 2, 1, 14.668800000000026, 0.30786730665995404, -0.30862208503893929, -0.440638886386845670, -0.071038257593483881, 0.10535569000927486, },
		{ 2, 1, 2.2784000000000244, 7.92832011566740660, -15.4150649612716620, -11.08840207320282000, 7.6604150172016245000, -30.747900238558994, },
		{ 2, 2, 6.1951999999999998, 2.01459913230545990, -2.81758113549102830, -2.817581135491028300, -0.167574056324064410, -0.39650495571145311, },
		{ 1, 2, 19.174399999999817, 0.055196725082542739, -0.40032416555516920, -0.19856063039453764, -0.021669706852677023, 0.088538040105184679 },
	};

	for (idx = 0; idx < NITEM; idx++) {
		r = sqrt(rchk[idx][2]);
		vCal[2 * idx + 0] = rho((int)rchk[idx][0], (int)rchk[idx][1], r);
		vCal[2 * idx + 1] = phi((int)rchk[idx][0], (int)rchk[idx][1], r);

		vRef[2 * idx + 0] = rchk[idx][3];
		vRef[2 * idx + 1] = rchk[idx][6];
	}

	error->check(FLERR, idx * 2, vCal, vRef, 1, name, "RhoPhi", 5e-15, 5e-15, 0, 0);

#undef NITEM

	/*------------------------------------------ calcation check --------------------------------------------*/

	error->add_chklog(0, name, "");
	double BoxChk[6], BoxRef[6] = {
		3.54932, 4.21455, 
		3.57976, 3.76226, 
		2.92043, 3.91981, 
	};

	double ElaChk[9], ElaRef[9] = {
		249.17,	158.42,	110.70,	
		151.48,	82.448,	94.595,
		88.655,	106.50,	75.392,
	};
	addMDComputeAlloy();
	runMDCompute(-1, RunDump | RunEcho, 10, VNbAlloyCost, AlloyChk, "nms", "dump.*.eam");
	evalCompute(BoxChk, ElaChk);

	error->check(FLERR, 6, BoxChk, BoxRef, 1, name, "Box", 5e-5, 2e-5, 2.4066853115101645e-06, 8.3105203332387848e-06);
	error->check(FLERR, 9, ElaChk, ElaRef, 1, name, "Ela", 5e-4, 2e-4, 5.1236243357189267e-05, 0.00016221453771190106);
};



void PairStyle::inputPairEAMListFromFS(void* pPair, const char* file, const char** pele)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam/list", 1);
	auto pair = (PairEAMList*)pPair;

	pair->potModeEnum = PairEAMList::PotModeEnum::FS;
	if (!pair->map_allocated) pair->map_alloc();

	// read EAM Finnis-Sinclair file
	if (pair->fs) {
		memory->destroy(pair->fs->frho);
		memory->destroy(pair->fs->rhor);
		memory->destroy(pair->fs->z2r);
		delete pair->fs;
	}
	pair->fs = new PairEAMList::Fs();
	pair->read_file_fs(file);
	int ntypes = force->get_ntypes();
	int nelements = (int)pair->fs->elements.size();

	// read args that map atom types to elements in potential file
	// map[i] = which element the Ith atom type is, -1 if NULL

	for (int i = 0; i < ntypes; i++) {
		if (!pele[i]) {
			ErrorAll("Illegal PairEAMListCoeff command: Incorrect elements[%d]", i);
			return;
		}
		if (strcmp(pele[i], "NULL") == 0) {
			pair->map[i + 1] = -1; continue;
		}

		int j = 0;
		for (j = 0; j < nelements; j++) {
			if (pele[i] == pair->fs->elements[j]) break;
		}

		if (j < nelements) pair->map[i + 1] = j;
		else error->all(FLERR, "No matching element in FS potential file");
	}

	// set setflag i,j for type pairs where both are mapped to elements
	// set mass of atom type if i = j

	int count = 0;
	for (int i = 1; i <= ntypes; i++) {
		for (int j = i; j <= ntypes; j++) {
			if (pair->map[i] >= 0 && pair->map[j] >= 0) {
				count++;
			}
		}
	}

	if (count == 0) error->all(FLERR, "Illegal PairEAMListCoeff command: Incorrect elements input");
}

void PairEAMList::read_file_fs(CPCHAR filename) {

	if (filename == NULL || strcmp(filename, "NULL") == 0) {
		int nele = force->get_ntypes();
		for (int i = 1; i <= nele; i++) {
			fs->elements.push_back(force->get_elestr(i));
		}

		fs->frho = NULL;
		fs->rhor = fs->z2r = NULL;
		return;
	}

	// open potential file
	char line[MAXLINE], * ctmp;
	FILE* fptr = input->open(filename, "r");

	// read and broadcast header
	// extract element names from nelements line

	int i, j, n, nwords, nelements;
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	fgets(line, MAXLINE, fptr);
	n = strlen(line) + 1;

	nwords = sscanf(line, "%d", &nelements);
	nwords = input->count_words(line);
	if (nwords != nelements + 1)
		error->all(FLERR, "Incorrect element names in EAM potential file");

	ctmp = strtok(line, " \t\n\r\f");
	for (int i = 0; i < nelements; i++) {
		fs->elements.push_back(strtok(NULL, " \t\n\r\f"));
	}

	// parse potential format line
	fgets(line, MAXLINE, fptr);
	PairEAMFmt& fmt = fs->fmt;
	nwords = sscanf(line, "%d %lg %d %lg %lg",
		&fmt.nrho, &fmt.drho, &fmt.nr, &fmt.dr, &fmt.cut);

	if ((nwords != 5) || (fmt.nrho <= 0) || (fmt.nr <= 0) || (fmt.dr <= 0.0))
		error->all(FLERR, "Invalid EAM potential file");

	// allocate memory
	memory->create(fs->frho, nelements, fmt.nrho + 1, "pair:frho");
	memory->create(fs->rhor, nelements, nelements, fmt.nr + 1, "pair:rhor");
	memory->create(fs->z2r, nelements, nelements, fmt.nr + 1, "pair:z2r");


	for (i = 0; i < nelements; i++) {
		
		fgets(line, MAXLINE, fptr);	
		grab(fptr, fmt.nrho, &fs->frho[i][1]);
		for (j = 0; j < nelements; j++) {
			grab(fptr, fmt.nr, &fs->rhor[i][j][1]);
		}
	}

	for (i = 0; i < nelements; i++) {
		for (j = 0; j <= i; j++) {
			grab(fptr, fmt.nr, &fs->z2r[i][j][1]);
		}
	}

	// close the potential file
	fclose(fptr);
}

void PairEAMList::file2array_fs() {

	int i, j;
	int nelements = (int)fs->elements.size();

	nfrho = nelements + 1;					// nfrho = # of fs elements + 1 for zero array
	nrhor = nelements * nelements;			// nrhor = square of # of fs elements
	nz2r = nelements * (nelements + 1) / 2;	// nz2r = N*(N+1)/2 where N = # of fs elements

	memory->destroy(frho);
	memory->destroy(rhor);
	memory->destroy(z2r);

	list = fs->frho ? fs->fmt : m_dump; // set function params directly from fs file
	list_rhomax = ((size_t)list.nrho - 1) * list.drho;

	memory->create(frho, nfrho, list.nrho, "pair:frho");
	memory->create(rhor, nrhor, list.nr, "pair:rhor");
	memory->create(z2r, nz2r, list.nr, "pair:z2r");	

	// copy each element's frho, rhor, pair z2r to global
	
	if (!fs->frho) {
		temp_memset0(frho[0], nfrho * list.nrho);
		temp_memset0(rhor[0], nrhor * list.nr);
		temp_memset0(z2r[0], nz2r * list.nr);
		return;
	}

	int nrho = 0, nphi = 0;
	for (i = 0; i < nelements; i++) {
		temp_memcpy(frho[i], fs->frho[i] + 1, list.nrho);

		for (j = 0; j < nelements; j++) {
			temp_memcpy(rhor[nrho++], fs->rhor[i][j] + 1, list.nr);
		}
		for (j = 0; j <= i; j++) {
			temp_memcpy(z2r[nphi++], fs->z2r[i][j] + 1, list.nr);
		}
	}

	// add extra frho of zeroes for non-EAM types to point to (pair hybrid)
	// this is necessary b/c fp is still computed for non-EAM atoms
	temp_memset0(frho[nfrho - 1], list.nrho);
}

void PairEAMList::extra_check_fs(int) {

}