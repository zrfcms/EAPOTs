#ifdef PAIR_CLASS
PairStyle(eam/cross/zhou, PairEAMCrossZhou)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_ZHOU_H
#define EAPOT_PAIR_EAM_CROSS_ZHOU_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossZhou : virtual public PairEAMCross
	{
	public:
		PairEAMCrossZhou(EAPOT *eapot);
		~PairEAMCrossZhou(){};

		double cphi(double r);
		double dcore(double *c, double r);

	private:
		void extra_check(int);
		void partial_check();
		void transform_energy_check(double*);
		void transform_calculation_check();
	};

}

#endif
#endif
#endif