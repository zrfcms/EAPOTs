#ifdef PAIR_CLASS
PairStyle(eam/cross/mishin, PairEAMCrossMishin)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_MISHIN_H
#define EAPOT_PAIR_EAM_CROSS_MISHIN_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossMishin : virtual public PairEAMCross
	{
	public:
		PairEAMCrossMishin(EAPOT *eapot);
		~PairEAMCrossMishin(){};

		double cphi(double r);

		void setFullParamsStyle();
		void setFreeParamsStyle();
	private:
		double rc, h, E1, r0;
		double a, b, sig, g1, g2;

		double mh17, mh16, mh13, mh12, mh11, mh10;
		double mh9, mh8, mh7, mh6, mh5, mh4;
		double mh3, mh2, a3, a2, b3, b2;

	private:
		void extra_check(int);
		void partial_check();
	};

}

#endif
#endif
#endif