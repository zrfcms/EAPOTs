#ifdef PAIR_CLASS
PairStyle(eam/cross/zhou2, PairEAMCrossZhou2)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_CROSS_ZHOU2_H
#define EAPOT_PAIR_EAM_CROSS_ZHOU2_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossZhou2 : virtual public PairEAMCross
	{
	public:
		PairEAMCrossZhou2(EAPOT *eapot);
		~PairEAMCrossZhou2(){};

		double cphi(double r);
		double dcore(double *c, double r);

	private:
		void extra_check(int);
		void partial_check();
	};
}

#endif
#endif
#endif