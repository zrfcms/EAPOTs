#ifdef PAIR_CLASS
PairStyle(eam/cross/cubic, PairEAMCrossCubic)
#else

#ifdef LIBAPI
LIBAPI(void, setPairEAMCrossCubicChain, (APITYPE void* pPair, int nchain, const char* mode), (APINAME pPair, nchain, mode));
#else

#ifndef EAPOT_PAIR_EAM_CROSS_CUBIC_H
#define EAPOT_PAIR_EAM_CROSS_CUBIC_H

#include "pair_eam_cross.h"

namespace EAPOT_NS {

	class PairEAMCrossCubic : public PairEAMCross
	{
		friend class PairStyle;
	public:
		PairEAMCrossCubic(EAPOT *eapot);
		~PairEAMCrossCubic();

		double cphi(double r);
		double cdphi(int i, double r);

		virtual void setFullParamsStyle();
		virtual void setFreeParamsStyle();

		void set_nchain(int pnchain, int pmode);
		void update_nchain();

	protected:		

		int nchain, mode;
		class CubicSplineChain *chain;

	private:
		virtual void extra_check(int);
		virtual void partial_check();
	};

}

#endif
#endif
#endif