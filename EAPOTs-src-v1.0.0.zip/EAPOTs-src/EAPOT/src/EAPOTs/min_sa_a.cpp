#include "min_sa_a.h"
#include <ctype.h>
#include <stdlib.h>
#include "eapot_math.h"
#include "string.h"

#include "memory.h"
#include "error.h"
#include "update.h"
#include "modify.h"
#include "pair.h"
#include "force.h"
#include "output.h"

#include "min_chkfunc.h"
#include "option_mini.h"
using namespace EAPOT_NS;

#define STEPVAR 2.0
#define TEMPVAR 0.85

//1/(sqrt(2*pi))
#define ONE_OVER_SQRT_2_PI 0.39894228040143267794

//(exp(-((a) * (a)) / 2.0)/(sqrt(2*pi)))
#define GAUSS(a) (ONE_OVER_SQRT_2_PI * (exp(-((a) * (a)) / 2.0)))

#define ACCRPTNONE 0
#define ACCRPTTEMP 1
#define ACCRPTITER 2

MinSAA::MinSAA(EAPOT *eapot) : Min(eapot)
{
	styles.push_back("sa/a");
	linestyle = 0;

	NEPS = 0;
	NSTEP = 0;
	NTEMP = 0;
	acceptFlag = ACCRPTITER;

	F_old = NULL;
	X = NULL;
	v = NULL;
	xi = NULL;
	xi_opt = NULL;
	xi_new = NULL;
	naccept = NULL;
}

/* ---------------------------------------------------------------------- */

MinSAA::~MinSAA()
{
	memory->destroy(F_old);
	memory->destroy(X);
	memory->destroy(naccept);
}

void MiniStyle::setSimulatedAnnealingAMode(const char* mode) {

	update->minimize->styleCheck(FLERR, "sa/a", 1);
	MinSAA* min = (MinSAA*)update->minimize;
	if (strcmp(mode, "none") == 0) min->acceptFlag = ACCRPTNONE;
	else if (strcmp(mode, "temp") == 0) min->acceptFlag = ACCRPTTEMP;
	else if (strcmp(mode, "iter") == 0) min->acceptFlag = ACCRPTITER;
	else error->all(FLERR, "Illegal setSimulatedAnnealingAAcceptMode command");
}

/* ---------------------------------------------------------------------- */

void MinSAA::init()
{
	Min::init();
}

/* ---------------------------------------------------------------------- */

void MinSAA::setup_style()
{
	NEPS = 4;
	NSTEP = 20;
	NTEMP = 3;

	memory->destroy(F_old);
	memory->destroy(X);
	memory->destroy(naccept);

	memory->create(F_old, NEPS, "MinSAA::F_old");
	memory->create(X, 4, nvec, "MinSAA::X");
	memory->create(naccept, nvec, "MinSAA::naccept");
	v = X[0];
	xi = X[1];
	xi_opt = X[2];
	xi_new = X[3];
}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinSAA::reset_vectors()
{

	/* init displacement vector */
	for (int i = 0; i < nvec; i++)	v[i] = 0.1;

	temp_memcpy(xi, xvec, nvec);
	temp_memcpy(xi_new, xvec, nvec);
	temp_memcpy(xi_opt, xvec, nvec);
}



/****************************************************************
*
* void randomize_parameter
*   const int n:    index of parameter to change
* 	double *xi:		pointer to all parameters
* 	double *v:		pointer to displacement vector
*
* Function to generate random parameters for analytic/tabulated
* potentials.
*
* Displaces equidistant sampling points of a function.
* Displacement is given by gaussian.
*
****************************************************************/

void MinSAA::randomize_parameter(const int n, double* xi, double* v)
{
	const double width = fabs(normdist());
	const double height = normdist() * v[n];

	int up = static_cast<int>(4.0 * width);
	for (int i = 0; i <= up; i++) {
		xi[n] += GAUSS((double)i / width) * height;
	}
}

/****************************************************************
* Function to determine annealing starting temperature.
****************************************************************/

double MinSAA::get_annealing_temperature(const int ndim, const double* xi,
	double* xi_new,	double* displacements,	double F)
{
	double T = -1.0;

	double chi = 0.8;
	double dF = 0.0;

	int u = 10 * ndim;
	int m1 = 0;

	//printf("Determining optimal starting temperature T ...\n");

	for (int e = 0; e < u; e++) {
		temp_memcpy(xi_new, xi, ndim);

		randomize_parameter(static_cast<int>(eqdist() * ndim), xi_new, displacements);

		double F_new = func(xi_new);

		if (F_new <= F) {
			m1++;
		}
		else {
			dF += F_new - F;
		}
	}

	u -= m1;
	dF /= u;
	T = dF / log(u / (u * chi + (1 - chi) * m1));

	if (!isfinite(T) || T == 0) T = 1;
	if (T < 0)	T = -T;

	//printf("trial steps: %d  downhill: %d T: %f\n", u, m1, T);

	return T;
}


int MinSAA::iterate(int maxiter)
{

	int ntimestep = 0;

	const int ndim = force->pair->get_fsize();
	NTEMP *= ndim;

	double F = ecurrent;	//current solution
	double F_opt = F;		//historical optimal solution
	double F_new = F;		//temporary new solution

	/* Temperature */
	if (acceptFlag & ACCRPTTEMP) xi = xvec;
	double T = get_annealing_temperature(ndim, xi, xi_new, v, F);

	if (acceptFlag & ACCRPTITER) xi = xvec;
	//printf("  k\tT        \tF          \tF_opt\n");
	//printf("%3d\t%f\t%f\t%f\n", 0, T, 0, F, F_opt);

	for (int iter = 0; iter < maxiter; iter++) {
		ntimestep = ++update->ntimestep;
		niter++;

		eprevious = ecurrent;

		// function evaluation criterion
		if (neval >= update->max_eval) return return_final(MAXEVAL, xi_opt);

		// loop of the same temperature
		for (int m = 0; m < NTEMP; m++) {
			// loop of the same speed 
			for (int j = 0; j < NSTEP; j++) {
				// loop over parameters
				for (int h = 0; h < ndim; h++) {
					/* Step #1 */
					temp_memcpy(xi_new, xi, ndim);
					randomize_parameter(h, xi_new, v);
					F_new = func(xi_new); 

					/* accept new point */
					if (F_new <= F) {
						temp_memcpy(xi, xi_new, ndim);
						F = F_new;
						naccept[h]++;

						if (F_new < F_opt) {
							temp_memcpy(xi_opt, xi_new, ndim);
							F_opt = F_new;
						}
					}
					else if (eqdist() < (exp((F - F_new) / T))) {
						temp_memcpy(xi, xi_new, ndim);
						F = F_new;
						naccept[h]++;
					}
				}	// loop over parameters
			}		// steps per temperature

			/* Step adjustment */
			for (int n = 0; n < ndim; n++) {
				if (naccept[n] >(0.6 * NSTEP))
					v[n] *= (1 + STEPVAR * ((double)naccept[n] / NSTEP - 0.6) / 0.4);
				else if (naccept[n] < (0.4 * NSTEP))
					v[n] /= (1 + STEPVAR * (0.4 - (double)naccept[n] / NSTEP) / 0.4);
				naccept[n] = 0;
			}
		}
		//printf("%3d\t%f\t%f\t%f\n", ntimestep, T, F, F_opt);

		/*Temp adjustment */
		T *= TEMPVAR;

		for (int i = 0; i < NEPS - 1; i++)
			F_old[i] = F_old[i + 1];
		F_old[NEPS - 1] = F;

		if (!loop_again(F, F_opt)) return return_final(ETOL, xi_opt);

		ecurrent = F_opt;
		if (output->next == ntimestep) {
			func(xi_opt); neval--; 
			output->write(ntimestep);
		}
	}
	return return_final(MAXITER, xi_opt);
}

bool MinSAA::loop_again(double F, double F_opt){
	// energy tolerance criterion
	const int ndim = force->pair->get_fsize();

	for (int n = 0; n < NEPS - 1; n++) {
		if (fabs(F - F_old[n]) >(update->etol * F)) {
			return true;
		}
	}
	if (F - F_opt > update->etol * F) {
		temp_memcpy(xi, xi_opt, ndim);
		F = F_opt;
		return true;
	}

	temp_memcpy(xi, xi_opt, ndim);
	return false;
}
