#include "stdlib.h"
#include "string.h"

#include "dump_external.h"
#include "dump_file.h"

#include "error.h"
#include "memory.h"

#include "input.h"
#include "pair.h"
#include "force.h"
#include "output.h"
#include "update.h"

#include "min.h"
#include "option_dump.h"

using namespace std;
using namespace EAPOT_NS;

/* ---------------------------------------------------------------------- */

DumpExternal::DumpExternal(EAPOT *lmp, const char* pid, const char* pstyle, const char* pfile)
	: Dump(lmp, pid, pstyle, pfile)
	, caller(NULL)
	, callback(NULL)
	, param{ 0, 0, 0, NULL, 0.0, 0, NULL, NULL }
{
	styles.push_back("external");
	fileDump = NULL;
	imageDump = NULL;

	//If there is no path for check storage, then create
	if (output->chkdirFlag == 0) {
		const char *path = "chkdata";
		input->shell_mkdir(1, &path);
		output->chkdirFlag = 1;
	}
}



void DumpStyle::setDumpExternalFile(void* pidump, void* prefDump) {
	Dump* idump = (Dump*)pidump, * refDump = (Dump*)prefDump;

	idump->styleCheck(FLERR, "external", 1);
	refDump->styleCheck(FLERR, "file", 1);

	((DumpExternal*)idump)->fileDump = (DumpFile*)refDump;
}


void DumpStyle::setDumpExternalImage(void* pidump, void* prefDump) {
	Dump* idump = (Dump*)pidump, * refDump = (Dump*)prefDump;
	idump->styleCheck(FLERR, "external", 1);
	refDump->styleCheck(FLERR, "image", 1);

	((DumpExternal*)idump)->imageDump = (DumpImage*)refDump;
}

void DumpStyle::setDumpExternalScript(void* pidump, const char* script) {
	((Dump*)pidump)->styleCheck(FLERR, "external", 1);
	((DumpExternal*)pidump)->pythonScript = script;
}

void DumpStyle::setDumpExternalCallback(void* pidump, StrCallback callback, void* caller) {
	((Dump*)pidump)->styleCheck(FLERR, "external", 1);
	((DumpExternal*)pidump)->callback = callback;
	((DumpExternal*)pidump)->caller = caller;
}

/* ---------------------------------------------------------------------- */
DumpCallbackParam* DumpExternal::updateParam(int mode) {
	param.mode = mode;
	param.step = update->ntimestep;
	param.nparam = force->pair->get_fsize();
	param.param = force->pair->get_fvec();
	param.costValue = update->minimize->get_ecurrent();

	if (fileDump) {
		auto& pfiles = fileDump->fileDump;
		int nfile = pfiles.size();
		if (files.size() != nfile) {
			files.resize(nfile, NULL);
		}
		for (int i = 0; i < nfile; i++) {
			files[i] = pfiles[i].c_str();
		}
		param.nfile = nfile;
		param.files = files.data();
	}

	return &param;
}

void DumpExternal::init_style()
{
	if (multifile == 0) openfile(0);

	if (this->callback == NULL) {

		int ntypes = force->get_ntypes();
		char* tmp = error->ErrCheckBuff;

		// '../../../LAMMPS/', './chkdata/', ('Cu',), 'eam/alloy', { 'mass': (64.5,) }
		std::string s = "import EACHKInter\n"
			"eapot.chkinter = EACHKInter.EACHKInter('" + output->lammpsDir + "', './chkdata/', (";
		for (int i = 1; i <= ntypes; i++) {
			sprintf(tmp, "'%s', ", force->get_elestr(i)); s += tmp;
		}

		sprintf(tmp, "), '%s', { 'mass': (", force->pair->chkStyle.c_str()); s += tmp;
		for (int i = 1; i <= ntypes; i++) {
			sprintf(tmp, FDBLFMTG ", ", force->massVec[i]); s += tmp;
		}
		s += ") })\n" + pythonScript;

		if (eapot->pythonCallback) eapot->pythonCallback(eapot->caller, FLERR, s.c_str());

		s = "def DumpCallbackFunc(caller, ptr):\n"
			"    p = cast(ptr, pDumpCallbackParam)[0]\n"
			"    if p.mode == 0: return EAPOT.packMsg(eapot.chkinter.init(None))\n"
			"    files = [p.files[i].decode() for i in range(p.nfile)]\n"
			"    return EAPOT.packMsg(eapot.chkinter.run(files))\n"
			"eapot.DumpCallbackAPI = eapot.StrCallbackType(DumpCallbackFunc)\n"
			"exter = eapot.getDump('exter', None)\n"
			"eapot.setDumpExternalCallback(exter, eapot.DumpCallbackAPI, None)\n";
		if (eapot->pythonCallback) eapot->pythonCallback(eapot->caller, FLERR, s.c_str());

	}	

	if (!this->callback) {
		error->all(FLERR, "external callback is empty!");
	}

	dumpHeadinfo = (this->callback)(caller, updateParam(0));

	
	if (multifile == 0 && update->ntimestep == 0) {
		fprintf(fp, "step  %s\n", dumpHeadinfo.c_str());
	}
}

/* ---------------------------------------------------------------------- */

void DumpExternal::write()
{
	//PyGILState_STATE gstate = PyGILState_Ensure(); 

	// if file per timestep, open new file
	if (multifile) openfile(0);

	fprintf(fp, "%-6d", update->ntimestep);

	if (multifile) {
		fprintf(fp, dumpHeadinfo.c_str());
		fprintf(fp, "\n");
	}


	if (this->callback) {
		dumpAbstract = (this->callback)(caller, updateParam(1));
	}

	fprintf(fp, dumpAbstract.c_str());
	fprintf(fp, "\n");

	if (multifile) {
		fclose(fp);
		fp = NULL;
	}
	else {
		fflush(fp);
	}
}
