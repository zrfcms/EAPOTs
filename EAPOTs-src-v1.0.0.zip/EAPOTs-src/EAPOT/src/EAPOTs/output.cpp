#include "memory.h"
#include "error.h"
#include "input.h"

#include "update.h"
#include "modify.h"
#include "output.h"

#include "thermo.h"
#include "dump.h"
#include "style_dump.h"

#include "force.h"
#include "pair.h"
#include "image.h"

using namespace EAPOT_NS;

#define DELTA 1

/* ----------------------------------------------------------------------
initialize all output
------------------------------------------------------------------------- */

Output::Output(EAPOT *eapot) 
: Pointers(eapot)
{
	// create default Thermo class
	thermo = new Thermo(eapot, "one", 0, NULL);

	dumpdirFlag = 0;
	chkdirFlag = 0;

	thermo_every = 0;
	var_thermo = NULL;

	ndump = 0;
	max_dump = 0;
	every_dump = NULL;
	next_dump = NULL;
	last_dump = NULL;
	dump = NULL;

	dumplog = NULL;
	dumpLogName = "";

	thermolog = NULL;
	thermoLogName = "";

	lammpsDir =  "../../../LAMMPS";
	EACHKDir = "../../EACHK";

	dump_map = new DumpCreatorMap();

#define DUMP_CLASS
#define DumpStyle(key,Class) \
	(*dump_map)[#key] = &dump_creator<Class>;
#include "style_dump.h"
#undef DumpStyle
#undef DUMP_CLASS

	//If there is no path for storage, then create
	if (dumpdirFlag == 0) {

		const char* path = "task";
		if (!Input::exists(path)) {
			input->shell_mkdir(1, &path);
		}
		else if (Input::exists("task/EAPOT.eam")) {
			path = "task/EAPOT.eam";
			input->shell_rm(1, &path);
		}
		dumpdirFlag = 1;
	}
}

/* ----------------------------------------------------------------------
free all memory
------------------------------------------------------------------------- */

Output::~Output()
{
	if (dumplog) fclose(dumplog);
	if (thermolog) fclose(thermolog);

	if (thermo) delete thermo;
	delete[] var_thermo;

	memory->destroy(every_dump);
	memory->destroy(next_dump);
	memory->destroy(last_dump);
	for (int i = 0; i < ndump; i++) delete dump[i];
	memory->sfree(dump);

	delete dump_map;
}

/* ---------------------------------------------------------------------- */

void Output::init()
{
	thermo->init();

	for (int i = 0; i < ndump; i++) dump[i]->init();

	if (!dumpLogName.empty() && dumplog == NULL) {
		dumplog = input->open(dumpLogName.c_str(), "w");
	}

	if (!thermoLogName.empty() && thermolog == NULL) {
		thermolog = input->open(thermoLogName.c_str(), "w");
	}
}

void Output::write_dumplog() {
	fseek(dumplog, 0, SEEK_SET);
	fprintf(dumplog, "{\n");
	for (int i = 0; i < ndump; i++) {
		fprintf(dumplog, "\"%s\" : \"%s\",\n", dump[i]->id.c_str(), dump[i]->fileDump[0].c_str());
	}
	fprintf(dumplog, "\"Ndumps\" : %d\n", ndump);
	fprintf(dumplog, "}");
	fflush(dumplog);
}

/* ----------------------------------------------------------------------
// modify settings for output system
------------------------------------------------------------------------- */

#define setFile(var, file)	\
if (file) {					\
	var = file;				\
}							\
else {						\
	var.clear();			\
}

void Output::setPath(const char* key, const char* file) {

	if (strcmp(key, "lammps") == 0) {
		setFile(lammpsDir, file);
	}
	else if (strcmp(key, "eachk") == 0) {
		setFile(EACHKDir, file);
	}
	else {
		error->all(FLERR, "Illegal output keyword");
	}
}

void Output::setLogFile(const char* key, const char* file){

	if (strcmp(key, "dump") == 0) {
		setFile(dumpLogName, file);
	}
	else if (strcmp(key, "thermo") == 0) {
		setFile(thermoLogName, file);
	}
	else {
		error->all(FLERR, "Illegal output setLogFile keyword");
	}	
}

/* ----------------------------------------------------------------------
perform output for setup of run/min
do dump first, so memory_usage will include dump allocation
do thermo last, so will print after memory_usage
memflag = 0/1 for printing out memory usage
------------------------------------------------------------------------- */

void Output::setup(int memflag)
{
	int ntimestep = update->ntimestep;

	// perform dump at start of run only if:
	//   current timestep is multiple of every and last dump not >= this step
	//   this is first run after dump created and firstflag is set
	//   note that variable freq will not write unless triggered by firstflag
	// set next_dump to multiple of every or variable value
	// set next_dump_any to smallest next_dump
	// wrap dumps that invoke computes and variable eval with clear/add
	// if dump not written now, use addstep_compute_all() since don't know
	//   what computes the dump write would invoke
	// if no dumps, set next_dump_any to last+1 so will not influence next

	int writeflag;

	if (ndump) {
		for (int idump = 0; idump < ndump; idump++) {
			if (dump[idump]->clearstep || every_dump[idump] == 0)
				modify->clearstep_compute();
			writeflag = 0;
			if (every_dump[idump] && ntimestep % every_dump[idump] == 0 &&
				last_dump[idump] != ntimestep) writeflag = 1;
			if (last_dump[idump] < 0 && dump[idump]->firstFlag == 1) writeflag = 1;

			if (writeflag) {
				dump[idump]->write();
				last_dump[idump] = ntimestep;
			}
			if (every_dump[idump])
				next_dump[idump] =
				(ntimestep / every_dump[idump])*every_dump[idump] + every_dump[idump];

			if (idump) next_dump_any = MIN(next_dump_any, next_dump[idump]);
			else next_dump_any = next_dump[0];
		}
	}
	else next_dump_any = update->laststep + 1;

	if (dumplog) write_dumplog();

	// print memory usage unless being called between multiple runs
	if (memflag) memory_usage();

	// set next_thermo to multiple of every or variable eval if var defined
	// insure thermo output on last step of run
	// thermo may invoke computes so wrap with clear/add

	modify->clearstep_compute();

	thermo->header();
	thermo->compute(0);
	last_thermo = ntimestep;

	if (thermo_every) {
		next_thermo = (ntimestep / thermo_every)*thermo_every + thermo_every;
		next_thermo = MIN(next_thermo, update->laststep);
	}
	else next_thermo = update->laststep;

	// next = next timestep any output will be done

	next = MIN(next_dump_any, next_thermo);
}

/* ----------------------------------------------------------------------
perform all output for this timestep
only perform output if next matches current step and last output doesn't
do dump/restart before thermo so thermo CPU time will include them
------------------------------------------------------------------------- */

void Output::write(int ntimestep)
{
	// next_dump does not force output on last step of run
	// wrap dumps that invoke computes or eval of variable with clear/add

	if (next_dump_any == ntimestep) {
		for (int idump = 0; idump < ndump; idump++) {
			if (next_dump[idump] == ntimestep) {
				if (dump[idump]->clearstep || every_dump[idump] == 0)
					modify->clearstep_compute();
				if (last_dump[idump] != ntimestep) {
					dump[idump]->write();
					last_dump[idump] = ntimestep;
				}
				next_dump[idump] += every_dump[idump];
			}
			if (idump) next_dump_any = MIN(next_dump_any, next_dump[idump]);
			else next_dump_any = next_dump[0];
		}
	}
	if (dumplog) write_dumplog();

	// insure next_thermo forces output on last step of run
	// thermo may invoke computes so wrap with clear/add

	if (next_thermo == ntimestep) {
		modify->clearstep_compute();
		if (last_thermo != ntimestep) thermo->compute(1);
		last_thermo = ntimestep;
		if (thermo_every) next_thermo += thermo_every;
		else next_thermo = update->laststep;
		next_thermo = MIN(next_thermo, update->laststep);
	}

	// next = next timestep any output will be done

	next = MIN(next_dump_any, next_thermo);
}

/* ----------------------------------------------------------------------
force a snapshot to be written for all dumps
called from PRD and TAD
------------------------------------------------------------------------- */

void Output::write_dump(int ntimestep)
{
	for (int idump = 0; idump < ndump; idump++) {
		dump[idump]->write();
		last_dump[idump] = ntimestep;
	}
	if (dumplog) write_dumplog();
}

/* ----------------------------------------------------------------------
   timestep is being changed, called by update->setTimestep()
   reset next timestep values for dumps, restart, thermo output
   reset to smallest value >= new timestep
   if next timestep set by variable evaluation,
     eval for ntimestep-1, so current ntimestep can be returned if needed
     no guarantee that variable can be evaluated for ntimestep-1
       if it depends on computes, but live with that rare case for now
------------------------------------------------------------------------- */


void Output::setTimestep(int ntimestep)
{
	next_dump_any = INT_MAX;
	for (int idump = 0; idump < ndump; idump++) {
		if (every_dump[idump]) {
			next_dump[idump] = (ntimestep / every_dump[idump])*every_dump[idump];
			if (next_dump[idump] < ntimestep) next_dump[idump] += every_dump[idump];
		}
		next_dump_any = MIN(next_dump_any, next_dump[idump]);
	}

	if (thermo_every) {
		next_thermo = (ntimestep / thermo_every)*thermo_every;
		if (next_thermo < ntimestep) next_thermo += thermo_every;
		next_thermo = MIN(next_thermo, update->laststep);
	}
	else next_thermo = update->laststep;

	next = MIN(next, next_thermo);
}

/* ----------------------------------------------------------------------
add a Dump to list of Dumps
------------------------------------------------------------------------- */

void* Output::addDump(int step, const char* id, const char* style, const char* file)
{
	// error checks

	for (int idump = 0; idump < ndump; idump++)
	if (id == dump[idump]->id) error->all(FLERR, "Reuse of dump ID");
	if (step <= 0) error->all(FLERR, "Invalid dump frequency");

	// extend Dump list if necessary

	if (ndump == max_dump) {
		max_dump += DELTA;
		dump = (Dump **)
			memory->srealloc(dump, max_dump*sizeof(Dump *), "output:dump");
		memory->grow(every_dump, max_dump, "output:every_dump");
		memory->grow(next_dump, max_dump, "output:next_dump");
		memory->grow(last_dump, max_dump, "output:last_dump");
	}

	// initialize per-dump data to suitable default values

	every_dump[ndump] = 0;
	last_dump[ndump] = -1;
	// create the Dump

	if (dump_map->find(style) != dump_map->end()) {
		DumpCreator dump_creator = (*dump_map)[style];
		dump[ndump] = dump_creator(eapot, id, style, file);
	}
	else error->all(FLERR, "Unknown dump style");

	every_dump[ndump] = step;
	if (every_dump[ndump] <= 0) error->all(FLERR, "Illegal dump command");
	last_dump[ndump] = -1;
	ndump++;

	eapot->once_initFlag = 0;
	return dump[ndump - 1];
}

/* ----------------------------------------------------------------------
one instance per dump style in style_dump.h
------------------------------------------------------------------------- */

template <typename T>
Dump *Output::dump_creator(EAPOT *eapot, const char* id, const char* style, const char* file)
{
	return new T(eapot, id, style, file);
}


/* ----------------------------------------------------------------------
delete a Dump from list of Dumps
------------------------------------------------------------------------- */

void Output::deleteDump(void* pdump)
{
	// find which dump it is and delete it

	int idump;
	for (idump = 0; idump < ndump; idump++)
	if (pdump == dump[idump]) break;
	if (idump == ndump) error->all(FLERR, "Could not find undump");

	delete dump[idump];

	// move other dumps down in list one slot

	for (int i = idump + 1; i < ndump; i++) {
		dump[i - 1] = dump[i];
		every_dump[i - 1] = every_dump[i];
		next_dump[i - 1] = next_dump[i];
		last_dump[i - 1] = last_dump[i];
	}
	ndump--;
}

/* ----------------------------------------------------------------------
find a dump by ID
return index of dump or -1 if not found
------------------------------------------------------------------------- */

int Output::findDump(const char *id)
{
	if (id == NULL) return -1;
	int idump;
	for (idump = 0; idump < ndump; idump++)
	if (id == dump[idump]->id) break;
	if (idump == ndump) return -1;
	return idump;
}

void* Output::getDump(const char* id, const char* style) {

	int idx = findDump(id);
	if (idx < 0) {
		ErrorAll("can not find Dump: %s", id);
	}

	if (style) dump[idx]->styleCheck(FLERR, style, 1);;
	return dump[idx];
}

/* ----------------------------------------------------------------------
set thermo output frequency from input md.run
------------------------------------------------------------------------- */

void Output::setThermoStep(int narg)
{
	thermo_every = narg;
	if (thermo_every < 0) error->all(FLERR, "Illegal thermo steps");
}

/* ----------------------------------------------------------------------
new Thermo style
------------------------------------------------------------------------- */

void Output::setThermoKeys(const char* style, int num, const char** keys)
{

	// warn if previous thermo had been modified via thermo_modify command

	if (thermo->modified)
		error->warning(FLERR, "New thermo_style command, "
		"previous thermo_modify settings will be lost");

	// set thermo = NULL in case new Thermo throws an error

	delete thermo;
	thermo = NULL;
	thermo = new Thermo(eapot, style, num, keys);
}

/* ----------------------------------------------------------------------
sum and print memory usage
result is only memory on proc 0, not averaged across procs
------------------------------------------------------------------------- */
void Output::memory_usage()
{

}

void Output::runDumpOnce()
{
	eapot->init();
	write_dump(0);
}

void Output::setDumpStep(void* dump, int n) {
	int idump;
	for (idump = 0; idump < output->ndump; idump++)
		if (dump == output->dump[idump]) break;
	if (idump <= 0) error->all(FLERR, "Illegal setDumpSteps command: ");

	output->every_dump[idump] = n;
	if (n <= 0) error->all(FLERR, "Illegal dump_modify command");
};

void Output::setThermoLineStyle(const char* format) {
	thermo->modified = 1;
	if (strcmp(format, "one") == 0) {
		thermo->lineflag = Thermo::ONELINE;
	}
}

void Output::setThermoPrintCost(int flag) {
	thermo->modified = 1;
	thermo->costflag = flag;
}

void Output::setThermoBlank(int flag) {
	thermo->modified = 1;
	thermo->blankFlag = flag;
}

void Output::delThermoFormat() {
	thermo->modified = 1;
	delete[] thermo->format_line_user;
	delete[] thermo->format_int_user;
	delete[] thermo->format_float_user;
	thermo->format_line_user = NULL;
	thermo->format_int_user = NULL;
	thermo->format_float_user = NULL;
	for (int i = 0; i < thermo->nfield_initial + 1; i++) {
		delete[] thermo->format_column_user[i];
		thermo->format_column_user[i] = NULL;
	}
}

void Output::setThermoFormatIndex(int i, const char* format) {
	thermo->modified = 1;
	if (i < 0 || i >= thermo->nfield_initial + 1) {
		error->all(FLERR, "Illegal setThermoFormatIndex command");
	}
	if (thermo->format_column_user[i]) delete[] thermo->format_column_user[i];
	int n = strlen(format) + 1;
	thermo->format_column_user[i] = new char[n];
	strcpy(thermo->format_column_user[i], format);
}

void Output::setThermoFormatStyle(const char* key, const char* format) {
	thermo->modified = 1;

	if (strcmp(key, "line") == 0) {
		delete[] thermo->format_line_user;
		int n = strlen(format) + 1;
		thermo->format_line_user = new char[n];
		strcpy(thermo->format_line_user, format);
	}
	else if (strcmp(key, "int") == 0) {
		if (thermo->format_int_user) delete[] thermo->format_int_user;
		int n = strlen(format) + 1;
		thermo->format_int_user = new char[n];
		strcpy(thermo->format_int_user, format);
		// replace "d" in format_int_user with int format specifier
		// use of &str[1] removes leading '%' from BIGINT_FORMAT string
		char* ptr = strchr(thermo->format_int_user, 'd');
		if (ptr == NULL) error->all(FLERR,
			"setThermoFormatStyle int format does not contain d character");
	}
	else if (strcmp(key, "float") == 0) {
		if (thermo->format_float_user) delete[] thermo->format_float_user;
		int n = strlen(format) + 1;
		thermo->format_float_user = new char[n];
		strcpy(thermo->format_float_user, format);
	}
	else if (strcmp(key, "cost_float") == 0) {
		if (thermo->format_cost_float_user) delete[] thermo->format_cost_float_user;
		int n = strlen(format) + 1;
		thermo->format_cost_float_user = new char[n];
		strcpy(thermo->format_cost_float_user, format);
	}
	else if (strcmp(key, "cost_line") == 0) {
		delete[] thermo->format_cost_line_user;
		int n = strlen(format) + 1;
		thermo->format_cost_line_user = new char[n];
		strcpy(thermo->format_cost_line_user, format);
	}
	else {
		error->all(FLERR, "Illegal setThermoFormatStyle command");
	}

}







void Output::dump_lmp(const char* name, int num, double* bound, int* id, int* type, double* p){
	
	char buff[256];

	FILE* pfile;
	pfile = fopen(name, "w");
	if (pfile == NULL){
		sprintf(buff, "file %s canot open!", name);
		error->all(FLERR, buff);
	}

	char format_std[] = "%20.12f\t";
	char format_end[] = "%20.12f\n";
	
	fprintf(pfile,
		"ITEM: TIMESTEP\n"
		"0\n"
		"ITEM: NUMBER OF ATOMS\n"
		"%d\n"
		"ITEM: BOX BOUNDS pp pp pp\n"
		"%20.12f %20.12f\n"
		"%20.12f %20.12f\n"
		"%20.12f %20.12f\n"
		"ITEM: ATOMS id type x y z\n",
		num, bound[0], bound[1], bound[2],
		bound[3], bound[4], bound[5]
		);

	int tid, ttype, len;

	for (int i = 0; i < num; i++){

		tid = id ? id[i] : (i + 1);
		ttype = type ? type[i] : 1;

		len = sprintf(buff, "%d\t", tid);
		len += sprintf(buff + len, "%d\t", ttype);

		len += sprintf(buff + len, format_std, p[3 * i]);
		len += sprintf(buff + len, format_std, p[3 * i + 1]);
		len += sprintf(buff + len, format_end, p[3 * i + 2]);

		fputs(buff, pfile);
	}
	fclose(pfile);

}