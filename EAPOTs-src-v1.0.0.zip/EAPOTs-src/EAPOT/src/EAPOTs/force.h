#ifndef EAPOT_FORCE_H
#define EAPOT_FORCE_H

#include "pointers.h"
#include <stdio.h>
#include <map>
#include <vector>
#include <string>

namespace EAPOT_NS {

	class Force : protected Pointers {
	public:
		class Pair *pair;
		char *pair_style, *pair_top;

		class Bond *bond;
		char *bond_style, *bond_top;

		typedef Pair *(*PairCreator)(EAPOT *);
		typedef Bond *(*BondCreator)(EAPOT *);

		typedef std::map<std::string, PairCreator> PairCreatorMap;
		typedef std::map<std::string, BondCreator> BondCreatorMap;

		PairCreatorMap *pair_map;
		BondCreatorMap *bond_map;

		Force(class EAPOT *);
		~Force();
		void init();
		void setup();

		void create_bond(const char *, int);
		class Bond *new_bond(const char *, int, int &);

		void store_style(char *&, char *&, const char *);

		int get_ntypes();
		void set_ntypes(int);

		int get_eleidx(int);
		const char* get_elestr(int);
		void set_elestr(int, const char*);

		std::string ele_line;
		std::vector<double> massVec;
		std::vector<const char*> getEles();
		std::string& eleLineFormat(const char*);		

	private:
		int ntypes;
		std::vector<int> eleidx;
		std::vector<std::string> elestr;

		template <typename T> static Pair *pair_creator(EAPOT *);
		template <typename T> static Bond *bond_creator(EAPOT *);

	public: // API
		void* addPair(const char*);
		void setMass(int n, double* mass);
		void setElement(int n, const char** ele);
		const char* getPotScript(void* pPair);
	};

}

#endif