#ifdef MINIMIZE_CLASS
MinimizeStyle(pso/taka, MinPSOTaka)
#else

#ifdef LIBAPI
LIBAPI(void, setParticleSwarmTakaParticles, (APITYPE int n), (APINAME n));
#else

#ifndef EAPOT_MIN_PSOTAKA_H
#define EAPOT_MIN_PSOTAKA_H

#include "min.h"

namespace EAPOT_NS {

	class MinPSOTaka : public Min {
		friend class MiniStyle;
	public:
		MinPSOTaka(class EAPOT *);
		~MinPSOTaka();
		void init();
		void setup_style();
		void reset_vectors();

		/* Particle Swarm Optimization */
		int iterate(int);

	protected:
		// vectors needed by linesearch minimizers
		// xvec,fvec are stored by Pair class

		int iG;							//Global optimal solution index
		double *XG, YG;					//Global optimal solution vector and value

		double **X, **Xbest, **V;
		double *Y, *Ybest;
		int Nparticle;					// Number of particles 
	

		void UpdateBest(int i);			/* update pbest */
		void UpdateGlobal(int i);
		double currenterr(const int n);
	};

}

#endif
#endif
#endif

/* Coded by T.Takahama */