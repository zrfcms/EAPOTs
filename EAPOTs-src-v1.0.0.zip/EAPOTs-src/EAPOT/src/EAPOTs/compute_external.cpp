#include "compute_external.h"
#include <ctype.h>
#include <stdlib.h>

#include "modify.h"

#include "memory.h"
#include "error.h"
#include "force.h"
#include "pair.h"
#include "option_comp.h"

using namespace EAPOT_NS;

ComputeTerm::ComputeTerm(EAPOT *eapot, const char* pid, const char* pstyle, const char* pfile)
: Compute(eapot, pid, pstyle, pfile)
, callback(NULL)
, caller(NULL){
	styles.push_back("term");
}

void CompStyle::setComputeExternalTitle(void* pcomp, const char* ptitle) {
	((Compute*)pcomp)->styleCheck(FLERR, "term", 1);
	((ComputeTerm*)pcomp)->costThermoHead = ptitle;
};

void CompStyle::setComputeExternalScript(void* pcomp, const char* script) {
	((Compute*)pcomp)->styleCheck(FLERR, "term", 1);
	((ComputeTerm*)pcomp)->pythonScript = script;
}

void CompStyle::setComputeExternalCallback(void* pcomp, CompCallback callback, void* caller) {
	((Compute*)pcomp)->styleCheck(FLERR, "term", 1);
	((ComputeTerm*)pcomp)->callback = callback;
	((ComputeTerm*)pcomp)->caller = caller;
}


ComputeTerm::~ComputeTerm(){
};

void ComputeTerm::init()
{
	data.resize(1, 0.0);

	if (!pythonScript.empty() && !this->callback && eapot->pythonCallback) {
		std::string str = pythonScript +
			"\neapot.computeCostAPI = eapot.CompCallbackType(computeCostScript)\n"
			"cost = eapot.getCompute('cost', None)\n"
			"eapot.setComputeExternalCallback(cost, eapot.computeCostAPI, None)\n";

		eapot->pythonCallback(eapot->caller, FLERR, str.c_str());

	}
	if (!this->callback) {
		error->all(FLERR, "external callback is empty!");
	}
}

void ComputeTerm::compute()
{

	std::vector<void*> param;
	std::vector<const char*> style;

	int idx = 0;
	for (int icom = 0; icom < modify->ncompute - 1; icom++) {
		Compute* pc = modify->compute[icom];
		if (pc->vparam == NULL) continue;
		param.push_back(pc->vparam);
		style.push_back(pc->styles.back()); 
		idx++;
	}

	auto &p = force->pair->paramVec;
	const char* res = (this->callback)(caller, p.size(), p.data(), idx, style.data(), param.data(), &data[0]);
	costThermoLog = res;
}

inline double square(double t) {
	return t*t;
}

double paramlimit(double x, double a, double b, double c) {
	return c * (x < a) * (x / a - 1) * (x / a - 1) + c * (b < x) * (x / b - 1) * (x / b - 1);
}

void ComputeTerm::extracheck(int type) {
	compute();

	double ratio;
	double* hcp = modify->compute[0]->data.data();
	double* hcpYs = modify->compute[1]->data.data();

	double* fcc = modify->compute[2]->data.data();
	double* fccYs = modify->compute[3]->data.data();
	double* fccEla = modify->compute[5]->data.data();

	double* L10 = modify->compute[6]->data.data();


	ratio = 16020 / (fccYs[0] * fccYs[1]);
	double YsFcc = ratio * (fccYs[6] - 6 * fcc[6]);
	double c_A0Fcc = 10.0 * square(fcc[0] / 3.61 - 1.0);
	double c_YsFcc = 5.0 * square(YsFcc / 52.0 - 1.0);

	double c_C11 =  1.0*square(fccEla[0*6+0]/172 - 1.0);
	double c_C12 =  1.0*square(fccEla[0*6+1]/125 - 1.0);
	double c_C33 =  1.0*square(fccEla[3*6+3]/80  - 1.0);

	double caHcp = hcp[2] / hcpYs[1];
	ratio = 16020 / (hcpYs[0] * hcpYs[1]);
	double YsHcp = ratio * (hcpYs[6] - 6 * hcp[6]);
	double c_A0Hcp = 10.0 * square(hcp[1] / 2.55 - 1.0);
	double c_CAHcp = 10.0 * square(caHcp / 1.65 - 1.0);
	double c_YsHcp = 5.0 * square(YsHcp / -13.0 - 1.0);

	double caL10 = L10[2] / L10[0];
	double c_A0L10 = 100.0 * square(L10[0] / 3.56 - 1.0);
	double c_CAL10 = 100.0 * square(caL10 / 1.025 - 1.0);
	double c_EcL10 = 1.0e3 * square(-L10[6] / 15.8 - 1.0);

	double p0 = force->pair->paramVec[0];
	double p1 = force->pair->paramVec[1];
	double p2 = force->pair->paramVec[2];
	double c_p0 = paramlimit(p0, 0.15, 0.35, 1e2);
	double c_p1 = paramlimit(p1, 10.0, 15.0, 1e2);
	double c_p2 = paramlimit(p2, 0.12, 0.30, 1e2);

	double total = c_A0Fcc + c_YsFcc + c_C11 + c_C12 + c_C33 +
		c_A0Hcp + c_CAHcp + c_YsHcp + c_A0L10 + c_CAL10 + c_EcL10;
	total  += c_p0 + c_p1 + c_p2;

	error->add_chklog(0, "ComTermPython", "");
	error->check(FLERR, 1, data.data(), &total, 1, "ComTermPython", "Py", 5e-14, 5e-15, 0.0, 0);
}

