#ifndef EAPOT_MODIFY_H
#define EAPOT_MODIFY_H

#include "pointers.h"

#include <string>
#include <map>


namespace EAPOT_NS {

	class Modify : protected Pointers
	{
	public:
		Modify(EAPOT *eapot);
		~Modify();
		virtual void init();
		virtual void setup(int);

		void clearstep_compute();

	public:

		typedef const char* CPCHAR;
		class Compute **compute;
		int ncompute, maxcompute;		

		typedef Compute	*(*ComputeCreator)(EAPOT *, CPCHAR, CPCHAR, CPCHAR);
		typedef std::map<std::string, ComputeCreator> ComputeCreatorMap;
		ComputeCreatorMap	*compute_map;
		int find_compute(const char *id);		

	public:	// API
		void* addCompute(CPCHAR id, CPCHAR style, CPCHAR file);
		void* getCompute(const char* id, const char* style);

	protected:
		template <typename T> static Compute *compute_creator(EAPOT *, CPCHAR, CPCHAR, CPCHAR);
	};

}
//

#endif

