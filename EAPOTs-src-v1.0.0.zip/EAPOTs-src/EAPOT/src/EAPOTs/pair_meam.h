#ifdef PAIR_CLASS
PairStyle(meam/first, PairMEAM)
PairStyle(meam/second, PairMEAM2nd)
#else

#ifdef LIBAPI
LIBAPI(void, addPairMEAMFreeParam, (APITYPE void* pPair, int num, const char** params), (APINAME pPair, num, params));
LIBAPI(void, addPairMEAMConstParam, (APITYPE void* pPair, int num, const char** params), (APINAME pPair, num, params));
#else

#ifndef EAPOT_PAIR_MEAM_H
#define EAPOT_PAIR_MEAM_H

#include "pair.h"
#include <vector>
#include <string>

#define maxelt 5
#define MEAMNParam 18

namespace EAPOT_NS {

	class PairMEAM : public Pair
	{
		friend class PairStyle;
		typedef enum { FCC, BCC, HCP, DIM, DIA, DIA3, B1, C11, L12, B2, CH4, LIN, ZIG, TRI } lattice_t;
	public:
		double cutmax;

		PairMEAM(EAPOT *eapot);
		~PairMEAM();

		void fvec_allocate();						// Note that it is need to consistent with getPresetScript()
		void setFreeParamsStyle();

		void export_pair(void*);
		void export_init(void*);
		virtual void extra_check(int);

	public:
		// output function
		void write(class DumpFile* dump);
		void transByFile(const char*);
		
		void try_set_meam_extra(void* ptr, int which, double value, int nindex, int* index);

	private:
		void meam_setup_global(int nelt, lattice_t* lat, int* ielement, double* atwt, double* alpha,
			double* b0, double* b1, double* b2, double* b3, double* alat, double* esub, double* asub,
			double* t0, double* t1, double* t2, double* t3, double* rozero, int* ibar);

		void meam_checkindex(int num, int lim, int nidx, int* idx, int* ierr);
		void meam_setup_param(int which, double value, int nindex, int* index /*index(3)*/, int* errorflag);
		void meam_setup_done(double* cutmax);
		void alloyparams(void);

		void compute_pair_meam(void);
		void compute_reference_density();

		double fcut(const double xi);
		double erose(const double r, const double re, const double alpha, const double Ec,
			const double repuls, const double attrac, const int form);
		void get_sijk(double C, int i, int j, int k, double* sijk);

		int get_Zij(const lattice_t latt);
		int get_Zij2(const lattice_t latt, const double cmin, const double cmax,
			const double stheta, double& a, double& S);
		int get_Zij2_b2nn(const lattice_t latt, const double cmin, const double cmax, double& S);
		void get_shpfcn(const lattice_t latt, const double sthe, const double cthe, double(&s)[3]);

		double embedding(const double A, const double Ec, const double rhobar, double& dF) const;
		double G_gam(const double gamma, const int ibar, int& errorflag) const;
		static double zbl(const double r, const int z1, const int z2);
		const double phi_meam_series(const double scrn, const int Z1, const int Z2, const int a, const int b, const double r, const double arat);

		void get_densref(double r, int a, int b, double* rho01, double* rho11, double* rho21, double* rho31,
			double* rho02, double* rho12, double* rho22, double* rho32);

		void get_tavref(double* t11av, double* t21av, double* t31av, double* t12av, double* t22av, double* t32av,
			double t11, double t21, double t31, double t12, double t22, double t32, double r, int a, int b, lattice_t latt);
		void interpolate_meam(int);

		double phi_meam(double r, int a, int b);
		int image(class DumpImage* dumpimage);

	protected:

		double cutforce, cutforcesq;

		double Ec_meam[maxelt][maxelt], re_meam[maxelt][maxelt];
		double A_meam[maxelt], alpha_meam[maxelt][maxelt], rho0_meam[maxelt];
		double delta_meam[maxelt][maxelt];
		double beta0_meam[maxelt], beta1_meam[maxelt];
		double beta2_meam[maxelt], beta3_meam[maxelt];
		double t0_meam[maxelt], t1_meam[maxelt];
		double t2_meam[maxelt], t3_meam[maxelt];
		double rho_ref_meam[maxelt];
		int ibar_meam[maxelt], ielt_meam[maxelt];
		lattice_t lattce_meam[maxelt][maxelt];
		int nn2_meam[maxelt][maxelt];
		int zbl_meam[maxelt][maxelt];
		int eltind[maxelt][maxelt];
		int neltypes;

		double** phir;
		double** phirar, ** phirar1, ** phirar2, ** phirar3, ** phirar4, ** phirar5, ** phirar6;

		double attrac_meam[maxelt][maxelt], repuls_meam[maxelt][maxelt];

		double Cmin_meam[maxelt][maxelt][maxelt];
		double Cmax_meam[maxelt][maxelt][maxelt];
		double rc_meam, delr_meam, ebound_meam[maxelt][maxelt];
		int augt1, ialloy, mix_ref_t, erose_form;
		int emb_lin_neg, bkgd_dyn;
		double gsmooth_factor;

		int vind2D[3][3], vind3D[3][3][3];                  // x-y-z to Voigt-like index
		int v2D[6], v3D[10];                                // multiplicity of Voigt index (i.e. [1] -> xy+yx = 2

		int nr, nrar;
		double dr, rdrar;

		double stheta_meam[maxelt][maxelt];
		double ctheta_meam[maxelt][maxelt];

		/*
		'Cu'(elt)            'fcc'(lattce_s)   12.(z)          29(ielement)    63.54(atwt)
		5.10570729(alpha_s)  3.634(b0)         2.20(b1)        6(b2)           2.20(b3)      3.62(alat)    3.54(Ec_s)    1.07(A)
		1.0(t0)              3.13803254(t1)    2.49438711(t2)  2.95269237(t3)  1.(rho0)      0(ibar)
		*/

		int lattce_s[maxelt];
		double z[maxelt], atwt[maxelt];			// note that z was unused		
		double alpha_s[maxelt];
		double alat_s[maxelt], Ec_s[maxelt];


		// t0 = 1.0, z[i] = MEAM::get_Zij(lat[i])
		// z given is ignored: if this is mismatched, we definitely won't do what the user said -> fatal error
		int secondFlag;
		static const int nkeyCross;
		static const char* keySingle[];
		static const char* keyCross[];
		static const char* idx2Latc[];

		struct ExtraParam {
			int which;
			int nindex;
			int index[3];
			double value;
			char name[64];
		};
		ExtraParam get_extra_param(const char*);
		std::vector<ExtraParam> fextra, cextra;

	private:
		int getPyParamNum();
		void defaultDofMap(double*, double*);
	};

	class PairMEAM2nd :public PairMEAM 
	{
	public:
		PairMEAM2nd(EAPOT* eapot);
		void extra_check(int);
	};
}

#endif
#endif
#endif