#ifdef PAIR_CLASS
PairStyle(bop/tersoff, PairTersoff)
PairStyle(bop/brenner, PairBrenner)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_TERSOFF_H
#define EAPOT_PAIR_TERSOFF_H

#include "pair_tribody.h"
#include <vector>
#include <string>

namespace EAPOT_NS {

	class PairTersoff : public PairTribody
	{
	public:

		PairTersoff(EAPOT *eapot);
		~PairTersoff();

		void fvec_allocate();						// Note that it is need to consistent with getPresetScript()

		virtual void export_pair(void*);
		void export_init(void*);
		void extra_check(int);

		virtual int image(class DumpImage* dumpimage);

	private:
		void defaultDofMap(double*, double*);
	};

	class PairBrenner : public PairTersoff
	{
	public:

		PairBrenner(EAPOT* eapot);
		~PairBrenner();

		void extra_check(int);
		void setFreeParamsStyle();
	};
}

#endif
#endif
#endif