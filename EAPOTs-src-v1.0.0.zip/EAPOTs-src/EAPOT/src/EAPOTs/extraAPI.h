#ifdef OUTPUTAPI
// delete a Dump from Dump list
LIBAPI(void, deleteDump, (APITYPE void* pDump), (APINAME pDump));

// modify lammps eachk dir
LIBAPI(void, setPath, (APITYPE const char* key, const char* path), (APINAME key, path));
// modify thermoLogName, dumpLogName
LIBAPI(void, setLogFile, (APITYPE const char* key, const char* file), (APINAME key, file));
LIBAPI(void, setDumpStep, (APITYPE void* pDump, int step), (APINAME pDump, step));

// set thermo output freqquency
LIBAPI(void, setThermoStep, (APITYPE int step), (APINAME step));
// create a thermo style
LIBAPI(void, setThermoKeys, (APITYPE const char* style, int num, const char** keys), (APINAME style, num, keys));

LIBAPI(void, setThermoLineStyle, (APITYPE const char* fmt), (APINAME fmt));
LIBAPI(void, setThermoPrintCost, (APITYPE int flag), (APINAME flag));
LIBAPI(void, setThermoBlank, (APITYPE int flag), (APINAME flag));

LIBAPI(void, setThermoFormatIndex, (APITYPE int i, const char* fmt), (APINAME i, fmt));
LIBAPI(void, setThermoFormatStyle, (APITYPE const char* key, const char* fmt), (APINAME key, fmt));

#else


#endif