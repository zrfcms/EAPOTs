#ifndef EAPOT_IMAGE_H
#define EAPOT_IMAGE_H

#include <math.h>
#include <stdio.h>
#include <vector>
#include <string>

#include "pointers.h"
#include "imageTypes.h"

namespace EAPOT_NS {

	typedef unsigned char ubyte;

	struct Font {
		int width;
		int height;
	};

	struct Color {
		ubyte r;
		ubyte g;
		ubyte b;
	};

	struct PlotLine {
		double data;				// point coordinates in a axis
		double start;				// Starting point coordinates in b axis
		double finish;				// Finish   point coordinates in b axis

		int vertical;				// 0 for horizontal, 1 for vertical
		int reallen;				// Solid line length in dashed line
		int imagelen;				// Blank length in dashed line
	};

	class Axes {
		friend class Image;
	public:
		Axes(class Image*);
		void show();
		Axes& legend(double centx, double centy);
		Axes& limit(double, double, double, double);
		Axes& limit(const AxisLimit& x, const AxisLimit& y);
		Axes& setRange(double dx, double dy, double dwidth, double dheight);

		Axes& line(PlotLine line);
		Axes& plot(int n, double *val, const char* label);
		Axes& text(double x, double y, const char* str, double xoffset = 0, double yoffset = 0);
		Axes& frame(double x1, double x2, double y1, double y2, int margin, bool check = false);

		int xlo, ylo;				// Starting point coordinates in x,y axis
		int width, height;			// lenth in x, y axis
		int xhi, yhi;				// Finish point coordinates in x, y axis

		double xrange[3];			// Data limits for X-axis range (xlim)
		double yrange[3];			// Data limits for Y-axis range (ylim)

		bool box;					// draw box frame
		std::string xlabel;			// label in x axis
		std::string ylabel;			// label in y axis

		std::vector<Color> plotColor;
		std::vector<std::string> labelText;

	private:
		Image* image;
	};



	

	class Image : protected Pointers {

	public:		

		Color color;
		Color backColor;				// RGB values of background		

		int width, height;				// size of image
		int linewidth, quality;
		std::vector<Axes> axes;

		enum class ImageFormat { BMP, JPG, PNG } format;

		Image(class EAPOT *, int);
		~Image();
		void buffers();
		void clear();
		void show();

		void write(FILE*);
		void writeBMP(FILE*);
		void writeJPG(FILE*);

		double *element2color(char *);
		double element2diam(char *);
		double *color2rgb(const char *, int index = 0);
		int default_colors();
		ubyte *GetBuffer(){	return imageBuffer;	};

	public:
		Font font;
		std::vector<Axes>& subplots(int nx, int ny);
		void createAxes(double, double, double, double);

		void BGRTrans(ubyte& r, ubyte& g, ubyte& b);
		void setColord(double r, double g, double b);
		void setColoru(ubyte r, ubyte g, ubyte b);
		Color setColorRainbow(double x);

		void drawColor(int ix, int iy);
		void drawColor_s(int ix, int iy);
		void drawColor(int ix, int iy, double alpha);
		void drawColor_s(int ix, int iy, double alpha);
		void drawColor_y(int ix, double dy, double alpha = 1);
		void drawColor_x(double dx, int iy, double alpha = 1);

		void Bresenhamy(int ix1, int ix2, double dy1, double dy2);

		void drawFrameLineY(int x, int y1, int y2);
		void drawFrameLineX(int y, int x1, int x2);

		void xUnitize(int n, double* x, double xlo, 
			double xhi, double unitlo, double unithi);
		void yUnitize(int n, double* y, double ylo,
			double yhi, double unitlo, double unithi);

		const unsigned char* ascii(char idx);
	private:
		int npixels;
		unsigned char *imageBuffer;

		// internal methods

		void drawPixel(int ix, int iy, double *c);
		// inline functions

		inline double saturate(double v) {
			if (v < 0.0) return 0.0;
			else if (v > 1.0) return 1.0;
			else return v;
		}

		inline double distance(double* a, double* b) {
			return sqrt((a[0] - b[0]) * (a[0] - b[0]) +
				(a[1] - b[1]) * (a[1] - b[1]) +
				(a[2] - b[2]) * (a[2] - b[2]));
		}
	};

}

#endif
