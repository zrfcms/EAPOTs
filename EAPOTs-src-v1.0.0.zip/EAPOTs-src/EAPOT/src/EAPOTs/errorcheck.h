#ifndef EAPOT_ERROR_CHECK_H
#define EAPOT_ERROR_CHECK_H

#include "pointers.h"


namespace EAPOT_NS {

	class ErrorCheck
	{
	public:
		int num;
		double max;
		double all;
		int mi;
		int mj;
		int mk;
		const char* name;

		double maxcut;
		double allcut;

		ErrorCheck(){
			Reset();
		}

		void Reset(){
			num = 0;
			max = 0;
			all = 0;
			mi = 0;
			mj = 0;
			mk = 0;
			name = "";
		}

		void Reset(double pmaxcut, double pallcut){
			maxcut = pmaxcut;
			allcut = pallcut;

			Reset();
		}

		void Merge(int pnum, double pmax, double pall){
			all += pall;
			max = max > pmax ? max : pmax;
			num += pnum;
		}

		void SetIndex(int i, int j, int k){
			mi = i;
			mj = j;
			mk = k;
		}
	};
}

#endif

