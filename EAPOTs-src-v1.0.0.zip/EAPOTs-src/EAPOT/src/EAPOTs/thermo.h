#ifndef EAPOT_THERMO_H
#define EAPOT_THERMO_H

#include "pointers.h"
#include <vector>
#include <string>

namespace EAPOT_NS {

	class Thermo : protected Pointers {
		friend class Output;
	public:

		enum { ONELINE, MULTILINE, NONE };
		enum { INT, FLOAT, STRING };

		char *style;
		int normflag;          // 0 if do not normalize by atoms, 1 if normalize
		int modified;          // 1 if thermo_modify has been used, else 0
		int blankFlag;		   // 1 if do not output any information, else 0

		Thermo(class EAPOT *, const char* style, int num, const char **keys);
		~Thermo();
		void init();
		void header();
		void compute(int);

		int printHeaderFlag;		// 1 if now thermo is printing header
									// singal for all thermo key words function

	private:

		char *line;

		typedef void (Thermo::*FnPtr)();
		FnPtr *vfunc;                // list of ptrs to functions
		void call_vfunc(int);

		int nfield, nfield_initial;
		char **keyword;
		int *vtype;

		int ifield;            // which field in thermo output is being computed
		int *field2index;      // which compute,fix,variable calcs this field
		int *argindex1;        // indices into compute,fix scalar,vector
		int *argindex2;


		int ncompute;                // # of Compute objects called by thermo
		char **id_compute;           // their IDs
		int *compute_which;          // 0/1/2 if should call scalar,vector,array
		class Compute **computes;    // list of ptrs to the Compute objects
		class ComputeTerm *err;
		
		std::vector<int> dumps;
		std::vector<std::string> id_dump;

		// private methods

		void allocate();
		void deallocate();
		void parse_fields(char *str);

		char **format;		
		char *format_line_user;		//format values = line string

		//format values = int string, float string
		char *format_float_user, *format_int_user;
		//M string: M = integer from 1 to N, where N = # of quantities being output
		char **format_column_user;

		char *format_float_one_def;
		char *format_int_one_def;

		int firststep;
		int lineflag;
		double last_time;
		int last_step;

		int costflag;
		int format_cost_num;
		char **format_cost;
		char *format_cost_line_user;
		char *format_cost_float_user;
		char *format_cost_float_one_def;

		int ivalue;            // integer value to print
		double dvalue;         // double value to print
		const char* svalue;
	
		void addfield(const char *key, FnPtr func, int typeflag);
		int addCompute(const char*, int);
		int add_dump(const char*);

		void compute_step();
		void compute_neval();
		void compute_err();
		void compute_pylog();
		void compute_checklog();
		void compute_compute();
		void compute_dump();
	};

}

#endif
