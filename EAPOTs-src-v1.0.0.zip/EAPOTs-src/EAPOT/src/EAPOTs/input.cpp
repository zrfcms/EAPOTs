#include "stdlib.h"
#include "string.h"
#include <errno.h>
#include "sys/stat.h"

#include "memory.h"
#include "error.h"
#include "input.h"

#if defined(_WIN32)
#include "io.h"
#include "direct.h"
#define access	_access
#define getcwd	_getcwd	
#define chdir	_chdir	
#define unlink	_unlink	
#define rmdir	_rmdir	
#define strdup	_strdup	
#define putenv	_putenv
#endif

#if !defined(_WIN32) || defined(__MINGW32__)
#include <unistd.h>
#endif

using namespace EAPOT_NS;

#define NELEMENTS 118

Input::Input(EAPOT* eapot)
	: Pointers(eapot)
	, timestr("")
	, lastCommand("(unknown)")
{
	echo_screen = 0;
	echo_log = 1;

	time_label = 0;

	tmpBuffSize = 1024;
	tmpBuff = NULL;
	memory->create(tmpBuff, tmpBuffSize, "Input::tmpBuff");
}

Input::~Input()
{
	memory->destroy(tmpBuff);
	tmpBuff = NULL;

}

void Input::print(const char* buff) {
	if (screen) fprintf(screen, buff);
	if (logfile) fprintf(logfile, buff);
}

const char Input::splitWord[] = " \t\n\r\f";

void Input::getRange(int n, double* v, double& plo, double& phi) {
	double lo = v[0];
	double hi = v[0];
	for (int i = 1; i < n; i++) {
		lo = MIN(lo, v[i]);
		hi = MAX(hi, v[i]);
	}
	plo = lo;
	phi = hi;
}


FILE* Input::open(char const* _FileName, char const* _Mode) {

	FILE* pf = fopen(_FileName, _Mode);
	if (pf == NULL) {
		ErrorAll("Cannot open file %s", _FileName);
	}

	return pf;
}

int Input::read_lines_from_file(FILE* fp, int nlines, int maxline, char* buf)
{
	int m;

	m = 0;
	for (int i = 0; i < nlines; i++) {
		if (!fgets(&buf[m], maxline, fp)) {
			m = 0;
			break;
		}
		m += strlen(&buf[m]);
	}
	if (m) {
		if (buf[m - 1] != '\n') strcpy(&buf[m++], "\n");
		m++;
	}

	if (m == 0) return 1;

	return 0;
}


double Input::numeric(const char *file, int line, const char *str)
{
	if (!str) {
		error->all(file, line, "Expected floating point parameter "
			"in input script or data file");
		return 0.0;
	}

	int n = strlen(str);
	if (n == 0)
		error->all(file, line, "Expected floating point parameter "
		"in input script or data file");

	for (int i = 0; i < n; i++) {
		if (isdigit(str[i])) continue;
		if (str[i] == '-' || str[i] == '+' || str[i] == '.') continue;
		if (str[i] == 'e' || str[i] == 'E') continue;
		error->all(file, line, "Expected floating point parameter "
			"in input script or data file");
	}

	return atof(str);
}


int Input::inumeric(const char *file, int line, const char *str)
{
	if (!str) {
		error->all(file, line, "Expected integer parameter in input script or data file");
		return 0;
	}
		
	int n = strlen(str);
	if (n == 0)
		error->all(file, line,
		"Expected integer parameter in input script or data file");

	for (int i = 0; i < n; i++) {
		if (isdigit(str[i]) || str[i] == '-' || str[i] == '+') continue;
		error->all(file, line,
			"Expected integer parameter in input script or data file");
	}

	return atoi(str);
}

/**********************************************************************************************************/

void Input::numerics(const char* file, int line, char* str, int n, 
	double* data, char const* Delimiter, bool chkFlag) {

	char* next = strtok(str, Delimiter);
	if (next == NULL) {
		error->all(file, line, "Incorrect using Input::numerics"); return;
	}
	data[0] = chkFlag ? numeric(file, line, next) : atof(next);

	for (int m = 1; m < n; m++) {
		next = strtok(NULL, Delimiter);
		if (next == NULL) {
			error->all(file, line, "Incorrect using Input::numerics"); return;
		}
		data[m] = chkFlag ? numeric(file, line, next) : atof(next);
	}
}


void Input::inumerics(const char* file, int line, char* str, int n, 
	int* data, char const* Delimiter, bool chkFlag) {

	char* next = strtok(str, Delimiter);
	if (next == NULL){ error->all(
		file, line, "Incorrect using Input::numerics"); return;
	}
	data[0] = chkFlag ? inumeric(file, line, next) : atoi(next);

	for (int m = 1; m < n; m++) {
		next = strtok(NULL, Delimiter);
		if (next == NULL) {
			error->all(file, line, "Incorrect using Input::numerics"); return;
		}
		data[m] = chkFlag ? inumeric(file, line, next) : atoi(next);
	}
}

char* Input::tmpBuffCheck(int size) {
	if (tmpBuffSize >= size)  return tmpBuff;

	tmpBuffSize = static_cast<int>(size * 1.5);
	memory->grow(tmpBuff, tmpBuffSize, "Input::cbuff");
	return tmpBuff;
}

void Input::numerics(const char* file, int line, const char* cstr, int n,
	double* data, char const* Delimiter, bool chkFlag) {

	strcpy(tmpBuffCheck(strlen(cstr) + 1), cstr);
	numerics(file, line, tmpBuff, n, data, Delimiter, chkFlag);
}

void Input::inumerics(const char* file, int line, const char* cstr, int n, 
	int* data, char const* Delimiter, bool chkFlag) {

	strcpy(tmpBuffCheck(strlen(cstr) + 1), cstr);
	inumerics(file, line, tmpBuff, n, data, Delimiter, chkFlag);
}



int Input::int_between_brackets(char *&ptr, int varallow)
{
	int index;

	char *start = ++ptr;
	
	while (*ptr && *ptr != ']') {
		if (!isdigit(*ptr))
			error->all(FLERR, "Non digit character between brackets in variable");
		ptr++;
	}	

	if (*ptr != ']') error->all(FLERR, "Mismatched brackets in variable");
	if (ptr == start) error->all(FLERR, "Empty brackets in variable");

	*ptr = '\0';

	index = atoi(start);

	*ptr = ']';

	if (index == 0)
		error->all(FLERR, "Index between variable brackets must be positive");
	return index;
}

int Input::count_words(const char *line)
{
	int n = strlen(line) + 1;
	char *copy;
	memory->create(copy, n, "atom:copy");
	strcpy(copy, line);

	char *ptr;
	if ((ptr = strchr(copy, '#'))) *ptr = '\0';

	if (strtok(copy, splitWord) == NULL) {
		memory->destroy(copy);
		return 0;
	}
	n = 1;
	while (strtok(NULL, splitWord)) n++;

	memory->destroy(copy);
	return n;
}


void Input::setLog(const char* pfile, const char* pmode)
{
	int appendflag = 0;
	if (strcmp(pmode, "append") == 0) appendflag = 1;

	if (logfile) fclose(logfile);
	if (!pfile) {
		logfile = NULL;
	}
	else {
		std::string fileName;
		if (time_label){
			fileName = timestr;
		}
		fileName += pfile;
		const char* mode = appendflag ? "a" : "w";
		logfile = fopen(fileName.c_str(), mode);

		if (logfile == NULL) {
			ErrorAll("Cannot open logfile %s", pfile);
		}
	}
}


void Input::setEcho(int pscreen, int plog)
{
	echo_screen = pscreen;
	echo_log = plog;
}

char * Input::shell_failed_message(const char* cmd, int errnum)
{
	const char *errmsg = strerror(errnum);
	size_t len = strlen(cmd) + strlen(errmsg) + 64;
	char *msg = new char[len];
	sprintf(msg, "Shell command '%s' failed with error '%s'", cmd, errmsg);
	return msg;
}


bool Input::shell_getcwd(char *Buf, int Size){
	int err;
	
	err = (getcwd(Buf, Size)  == NULL) ? errno : 0;
	if (err != 0) {
		char *message = shell_failed_message("cd", err);
		error->warning(FLERR, message);
		delete[] message;
		return false;
	}
	return true;
}

bool Input::shell_cd(const char *parg){
	int err;
	err = (chdir(parg) < 0) ? errno : 0;
	if (err != 0) {
		char *message = shell_failed_message("cd", err);
		sprintf(error->ErrCheckBuff, "%s:\"%s\"", message, parg);
		error->warning(FLERR, error->ErrCheckBuff);
		delete[] message;
		return false;
	}
	return true;
}

bool Input::shell_mkdir(int pnarg, const char **parg){
	int err;
	if (pnarg < 1) error->all(FLERR, "Illegal shell mkdir command");

	for (int i = 0; i < pnarg; i++) {
#if defined(_WIN32)
		err = _mkdir(parg[i]);
#else
		err = mkdir(parg[i], S_IRWXU | S_IRGRP | S_IXGRP);
#endif
		if (err < 0) {
			if (strcmp(strerror(errno), "File exists") == 0) {
				sprintf(error->ErrCheckBuff,
					"Path already exists!	skip: \"%s\"\n", parg[i]);
				print(error->ErrCheckBuff);
			}
			else {
				char *message = shell_failed_message("mkdir", errno);
				error->warning(FLERR, message);
				delete[] message;		
				return false;
			}			
		}
	}
	return true;
}

bool Input::shell_mv(const char *arg1, const char *arg2){
	int err;
	err = (rename(arg1, arg2) < 0) ? errno : 0;
	if (err != 0) {
		char *message = shell_failed_message("mv", err);
		error->warning(FLERR, message);
		sprintf(error->ErrCheckBuff, 
			"command: %s -> %s failed", arg1, arg2);
		error->warning(FLERR, error->ErrCheckBuff);
		delete[] message;
		return false;
	}
	return true;
}

bool Input::shell_rm(int pnarg, const char **parg){
	if (pnarg < 1) error->all(FLERR, "Illegal shell rm command");

	for (int i = 0; i < pnarg; i++) {
		if (unlink(parg[i]) < 0) {
			if (errno == ENOENT) {
				sprintf(error->ErrCheckBuff,
					"No such file!		skip: \"%s\"\n", parg[i]);
				print(error->ErrCheckBuff);
			}
			else {
				char *message = shell_failed_message("rm", errno);
				error->warning(FLERR, message);
				delete[] message;
				return false;
			}
		}
	}
	return true;
}

bool Input::shell_rmdir(int pnarg, const char **parg){
	if (pnarg < 1) error->all(FLERR, "Illegal shell rmdir command");

	for (int i = 0; i < pnarg; i++) {
		if (rmdir(parg[i]) < 0) {
			char *message = shell_failed_message("rmdir", errno);
			sprintf(error->ErrCheckBuff, "%s:\"%s\"", message, parg[i]);
			error->warning(FLERR, error->ErrCheckBuff);
			delete[] message;
			return false;
		}
	}
	return true;
}

bool Input::shell_putenv(int pnarg, const char** parg)
{
	for (int i = 1; i < pnarg; i++) {
		char* ptr = strdup(parg[i]);

		int err = 0;
		if (ptr != NULL) err = putenv(ptr);

		err = (err < 0) ? errno : 0;
		if (err != 0) {
			char* message = shell_failed_message("putenv", err);
			error->warning(FLERR, message);
			delete[] message;
			return false;
		}
	}
	return true;
	// use work string to concat args back into one string separated by spaces
	// invoke string in shell via system()
}

bool Input::exists(const char* parg) {
	return access(parg, 0) == 0;
}

int Input::ele2int(const char* element){
	static const char* name[NELEMENTS + 1] = {
		"n", "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
		"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
		"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
		"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
		"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
		"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
		"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
		"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
		"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
		"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
		"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
		"Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
	};
	for (int i = 1; i <= NELEMENTS; i++)
	if (strcmp(element, name[i]) == 0) return i;
	return -1;
}

const char* Input::int2ele(const int num){
	static const char *name[NELEMENTS + 1] = {
		"n", "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
		"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
		"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
		"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
		"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
		"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
		"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
		"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
		"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
		"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
		"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
		"Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
	};

	return name[num];
}

double Input::getAtomicMass(const int num) {
	static double mass[NELEMENTS + 1] = {
		1.0, 1.00794, 4.002602, 6.941, 9.0121831, 10.811, 12.0107, 14.0067, 15.9994, 18.998403163, 20.1797,
		22.98976928, 24.3050, 26.9815385, 28.0855, 30.973761998, 32.065, 35.453, 39.948, 39.0983, 40.078,
		44.955908, 47.867, 50.9415, 51.9961, 54.938044, 55.845, 58.933194, 58.6934, 63.546, 65.38,
		69.723, 72.64, 74.921595, 78.971, 79.904, 83.798, 85.4678, 87.62, 88.90584, 91.224,
		92.90637, 95.95, 98.9072, 101.07, 102.90550, 106.42, 107.8682, 112.414, 114.818, 118.710,
		121.760, 127.60, 126.90447, 131.293, 132.90545196, 137.327, 138.90547, 140.116, 140.90766, 144.242,
		144.9, 150.36, 151.964, 157.25, 158.92535, 162.500, 164.93033, 167.259, 168.93422, 173.054,
		174.9668, 178.49, 180.94788, 183.84, 186.207, 190.23, 192.217, 195.084, 196.966569, 200.59,
		204.3833, 207.2, 208.98040, 208.9824, 209.9871, 222.0176, 223.0197, 226.0245, 227.0277, 232.0377,
		231.03588, 238.02891, 237.0482, 239.0642, 243.0614, 247.0704, 247.0703, 251.0796, 252.0830, 257.0591,
		258.0984, 259.1010, 262.1097, 267.1218, 268.1257, 269.1286, 274.1436, 277.1519, 278, 281,
		282, 285, 284, 289, 288, 292, 294, 295,
	};

	return mass[num];
}
