#include "pair_eam_dai.h"
#include "float.h"
#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;

PairEAMDai::PairEAMDai(EAPOT *eapot)
: PairEAM(eapot)
{
	styles.push_back("fs/dai");
	eam_fsize = 7;
	eam_csize = 5;

	rc1 = rc2 = c0 = c1 = c2 = c3 = c4 = 0;
	a = b = m = n = r = r0 = 0;

	b2 = b3 = r0T = r02T = r03T = r04T = 0;
};

PairEAMDai::~PairEAMDai(){

};

void PairEAMDai::setFullParamsStyle()
{
	int idx = eam_fsize;
	rc1 = paramVec[idx++];
	rc2 = paramVec[idx++];
	r0 = paramVec[idx++];
	m = paramVec[idx++];
	n = paramVec[idx++];
	setFreeParamsStyle();
};

void PairEAMDai::setFreeParamsStyle()
{
	int idx = 0;
	c0 = paramVec[idx++];
	c1 = paramVec[idx++];
	c2 = paramVec[idx++];
	c3 = paramVec[idx++];
	c4 = paramVec[idx++];
	a = paramVec[idx++];
	b = paramVec[idx++];

	b2 = b * b;
	b3 = b2 * b;

	r0T = 1.0 / r0;
	r02T = 1.0 / (r0 * r0);
	r03T = r0T * r02T;
	r04T = r02T * r02T;

	PairEAM::setFreeParamsStyle();
};


double PairEAMDai::emb(int type, double x){
	return -sqrt(x);
};

double PairEAMDai::rho(int itype, int jtype, double r){
	if (r >= rc2 || r >= cutmax) return 0;
	double drc2 = rc2 - r;
	double ratr = r / r0 - 1;
	double d0raPow = a * pow(drc2, n);
	double d0rExp = exp(-b * ratr);
	return d0rExp * d0raPow;
};

double PairEAMDai::phi(int itype, int jtype,  double r){
	if (r >= rc1 || r >= cutmax) return 0;

	double drc1 = rc1 - r;
	double r2 = r * r;
	double r3 = r * r * r;
	double r4 = r * r * r * r;
	double d0pPow = pow(drc1, m);
	double d0pPoly = c4 * r4 + c3 * r3 + c2 * r2 + c1 * r + c0;
	return d0pPow * d0pPoly;
}

void PairEAMDai::function_check(){

#define N 4

	const char* name = "EAMDai";
	error->add_chklog(0, name, "");

	double rChk[N], pChk[N], rRef[N] = {
		1.264191440309603500e+01, 1.361723990949619000e+00, 1.015728363119043600e-01, 3.923706098604419700e-03 
	}, pRef[N] = {
		1.188231616957434300e+01, 6.447417065891558600e-02, 2.237009232424433400e-02, 8.171564915399056100e-03
	};
	double tx[] = { 0.5, 1, 1.5, 2.0 };
	for (int i = 0; i < 4; i++) tx[i] *= 3.615 / sqrt(2);

	int j;
	for (j = 0; j < N; j++)	{
		rChk[j] = rho(1, 1, tx[j]);
		pChk[j] = phi(1, 1, tx[j]);
	}

	error->check(FLERR, N, rChk, rRef, 1, "EAMDai", "r", 8e-14, 2e-14, 3.2612277730406308e-16, 6.8380846104498584e-16);
	error->check(FLERR, N, pChk, pRef, 1, "EAMDai", "p", 8e-14, 2e-14, 3.2879737068273915e-14, 3.2879737068273915e-14);

#undef N
}

void PairEAMDai::testrun(int type) {

	const char* name = "EAMDai";
	error->add_chklog(0, name, "");

#define N 5
	double ref[N] = {
		3.6098636128158543, 3.4910813561004437,
		176.24961090984365, 124.93163291841508, 81.8259148947375
	};

	addMDCheckCubic(FLERR, 0, name, "Box", &ref[0], 2.1082940247000813e-09, 2.108297077662745e-09);
	addMDCheckCubic(FLERR, 1, name, "Ela", &ref[2], 9.1145724614604966e-07, 1.9985393311157192e-06);

#undef N
}

void PairEAMDai::extra_check(int){

	addMDComputeFcc();
	runMDCompute(-1, RunDump | RunEcho, 10, CuFccCost, FccChk, "nms", "dump.*.eam");
	function_check();
	testrun(0);
}
