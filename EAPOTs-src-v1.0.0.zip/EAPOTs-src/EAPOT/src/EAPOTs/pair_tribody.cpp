#include "pair_tribody.h"

#include "error.h"
#include "input.h"
#include "output.h"
#include "force.h"
#include "dump_file.h"
#include "compute_elastic.h"

#include "memory.h"
#include "libLAMMPS/lammps_api.h"

using namespace EAPOT_NS;

/*
iele	element 1 (the center atom in a 3-body interaction)
jele	element 2 (the atom bonded to the center atom)
kele	element 3 (the atom influencing the 1-2 bond in a bond-order sense)
powerm	m
gamma	gamma
lam3	lambda3 (1/distance units)
c		c
d		d
h		cos theta0 (can be a value < -1 or > 1)
powern	n
beta	beta
lam2	lambda2 (1/distance units)
bigb	B (energy units)
bigr	R (distance units)
bigd	D (distance units)
lam1	lambda1 (1/distance units)
biga	A (energy units)
*/

PairTribody::PairTribody(EAPOT* eapot)
	: Pair(eapot)
	, paramNum(0)
	, triTitle("tri ")	
{
	styles.push_back("tri");
	char buff[64];
	int n = force->get_ntypes();
	for (int i = 1; i <= n; i++)
	for (int j = 1; j <= n; j++)
	for (int k = 1; k <= n; k++) {
		sprintf(buff, "%s %s %s ", force->get_elestr(i),
			force->get_elestr(j), force->get_elestr(k));
		triTitle += buff;
	}
};

PairTribody::~PairTribody() {

}

#define SetTypeParam(p, i, j, k) {sprintf(buf, "%s_%d%d%d", p, i+1, j+1, k+1);paramName.push_back(buf);}

int PairTribody::getPyParamNum() {
	int n = force->get_ntypes();

	char buf[64];
	paramName.clear();
	for (int mm = 0; mm < paramNum; mm++) {
		for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		for (int k = 0; k < n; k++)
			SetTypeParam(key[mm].c_str(), i, j, k);
	}
	return paramNum * n * n * n;
}

#define IDX(i,j,k) (i*n2+j*n+k)

#define Val(iParam, itri) paramVec[iParam*n3 + itri]

#define SafePrint dump->sbufChk(FLERR, off); off += sprintf

void PairTribody::export_pair_template(void* md, const char* name) {

	if (transByFileMode) {
		transByFile(name);
		std::string telt = force->eleLineFormat(" ");
		pair_coeff(md, name, telt.c_str());
	}
	else {
		int idx = 0;
		const int n = force->get_ntypes();
		const int n2 = n * n;
		const int n3 = n * n * n;

		if (val.size() != paramVec.size()) {
			val.resize(paramVec.size(), 0.0);
		}

		for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		for (int k = 0; k < n; k++) {
			const int itri = IDX(i, j, k);
			for (size_t iParam = 0; iParam < paramNum; iParam++) {
				val[idx++] = Val(iParam, itri);
			}
		}		
	}
}

void PairTribody::write(class DumpFile* dump) {

	// --------------------------------- open --------------------------------- //
	dump->openfile(0);
	// ------------------------------------------------------------------------ //

	FILE* fp = dump->fp;
	char*& sbuf = dump->sbuf;

	fprintf(fp, "# %s at %s by EAPOT\n", dump->fileDump[0].c_str(), input->timestr);
	fprintf(fp, "# %d dof %d params:\n", get_fsize(), (int)paramVec.size());
	fprintf(fp, "# format of a single entry (one or more lines):\n");
	fprintf(fp, "#   element 1	element 2	element 3	");
	for (auto& iparam : key) fprintf(fp, "%s\t", iparam.c_str());
	fprintf(fp, "\n");


	int i, j, k, off = 0;
	const int n = force->get_ntypes();
	const int n2 = n * n, n3 = n * n * n;

	for (i = 0; i < n; i++)
	for (j = 0; j < n; j++)
	for (k = 0; k < n; k++) {
		const int itri = IDX(i, j, k);
		SafePrint(&sbuf[off], "%s\t%s\t%s\t", force->get_elestr(i + 1),
			force->get_elestr(j + 1), force->get_elestr(k + 1));

		for (size_t iParam = 0; iParam < paramNum; iParam++) {
			SafePrint(&sbuf[off], FDBLFMTGTab, Val(iParam, itri));
		}
		SafePrint(&sbuf[off], "\n\n");
	}

	// ------------------------------- output --------------------------------- //
	dump->nsme = off;
	fwrite(dump->sbuf, sizeof(char), dump->nsme, fp);
	dump->closefile();
	// ------------------------------------------------------------------------ //
}
#define P(i,j,k) p[lo + i * n2 + j * n + k]

int PairTribody::TribodyLoop3(double* p, double* f, int idx, int iparm, int n) {
	if (n == 1) {
		p[iparm] = f[idx];
		return idx + 1;
	}
	
	double p1 = f[idx];
	double p2 = f[idx + 1];
	double p3 = f[idx + 2];

	int n2 = n * n;
	size_t lo = (size_t)iparm * n2 * n;

	for (size_t i = 0; i < n; i++) {
		for (size_t j = 0; j < n; j++) {
			for (size_t k = 0; k < n; k++) {
				P(i, j, k) = p3;
			}
			P(i, j, j) = p2;
		}
		P(i, i, i) = p1;
	}
	return idx + 3;
}

int PairTribody::TribodyLoopN2h(double* p, double* f, int idx, int iparm, int n) {
	int n2 = n * n;
	size_t lo = (size_t)iparm * n2 * n;

	for (size_t i = 0; i < n; i++) {
		for (size_t j = i; j < n; j++) {
			P(i, j, j) = f[idx];
			idx += 1;
		}
		for (size_t j = 0; j < i; j++) {
			P(i, j, j) = P(j, i, i);
		}
	}

	return idx;
}

int PairTribody::TribodyLoopN3(double* p, double* f, int idx, int iparm, int n) {

	int n2 = n * n;
	size_t lo = (size_t)iparm * n2 * n;

	double p3 = f[idx];
	for (size_t i = 0; i < n; i++) {
		for (size_t j = 0; j < n; j++) {
			for (size_t k = 0; k < n; k++) {
				P(i, j, k) = p3;
			}
		}
	}

	return idx + 1;
}

int PairTribody::TribodyLoopN(double* p, double* f, int idx, int iparm, int n) {

	int n2 = n * n;
	size_t lo = (size_t)iparm * n2 * n;

	
	for (size_t i = 0; i < n; i++) {
		double p0 = f[idx++];

		for (size_t j = 0; j < n; j++) {
			for (size_t k = 0; k < n; k++) {
				P(i, j, k) = p0;
			}
		}
	}

	return idx;
}

int PairTribody::TribodyLoopNg(double* p, double* f, int idx, int iparm, int n) {


	int n2 = n * n;
	double p3 = f[idx++];
	size_t lo = (size_t)iparm * n2 * n;	

	for (size_t i = 0; i < n; i++) {
		for (size_t j = 0; j < n; j++) {
			for (size_t k = 0; k < n; k++) {
				P(i, j, k) = p3;
			}
			P(i, j, i) = f[idx];
		}
		idx++;
	}

	return idx;
}