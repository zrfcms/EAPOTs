#include "eapot.h"

#include "ctype.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctime>
#include <string>
#include <vector>
#include "string.h"

#include "memory.h"
#include "error.h"
#include "input.h"

#include "update.h"
#include "force.h"
#include "modify.h"
#include "output.h"
#include "thermo.h"

#include "min.h"
#include "pair.h"
#include "compute.h"

#include "option_dump.h"
#include "option_pair.h"
#include "option_comp.h"
#include "option_mini.h"

using namespace EAPOT_NS;

static void print_style(FILE *fp, const char *str, int &pos);

void EAPOTcallback(void* ptr, const char* file, int line, const char* str, const char* lastcmd) {
	EAPOT* eapot = (EAPOT*)ptr;
	sprintf(eapot->error->ErrCheckBuff, "ERROR command during calling in library: %s\n", lastcmd);
	eapot->error->all(file, line, eapot->error->ErrCheckBuff);
}


enum CheckItem {
	PairSingle = 1 << 0,
	PairCross = 1 << 1,
	ComputeMD = 1 << 2,
	DumpCheck = 1 << 3,
	MinimizeCheck = 1 << 4,
	PairMEAM = 1 << 5,
	PythonParam = 1 << 6,
	PairTersoff = 1 << 7,
	PairSW = 1 << 8,
};


EAPOT::EAPOT(int narg, char **arg)
	: pythonCallback(NULL)
	, caller(NULL)
{
	memory = new Memory(this);
	error = new Error(this);

	int inflag = 0;
	int screenflag = 0;
	int logflag = 0;
	//int citeflag = 1;
	int helpflag = 0;

	screen = stdout;
	logfile = fopen("EAPOT.log", "w");
	if (logfile == NULL) error->all(FLERR, "Cannot open logfile EAPOT.log");

	int iarg = 1;
	while (iarg < narg) {
		if (strcmp(arg[iarg], "-in") == 0 ||
			strcmp(arg[iarg], "-i") == 0) {
			if (iarg + 2 > narg)
				error->all(FLERR, "Invalid command-line argument");
			inflag = iarg + 1;
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "-screen") == 0 ||
			strcmp(arg[iarg], "-sc") == 0) {
			if (iarg + 2 > narg)
				error->all(FLERR, "Invalid command-line argument");
			screenflag = iarg + 1;
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "-log") == 0 ||
			strcmp(arg[iarg], "-l") == 0) {
			if (iarg + 2 > narg)
				error->all(FLERR, "Invalid command-line argument");
			logflag = iarg + 1;
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "-help") == 0 ||
			strcmp(arg[iarg], "-h") == 0) {
			if (iarg + 1 > narg)
				error->all(FLERR, "Invalid command-line argument");
			helpflag = 1;
			//citeflag = 0;
			iarg += 1;
		}
		else error->all(FLERR, "Invalid command-line argument");
	}

	input = new Input(this);
	const char* temp = "temp";
	if (!Input::exists(temp)) input->shell_mkdir(1, &temp);

	create();

	pairStyle = new PairStyle(this);
	dumpStyle = new DumpStyle(this);
	compStyle = new CompStyle(this);
	miniStyle = new MiniStyle(this);
	
	if (inflag == 0) infile = stdin;
	else infile = fopen(arg[inflag], "r");
	if (infile == NULL) {
		ErrorAll("Cannot open input file %s", arg[inflag]);
	}

	if (screenflag != 0) {
		screen = fopen(arg[screenflag], "w");
		if (screen == NULL) {
			ErrorAll("Cannot open input file %s", arg[screenflag]);
		}
	}


	if (logflag != 0) {
		fclose(logfile);
		if (strcmp(arg[logflag], "none") == 0)
			logfile = NULL;
		else {
			sprintf(error->ErrCheckBuff, "%s", arg[logflag]);
			logfile = fopen(error->ErrCheckBuff, "w");
			if (logfile == NULL) error->all(FLERR, "Cannot open logfile *.log");
		}
	}

	if (helpflag) {
		if (screen) help();
	}

	// time
	time_t lt1;
	time(&lt1);
	tm *newtime = localtime(&lt1);
	strftime(error->ErrCheckBuff, 32, "%Y%m%d.%H%M%S", newtime);
	strcpy(input->timestr, &error->ErrCheckBuff[2]);

	once_initFlag = 0;
};


EAPOT::~EAPOT()
{
	destroy();

	if (screen && screen != stdout) fclose(screen);
	if (logfile) fclose(logfile);
	logfile = NULL;
	if (screen != stdout) screen = NULL;

	if (infile && infile != stdin) fclose(infile);

	delete pairStyle;
	delete dumpStyle;
	delete compStyle;
	delete miniStyle;

	delete input;
	delete error;
	delete memory;
}


void EAPOT::clear()
{
	destroy();
	create();
	once_initFlag = 0;
}

void EAPOT::create()
{
	modify = new Modify(this);
	force = new Force(this);
	output = new Output(this);
	update = new Update(this);
}

void EAPOT::destroy(){
	delete modify;
	modify = NULL;

	delete force;
	force = NULL;

	delete output;
	output = NULL;

	delete update;
	update = NULL;
}


#define setElements1(A) { const char * ele[] = { A }; force->setElement(1, ele); }
#define setElements2(A, B) { const char * ele[] = { A, B }; force->setElement(2, ele); }
#define setElements3(A, B, C) { const char * ele[] = { A, B, C}; force->setElement(3, ele); }

#define setFreeParam(PAIR, ...) { double param[] = { __VA_ARGS__ }; pairStyle->setPairFreeParams(PAIR, param); };
#define setFullParam(PAIR, ...) { double param[] = { __VA_ARGS__ }; pairStyle->setPairFullParams(PAIR, param); };

#define setPairStyle(PAIR) void* pair = force->addPair(PAIR);
#define setEAMFormat(PAIR, NRHO, DRHO, NR, DR, CUT) pairStyle->setPairEAMDumpFormat(PAIR, NRHO, DRHO, NR, DR, CUT);
#define setEAMInputs(PAIR, TYPE, FILE, ...) { const char * ele[] = { __VA_ARGS__ };  pairStyle->inputPairEAMListFrom ## TYPE ## (pair, FILE, ele); }

#define PAIR_EAM_ZHOU_PARM_INIT_CU														\
	update->setTimestep(0);																\
	setFullParam(pair, 0.396620, 0.548085, -2.19,										\
	0, 0.561830, -2.100595, 1.554485, 8.127620, 4.334731, 								\
	0.308782, 0.756515, 21.175871, 20, 2.556162, 0.85, 1.15);

#define MINIMIZE_CHECK(pname, pref)														\
	ecurrent = update->minimize->get_ecurrent();										\
	ref = pref;																			\
	error->check(FLERR, 1, &ecurrent, &ref, 0, pname, "minimize", 1e-16, 1e-16, 0, 0);

#define Add_Default_Cross_Potential_Zhou2()												\
	clear();																			\
	setElements2("Cu", "Ni");															\
	setPairStyle("eam/cross/zhou2");													\
	setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);								\
	setFullParam(pair, 0.11, 12, 0.36, 2.55, 18, 0.33, 2.5, 0.69, 2.5, 22);				\
	setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");

void EAPOT::check(int mode, int chkLogLevel){

	error->selfCheckMode = 1;

	/***************************************** pair  ***************************************/
	if (mode & CheckItem::PairCross) {
		{
			clear();
			setElements1("Nb");
			setPairStyle("eam/ackland");
			setEAMFormat(pair, 5000, 5e-3, 5000, 9e-4, 4.5);
			setEAMInputs(pair, Alloy, NULL, "Nb");
			setFullParam(pair, 3.013789, 3.915354, 48, -1.5640104, 2.0055779, -0.4663764, 0.8, 2.8585, 4.2);
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("V", "Nb");
			setPairStyle("eam/ackland");
			setEAMFormat(pair, 5000, 5e-3, 5000, 9e-4, 4.5);
			setEAMInputs(pair, Alloy, NULL, "V", "Nb");
			setFullParam(pair, 2.010637, 3.013789, 3.692767, 3.915354,
				23.0, -0.8816318, 1.49077560, -0.3976370,
				35.5, -1.2228211, 1.74817675, -0.4320067,
				48.0, -1.5640104, 2.00557790, -0.4663764,
				0.50, 2.63200, 3.8, 0.65, 2.74525, 4.0, 0.80, 2.85850, 4.2);
			force->pair->extra_check(1);
		} {
			clear();
			setElements1("Nb");
			setPairStyle("fs/ackland");
			setEAMFormat(pair, 5000, 5e-3, 5000, 9e-4, 4.5);
			setEAMInputs(pair, Alloy, NULL, "Nb");
			pairStyle->setPairEAMOutputMode(pair, "fs");
			setFullParam(pair, 3.013789, 3.915354, 48, -1.5640104, 2.0055779, -0.4663764, 0.8, 2.8585, 4.2);
			force->pair->extra_check(100);
		} {
			clear();
			setElements2("V", "Nb");
			setPairStyle("fs/ackland");
			setEAMFormat(pair, 5000, 5e-3, 5000, 9e-4, 4.5);
			setEAMInputs(pair, FS, NULL, "V", "Nb");
			pairStyle->setPairEAMOutputMode(pair, "fs");
			setFullParam(pair, 2.010637, 3.013789, 3.692767, 3.766963, 3.841158, 3.915354,
				23.0, -0.8816318, 1.49077560, -0.3976370,
				35.5, -1.2228211, 1.74817675, -0.4320067,
				48.0, -1.5640104, 2.00557790, -0.4663764,
				0.50, 2.63200, 3.8, 0.65, 2.74525, 4.0, 0.80, 2.85850, 4.2);
			force->pair->extra_check(101);
		} {
			clear();
			setElements1("V");
			setPairStyle("fs/finnis");
			setEAMFormat(pair, 5000, 5e-3, 5000, 9e-4, 4.5);
			setEAMInputs(pair, FS, NULL, "V");
			pairStyle->setPairEAMOutputMode(pair, "fs");
			setFullParam(pair, 2.010637, 3.692767, -0.8816318, 1.49077560, -0.3976370, 3.8);
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("V", "Nb");
			setPairStyle("fs/finnis");
			setEAMFormat(pair, 5000, 5e-3, 5000, 9e-4, 4.5);
			setEAMInputs(pair, FS, NULL, "V", "Nb");
			pairStyle->setPairEAMOutputMode(pair, "fs");
			pairStyle->setPairDof(pair, 14, 3);
			pairStyle->setPairDofScript(pair,
				"def PairDofMapScript(caller, ndof, vdof, nf, nc, f, c, name): \n"
				"    p = asArray(vdof, shape=(ndof, ))\n"
				"    p[0:3]    = f[0:3]		\n"
				"    p[3],p[4] = f[3], f[3]	\n"
				"    p[5:15]   = f[4:14]	\n"
				"    p[15:18]  = c[0:3]		\n");
			setFullParam(pair, 2.010637, 3.013789, 3.692767, 3.8040605, 3.915354,
				-0.8816318, 1.49077560, -0.3976370,
				-1.2228211, 1.74817675, -0.4320067,
				-1.5640104, 2.00557790, -0.4663764, 3.8, 4.0, 4.2);
			force->pair->extra_check(1);

		} {
			clear();
			setElements1("Cu");
			setPairStyle("tb/rosato");
			setEAMFormat(pair, 5000, 2e-2, 5000, 1.5e-3, 7.0);
			setEAMInputs(pair, FS, NULL, "Cu");
			setFullParam(pair, 1.224, 2.278, 0.0855, 10.960, 2.79, 2.79);
			pairStyle->setPairEAMOutputMode(pair, "fs");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("tb/rosato");
			setEAMFormat(pair, 5000, 5e-3, 5000, 1.2e-3, 6.0);
			setEAMInputs(pair, FS, NULL, "Cu", "Ni");
			setFullParam(pair, 1.224, 2.278, 1.17267, 1.915, 1.12133, 1.552, 1.070, 1.189,
				0.0855, 10.960, 0.06155, 13.9795, 0.0376, 16.999,
				2.79, 2.73667, 2.68333, 2.63, 2.79, 2.71, 2.63);
			pairStyle->setPairEAMOutputMode(pair, "fs");
			force->pair->extra_check(1);
		} {
			clear();
			setElements1("Cu");
			setPairStyle("tb/li");
			setEAMFormat(pair, 5000, 5e-2, 5000, 1.5e-3, 7.0);
			setEAMInputs(pair, FS, NULL, "Cu");
			setFullParam(pair, 1.5940, 1.6823, 567.227, -3.7319, 5.2463, -3.2679, 
				0.7566, 2.8579, 2.8579, 6, 4, 6.7000, 5.0200);
			pairStyle->setPairEAMOutputMode(pair, "fs");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("V", "Nb");
			setPairStyle("tb/li");
			setEAMFormat(pair, 5000, 5e-2, 5000, 1.5e-3, 7.0);
			setEAMInputs(pair, FS, NULL, "V", "Nb");
			setFullParam(pair, 0.2708, 1.8017, 0.71186, 1.7619, 1.15293, 1.7221, 1.5940, 1.6823,
				350.6440, -3.7617, 5.3347, -3.35760, 0.7870,
				567.2270, -3.7319, 5.2463, -3.26790, 0.7566,
				458.9355, -3.7468, 5.2905, -3.31275, 0.7718,
				2.8579, 2.77997, 2.70203, 2.6241, 2.8579, 2.741, 2.6241,
				6, 4, 6.7000, 5.00);
			pairStyle->setPairEAMOutputMode(pair, "fs");
			force->pair->extra_check(1);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/list");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/list");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			const char * files[] = { "../../res/pot/Cum.eam", "../../res/pot/Nim.eam" }; 
			pairStyle->inputPairEAMListFromFunc(pair, files);
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/morse");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0013, 6.5);
			setFullParam(pair, 0.24, 1.30694, 2.55, 6.28795);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/zhou");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair,
				0.087864715201346755, 11.451813574611243, 0.35957173175284329, 2.3585991703602200, 17.634409440168945, 
				0.520414261004391370, 2.4456346562110625, 0.69032493650479765, 2.5558911939467714, 21.549271972585601, 
				0.587761441576617470, 11.837186141427459, 0.30648236090248371, 2.5282102350524180, 13.025800120912425, 
				0.532697286566228720, 5.6633873353592605, 0.75330378293117461, 2.6151491289119724, 20.742288736371094);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/zhou2");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair,
				0.087864715201346755, 11.451813574611243, 0.35957173175284329, 2.3585991703602200, 17.634409440168945,
				0.520414261004391370, 2.4456346562110625, 0.69032493650479765, 2.5558911939467714, 21.549271972585601);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/demk");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair, 2.608, 1.815, 0.483, 3.806);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/dai");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair, 6.100, 0.123554, -0.134361, 0.0543818, -0.981194E-2, 0.675816E-3, 4);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/johnson");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair, 1.0);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/mishin");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair, 5.2, 4.533, 6.36726e-2, 4.43591, 6.67054, 0.34906, 116.4051, 0, 0);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/ackland");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair, 4.2, -1.5640104, 2.0055779, -0.4663764, 48, 0.8, 2.8585);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/hijazi");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair, 0.740938, 2.373944, 1.702142, 1.3);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/zhouPdAgH");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			setFullParam(pair, 0.740938, 2.373944, 1.702142, 1.3, 4.95, 0.3);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/cubic");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			pairStyle->setPairEAMCrossCubicChain(pair, 7, "fix");
			setFullParam(pair, 14.0786236789212005, -4.4526835887173704, 5.5025121262565992, 
				-1.0687489808214079, -0.3461498208163201, -0.0064991947759021, -0.0357435602984102, 
				1.6, 1.7, 1.8, 2.0, 2.5, 3.2, 4.2);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Cu", "Ni");
			setPairStyle("eam/cross/ashwin");
			setEAMFormat(pair, 5000, 0.08, 5000, 0.0012, 5.7444);
			pairStyle->setPairEAMDumpImageLimitRlo(pair, 0.0);
			pairStyle->setPairEAMCrossCubicChain(pair, 7, "fix");
			pairStyle->setPairEAMCrossAshwinAtomicNumber(pair, 26, 1);
			pairStyle->setPairEAMCrossAshwinZBLRange(pair, 0.6, 1.2);
			setFullParam(pair, 14.0786236789212005, -4.4526835887173704, 5.5025121262565992, 
				-1.0687489808214079, -0.3461498208163201, -0.0064991947759021, -0.0357435602984102, 
				1.6, 1.7, 1.8, 2.0, 2.5, 3.2, 4.2);
			setEAMInputs(pair, Alloy, "../../res/pot/CuNiJ4.eam", "Cu", "Ni");
			force->pair->extra_check(0);
		}
	}

	/*****************************************   md   ***************************************/

	if (mode & CheckItem::ComputeMD) {
		//// loadvasp check
		//input->one("loadvasp Mg.03.05	../tools/CONTCAR_0.3_0.33333330 OUTCAR ../tools/OUTCAR_0.3_0.33333330 GroundEnergy 1 0.0 check");
		//input->one("loadvasp Mg.03.10	../tools/CONTCAR_0.3_0.66666660 OUTCAR ../tools/OUTCAR_0.3_0.66666660 GroundEnergy 1 0.0 check");
		//input->one("loadvasp Mg.07.05	../tools/CONTCAR_0.7_0.33333330 OUTCAR ../tools/OUTCAR_0.7_0.33333330 GroundEnergy 1 0.0 check");
		//input->one("loadvasp Mg.07.10	../tools/CONTCAR_0.7_0.66666660 OUTCAR ../tools/OUTCAR_0.7_0.66666660 GroundEnergy 1 0.0 check");
		//input->one("loadvasp Mg.10.15	../tools/CONTCAR_1.0_0.99999990 OUTCAR ../tools/OUTCAR_1.0_0.99999990 GroundEnergy 1 0.0 check");
		//input->one("loadvasp B2.1		../tools/B2.1.CONTCAR	OUTCAR ../tools/B2.1.OUTCAR GroundEnergy 2 -0.68183624 -0.24807377 check");
		//input->one("loadvasp CaF2.tri	../tools/CaF2.tri.POSCAR check");

		{
			Add_Default_Cross_Potential_Zhou2();

			void* comp = NULL;			// compute pointer
			int fixAtom[] = { 0,0,0 };

#define AddComputeEnergyCheck(ID, MODEL, REF)											\
		comp = modify->addCompute(ID, "energy", "../../res/struct/" MODEL);				\
		compStyle->setComputeEnergyRefFile(comp, "../../res/struct/" REF);				\
		compStyle->setComputeEnergyEnergyAtom(comp, 1);									\
		compStyle->setComputeEnergyVirial(comp, 1, 1);

			AddComputeEnergyCheck("lmpL12", "L12_A3B.lammps", "L12_A3B.min.log");					// 0

			AddComputeEnergyCheck("lmpHex", "Hex.lmp", "Hex.log");									// 1
			AddComputeEnergyCheck("lmpHexp", "Hex.pri.lmp", "Hex.pri.log");							// 2

			AddComputeEnergyCheck("lmpB1", "B1.lmp", "B1.log");										// 3
			AddComputeEnergyCheck("lmpB1p", "B1.pri.lmp", "B1.pri.log");							// 4

			AddComputeEnergyCheck("CaF2", "CaF2.lmp", "CaF2.log");									// 5 
			AddComputeEnergyCheck("CaF2p", "CaF2.pri.lmp", "CaF2.pri.log");							// 6

			AddComputeEnergyCheck("lmpL12Rba", "L12_A3B_disturb.lammps", "L12_A3B_disturb.log");	// 7

			AddComputeEnergyCheck("lmpL12Rb", "L12_A3B_disturb.lammps", "L12_A3B_disturb.log");		// 8
			compStyle->setComputeEnergyRelaxAtom(comp, fixAtom);

			AddComputeEnergyCheck("lmpL12Ra", "L12_A3B_disturb.lammps", "L12_A3B_disturb.log");		// 9
			compStyle->setComputeEnergyRelaxBox(comp, "none", NULL);

			comp = modify->addCompute("lmpL12_el", "elastic", "lmpL12");
			comp = modify->addCompute("lmpHex_el", "elastic", "lmpHex");
			comp = modify->addCompute("lmpB1_el", "elastic", "lmpB1");

			init();
			int ilmp = 0, ilmpel;
			ilmpel = modify->ncompute - 3;

			error->add_chklog(0, "CompLMP(static)", "");
			modify->compute[ilmp++]->extracheck(0);
			modify->compute[ilmp++]->extracheck(1);
			modify->compute[ilmp++]->extracheck(2);
			modify->compute[ilmp++]->extracheck(3);
			modify->compute[ilmp++]->extracheck(4);
			modify->compute[ilmp++]->extracheck(5);
			modify->compute[ilmp++]->extracheck(6);

			error->add_chklog(0, "CompLMP(relax)", "");
			modify->compute[ilmp++]->extracheck(7);
			modify->compute[ilmp++]->extracheck(8);
			modify->compute[ilmp++]->extracheck(9);

			error->add_chklog(0, "CompLMPEL", "");
			modify->compute[ilmpel++]->extracheck(0);
			modify->compute[ilmpel++]->extracheck(1);
			modify->compute[ilmpel++]->extracheck(2);

		} {
			int ilmp = 0;
			int relaxAtomYs[] = { 0, 0, 1 };
			Add_Default_Cross_Potential_Zhou2();

			void* hcpEc = modify->addCompute("hcp", "energy", "../../res/struct/hcp.t2.lammps");
			void* hcpYs = modify->addCompute("hcpYs", "energy", "../../res/struct/hcp.2.t2.lammps");
			compStyle->setComputeEnergyNoRelax(hcpYs);
			compStyle->setComputeEnergyRemapStyle(hcpYs, hcpEc, "xxy");

			void* fccEc = modify->addCompute("fcc", "energy", "../../res/struct/fcc.t2.lammps");
			void* YsFix = modify->addCompute("YsFix", "energy", "../../res/struct/fcc.GSF.2.t2.lammps");
			compStyle->setComputeEnergyRemapStyle(YsFix, fccEc, "v");
			compStyle->setComputeEnergyNoRelax(YsFix);
			
			void* YsRlx = modify->addCompute("YsRlx", "energy", "../../res/struct/fcc.GSF.2.t2.lammps");
			compStyle->setComputeEnergyRemapStyle(YsRlx, fccEc, "v");
			compStyle->setComputeEnergyRelaxBox(YsRlx, "none", NULL);
			compStyle->setComputeEnergyRelaxAtom(YsRlx, relaxAtomYs);

			void* fccEl = modify->addCompute("fccEla", "elastic", "fcc");


			void* L10Ec = modify->addCompute("L10", "energy", "../../res/struct/L10.lammps");
			void* L10ma = modify->addCompute("L10map", "energy", "../../res/struct/L10.remap.lammps");
			compStyle->setComputeEnergyNoRelax(L10ma);
			compStyle->setComputeEnergyRemapStyle(L10ma, L10Ec, "shape");

			void* cost = modify->addCompute("cost", "term", "none");
			compStyle->setComputeExternalTitle(cost, "3.615  52  42 | 175 125  80 | 2.55 1.65 -13 | 3.56 1.03 3.95");
			compStyle->setComputeExternalScript(cost,
				"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
				"    v = EAPOT.parseCompute(nparam, style, param)\n"
				"    hcp, hcpYs, fcc, YsFix, YsRlx, fccEla, L10, L10map = v\n"

				"    ratio    = 16020/(YsFix.xx * YsFix.yy)\n"
				"    YsFix    = ratio*(YsFix.energy - 6*fcc.energy)\n"
				"    YsRlx    = ratio*(YsRlx.energy - 6*fcc.energy)\n"
				"    c_A0Fcc  = 10.0*(fcc.xx/3.61 - 1.0)**2\n"
				"    c_YsFix  =  5.0*(YsFix /52.0 - 1.0)**2\n"
				"    c_YsRlx  =  5.0*(YsRlx /42.0 - 1.0)**2\n"
				"    c_C11    =  1.0*(fccEla.C[0,0]/172 - 1.0)**2\n"
				"    c_C12    =  1.0*(fccEla.C[0,1]/125 - 1.0)**2\n"
				"    c_C33    =  1.0*(fccEla.C[3,3]/80  - 1.0)**2\n"

				"    caHcp    = hcp.zz/hcpYs.yy\n"
				"    ratio    = 16020/(hcpYs.xx * hcpYs.yy)\n"
				"    YsHcp    = ratio*(hcpYs.energy - 6*hcp.energy)\n"
				"    c_A0Hcp  = 10.0*(hcp.yy/2.55 - 1.0)**2\n"
				"    c_CAHcp  = 10.0*(caHcp/ 1.65 - 1.0)**2\n"
				"    c_YsHcp  =  5.0*(YsHcp/-13.0 - 1.0)**2\n"

				"    caL10    = L10.zz/L10.xx\n"
				"    c_A0L10  = 100.0*(L10.xx/3.56 - 1.0)**2\n"
				"    c_CAL10  = 100.0*(caL10/1.025 - 1.0)**2\n"
				"    c_EcL10  = 1.0e3*(-L10.energy/15.8 - 1.0)**2\n"

				"    c_p0     = ParamLimitRatio(p[0], 0.15, 0.35, 1e2)\n"
				"    c_p1     = ParamLimitRatio(p[1], 10.0, 15.0, 1e2)\n"
				"    c_p2     = ParamLimitRatio(p[2], 0.12, 0.30, 1e2)\n"

				"    res[0] = c_A0Fcc + c_YsFix + c_C11 + c_C12 + c_C33 + c_A0Hcp + "
				"    c_CAHcp + c_YsHcp + c_A0L10 + c_CAL10 + c_EcL10 + c_p0 + c_p1 + c_p2\n"
				"    sum = '%5.3f %3.0f %3.0f | %3.0f %3.0f %3.0f | %4.2f %4.2f %3.0f | %4.2f %4.2f %4.2f'%("
				"    fcc.xx, YsFix, YsRlx, fccEla.C[0,0], fccEla.C[0,1], fccEla.C[3,3], hcp.yy, "
				"    caHcp, YsHcp, L10.xx, caL10, -L10.energy/4)\n"
				//"    print(sum)\n"
				"    return EAPOT.packMsg(sum)\n");

			init();
			init();			// another init() to test memory alloc for init in compute

			ilmp = 0;
			error->add_chklog(0, "CompLMP(SFE)", "");
			modify->compute[ilmp++]->extracheck(10);
			modify->compute[ilmp++]->extracheck(11);
			modify->compute[ilmp++]->extracheck(12);
			modify->compute[ilmp++]->extracheck(13);
			modify->compute[ilmp++]->extracheck(14);

			modify->compute[ilmp++]->compute(); // skip elatic compute

			modify->compute[ilmp++]->extracheck(15);
			modify->compute[ilmp++]->extracheck(16);

			modify->compute[ilmp++]->extracheck(0);
		}
	}


	/***************************************** single ***************************************/

	if (mode & CheckItem::PairSingle) {
		{
			clear();
			setPairStyle("fs/dai");
			setEAMFormat(pair, 5000, 0.01, 5000, 0.0016, 8.0);
			setFullParam(pair, 0.123554, -0.134361, 0.0543818, -0.981194E-2, 
				0.675816E-3, 0.656618E-4, 1.836569, 6.1, 7.8, 2.552655, 4, 6);
			force->pair->extra_check(0);
		} {
			clear();
			setPairStyle("eam/mishin");
			setEAMFormat(pair, 10000, 0.12E-02, 10000, 0.550678E-03, 0.5506786E+01);
			setFullParam(pair, 5.50679, 0.50037, 2.01458e2, 6.59288e-3, 0.83591, 4.46867, 2.97758, 
				1.54927, 0.86225e-2, 3.80362, -2.19885, -2.61984e2, 0.17394, 5.35661e2, -2.28235, 1.35535, 
				-0.86074, 1.78804, 2.97571, 0.40000, 0.30000, 2.24, 1.80, 1.20, 4.0, 40.0, 1.15e3);
			force->pair->extra_check(0);
		} {
			clear();
			setPairStyle("eam/voter1");
			setEAMFormat(pair, 500, 0.5957203073046090E-02, 500, 0.1281429334268537E-01, 0.6394332378000000E+01);
			setFullParam(pair, 2.04175, 1.30694, 2.09230, 6.28795, 3.46031, 0.03014, 0.93108, 2.39580, 3.615, 3.54, 138.3);
			pairStyle->setPairEAMVotermRoseAxis(pair, 0);
			pairStyle->setPairEAMVotermRoseSampleRange(pair, 2.5, 4.0, 10);
			pairStyle->setPairEAMVotermRoseSampleRange(pair, 4.0, 5.5, 10);
			pairStyle->setPairEAMVotermRoseSampleRange(pair, 5.5, 7.0, 10);
			pairStyle->setPairEAMVotermRoseStructure(pair, "../../res/struct/fcc.lammps");
			force->pair->extra_check(0);
		} {
			clear();
			setPairStyle("eam/voter3");
			setEAMFormat(pair, 500, 0.5957203073046090E-02, 500, 0.1281429334268537E-01, 0.6394332378000000E+01);
			setFullParam(pair, 2.21365, 1.29030, 2.21271, 6.39433, 3.48630, 0.23447, 0.90905, 1.88793, 0.4, 10.0, 1.0, 3.52, 4.45, 181);
			pairStyle->setPairEAMVotermRoseAxis(pair, 0);
			pairStyle->setPairEAMVotermRoseSampleRange(pair, 2.5, 7.0, 30);
			pairStyle->setPairEAMVotermRoseStructure(pair, "../../res/struct/fcc.lammps");
			force->pair->extra_check(0);
		} {
			clear();
			setPairStyle("eam/voter2");
			setEAMFormat(pair, 500, 0.5957203073046090E-02, 500, 0.1281429334268537E-01, 0.6394332378000000E+01);
			setFullParam(pair, 2.21365, 1.29030, 2.21271, 6.39433, 3.48630, 0.23447, 0.90905, 1.88793, 0.4, 10.0, 1.0, 3.52, 4.45, 181);
			pairStyle->setPairEAMVotermRoseAxis(pair, 0);
			pairStyle->setPairEAMVotermRoseSampleRange(pair, 2.5, 7.0, 30);
			pairStyle->setPairEAMVotermRoseStructure(pair, "../../res/struct/fcc.lammps");
			force->pair->extra_check(0);
		} {
			clear();
			setPairStyle("eam/zxwe");
			setEAMFormat(pair, 5000, 0.02, 5000, 0.0014, 7.0);
			setFullParam(pair, 0.396620, 0.548085, -2.19, 0, 0.561830, -2.100595, 1.554485, 
				8.127620, 4.334731, 0.308782, 0.756515, 21.175871, 20, 2.556162, 0.85, 1.15);
			pairStyle->setPairEAMDumpImageEmbXMult(pair, 3.5);
			force->pair->extra_check(0);
		} {
			clear();
			setPairStyle("eam/zhou");
			setEAMFormat(pair, 5000, 0.02, 5000, 0.0014, 7.0);
			setFullParam(pair, 0.396620, 0.548085, -2.19, 0, 0.561830, -2.100595, 1.554485, 
				8.127620, 4.334731, 0.308782, 0.756515, 20, 2.556162, 0.85, 1.15);
			pairStyle->setPairEAMZXWRhoStructure(pair, "../../res/struct/fcc.lammps");
			pairStyle->setPairEAMZXWRhoAxisLattice(pair, 0, 3.61496);
			pairStyle->setPairEAMDumpImageEmbXMult(pair, 3.5);
			force->pair->extra_check(0);
		}
	}

	if (mode & CheckItem::PairMEAM) {
		{
			// check second
			clear();			
			setElements1("Fe");
			setPairStyle("meam/second");

			const char* extra[] = {	"Cmin(1,1,1)", "rc", "Cmax(1,1,1)", "augt1"	};
			pairStyle->addPairMEAMFreeParam(pair, 1, &extra[0]);
			pairStyle->addPairMEAMConstParam(pair, 3, &extra[1]);

			//	elt lat	z iele  atwt  alpha	 b0  b1  b2  b3  alat  esub	asub  t0   t1   t2    t3   rho0 ibar
			//       1	8  26  55.845 5.13	4.01 1.0 1.0 1.0 2.851 4.29	0.555 1.0 2.77 1.00	-10.81 1.0   -5
			//						    *    *    *   *   *               *	       *    *      *
			setFullParam(pair, 5.13, 4.01, 1.0, 1.0, 1.0,  0.555, 2.77, 1.00, -10.81,  0.533,
				1, 8, 26, 55.845,  2.851, 4.29, 1.0, 1.0, -5,	4.0, 2.8, 0);
			force->pair->extra_check(0);
		} {
			// single check
			clear();			
			setElements1("C");
			setPairStyle("meam/first");
			setFullParam(pair, 4.38, 4.1, 4.2, 5.0, 3.0, 1.0, 5.0, 9.34, -1.0,
				4, 4, 6, 12.0111, 3.567, 7.37, 1.0, 2.25, 1);
			force->pair->extra_check(0);
		}

		//		  0		1	2		3		4		5		6		7		8		9		10		11		12		13		14		15		16		17
		//	elt	 lat	z	iele	atwt	alpha	b0		b1		b2		b3		alat	esub	asub	t0		t1		t2		t3		rho0	ibar
		//	'C'	'dia'	4	6		12.0111	4.38	4.1		4.2		5		3		3.567	7.37	1		1		5		9.34	-1		2.25	1
		//									*		*		*		*		*						*				*		*		*
#define ADD_MEAM_FOR_BN_SYSTEM()														\
		setPairStyle("meam/first");														\
		const char* extra[] = { "Ec(1,2)", "alpha(1,2)", "re(1,2)",						\
			"lattce(1,2)", "Cmax(1,2,1)", "Cmax(1,2,2)", "Cmax(2,2,1)", "Cmax(1,1,2)"	\
		};																				\
		pairStyle->addPairMEAMFreeParam(pair, 3, &extra[0]);							\
		pairStyle->addPairMEAMConstParam(pair, 5, &extra[3]);							\
		pairStyle->setPairDofScript(pair,												\
			"def PairDofMapScript(caller, ndof, vdof, nf, nc, f, c, name):			\n"	\
			"    p = asArray(vdof, shape=(ndof, ))									\n"	\
			"    d = [name[i] for i in range(len(p))]								\n"	\
			"    p[4:12]  = f[0:8]					# alpha b0 b1 b2 b3 alat esub	\n"	\
			"    p[13:16] = f[8:11]					# t1    t2 t3					\n"	\
			"    p[22:30] = f[11:19]				# 4.38 4.1  4.2 5 3 3.567 7.37	\n"	\
			"    p[31:34] = f[19:22]				# 5    9.34 -1					\n"	\
			"    p[d.index(b'Ec(1,2)')]    = f[22]	# 6.5							\n"	\
			"    p[d.index(b'alpha(1,2)')] = f[23]	# 4.2							\n"	\
			"    p[d.index(b're(1,2)')]    = f[24]	# 1.64							\n"	\
			"    p[0:4]         = c[0:4]			# lat	z iele atwt				\n"	\
			"    p[12],p[16:18] = c[4],c[5:7]		# t0 rho0 ibar					\n"	\
			"    p[18:22]       = c[7:11]			# 'dia' 4 6 12.0111				\n"	\
			"    p[30],p[34:36] = c[11],c[12:14]	# 1 2.25 1						\n"	\
			"    p[d.index(b'lattce(1,2)')] = c[14] # 4								\n"	\
			"    p[d.index(b'Cmax(1,2,1)')] = c[15] # 2.8							\n"	\
			"    p[d.index(b'Cmax(1,2,2)')] = c[15] # 2.8							\n"	\
			"    p[d.index(b'Cmax(2,2,1)')] = c[15] # 2.8							\n"	\
			"    p[d.index(b'Cmax(1,1,2)')] = c[15] # 2.8							\n"	\
		);

		{
			// cross check
			clear();
			setElements2("B", "N");
			ADD_MEAM_FOR_BN_SYSTEM();
			pairStyle->setPairDof(pair, 25, 16);
			setFullParam(pair, 4.479, 4.522, 4.279, 5.045, 3.143, 3.704, 7.508, 1.133, 5.083, 9.418, -0.823,
				4.046, 4.147, 5.944, 4.263, 3.161, 3.429, 5.404, 0.804, 5.310, 9.174, -0.895, 6.9996, 4.258, 1.688,
				4, 4, 5, 10.811, 1.0, 2.25, 1, 4, 4, 7, 14.0067, 1.0, 2.25, 1, 4, 2.8);
			force->pair->extra_check(1);

			output->addDump(10, "image", "image", "BN.meam.*.jpg");
			output->runDumpOnce();
		} {
			// cross check useFile
			clear();
			setElements2("B", "N");
			ADD_MEAM_FOR_BN_SYSTEM();
			pairStyle->setPairDof(pair, 25, 16);
			setFullParam(pair, 4.479, 4.522, 4.279, 5.045, 3.143, 3.704, 7.508, 1.133, 5.083, 9.418, -0.823,
				4.046, 4.147, 5.944, 4.263, 3.161, 3.429, 5.404, 0.804, 5.310, 9.174, -0.895, 6.9996, 4.258, 1.688,
				4, 4, 5, 10.811, 1.0, 2.25, 1, 4, 4, 7, 14.0067, 1.0, 2.25, 1, 4, 2.8);
			pairStyle->setPairCommByFile(pair, 1);
			force->pair->extra_check(2);
		} {
			// check Elastic relax and extra paramaters if works
			clear();
			setElements2("B", "N");
			ADD_MEAM_FOR_BN_SYSTEM();
			pairStyle->setPairDof(pair, 25, 16);
			setFullParam(pair, 4.479, 4.522, 4.279, 5.045, 3.143, 3.704, 7.508, 1.133, 5.083, 9.418, -0.823,
				4.046, 4.147, 5.944, 4.263, 3.161, 3.429, 5.404, 0.804, 5.310, 9.174, -0.895, 6.5, 4.2, 1.64,
				4, 4, 5, 10.811, 1.0, 2.25, 1, 4, 4, 7, 14.0067, 1.0, 2.25, 1, 4, 2.8);
			force->pair->extra_check(100);
		}
	}
	if (mode & CheckItem::PairTersoff) {	
		{
			clear();
			setElements1("C");
			setPairStyle("bop/tersoff");
			setFullParam(pair, 19981, 7.034, -0.33953, 0.99054, 4.1612E-06, 2.3064, 389.63, 3.4653, 1544.8, 3, 1, 0, 1.95, 0.15);
			force->pair->extra_check(0);
		} {
			clear();
			setElements1("C");
			setPairStyle("bop/brenner");
			setFullParam(pair, 19981, 7.034, -0.33953, 0.99054, 4.1612E-06, 1.99905, 1.50247, 1.53988, 3.73705, 3, 1, 0, 1.95, 0.15);
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("C", "Si");
			setPairStyle("bop/tersoff");
			setFullParam(pair, 19981, 100390, 7.034, 16.217,
				-0.33953, -0.59825, 0.99054, 0.78734, 4.1612E-06, 1.1E-06,
				2.3064, 2.0193, 1.7322,     389.63, 432.154,  471.18, 
				3.4653, 2.9726, 2.4799,     1544.8, 1681.731, 1830.8,
				3, 1, 0, 2.35726, 1.95, 2.85,  0.152719, 0.15, 0.15);
			force->pair->extra_check(1);
		} {
			clear();
			setElements2("C", "Si");
			setPairStyle("bop/tersoff");
			setFullParam(pair, 19981, 100390, 7.034, 16.217,
				-0.33953, -0.59825, 0.99054, 0.78734, 4.1612E-06, 1.1E-06,
				2.3064, 2.0193, 1.7322,     389.63, 432.154,  471.18, 
				3.4653, 2.9726, 2.4799,     1544.8, 1681.731, 1830.8,
				3, 1, 0, 2.35726, 1.95, 2.85,  0.152719, 0.15, 0.15);
			pairStyle->setPairCommByFile(pair, 1);
			force->pair->extra_check(2);
		} {
			clear();
			setElements2("C", "Si");
			setPairStyle("bop/brenner");
			setFullParam(pair, 19981, 100390, 7.034, 16.217,
				-0.33953, -0.59825,   0.99054, 0.78734, 4.1612E-06, 1.1E-06,    
				1.99905, 1.73242, 1.46555,     1.50247, 1.47209, 1.43165, 
				1.53988, 1.83099, 2.29516,     3.73705, 3.43563, 2.66602,
				3, 1, 0, 2.35726, 1.95, 2.85, 0.152719, 0.15, 0.15);
			force->pair->extra_check(1);
		}
	}
	if (mode & CheckItem::PairSW) {
		{
			clear();
			setElements1("Si");
			setPairStyle("sw");
			setFullParam(pair, 2.1683, 2.0951, 1.80, 21.0, 1.20, 7.049556277, 0.6022245584, -0.333333333333, 4.0, 0.0, 0.0);
			force->pair->extra_check(0);
		} {
			clear();
			setElements2("Ga", "N");
			setPairStyle("sw");
			setFullParam(pair, 1.20, 2.17, 1.6136914, 2.100, 1.695, 1.300,
				1.6, 1.8, 1.8, 32.5, 1.2, 7.917, 0.72, -0.333333333333, 4.0, 0.0, 0.0 );
			force->pair->extra_check(1);
		} {
			clear();
			setElements2("Ga", "N");
			setPairStyle("sw");
			setFullParam(pair, 1.20, 2.17, 1.6136914, 2.100, 1.695, 1.300,
				1.6, 1.8, 1.8, 32.5, 1.2, 7.917, 0.72, -0.333333333333, 4.0, 0.0, 0.0 );
			pairStyle->setPairCommByFile(pair, 1);
			force->pair->extra_check(2);
		}
	}
	if (mode & CheckItem::PythonParam) {
		{
			clear();
			setPairStyle("eam/zxwe");
			setEAMFormat(pair, 5000, 0.02, 5000, 0.0014, 7.0);
			setFullParam(pair, 0.39, 0.54, -2.1, 0, 0.56, -2.1, 1.55, 
				8.12, 4.33, 0.30, 0.75, 21.17, 20, 2.556, 0.85, 1.15);
			force->pair->extra_check(1);
		} {
			// 0 1 2  3  4  5    6     7     8     9    10    11    12 13 14 15
			// A B F0 F1 F2 F3 fe    alpha beta  kappa gamma rhoe | n  re c1 c2
			// A B F0 F2 F3 fe alpha beta  kappa gamma | F1  rhoe   n  re c1 c2
		} {
			clear();
			setPairStyle("eam/zxwe");
			setEAMFormat(pair, 5000, 0.02, 5000, 0.0014, 7.0);

			pairStyle->setPairDofScript(pair,
				"def PairDofMapScript(caller, ndof, vdof, nf, nc, f, c, name):\n"
				"    p = asArray(vdof, shape=(ndof, ))\n"
				"    p[0:3], p[4:11] = f[0:3], f[3:10]\n"		//	A B F0, F2 F3 fe alpha beta  kappa gamma
				"    p[3],  p[11:16] = c[0],    c[1:6]\n");		//	F1, rhoe n re c1 c2
			pairStyle->setPairDof(pair, 10, 6);
			setFullParam(pair, 0.39, 0.54, -2.1, 0.56, -2.1, 1.55, 
				8.12, 4.33, 0.30, 0.75, 0, 21.17, 20, 2.556, 0.85, 1.15);
			force->pair->extra_check(2);
		} {
			Add_Default_Cross_Potential_Zhou2();
			force->pair->extra_check(1);
		} {
			Add_Default_Cross_Potential_Zhou2();
			pairStyle->setPairDofScript(pair,
				"def PairDofMapScript(caller, ndof, vdof, nf, nc, f, c, name):\n"
				"    p = asArray(vdof, shape=(ndof, ))\n"
				"    p[0:4], p[5:9] = f[0:4], f[4:8]\n"
				"    p[4],   p[9]   = c[0], c[1]    \n");
			pairStyle->setPairDof(pair, 8, 2);
			setFullParam(pair, 0.11, 12, 0.36, 2.55, 0.33, 2.5, 0.69, 2.5, 18, 22);
			force->pair->extra_check(2);
		} {
			Add_Default_Cross_Potential_Zhou2();
			pairStyle->enablePairEAMListTransform(pair, 1);
			setFullParam(pair, 0, 1, 0, 1, 0.11, 12, 0.36, 2.55, 18, 0.33, 2.5, 0.69, 2.5, 22);
			force->pair->extra_check(3);
		} {
			Add_Default_Cross_Potential_Zhou2();
			pairStyle->setPairDofScript(pair,
				"def PairDofMapScript(caller, ndof, vdof, nf, nc, f, c, name):\n"
				"    p = asArray(vdof, shape=(ndof, ))\n"
				"    p[0:2], p[4:8], p[9:13] = f[0:2], f[2:6], f[6:10]\n"
				"    p[2:4], p[8],   p[13]   = c[0:2], c[2], c[3]\n");
			pairStyle->setPairDof(pair, 10, 4);
			pairStyle->enablePairEAMListTransform(pair, 1);
			setFullParam(pair, 0, 1, 0.11, 12, 0.36, 2.55, 0.33, 2.5, 0.69, 2.5, 0, 1, 18, 22);
			force->pair->extra_check(4);
		}
	}

	if (mode & CheckItem::DumpCheck) {
		{
			clear();
			setElements2("C", "Si");
			setPairStyle("bop/tersoff");
			setFullParam(pair, 19981, 100390, 7.034, 16.217, 
				-0.33953, -0.59825, 0.99054, 0.78734, 4.1612E-06, 1.1E-06, 
				2.3064, 2.0193, 1.7322, 389.63, 432.154, 471.18, 
				3.4653, 2.9726, 2.4799, 1544.8, 1681.731, 1830.8, 
				3, 1, 0, 2.35726, 1.95, 2.85, 0.152719, 0.15, 0.15);
			output->addDump(10, "image", "image", "CSi.tersoff.*.jpg");
			output->runDumpOnce();
		} {
			clear();
			setElements2("Ga", "N");
			setPairStyle("sw");
			setFullParam(pair, 1.20, 2.17, 1.6136914, 2.100, 1.695, 1.300, 
				1.6, 1.8, 1.8, 32.5, 1.2, 7.917, 0.72, -0.333333333333, 4.0, 0.0, 0.0);
			output->addDump(10, "image", "image", "CSi.sw.*.jpg");
			output->runDumpOnce();
		} {
			clear();
			setElements2("V", "Nb");
			setPairStyle("fs/ackland");
			setEAMInputs(pair, FS, NULL, "V", "Nb");
			pairStyle->setPairEAMOutputMode(pair, "fs");
			setFullParam(pair, 2.010637, 3.013789, 3.692767, 3.766963, 3.841158, 3.915354, 
				23.0, -0.8816318, 1.49077560, -0.3976370, 
				35.5, -1.2228211, 1.74817675, -0.4320067, 
				48.0, -1.5640104, 2.00557790, -0.4663764, 
				0.50, 2.63200, 3.8, 0.65, 2.74525, 4.0, 0.80, 2.85850, 4.2);

			modify->addCompute("AB3", "energy", "../../res/struct/L12_AB3.lammps");
			modify->addCompute("A3B", "energy", "../../res/struct/L12_A3B.lammps");

			const char* cost[] = {
				"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
				"    v = EAPOT.parseCompute(nparam, style, param)\n"
				"    AB3, A3B = v\n"
				"    cAB3  = (AB3.xx/4.110 - 1.0)**2 + (AB3.Ec/6.820 - 1.0)**2\n"
				"    cA3B  = (A3B.xx/3.960 - 1.0)**2 + (A3B.Ec/5.770 - 1.0)**2\n"
				"    sum = '%5.3f %5.3f %5.3f %5.3f'%(AB3.xx, A3B.xx, AB3.Ec, A3B.Ec)\n"
				"    res[0] = cAB3+cA3B\n"
				"    return EAPOT.packMsg(sum)\n", "4.110 3.960 6.820 5.770"
			};

			force->pair->runMDCompute(10, Pair::RunDump | Pair::RunEcho, 10, cost, NULL, "nms", "VNb.*.eam");

		} {
			clear();
			setElements1("Cu");
			setPairStyle("eam/voter1");
			setEAMFormat(pair, 500, 0.5957203073046090E-02, 500, 0.1281429334268537E-01, 0.6394332378000000E+01);
			setFullParam(pair, 2.04175, 1.30694, 2.09230, 6.28795, 3.46031, 0.03014, 0.93108, 2.39580, 3.615, 3.54, 138.3);
			pairStyle->setPairEAMVotermRoseAxis(pair, 0);
			pairStyle->setPairEAMVotermRoseSampleRange(pair, 2.5, 7.0, 30);
			pairStyle->setPairEAMVotermRoseStructure(pair, "../../res/struct/fcc.lammps");
			pairStyle->setPairEAMDumpImageLimitRlo(pair, 1.0);
			pairStyle->setPairDumpImageYLimit(pair, 0, 0.0, 20.0);

			modify->addCompute("fcc", "energy", "../../res/struct/fcc.lammps");
			modify->addCompute("Ela", "elastic", "fcc");

			void* CompCost = modify->addCompute("cost", "term", "none");
			compStyle->setComputeExternalScript(CompCost,
				"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
				"    v = EAPOT.parseCompute(nparam, style, param)\n"
				"    fcc, C = v[0], v[1].C\n"
				"    c_A0Fcc  = 10.0*(fcc.xx/3.615  - 1.0)**2\n"
				"    c_EcFcc  = 10.0*(fcc.Ec/3.540      - 1.0)**2\n"
				"    c2 = (C[0,0]/172 - 1.0)**2 + (C[0,1]/125 - 1.0)**2 + (C[3,3]/80 - 1.0)**2\n"

				"    res[0] = c_A0Fcc + c_EcFcc + c2\n"
				"    sum = '%5.3f %5.3f %3.0f %3.0f %3.0f %10.8g %10.8g'%"
				"(fcc.xx, fcc.Ec, C[0,0], C[0,1], C[3,3], fcc.rhoAve, fcc.embAve)\n"
				"    return EAPOT.packMsg(sum)\n");
			compStyle->setComputeExternalTitle(CompCost, "3.615 3.540 175 125  80 -2.5000000 1.00000000");

			output->setLogFile("dump", "dump.log");
			output->setLogFile("thermo", "thermo.log");


			void* file = output->addDump(10, "file", "file", "Cu.*.eam");
			void* image = output->addDump(10, "image", "image", "Cu.*.jpg");
			void* check = output->addDump(10, "exter", "external", "Cu.log");

			dumpStyle->setDumpExternalFile(check, file);
			dumpStyle->setDumpExternalScript(check, "eapot.chkinter.add('fcc', eapot.chkinter.ele)");

			output->setThermoStep(10);
			const char* keys[] = { "step", "eval", "err", "pylog", "d_exter" };
			output->setThermoKeys("custom", 5, keys);
			output->setThermoFormatStyle("line", "%4d %4d %10.3e %s\n %s\n");

			update->setMinimizeStyle("nms");
			update->runMinimize(CompCost, 1e-15, 1e-15, 10, 1000);
		}
	}

	error->print_chklog(0, chkLogLevel);

	/********************************* minimize check ******************************/

	if (mode & CheckItem::MinimizeCheck) {

		double ecurrent, ref;
		void* Ec, * Ela, * CompCost;	
		const char* keys[] = { "step", "eval", "err", "pylog" };

		{
			clear();
			setPairStyle("eam/zxwe");
			pairStyle->setPairEAMDumpdr(pair, 0.0014);
			pairStyle->setPairEAMDumpCutoff(pair, 7.0);
			output->setLogFile("thermo", NULL);
			output->setThermoStep(20);

			PAIR_EAM_ZHOU_PARM_INIT_CU;

			Ec = modify->addCompute("Ec", "energy", "../../res/struct/Cu.lammps");
			Ela = modify->addCompute("Ela", "elastic", "Ec");
			compStyle->setComputeEnergyNoRelax(Ec);

			CompCost = modify->addCompute("cost", "term", "none");
			compStyle->setComputeExternalScript(CompCost,
				"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
				"    v = EAPOT.parseCompute(nparam, style, param)\n"
				"    sts, Ec, Ela = v[0].stress[0], v[0].Ec, v[1].C\n"
				"    c_C11    = 0.1*(Ela[0,0]/172 - 1.0)**2\n"
				"    c_C12    = 0.1*(Ela[0,1]/125 - 1.0)**2\n"
				"    c_C33    = 0.1*(Ela[3,3]/80  - 1.0)**2\n"

				"    res[0] = sts**2 + (Ec/3.540 - 1.0)**2 + c_C11 + c_C12 + c_C33\n"
				"    sum = '%10.3e %5.3f %3.0f %3.0f %3.0f'%(sts, Ec, Ela[0,0], Ela[0,1], Ela[3,3])\n"
				"    return EAPOT.packMsg(sum)\n");
			compStyle->setComputeExternalTitle(CompCost, " 0.000e-00 3.540 175 125  80");

			output->setThermoStep(20);			
			output->setThermoKeys("custom", 4, keys);
			output->setThermoFormatStyle("line", "%6d %6d %17.10e %s");

			////************************************ CG ***********************************//
			PAIR_EAM_ZHOU_PARM_INIT_CU;
			output->setThermoStep(1);
			update->runMinimize(CompCost, 1e-15, 1e-15, 5, 1000);
			MINIMIZE_CHECK("cg", 0.0025173513468925855403);

			//********************************* Simplex *********************************//
			output->setThermoStep(20);
			update->setMinimizeStyle("nms");

			PAIR_EAM_ZHOU_PARM_INIT_CU;
			update->runMinimize(CompCost, 1e-20, 1e-20, 100, 10000);
			MINIMIZE_CHECK("nms", 71.635186002469552591);

			//********************************* Powell  *********************************//
			output->setThermoStep(1);
			update->setMinimizeStyle("powell");

			PAIR_EAM_ZHOU_PARM_INIT_CU;
			update->runMinimize(CompCost, 0, 0, 1, 100000);
			MINIMIZE_CHECK("powell", 0.00035840184348272686055);

			//************************* Simulated annealing / b *************************//
			output->setThermoStep(100);
			update->setMinimizeStyle("sa/b");

			PAIR_EAM_ZHOU_PARM_INIT_CU;
			update->setRandomSeed(1);
			update->runMinimize(CompCost, 1e-6, 1e-6, 500, 10000);
			MINIMIZE_CHECK("sa/b", 0.021769804533307485217);

			//****************************** Particle swarm *****************************//
			output->setThermoStep(2);
			update->setMinimizeStyle("pso/taka");

			PAIR_EAM_ZHOU_PARM_INIT_CU;
			update->setRandomSeed(76);
			miniStyle->setParticleSwarmTakaParticles(50);
			update->runMinimize(CompCost, 1e-20, 1e-20, 10, 10000);
			MINIMIZE_CHECK("pso/taka", 19.182445289500286378);
		}

		{
			//*************************** Differential Evolution ************************//
			clear();
			setPairStyle("eam/zhou");
			pairStyle->setPairEAMDumpdr(pair, 0.0014);
			pairStyle->setPairEAMDumpCutoff(pair, 7.0);
			pairStyle->setPairEAMZXWRhoStructure(pair, "../../res/struct/fcc.lammps");
			pairStyle->setPairEAMZXWRhoAxisLattice(pair, 0, 3.61496);
			setFullParam(pair, 0.4, 0.55, -2.2, 0.0, 0.56, -2.1, 1.55, 8.0, 4.0, 0.3, 0.75, 20, 2.556162, 0.85, 1.15);
			output->setLogFile("thermo", NULL);

			Ec = modify->addCompute("Ec", "energy", "../../res/struct/Cu.lammps");
			Ela = modify->addCompute("Ela", "elastic", "Ec");
			compStyle->setComputeEnergyNoRelax(Ec);
			compStyle->setComputeElasticLoadDelta(Ela, 1e-5);

			CompCost = modify->addCompute("cost", "term", "none");
			compStyle->setComputeExternalScript(CompCost,
				"def computeCostScript(caller, np, p, nparam, style, param, res):	\n"
				"    v = EAPOT.parseCompute(nparam, style, param)						\n"
				"    sts, Ec, Ela = v[0].stress[0], v[0].Ec, v[1].C					\n"
				"    c1        = 1.0e-2*sts**2 + 1000*(Ec/3.540 - 1.0)**2			\n"
				"    c_C11     = 5.00*(Ela[0,0]/172 - 1.0)**2						\n"
				"    c_C12     = 5.00*(Ela[0,1]/125 - 1.0)**2						\n"
				"    c_C33     = 5.00*(Ela[3,3]/80  - 1.0)**2						\n"

				"    c_oth = 0														\n"
				"    c_oth += ParamLimitRatio(p[0],   0.2,  0.8, 1e6)				\n"
				"    c_oth += ParamLimitRatio(p[1],   0.3,  1.2, 1e6)				\n"

				"    c_oth += ParamLimitRatio(p[2],  -4.0, -1.0, 1e6)				\n"
				"    c_oth += ParamlimitAbslo(p[3],   0.0,  0.0, 1e2)				\n"
				"    c_oth += ParamLimitRatio(p[4],  -1.0,  2.0, 1e6)				\n"
				"    c_oth += ParamLimitRatio(p[5],  -4.0,  4.0, 1e6)				\n"

				"    c_oth += ParamLimitRatio(p[6],   0.6,  3.0, 1e6)				\n"
				"    c_oth += ParamLimitRatio(p[7],   4.0,  16., 1e6)				\n"
				"    c_oth += ParamLimitRatio(p[8],   2.0,  10., 1e6)				\n"
				"    c_oth += ParamLimitRatio(p[9],   0.1,  0.8, 1e6)				\n"
				"    c_oth += ParamLimitRatio(p[10],  0.2,  1.6, 1e6)				\n"

				"    res[0] = c1 + c_C11 + c_C12 + c_C33 + c_oth\n"
				"    sum = '%10.3e %5.3f %3.0f %3.0f %3.0f'%(sts, Ec, Ela[0,0], Ela[0,1], Ela[3,3])\n"
				"    return EAPOT.packMsg(sum)\n");
			compStyle->setComputeExternalTitle(CompCost, " 0.000e-00 3.540 175 125  80");

			output->setThermoKeys("custom", 4, keys);
			output->setThermoFormatStyle("line", "%6d %6d %17.10e %s");

			output->setThermoStep(10);
			update->setMinimizeStyle("de/a");

			update->setRandomSeed(1);
			update->runMinimize(CompCost, 1e-10, 1e-10, 80, 10000);
			MINIMIZE_CHECK("de/a", 63.193405279030280042);
		}
	}
}

void EAPOT::init()
{
	update->init();
	force->init();
	modify->init();
	output->init();
}


void EAPOT::once_init(){
	force->init(); 
	modify->init();
	output->init();
	once_initFlag = 1;
}


void EAPOT::help()
{
	FILE *fp = screen;

	// general help message about command line and flags

	fprintf(fp,
		"\nEAPOT - " EAPOT_VERSION "\n\n"
		"For generating the empirical interatomic potentials \n"
		"List of command line options supported by this nEAPOT executable:\n\n"
		"-check                      : global checking (-c)\n"
		"-help                       : print this help message (-h)\n");

	fprintf(fp, "List of style options included in this EAPOT executable\n\n");

	int pos;

	pos = 80;
	fprintf(fp, "* Minimize styles:\n");
#define MINIMIZE_CLASS
#define MinimizeStyle(key,Class) print_style(fp,#key,pos);
#include "style_minimize.h"
#undef MINIMIZE_CLASS
	fprintf(fp, "\n\n");

	pos = 80;
	fprintf(fp, "* Compute styles:\n");
#define COMPUTE_CLASS
#define ComputeStyle(key,Class) print_style(fp,#key,pos);
#include "style_compute.h"
#undef COMPUTE_CLASS
	fprintf(fp, "\n\n");

	pos = 80;
	fprintf(fp, "* Dump styles:\n");
#define DUMP_CLASS
#define DumpStyle(key,Class) print_style(fp,#key,pos);
#include "style_dump.h"
#undef DUMP_CLASS
	fprintf(fp, "\n\n");

	pos = 80;
	fprintf(fp, "* Command styles\n");
#define COMMAND_CLASS
#define CommandStyle(key,Class) print_style(fp,#key,pos);
#include "style_command.h"
#undef COMMAND_CLASS
	fprintf(fp, "\n\n");

	pos = 80;
	fprintf(fp, "* Pair styles\n");
#define PAIR_CLASS
#define PairStyle(key,Class) print_style(fp,#key,pos);
#include "style_pair.h"
#undef PAIR_CLASS
	fprintf(fp, "\n\n");
}


void print_style(FILE *fp, const char *str, int &pos)
{
	if (isupper(str[0])) return;

	int len = strlen(str);
	if (pos + len > 80) {
		fprintf(fp, "\n");
		pos = 0;
	}

	if (len < 16) {
		fprintf(fp, "%-16s", str);
		pos += 16;
	}
	else if (len < 32) {
		fprintf(fp, "%-32s", str);
		pos += 32;
	}
	else if (len < 48) {
		fprintf(fp, "%-48s", str);
		pos += 48;
	}
	else if (len < 64) {
		fprintf(fp, "%-64s", str);
		pos += 64;
	}
	else {
		fprintf(fp, "%-80s", str);
		pos += 80;
	}
}