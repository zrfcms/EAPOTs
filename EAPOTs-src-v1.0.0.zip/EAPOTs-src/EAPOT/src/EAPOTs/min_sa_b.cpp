
#include "min_sa_b.h"
#include <ctype.h>
#include <stdlib.h>
#include "math.h"
#include "eapot_math.h"
#include "string.h"

#include "memory.h"
#include "error.h"

#include "update.h"
#include "modify.h"
#include "pair.h"
#include "force.h"
#include "output.h"

#include "min_chkfunc.h"
#include "option_mini.h"
using namespace EAPOT_NS;

#define eps 1e-15

MinSAB::MinSAB(EAPOT *eapot) : Min(eapot)
{
	styles.push_back("sa/b");
	linestyle = 0;

	X = NULL;
	dx = NULL;
	xi = NULL;
	xi_new = NULL;
	xi_opt = NULL;
	hi = NULL;
	lo = NULL;
	len = NULL;

	//chkfunc = (ChkFunc*)new AnnealFunc;
}

/* ---------------------------------------------------------------------- */

MinSAB::~MinSAB()
{
	memory->destroy(X);
}

/* ---------------------------------------------------------------------- */

void MinSAB::init()
{
	Min::init();

}

/* ---------------------------------------------------------------------- */

void MinSAB::setup_style()
{

	memory->destroy(X);
	memory->create(X, 7, nvec, "MinSAA::X");

	dx = X[0];
	xi = X[1];
	xi_new = X[2];
	xi_opt = X[3];
	hi = X[4];
	lo = X[5];
	len = X[6];
}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinSAB::reset_vectors()
{
	temp_memset0(dx, nvec);
	temp_memcpy(xi, xvec, nvec);
	temp_memcpy(xi_new, xvec, nvec);
	temp_memcpy(xi_opt, xvec, nvec);

	double tlen;
	for (int i = 0; i < nvec; i++){
		tlen = xvec[i] * 0.1;
		lo[i] = xvec[i] - tlen;
		hi[i] = xvec[i] + tlen;
		len[i] = tlen * 2; 
	}
}



void MinSAB::Mu_Inv(int ndim, double* x, double mu)
{
	double p;
	double y;
	for (int i = 0; i < ndim; i++){
		y = eqdist() * 2 - 1;
		p = pow(1 + mu, fabs(y));
		x[i] = (p - 1) / mu;

		if (y < 0) x[i] = -x[i];
		else if (y == 0) x[i] = 0;
	}		
}


int MinSAB::iterate(int maxiter)
{
	int ntimestep;
	const int ndim = nvec;

	double q = 1;
	double x, scale;
	bool accept;

	double F = ecurrent;	//current solution
	double F_new = F;		//temporary new solution
	double F_opt = F;		//historical optimal solution
	double dF;

	double Ti, mu;

	for (int iter = 0; iter < maxiter; iter++) {

		ntimestep = ++update->ntimestep;
		niter++;

		eprevious = ecurrent;

		// function evaluation criterion
		if (neval >= update->max_eval) return return_final(MAXITER, xi_opt);

		Ti = pow((double)iter / maxiter, q);
		mu = pow(10, Ti * 100);		//calclate mu
		Mu_Inv(ndim, dx, mu);

		for (int i = 0; i < ndim; i++){
			dx[i] *= len[i];
			x = xi[i] + dx[i];

			if (x < lo[i]) x = lo[i];
			if (x > hi[i]) x = hi[i];		
			xi_new[i] = x;
		}
		F_new = func(xi_new);
		dF = F_new - F;

		accept = dF < 0;
		if (!accept){
			scale = -Ti*dF / ((fabs(F) + eps) * update->etol);
			accept = eqdist() < exp(scale);
		}
		if (accept){
			temp_memcpy(xi, xi_new, ndim);
			F = F_new;
		}
		if (F < F_opt){
			temp_memcpy(xi_opt, xi, ndim);
			F_opt = F;
		}
		//if (fmod(iter, 50) == 0) printf("%4d %12.6g %12.6g %12.6g %12.6g %12.6g %12.6g\n", 
		//	iter, F_opt, mu, scale, Ti, dF, F);
		//if (fmod(iter, 50) == 0) printf("%4d %12.6g %12.6g %12.6g %12.6g %12.6g\n", 
		//	iter, xi_new[0], xi_new[1], dx[0], dx[1], dF);
		ecurrent = F_opt;

		if (output->next == ntimestep) {
			func(xi_opt); neval--;
			output->write(ntimestep);
		}
	}

	return return_final(MAXITER, xi_opt);
}
