#include "pair_eam_zxw.h"

#include "error.h"
#include "eapot_math.h"
#include "image.h"

#include "dump_image.h"
#include "dump_file.h"

#include "option_pair.h"
#include "libLAMMPS/lammps_api.h"

using namespace EAPOT_NS;



PairEAMZXWe::PairEAMZXWe(EAPOT* eapot)
	: PairEAM(eapot)
{
	styles.push_back("eam/zxwe");
	eam_fsize = 12;
	eam_csize = 4;

	A = B = fe = 0;
	alpha = beta = kappa = lambd = 0;
	lre = 0;

	nn = 20;
	re = c1 = c2 = 0;
	Fn0 = Fn1 = Fn2 = Fn3 = 0;
	F0 = F1 = F2 = F3 = 0;
	Fe = eta = lrs = 0;
}

PairEAMZXWe::~PairEAMZXWe() {

}

double PairEAMZXWe::emb(int type, double lr) {

	double r;
	double lrn = lr / lre;

	if (lrn < c1) {
		double lrn_m = lrn - 1;
		double lrn_m2 = lrn_m * lrn_m;
		r = Fn0 + Fn1 * lrn_m + Fn2 * lrn_m2 + Fn3 * lrn_m2 * lrn_m;
	}
	else if (lrn < c2) {
		double lrn_m = lrn - 1;
		double lrn_m2 = lrn_m * lrn_m;
		r = F0 + F1 * lrn_m + F2 * lrn_m2 + F3 * lrn_m2 * lrn_m;
	}
	else {
		lrn = lr / lrs;
		r = Fe * (1 - eta * log(lrn)) * pow(lrn, eta);
	}

	if (isfinite(r)) return r;
	return 0;
}


double PairEAMZXWe::rho(int itype, int jtype, double r) {

	if (r >= cutmax) return 0;

	double rs = r / re;
	double rq = rs - 1.0;
	return fe * exp(-beta * rq) / (1 + pow(rs - lambd, nn));
}

double PairEAMZXWe::phi(int itype, int jtype, double r) {

	if (r >= cutmax) return 0;

	double rs = r / re;
	double rq = rs - 1.0;
	return A * exp(-alpha * rq) / (1 + pow(rs - kappa, nn))
		- B * exp(-beta * rq) / (1 + pow(rs - lambd, nn));
}

void PairEAMZXWe::setFullParamsStyle() {

	int idx = eam_fsize;
	nn = int(paramVec[idx++]);
	re = paramVec[idx++];
	c1 = paramVec[idx++];
	c2 = paramVec[idx++];

	setFreeParamsStyle();
}

void PairEAMZXWe::setFreeParamsStyle() {

	int idx = 0;
	A = paramVec[idx++];
	B = paramVec[idx++];
	F0 = paramVec[idx++];
	F1 = paramVec[idx++];
	F2 = paramVec[idx++];
	F3 = paramVec[idx++];
	fe = paramVec[idx++];

	alpha = paramVec[idx++];
	beta  = paramVec[idx++];
	kappa = paramVec[idx++];
	lambd = paramVec[idx++];
	lre = paramVec[idx++];
	lrs = lre;

	// Coefficient of the first half
	getFnParams();

	// The coefficient of the third half
	double nlr = c2 - 1;
	double nlr2 = nlr * nlr;
	double nlr3 = nlr2 * nlr;

	double dF20 = F0 + F1 * nlr + F2 * nlr2 + F3 * nlr3;
	double dF21 = F1 + 2 * F2 * nlr + 3 * F3 * nlr2;
	double dF20_logc2 = dF20 * log(c2);
	double tb = dF21 * c2 * log(c2);
	double td = sqrt(-c2 * dF21 * log(c2) * (4 * dF20 - tb));

	eta = (tb - td) / (2 * dF20_logc2);
	Fe = -dF20 / (pow(c2, eta) * (eta * log(c2) - 1));

	PairEAM::setFreeParamsStyle();
}

void PairEAMZXWe::getFnParams() {
	// Coefficient of the first half
	double cm1 = 1 / c1;
	double cm2 = 1 / (c1 * c1);
	double cm3 = 1 / (c1 * c1 * c1);
	double m1 = 3 * cm1 - 3 * cm2 + 1 * cm3;
	double m2 = 3 * cm1 - 6 * cm2 + 3 * cm3;
	double m3 = 3 * cm3 - 3 * cm2;
	double M1[16] = {
		m1, m2, m3, cm3,
		1 - m1, 1 - m2, -m3, -cm3,
		m1 - 1, m2, m3 + 1, cm3,
		1 - m1, -m2, -m3, 1 - cm3,
	};

	double Fn[4], Fm[4] = { F0, F1, F2, F3 };
	math_product_r(Fn, Fm, M1, 4, 4);

	Fn0 = Fn[0];
	Fn1 = Fn[1];
	Fn2 = Fn[2];
	Fn3 = Fn[3];
}

void PairEAMZXWe::write_style(DumpFile* dump) {

	FILE* fp = dump->fp;

	fprintf(fp, "# lre Fn0 Fn1 Fn2 Fn3 Fe eta lrs: ");

	fprintf(fp, FDBLFMTG " ", lre);

	fprintf(fp, FDBLFMTG " ", Fn0);
	fprintf(fp, FDBLFMTG " ", Fn1);
	fprintf(fp, FDBLFMTG " ", Fn2);
	fprintf(fp, FDBLFMTG " ", Fn3);	
	
	fprintf(fp, FDBLFMTG " ", Fe);
	fprintf(fp, FDBLFMTG " ", eta);
	fprintf(fp, FDBLFMTG " ", lrs);
}

void PairEAMZXWe::back_image(class DumpImage* dumpimage, void* paxesf, void* paxesr, void* paxesp)
{
	Image* image = dumpimage->image;
	Axes* axes = (Axes*)paxesf;						// select sub axes
	image->setColoru(0, 255, 0);						// set plot color as green

	PlotLine line = { 0.0, 0.0, 1.0, 1, 5, 5 };			// y = 0, x = [0 1], horizontal, (5, 5) for dotted line

	line.data = c1 * lre;
	axes->line(line);								// Green dotted line for marking x = 0.85 lre boundary

	line.data = c2 * lre;
	axes->line(line);								// Green dotted line for marking x = 1.15 lre boundary
}

void PairEAMZXWe::extra_check(int type) {

#define NP 16
	double param[3][NP] = {
		{0.39, 0.54, -2.1, 0, 0.56, -2.1, 1.55, 8.12, 4.33, 0.30, 0.75, 21.17, 20, 2.556, 0.85, 1.15},
		{ 0.38999999950588410, 0.54000000001368065, -2.0999999999843348, -1.8022792834518622e-10, 
		  0.56000000050261733, -2.0999999999526451, 1.5499999998414220, 8.1199999999615393, 
		  4.3299999999809557, 0.30000000074505806, 0.74999999982506982, 21.170000000015456, 
		  20.0, 2.556, 0.85, 1.15, }, 
		
		{ 0.38763836730194123, 0.54099761482280406, -2.1008618055198824, 0.00000000000000000, 
		  0.55314546695078137, -2.0983443995303777, 1.5554692240941042, 8.1204695583284625, 
		  4.3290174273310109, 0.28749999571105672, 0.74999382323014563, 21.17, 
		  20.0, 2.556, 0.85, 1.15, }, 
	};

	switch (type) {
	case 0:
		addMDComputeFcc();
		runMDCompute(-1, RunDump | RunEcho, 10, CuFccCost, FccChk, "nms", "dump.*.eam");
		function_check();
		testrun(0);
		break;
	case 1:
		error->add_chklog(0, "EAMsPyParam", "");
		error->check(FLERR, NP, paramVec.data(), param[0], 1, "PairEAMZXWe", "p0/", 5e-15, 5e-15, 0, 0);
		addMDComputeFcc(); runMDCompute(5, 0, 10, CuFccCost, FccChk, "cg", "dump.*.eam");
		error->check(FLERR, NP, paramVec.data(), param[1], 1, "PairEAMZXWe", "p1/", 5e-15, 5e-15, 0, 0);
		if (paramVec[3] == param[0][3] || paramVec[11] == param[0][11]) {
			error->all(FLERR, "after cg, F1 == F1(init) or rhoe == rhoe(init)");
		}
		break;
	case 2:
		error->check(FLERR, NP, paramVec.data(), param[0], 1, "PairEAMZXWe", "p0/", 5e-15, 5e-15, 0, 0);
		addMDComputeFcc(); runMDCompute(5, 0, 10, CuFccCost, FccChk, "cg", "dump.*.eam");
		error->check(FLERR, NP, paramVec.data(), param[2], 1, "PairEAMZXWe", "p2/", 5e-15, 5e-15, 0, 0);
		if (paramVec[3] != param[0][3] || paramVec[11] != param[0][11]) {
			error->all(FLERR, "after cg, F1 != F1(init) or rhoe != rhoe(init)");
		}
		break;
	}
}

void PairEAMZXWe::function_check() {

	const char* name = "EAMZXWe";
	error->add_chklog(0, name, "");

#define N 10

	double rRef[N] = {
		9.3201647027809145, 6.0996484218438187, 3.9919585175356902, 2.6125657912769737,
		1.7098123599650126, 1.1189989227048651, 0.73233682642924847, 0.47928226084187081,
		0.31365279197596768, 0.20506317820951084,
	};
	double pRef[N] = {
		8.1116141477318155, 2.9968666513298583, 0.91723819326254286, 0.12874635861859152,
		-0.12884120040505331, -0.18145551428872089, -0.16652214785535996, -0.13921546243773714,
		-0.10593079131492851, -0.071853793779169547,
	};
	double fRef[N] = {
		-1.8549485649765201, -1.9954739852945427, -2.0922891842790521, -2.1521239755667665,
		-2.1817893092612466, -2.1899600431338788, -2.1871737039827197,  -2.1835609219341863,
		-2.1800226374704739, -2.1754419799586464,
	};

	double x, rChk[N], pChk[N], fChk[N];
	for (int i = 0; i < N; i++) {
		x = 1.5 + i * 0.25;
		rChk[i] = rho(1, 1, x);
		pChk[i] = phi(1, 1, x);
		x = 11 + i * 2.0;
		fChk[i] = emb(1, x);
	}

	error->check(FLERR, N, fChk, fRef, 1, name, "emb", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N, rChk, rRef, 1, name, "rho", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N, pChk, pRef, 1, name, "phi", 8e-14, 2e-14, 0.0, 0.0);

#undef N
}

void PairEAMZXWe::testrun(int type) {

	const char* name = "EAMZXWe";
	error->add_chklog(0, name, "");

#define N 5
	double Ref[N] = {
		3.614960129589922, 3.539994981760854,
		169.62673291156975, 122.13955259864045, 75.74217235621234
	};

	addMDCheckCubic(FLERR, 0, name, "Box", &Ref[0], 1.6351941848249121e-09, 1.6351980737472345e-09);
	addMDCheckCubic(FLERR, 1, name, "Ela", &Ref[2], 4.8304850639738747e-07, 7.7440536184686123e-07);

#undef N
}



PairEAMZXW::PairEAMZXW(EAPOT* eapot)
	: PairEAMZXWe(eapot)
	, slog("none")
	, screen("none")
	, structure("")
{
	styles.push_back("eam/zhou");
	axis = 0;
	a0 = 0.0;

	rho2 = 0;
	f0 = f1 = 0;
	etalo = 0.3;
	etahi = 1.5;

	eam_fsize = 11;
	eam_csize = 4;
}

PairEAMZXW::~PairEAMZXW() {

}


void PairEAMZXW::init_style() {
	PairEAM::init_style();

	void* md = NULL;
	md_open_echo(screen.c_str(), slog.c_str(), &md);
	md_set_callback(md, EAPOTcallback, eapot);

	double mcutforce = m_dump.cut;
	double mcutforcesq = mcutforce * mcutforce;

	// 1.head md.run
	set_echo(md, "none");
	set_newton(md, 0, 0);
	if (structure.empty()) error->all(FLERR, "reference structure is not set!");
	read_data(md, structure.c_str());

	if (a0 > 0) {
		double* boxhi = get_boxhi(md);
		double* boxlo = get_boxlo(md);
		double* tilt = get_tilt(md);
		double rat = a0 / (boxhi[axis] - boxlo[axis]);
		double box[6] = {
			(boxhi[0] - boxlo[0]) * rat,
			(boxhi[1] - boxlo[1]) * rat,
			(boxhi[2] - boxlo[2]) * rat,
			tilt[0] * rat,
			tilt[1] * rat,
			tilt[2] * rat,
		};
		change_box(md, box);
	}

	neighbor_setup(md, mcutforce);
	neighbor_build(md, 1);

	// 3.3 get radial distribution
	double* x, rsq, xi[3], xj[3];
	int i, j, jj, jnum, * jlist;

	x = get_atomx1d(md);
	i = get_ilist(md)[0];
	load_vector3(xi, x, i);
	jnum = get_numneigh(md)[i];
	jlist = get_firstneigh(md)[i];

	rlist.clear();
	rlist.reserve(jnum);

	for (jj = 0; jj < jnum; jj++) {
		j = jlist[jj];
		load_vector3(xj, x, j);
		rsq = dis2_vector3(xi, xj);
		if (rsq < mcutforcesq) {
			rlist.push_back(sqrt(rsq));
		}
	}
	
	md_close(md);
}

double PairEAMZXW::getLrs(double t) {

	return rho2 * exp((f1 * rho2) / (t * (f0 * t - f1 * rho2)));
}

void PairEAMZXW::getEta(double plrs, double& eta1, double& eta2) {

	double lgr = log(rho2 / lrs);
	double s = f1 * rho2 * (f1 * rho2 * lgr - 4 * f0) * lgr;

	if (s < 0) {
		eta1 = 0;
		eta2 = 0;
	}
	eta1 = (f1 * rho2 * lgr + sqrt(s)) / (2 * f0 * lgr);
	eta2 = (f1 * rho2 * lgr - sqrt(s)) / (2 * f0 * lgr);
}

void PairEAMZXW::getFemb2(double& pf0, double& pf1) {
	double nlr = c2 - 1;
	pf0 = F0 + F1 * nlr + F2 * nlr * nlr + F3 * nlr * nlr * nlr;
	pf1 = (F1 + 2 * F2 * nlr + 3 * F3 * nlr * nlr) / lre;
}

void PairEAMZXW::getFemb3(double& pf0, double& pf1) {
	pf0 = Fe * (1 - eta * log(rho2 / lrs)) * pow(rho2 / lrs, eta);
	pf1 = -Fe * eta * eta * pow(rho2 / lrs, eta) * log(rho2 / lrs) / rho2;
}

void PairEAMZXW::setFreeParamsStyle() {

	int idx = 0;
	A = paramVec[idx++];
	B = paramVec[idx++];
	F0 = paramVec[idx++];
	F1 = paramVec[idx++];
	F2 = paramVec[idx++];
	F3 = paramVec[idx++];
	fe = paramVec[idx++];

	alpha = paramVec[idx++];
	beta = paramVec[idx++];
	kappa = paramVec[idx++];
	lambd = paramVec[idx++];

	if (rlist.empty()) return;

	lre = 0;
	for (double r : rlist) {
		lre += rho(1, 1, r);
	}
	

	// Coefficient of the first half
	getFnParams();

	// The coefficient of the third half
	rho2 = lre * c2;
	double eta1, eta2;	
	getFemb2(f0, f1);

	// try lre as lrs, if eta is accepted
	lrs = lre;
	getEta(lre, eta1, eta2);
	if (!(etaAccept(eta1) || etaAccept(eta2))) {
#define NN 3
		double lrslist[NN] = {
			getLrs(etalo),
			getLrs((etahi + etalo) / 2),
			getLrs(etahi) 
		};

		int minidx = 0;
		double minval = fabs(lrslist[0] - lre);
		for (int idx = 1; idx < NN; idx++) {
			double ival = fabs(lrslist[idx] - lre);
			if (ival < minval) {
				minval = ival;
				minidx = idx;
			}
		}
#undef NN
		lrs = lrslist[minidx];
		getEta(lrs, eta1, eta2);		
	}

	double lgr = log(rho2 / lrs);
	eta = etaAccept(eta1) ? eta1 : eta2;
	Fe = f0 / pow(rho2 / lrs, eta) / (1 - eta * lgr);

	PairEAM::setFreeParamsStyle();
}


void PairStyle::setPairEAMZXWRhoAxisLattice(void* pPair, int axis, double a0) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/zhou", 1);
	auto pair = (PairEAMZXW*)pPair;
	pair->axis = axis;
	pair->a0 = a0;

	if (axis > 2 || axis < 0) {
		error->all(FLERR, "Illegal setPairEAMVotermRoseAxis sample axis: axis > 2 || axis < 0");
	}
}

void PairStyle::setPairEAMZXWRhoStructure(void* pPair, const char* pfile) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/zhou", 1);
	auto pair = (PairEAMZXW*)pPair;
	pair->structure = pfile;
}

void PairStyle::setPairEAMZXWScreenFile(void* pPair, const char* pfile) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/zhou", 1);
	auto pair = (PairEAMZXW*)pPair;
	pair->screen = pfile;
}

void PairStyle::setPairEAMZXWLogFile(void* pPair, const char* pfile) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/zhou", 1);
	auto pair = (PairEAMZXW*)pPair;
	pair->slog = pfile;
}

void PairEAMZXW::extra_check(int type) {

	addMDComputeFcc();
	runMDCompute(-1, RunDump | RunEcho, 10, CuFccCost, FccChk, "nms", "dump.*.eam");
	function_check();
	testrun(0);

	double fref[4], fchk[4];

	double p1[] = { 0.396620, 0.548085, -2.19, -0.1,
		0.561830, -2.100595, 1.554485, 8.127620, 4.334731, 0.308782, 0.756515 };
	setFreeParams(p1);
	getFemb2(fref[0], fref[1]);
	getFemb2(fchk[0], fchk[1]);

	double p2[] = { 0.396620, 0.548085, -0.74820257627351516, -0.13927257055858791,
		0.11033770128697734, -0.26083388139233554, 1.554485, 8.127620, 4.334731, 0.308782, 0.756515 };
	setFreeParams(p2);
	getFemb2(fref[2], fref[3]);
	getFemb2(fchk[2], fchk[3]);

	error->add_chklog(0, "EAMZXW", "");
	error->check(FLERR, 4, fchk, fref, 1, "EAMZXW", "Continuity", 5e-15, 5e-15, 0, 0);
}

void PairEAMZXW::function_check() {

	const char* name = "EAMZXW";
	error->add_chklog(0, name, "");

#define N 10

	double rRef[N] = {
		9.3201647027809145, 6.0996484218438187, 3.9919585175356902, 2.6125657912769737,
		1.7098123599650126, 1.1189989227048651, 0.73233682642924847, 0.47928226084187081,
		0.31365279197596768, 0.20506317820951084,
	};
	double pRef[N] = {
		8.1116141477318155, 2.9968666513298583, 0.91723819326254286, 0.12874635861859152,
		-0.12884120040505331, -0.18145551428872089, -0.16652214785535996, -0.13921546243773714,
		-0.10593079131492851, -0.071853793779169547,
	};
	double fRef[N] = {
		-1.8549500650460602, -1.9954752511581169, -2.0922901435755334, -2.1521245893839165,
		-2.1817895797941511, -2.1899600591792341, -2.1871736139513729, -2.1835608608796155,
		-2.1800225459510063, -2.1754418588659887,
	};

	double x, rChk[N], pChk[N], fChk[N];
	for (int i = 0; i < N; i++) {
		x = 1.5 + i * 0.25;
		rChk[i] = rho(1, 1, x);
		pChk[i] = phi(1, 1, x);
		x = 11 + i * 2.0;
		fChk[i] = emb(1, x);
	}

	error->check(FLERR, N, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N, rChk, rRef, 1, name, "r", 8e-14, 2e-14, 0.0, 0.0);
	error->check(FLERR, N, pChk, pRef, 1, name, "p", 8e-14, 2e-14, 0.0, 0.0);

#undef N
}

void PairEAMZXW::testrun(int type) {

	const char* name = "EAMZXW";
	error->add_chklog(0, name, "");

#define N 5
	double Ref[N] = {
		3.6149605144048187, 3.5399949817632437,
		169.625766589865, 122.13884495470272, 75.74193635995515
	};

	addMDCheckCubic(FLERR, 0, name, "Box", &Ref[0], 1.6345512721336791e-09, 1.6345575445890376e-09);
	addMDCheckCubic(FLERR, 1, name, "Ela", &Ref[2], 1.5208527824498051e-06, 2.8152494141656327e-06);

#undef N
}