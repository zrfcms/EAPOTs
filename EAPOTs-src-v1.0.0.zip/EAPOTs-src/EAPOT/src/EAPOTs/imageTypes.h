#ifndef EAPOT_IMAGE_TYPES_H
#define EAPOT_IMAGE_TYPES_H

namespace EAPOT_NS {

	class AxisLimit {
	public:
		AxisLimit() {
			lo = hi = 0;
			customlo = customhi = 2.0e100;
			range = 0;
		}

		double lo, hi;
		double customlo, customhi;
		double range;

		AxisLimit& set(double plo, double phi) {
			lo = plo; hi = phi;
			return *this;
		}

		AxisLimit& custom(double clo, double chi) {
			customlo = clo; customhi = chi;
			return *this;
		}

		AxisLimit& update() {
			if (lo >= hi) {
				lo = -1.0;
				hi = 1.0;
			}
			lo = customlo < 1e100 ? customlo : lo;
			hi = customhi < 1e100 ? customhi : hi;
			range = hi - lo;
			return *this;
		}
	};
}

#endif
