#ifdef MINIMIZE_CLASS
MinimizeStyle(powell, MinPowell)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_MIN_POWELL_H
#define EAPOT_MIN_POWELL_H

#include "min.h"

namespace EAPOT_NS {

	class MinPowell : public Min {
		friend class MiniStyle;
	public:
		MinPowell(class EAPOT *);
		~MinPowell();
		void init();
		void setup_style();
		void reset_vectors();

		int iterate(int);

	protected:

		typedef double (MinPowell::*FnPtr)(double, double &, double, double);

		FnPtr linemin;

		double fminbnd(double F, double &s, double a, double b);
		double fminexp(double F, double &s, double a, double b);

		double linesearch(double F, double &x, double *pX, double* pdir);

		double linefunc(double x);


		double dmax;
		double** dir;
		double *X, *X0;

		double* gbuff;
		const double* gdir;
		double* gX;
	};

}

#endif
#endif
#endif

