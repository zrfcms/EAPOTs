#include "pair_hybrid.h"

#include "pair.h"
#include "pair_eam.h"
#include "pair_eam_list.h"
#include "pair_eam_python.h"

#if defined(PAIRALL) || defined(EAMSINGLE)

#include "pair_eam_dai.h"
#include "pair_eam_mishin.h"
#include "pair_eam_voterm.h"
#include "pair_eam_zxw.h"

#endif

#if defined(PAIRALL) || defined(MEAMCORSS)

#include "pair_eam_cross.h"
#include "pair_eam_cross_johnson.h"
#include "pair_eam_cross_zhou.h"
#include "pair_eam_cross_zhou2.h"
#include "pair_eam_cross_demk.h"
#include "pair_eam_cross_dai.h"
#include "pair_eam_cross_mishin.h"
#include "pair_eam_cross_ackland.h"
#include "pair_eam_cross_hijazi.h"
#include "pair_eam_cross_zhouPdAgH.h"
#include "pair_eam_cross_cubic.h"
#include "pair_eam_cross_ashwin.h"
#include "pair_eam_cross_morse.h"

#endif

#include "pair_sw.h"
#include "pair_meam.h"
#include "pair_tersoff.h"
