#ifdef MINIMIZE_CLASS
MinimizeStyle(sa/b, MinSAB)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_MIN_SAB_H
#define EAPOT_MIN_SAB_H

#include "min.h"

namespace EAPOT_NS {

	class MinSAB : public Min {
		friend class MiniStyle;
	public:
		MinSAB(class EAPOT *);
		~MinSAB();
		void init();
		void setup_style();
		void reset_vectors();

		/* Particle Swarm Optimization */
		int iterate(int);

	protected:

		double** X;
		double* dx;
		double* xi;			// current optimal solution vectors
		double* xi_opt;		// historical optimal solution vectors
		double* xi_new;		// temporary new solution vectors
		double* hi;			// Upper Bound
		double* lo;			// Lower bound
		double* len;		// boundry

		void Mu_Inv(int, double*, double);

	};

}

#endif
#endif
#endif
