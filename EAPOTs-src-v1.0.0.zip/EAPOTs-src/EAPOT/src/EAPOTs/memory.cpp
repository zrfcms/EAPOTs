#include "memory.h"
#include "malloc.h"

using namespace EAPOT_NS;


Memory::Memory(EAPOT *eapot) : Pointers(eapot)
{
}


Memory::~Memory()
{
}


void* Memory::smalloc(int nbytes, const char *name)
{
  if (nbytes == 0) return NULL;
  void *ptr = malloc(nbytes);
  if (ptr == NULL) {
    fprintf(stdout,"Failed to allocate %d bytes for array %s\n", nbytes, name);
  }
  //fprintf(stdout, "%d bytes for array %s\n", nbytes, name);
  return ptr;
}

/* ----------------------------------------------------------------------
   safe realloc
------------------------------------------------------------------------- */

void* Memory::srealloc(void *ptr, int nbytes, const char *name)
{

	if (ptr == NULL){
		ptr = smalloc(nbytes, name);
		return ptr;
	}
	if (nbytes == 0) {
		destroy(ptr);
		return NULL;
	}

	ptr = realloc(ptr, nbytes);
	if (ptr == NULL) {
		fprintf(stdout, "Failed to reallocate %d bytes for array %s\n", nbytes, name);
	}

	return ptr;
}

/* ----------------------------------------------------------------------
   safe free
------------------------------------------------------------------------- */

void Memory::sfree(void *ptr)
{
  if (ptr == NULL) return;

  free(ptr);
}

/* ----------------------------------------------------------------------
   erroneous usage of templated create/grow functions
------------------------------------------------------------------------- */

void  Memory::fail(const char *name)
{
  fprintf(stdout, "Cannot create/grow a vector/array of pointers for %s\n", name);
}
