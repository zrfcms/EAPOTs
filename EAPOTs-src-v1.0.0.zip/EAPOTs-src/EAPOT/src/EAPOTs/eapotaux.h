#ifndef EAPOT_AUX_H
#define EAPOT_AUX_H

#include <string>
#include <vector>
#include <cstring>
namespace EAPOT_NS {

	using namespace std;

	class EString {

	public:
		EString(int size = 32) {
			m_capacity = size;
			s = (char*)malloc(m_capacity * sizeof(char));
		}
		~EString() {
			free(s);
		}

		bool reserve(size_t n = 0) {

			if (n < m_capacity) return true;

			m_capacity *= 2;

			if (n > m_capacity) {
				m_capacity = n;
			}

			void* newdata = realloc(s, m_capacity * sizeof(char));

			if (newdata) { s = (char*)newdata; }
			else { return false; }

			return true;
		}

		bool resize(size_t n) {

			if (n < 0 || n >= m_capacity) {
				return false;
			}
			s[n] = '\0';

			return true;
		}

		size_t capacity() { return	m_capacity; };
		const char* c_str() { return s; };
		const char* data() { return s; };

		char* s;
	private:
		size_t m_capacity;
	};

	class MathAux {

	public:

		static bool inverse33(double* inv, double* mat);

		static void productN33(double* C, const int N, double* A, double* B);

		static inline double volum33(double* mat);

		static double* domain_inv_lammps(double* h_inv, double* h);

		static void lamda2x_lammps(double* h, int n, double** x);

		static void x2lamda_lammps(double* h_inv, int n, double** x);

	};

	class StrAux {
	public:

		static inline void reserve(string& str, size_t size) {
			size_t capacity = str.capacity();
			if (size + 16 < capacity) return;

			capacity *= 2;

			if (size + 16 > capacity) {
				capacity = size + 16;
			}

			str.reserve(capacity);
		}

		static inline bool find(size_t& res, string& buff, const string& Right, const size_t Off = 0, bool moveFlag = false) {
			res = buff.find(Right, Off);

			if (res == string::npos) return true;

			if (moveFlag) res += Right.size();

			return false;
		}

		static inline bool rfind(size_t& res, string& buff, const string& Right, const size_t Off = string::npos, bool moveFlag = false) {

			res = buff.rfind(Right, Off);

			if (res == string::npos) return true;

			if (moveFlag) res += Right.size();

			return false;
		}


		static inline bool find(size_t& res, string& buff, const char* Right, const size_t Off = 0, bool moveFlag = false) {
			res = buff.find(Right, Off);

			if (res == string::npos) return false;

			if (moveFlag) res += strlen(Right);

			return false;
		}

		static inline bool rfind(size_t& res, string& buff, const char* Right, const size_t Off = string::npos, bool moveFlag = false) {

			res = buff.rfind(Right, Off);

			if (res == string::npos) return true;

			if (moveFlag) res += strlen(Right);

			return false;
		}


		static inline bool find(size_t& res, string& buff, const char Right, const size_t Off = 0, bool moveFlag = false) {
			res = buff.find(Right, Off);

			if (res == string::npos) return false;

			if (moveFlag) res++;

			return false;
		}

		static inline bool rfind(size_t& res, string& buff, const char Right, const size_t Off = string::npos, bool moveFlag = false) {

			res = buff.rfind(Right, Off);

			if (res == string::npos) return true;

			if (moveFlag) res++;

			return false;
		}


		static inline bool find_first_of(size_t& res, string& buff, const char* const Ptr, const size_t Off = 0) {

			res = buff.find_first_of(Ptr, Off);

			if (res == string::npos) return true;

			return false;
		}

		static inline bool find_first_not_of(size_t& res, string& buff, const char* const Ptr, const size_t Off = 0) {

			res = buff.find_first_not_of(Ptr, Off);

			if (res == string::npos) return true;

			return false;
		}

		static void split(vector<string>& dest, const string& str, const string& delim) {

			if (str.empty()) return;

			dest.clear();

			// First convert the string to be cut from a string type to a character type
			char* strs = new char[str.length() + 1]; // add 1 at last 
			strcpy(strs, str.c_str());

			char* d = new char[delim.length() + 1];  // add 1 at last 
			strcpy(d, delim.c_str());

			char* p = strtok(strs, d);
			while (p) {
				dest.push_back(p);
				p = strtok(NULL, d);
			}

			delete[] strs;
			delete[] d;

		}

		static vector<string> split(const string& str, const string& delim) {

			vector<string> dest;

			split(dest, str, delim);

			return dest;
		}

		static string& replace_all(string& str, const string& old_value, const string& new_value)
		{
			if (old_value == new_value) return  str;

			const size_t old_value_length = old_value.length();

			while (true)
			{
				string::size_type pos(0);
				if ((pos = str.find(old_value)) != string::npos)
				{
					str.replace(pos, old_value_length, new_value);
				}
				else { break; }
			}
			return  str;
		}

		static string& replace_all_distinct(string& str, const string& old_value, const  string& new_value)
		{
			if (old_value == new_value) return  str;

			const size_t old_value_length = old_value.length();
			const size_t new_value_length = new_value.length();

			for (string::size_type pos(0); pos != string::npos; pos += new_value_length)
			{
				if ((pos = str.find(old_value, pos)) != string::npos)
				{
					str.replace(pos, old_value_length, new_value);
				}
				else { break; }
			}
			return  str;
		}
	};

}

#endif