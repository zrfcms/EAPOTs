#ifndef EAPOT_ERROR_H
#define EAPOT_ERROR_H

#include "pointers.h"
#include "errorcheck.h"

#ifdef EAPOT_EXCEPTIONS
#include "exceptions.h"
#endif

#define ERRORBUFFSIZE	1024
#define CHKLOGBUFFSIZE	128
#define ErrorAll(...) { sprintf(error->ErrCheckBuff, __VA_ARGS__); error->all(FLERR, error->ErrCheckBuff); }

#include <vector>

namespace EAPOT_NS {

	class CHKLOG : public ErrorCheck
	{
	public:
		CHKLOG()
			: ErrorCheck()
		{
			level = 0;
			title[0] = '\0';
			message[0] = '\0';
			ref_max = 0;
			ref_all = 0;
		}
		~CHKLOG() {  };

		void mergeRef(double max, double all) {
			ref_all += all;
			ref_max = MAX(max, ref_max);
		}

		int level;
		char title[CHKLOGBUFFSIZE];
		char message[CHKLOGBUFFSIZE];
		double ref_max;
		double ref_all;
	};

	class Error : protected Pointers {

	public:
		char ErrCheckBuff[ERRORBUFFSIZE];
		char ErrCheckBuff1[ERRORBUFFSIZE];
		char ErrCheckBuff2[ERRORBUFFSIZE];

		Error(class EAPOT *eapot);
		~Error();
		void all(const char *, int, const char *);
		void warning(const char *, int, const char *, int = 1);
		void message(const char *, int, const char *, int = 1);
		void done(int = 0); // 1 would be fully backwards compatible
		
		ErrorCheck chk;
		int selfCheckMode;

		bool check(const char* file, int line, const char*, const char*);

		void check(const char* file, int line, int iup, int* pchk, int* pref,
			int level, const char* title, const char* message);

		void check(const char* file, int line, int iup, double* pchk, double* pref,
			int level, const char* title, const char* message, 
			double cmax, double call, double pmax, double pall);

		void print_chklog(int start, int level);

		int add_chklog(int level, const char* title, const char* message);

	private:
		
		void add_reflog(const char* file, int line, int level, double smax, double sall);

		std::vector<CHKLOG> chklog;
		size_t log0, log1, log2;

#ifdef EAPOT_EXCEPTIONS
		char *    get_last_error() const;
		ErrorType get_last_error_type() const;
		void   set_last_error(const char * msg, ErrorType type = ERROR_NORMAL);

	private:
		char * last_error_message;
		ErrorType last_error_type;
#endif
	};
}

#endif

