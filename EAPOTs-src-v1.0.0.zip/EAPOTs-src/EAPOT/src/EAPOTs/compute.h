#ifndef EAPOT_COMPUTE_H
#define EAPOT_COMPUTE_H

#include "pointers.h"
#include <string>
#include <vector>

enum {
	SCALAR,
	VECTOR,
	VECTOR2D,
};

namespace EAPOT_NS {

	class Compute : protected Pointers
	{
	public:
		Compute(class EAPOT*, const char* id, const char* style, const char* file);
		int styleCheck(const char* file, int line, const char* style, int errorFlag);

		virtual void export_pair() {};

	public:
		void* vparam;					// computed result param
		std::vector<double> data;		// computed data

		int invokedFlag;				// non-zero if invoked or accessed this step, 0 if not

		std::string id;
		std::vector<const char*> styles;
		static int instance_total;		// # of Model classes ever instantiated
		int instance_me, index_me;		// which Model class instantiation I am, index in modify->compute

		virtual void init() {};
		virtual void compute() = 0;
		virtual void extracheck(int) {};

	};

}

#endif