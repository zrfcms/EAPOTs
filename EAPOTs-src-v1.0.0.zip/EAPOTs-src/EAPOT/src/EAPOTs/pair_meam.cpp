#include "pair_meam.h"

#include "error.h"
#include "input.h"
#include "output.h"
#include "force.h"
#include "modify.h"
#include "compute.h"
#include "dump_file.h"
#include "dump_image.h"
#include "image.h"
#include "update.h"

#include "option_comp.h"
#include "option_pair.h"
#include "compute_elastic.h"
#include "libLAMMPS/lammps_api.h"

using namespace EAPOT_NS;

const int   PairMEAM::nkeyCross = 22;
const char* PairMEAM::keySingle[] = {
		"lat", "z","iele", "atwt","alpha",
		"b0", "b1", "b2", "b3", "alat",
		"esub", "asub", "t0", "t1", "t2",
		"t3", "rho0", "ibar",
};
const char* PairMEAM::keyCross[] = {
		"Ec","alpha","rho0","delta","lattce",
		"attrac","repuls","nn2","Cmin","Cmax","rc","delr",
		"augt1","gsmooth_factor","re","ialloy",
		"mixture_ref_t","erose_form","zbl",
		"emb_lin_neg","bkgd_dyn", "theta" 
};
const char* PairMEAM::idx2Latc[] = {
	"fcc", "bcc", "hcp", "dim", "dia", "dia3", "b1", "c11", "l12", "b2", "ch4", "lin", "zig", "tri"
};

/*
elt	lat		z	iele	atwt	alpha	b0		b1		b2		b3		alat	esub	asub	t0		t1		t2		t3		rho0	ibar
'C'	'dia'	4	6		12.0111	4.38	4.1		4.2		5		3		3.567	7.37	1		1		5		9.34	-1		2.25	1
'C'	'dia'	4	6		12.0111	4.38	5.2		3.87	4		4.5		3.567	7.37	1.278	1		15		2.09	-6		2.5		1
'C'	'dia'	4	6		12.0111	4.38	4.5		4		3.5		4.8		3.567	7.37	1		1		10.5	1.54	-8.75	3.2		1
'C'	'dia'	4	6		12.0111	4.38	3.3		2.8		1.5		3.2		3.567	7.37	1		1		10.3	1.54	-8.8	2.5		1
'C'	'dia'	4	6		12.0111	4.38	4.6		3.45	4		4.2		3.567	7.37	1.061	1		15		1.74	-8		2.5		1
'C'	'dia'	4	6		12.0111	4.38	4.5		4		3.5		4.8		3.567	7.37	1		1		10.5	1.54	-8.75	3.2		1
								*		*		*		*		*						*				*		*		*
"4.38 4.1 4.2 5.0 3.0  1.0 5.0 9.34 -1.0"
"4 4 6 12.0111  3.567 7.37 1.0 2.25 1"
*/

PairMEAM::PairMEAM(EAPOT* eapot)
	: Pair(eapot)
	, lattce_s{0,}
	, ielt_meam{ 0, }
	, z{ 0, }, atwt{ 0, }
	
	, alpha_s{ 0, }
	, beta0_meam{0,}, beta1_meam{0,}
	, beta2_meam{0,}, beta3_meam{0,}
	, alat_s{ 0, }, Ec_s{ 0, }, A_meam{ 0, }
	
	, t0_meam{0,}, t1_meam{0,}
	, t2_meam{0,}, t3_meam{0,}
	, rho0_meam{0,}, ibar_meam{0,}

{
	styles.push_back("meam/first");
	cutmax = 4.0;
	secondFlag = 0;
	chkStyle = "meam";

	xlim.resize(3);
	ylim.resize(3);
	dump_sample.resize(3, 1.5);
	xlim[1].customlo = xlim[2].customlo = 1.5;
	xlim[0].customhi = 2.0;

	phir = phirar = phirar1 = phirar2 = phirar3 = phirar4 = phirar5 = phirar6 = NULL;

	neltypes = 0;
	for (int i = 0; i < maxelt; i++) {
		A_meam[i] = rho0_meam[i] = beta0_meam[i] =
		beta1_meam[i] = beta2_meam[i] = beta3_meam[i] =
		t0_meam[i] = t1_meam[i] = t2_meam[i] = t3_meam[i] =
		rho_ref_meam[i] = ibar_meam[i] = ielt_meam[i] = 0.0;

		for (int j = 0; j < maxelt; j++) {
			lattce_meam[i][j] = FCC;
			Ec_meam[i][j] = re_meam[i][j] = alpha_meam[i][j] = delta_meam[i][j] = ebound_meam[i][j] = attrac_meam[i][j] = repuls_meam[i][j] = 0.0;
			nn2_meam[i][j] = zbl_meam[i][j] = eltind[i][j] = 0;
		}
	}
};

#define SetTypeParam(p, i) {sprintf(buf, "%s_%d", p, i+1);paramName.push_back(buf);}

int PairMEAM::getPyParamNum() {
	int ntypes = force->get_ntypes();
	int pyDof = ntypes * MEAMNParam;
	pyDof += fextra.size() + cextra.size();

	char buf[64];
	paramName.clear();
	for (int i = 0; i < ntypes; i++) {
		for (int j = 0; j < MEAMNParam; j++) 
			SetTypeParam(keySingle[j], i);
	}
	for (auto& iparam : fextra) {
		paramName.push_back(iparam.name);
	}
	for (auto& iparam : cextra) {
		paramName.push_back(iparam.name);
	}

	return pyDof;
}

PairMEAM::~PairMEAM() {

}

void PairMEAM::fvec_allocate() {

	int ntypes = force->get_ntypes();
	add_fsize(ntypes * 9 + fextra.size());
	add_csize(ntypes * 9 + cextra.size());
	Pair::fvec_allocate();
}

inline void slice(double* dest, double* source, int lo1, int lo2, int num) {
	for (int i = 0; i < num; i++) {
		dest[i + lo1] = source[i + lo2];
	}
}

void PairMEAM::defaultDofMap(double* f, double* c) {
	int ntypes = force->get_ntypes();

	int m = 0, n = 0;
	double* p = paramVec.data();
	for (int i = 0; i < ntypes; i++) {
		slice(p, f, m +  4, n + 0, 5);
		slice(p, f, m + 11, n + 5, 1);
		slice(p, f, m + 13, n + 6, 3);

		slice(p, c, m +  0, n + 0, 4);
		slice(p, c, m +  9, n + 4, 2);
		slice(p, c, m + 12, n + 6, 1);
		slice(p, c, m + 16, n + 7, 2);

		m = m + 18;
		n = n + 9;
	}

	int nfextra = (int)fextra.size();	
	slice(p, f, m, n, nfextra);
	m += nfextra;

	int ncextra = (int)cextra.size();
	slice(p, c, m, n, ncextra);
	m += ncextra;
}

void PairStyle::addPairMEAMFreeParam(void* pPair, int num, const char** params)
{
	((Pair*)pPair)->styleCheck(FLERR, "meam/first", 1);
	auto pair = (PairMEAM*)pPair;

	if (pair->cextra.size() != 0) {
		error->all(FLERR, "add free extra parameters first");
	}

	for (int i = 0; i < num; i++) {
		pair->fextra.push_back(pair->get_extra_param(params[i]));
	}
	pair->fvec_clear();
	pair->fvec_allocate();
}

void PairStyle::addPairMEAMConstParam(void* pPair, int num, const char** params)
{
	((Pair*)pPair)->styleCheck(FLERR, "meam/first", 1);
	auto pair = (PairMEAM*)pPair;

	if (pair->cextra.size() != 0) {
		error->all(FLERR, "add free extra parameters first");
	}

	for (int i = 0; i < num; i++) {
		pair->cextra.push_back(pair->get_extra_param(params[i]));
	}
	pair->fvec_clear();
	pair->fvec_allocate();
}


PairMEAM::ExtraParam PairMEAM::get_extra_param(const char* arg) {
	ExtraParam iparam;

	int maxparams = 5;
	char line[256], * params[5];

	strcpy(line, arg);

	int nparams = 0;
	params[nparams++] = strtok(line, "=(), '\t\n\r\f");
	while (nparams < maxparams && (params[nparams++] = strtok(NULL, "=(), '\t\n\r\f")))
		continue;
	nparams--;

	for (iparam.which = 0; iparam.which < nkeyCross; iparam.which++)
		if (strcmp(params[0], keyCross[iparam.which]) == 0) break;
	if (iparam.which == nkeyCross) {
		ErrorAll("Keyword %s in MEAM parameter file not recognized", params[0]);
	}

	strcpy(iparam.name, arg);
	iparam.nindex = nparams - 1;
	for (int i = 0; i < iparam.nindex; i++)
		iparam.index[i] = atoi(params[i + 1]) - 1;

	iparam.value = 0;
	return iparam;
}

#define GetParam(i) paramVec[i]

void PairMEAM::setFreeParamsStyle() {

	int idx = 0, ntypes = force->get_ntypes();	
	
	for (int iele = 0; iele < ntypes; iele++) {
		lattce_s[iele] = (int)GetParam(idx++);
		z[iele] = GetParam(idx++);
		ielt_meam[iele] = (int)GetParam(idx++);
		atwt[iele] = GetParam(idx++);

		alpha_s[iele] = GetParam(idx++);
		beta0_meam[iele] = GetParam(idx++);
		beta1_meam[iele] = GetParam(idx++);
		beta2_meam[iele] = GetParam(idx++);
		beta3_meam[iele] = GetParam(idx++);

		alat_s[iele] = GetParam(idx++);
		Ec_s[iele] = GetParam(idx++);
		A_meam[iele] = GetParam(idx++);

		t0_meam[iele] = GetParam(idx++);		
		t1_meam[iele] = GetParam(idx++);
		t2_meam[iele] = GetParam(idx++);
		t3_meam[iele] = GetParam(idx++);

		rho0_meam[iele] = GetParam(idx++);
		ibar_meam[iele] = (int)GetParam(idx++);
	}

	for (auto& iparam : fextra) {
		iparam.value = GetParam(idx++);
	}
	for (auto& iparam : cextra) {
		iparam.value = GetParam(idx++);
	}
}

void PairMEAM::try_set_meam_extra(void* md, int which, double value, int nindex, int* index) {
	int errorflag = set_meam_extra(md, which, value, nindex, index);
	if (errorflag) {
		ErrorAll("MEAM library error Index %d\n"
			"which(%d) value(%f) nindex(%d)", errorflag, which, value, nindex);
	}
}

void PairMEAM::export_pair(void* md) {

	if (transByFileMode) {
		transByFile("temp/temp.library");
		std::string telt = force->eleLineFormat(" ");
		pair_coeff(md, "temp/temp.library", (telt + " temp/temp.meam " + telt).c_str());
	}
	else {
		set_meam_single(md, lattce_s, ielt_meam, atwt, alpha_s,
			beta0_meam, beta1_meam, beta2_meam, beta3_meam, alat_s, Ec_s, A_meam,
			t0_meam, t1_meam, t2_meam, t3_meam, rho0_meam, ibar_meam);

		for (auto& iparam : fextra) {
			try_set_meam_extra(md, iparam.which, iparam.value, iparam.nindex, iparam.index);
		}

		if (secondFlag) {
			int idx[3] = { 0,0,0 };
			int ntypes = force->get_ntypes();
			for (idx[0] = 0; idx[0] < ntypes; idx[0]++) {
				for (idx[1] = 0; idx[1] <= idx[0]; idx[1]++) {
					try_set_meam_extra(md, 7, 1.0, 2, idx);
				}
			}
		}

		for (auto& iparam : cextra) {
			try_set_meam_extra(md, iparam.which, iparam.value, iparam.nindex, iparam.index);
		}

		set_meam_setup(md, &cutmax);
	}
}

void PairMEAM::export_init(void* md) {

	std::string telt = force->eleLineFormat(" ");

	if (transByFileMode) {
		transByFile("temp/temp.library");
		pair_style(md, "meam");
		pair_coeff(md, "temp/temp.library", (telt + " temp/temp.meam " + telt).c_str());
	}
	else {
		pair_style(md, "meam/ex");
		pair_coeff(md, "NULL", (telt + " NULL " + telt).c_str());
	}
}

void PairMEAM::transByFile(const char* name) {
	const char* extra[] = { "temp/temp.meam" };
	DumpFile dump(eapot, "file", "file", name);
	dump.setFileExtra(1, extra);
	write(&dump);
}

#define DTAB FDBLFMTGTab

#define SafePrint dump->sbufChk(FLERR, off); off += sprintf

void PairMEAM::write(class DumpFile* dump) {

	FILE* fp;	
	char*& sbuf = dump->sbuf;
	int off, ntypes = force->get_ntypes();

	// --------------------------------- open --------------------------------- //
	dump->openfile(0);
	// ------------------------------------------------------------------------ //

	fp = dump->fp;
	fprintf(fp, "# %s at %s by EAPOT\n", dump->fileDump[0].c_str(), input->timestr);
	fprintf(fp, "# %d dof %d params:\n", get_fsize(), (int)paramVec.size());
	fprintf(fp, "# elt		lat		z		ielement	atwt    alpha\n");
	fprintf(fp, "# b0		b1		b2		b3\n");
	fprintf(fp, "# alat		esub	asub    t0\n");
	fprintf(fp, "# t1		t2		t3		rozero		ibar\n\n");

	off = 0;	
	for (int i = 0; i < ntypes; i++) {
		// 6 params
		SafePrint(&sbuf[off], "'%s'\t'%s'\t" DTAB "%d\t" DTAB DTAB "\n",
			force->get_elestr(i + 1), idx2Latc[lattce_s[i]], 
			z[i], ielt_meam[i], atwt[i], alpha_s[i]);

		// 4 params
		SafePrint(&sbuf[off], DTAB DTAB DTAB DTAB "\n",	
			beta0_meam[i], beta1_meam[i], beta2_meam[i], beta3_meam[i]);

		// 4 params
		SafePrint(&sbuf[off], DTAB DTAB DTAB DTAB "\n", 
			alat_s[i], Ec_s[i], A_meam[i], t0_meam[i]);

		// 5 params
		SafePrint(&sbuf[off], DTAB DTAB DTAB DTAB "%d\n\n",
			t1_meam[i], t2_meam[i], t3_meam[i], rho0_meam[i], ibar_meam[i]);
	}

	// ------------------------------- output --------------------------------- //
	dump->nsme = off;
	fwrite(dump->sbuf, sizeof(char), dump->nsme, fp);
	dump->closefile();
	// ------------------------------------------------------------------------ //


	if (dump->fileList.size() < 2) {
		error->all(FLERR, "MEAM pair_style need two dump files!");
	}
	if (dump->fileList[1] == "NULL") return;
	dump->singlefile_opened = 0;	// or next openfile will failed

	// --------------------------------- open --------------------------------- //
	dump->openfile(1);
	// ------------------------------------------------------------------------ //

	fp = dump->fp;
	fprintf(fp, "# %s at %s by EAPOT\n", dump->fileDump[1].c_str(), input->timestr);

	off = 0;
	for (auto& iparam : fextra) {
		if (iparam.which == 4) {
			SafePrint(&sbuf[off], "%s = '%s'\n", iparam.name, idx2Latc[(int)iparam.value]);
		}
		else {
			SafePrint(&sbuf[off], "%s = " FDBLFMTG "\n", iparam.name, iparam.value);
		}
	}

	if (secondFlag) {
		int idx[3] = { 0,0,0 };
		int ntypes = force->get_ntypes();
		for (idx[0] = 0; idx[0] < ntypes; idx[0]++) {
			for (idx[1] = 0; idx[1] <= idx[0]; idx[1]++) {
				SafePrint(&sbuf[off], "%s(%d,%d) = 1\n", "nn2", idx[0] + 1, idx[1] + 1);
			}
		}
	}

	for (auto& iparam : cextra) {
		if (iparam.which == 4) {
			SafePrint(&sbuf[off], "%s = '%s'\n", iparam.name, idx2Latc[(int)iparam.value]);
		}
		else {
			SafePrint(&sbuf[off], "%s = " FDBLFMTG "\n", iparam.name, iparam.value);
		}
	}

	// ------------------------------- output --------------------------------- //
	dump->nsme = off;
	fwrite(dump->sbuf, sizeof(char), dump->nsme, fp);
	dump->closefile();
	// ------------------------------------------------------------------------ //
}


double femb(double A, double E, double rho) {
	if (rho < 1e-10) return 0;
	return A * E * rho * log(rho);
}

double rho(double rho0, double beta, double re, double r) {
	return rho0 * exp(-beta * (r / re - 1));
}

#define PACK(N, CMD)						\
for (int ii = 0; ii < N; ii++){				\
	buf[m++] = CMD;							\
}	

int PairMEAM::image(class DumpImage* dumpimage)
{
	Image* image = dumpimage->image;
	if (image->axes.empty()) image->subplots(3, 1);
	size_t n = force->get_ntypes();
	auto eles = force->getEles();
	eles.erase(eles.begin());

	// params setup
	lattice_t lattce_meam[maxelt];
	for (int i = 0; i < n; i++) {
		lattce_meam[i] = (lattice_t)lattce_s[i];
	}

	meam_setup_global(n, lattce_meam, ielt_meam, atwt, alpha_s,
		beta0_meam, beta1_meam, beta2_meam, beta3_meam, alat_s, Ec_s, A_meam,
		t0_meam, t1_meam, t2_meam, t3_meam, rho0_meam, ibar_meam);

	int errorflag = 0;
	for (auto& iparam : fextra) {
		meam_setup_param(iparam.which, iparam.value, iparam.nindex, iparam.index, &errorflag);
	}
	if (secondFlag) {
		int idx[3] = { 0,0,0 };
		for (idx[0] = 0; idx[0] < n; idx[0]++) {
			for (idx[1] = 0; idx[1] <= idx[0]; idx[1]++) {
				meam_setup_param(7, 1.0, 2, idx, &errorflag);
			}
		}
	}
	for (auto& iparam : cextra) {
		meam_setup_param(iparam.which, iparam.value, iparam.nindex, iparam.index, &errorflag);
	}
	meam_setup_done(&cutmax);

	
	// 1. get number of points to draw and malloc memory
	int nr = image->axes[0].width;

	size_t n2 = n * n;
	double* buf = dumpimage->requestDbuf(nr * (n2 + 4*n + n2));

	// 2. get cutoff
	double Rhomax = 0, PhiMax = 0, PhiMin = 0, cut = 0;
	for (int i = 0; i < n; i++)
	for (int j = 0; j < n; j++) {

		double rho0 = rho0_meam[i], re = re_meam[i][i];
		Rhomax = fmax(Rhomax, rho(rho0, beta0_meam[i], re, dump_sample[1]));
		Rhomax = fmax(Rhomax, rho(rho0, beta1_meam[i], re, dump_sample[1]));
		Rhomax = fmax(Rhomax, rho(rho0, beta2_meam[i], re, dump_sample[1]));
		Rhomax = fmax(Rhomax, rho(rho0, beta3_meam[i], re, dump_sample[1]));

		double phi = phi_meam(dump_sample[2], i, j);
		PhiMax = fmax(PhiMax, phi);
		PhiMin = fmin(PhiMin, phi);
	}

	xlim[0].set(0.0, 2.0).update();
	xlim[1].set(0.0, cutmax).update();
	xlim[2].set(0.0, cutmax).update();

	// 3. pack image data
	double dR = (xlim[0].hi - xlim[0].lo) / nr;
	double dr = (xlim[1].hi - xlim[1].lo) / nr;
	double Rlo = xlim[0].lo, rlo = xlim[1].lo;

	int idx = 0, m = 0, off = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++) {
		PACK(nr, femb(A_meam[i], Ec_meam[i][j], Rlo + ii * dR));
		//PACK(nr, fabs(Rlo + ii * dR));
	}
	for (size_t i = 0; i < n; i++){
		double rho0 = rho0_meam[i], re = re_meam[i][i];
		PACK(nr, rho(rho0, beta0_meam[i], re, rlo + ii * dr));
		PACK(nr, rho(rho0, beta1_meam[i], re, rlo + ii * dr));
		PACK(nr, rho(rho0, beta2_meam[i], re, rlo + ii * dr));
		PACK(nr, rho(rho0, beta3_meam[i], re, rlo + ii * dr));
	}
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++) {
		PACK(nr, phi_meam(rlo + ii * dr, i, j));
	}

	// 4. evaluate the drawing range
	double lo = 0, hi = 0;

	off = 0;
	input->getRange(nr * n2, &buf[off], lo, hi);
	ylim[0].set(1.1*fmin(lo, 0), fmax(hi, 0)).update();

	off += n2 * nr;
	input->getRange(nr * 4*n, &buf[off], lo, hi);
	ylim[1].set(fmin(lo, 0), Rhomax).update();

	off += 4 * n * nr;
	input->getRange(nr * n2, &buf[off], lo, hi);
	ylim[2].set(fmin(PhiMin, 0), fmax(PhiMax, 0)).update();


	char label[32];
	Axes& Axes1 = image->axes[0].limit(xlim[0], ylim[0]);
	Axes& Axes2 = image->axes[1].limit(xlim[1], ylim[1]);
	Axes& Axes3 = image->axes[2].limit(xlim[1], ylim[2]);

	image->setColoru(0, 255, 0);							// set plot color as green
	PlotLine line = { 0.0, 0.0, 1.0, 0, 5, 5 };				// y = 0, x = [0 1], horizontal, (5, 5) for dotted line
	Axes1.line(line);

	idx = m = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++) {
		sprintf(label, "--%s/%s", eles[i], eles[j]);
		image->setColorRainbow((idx + 0.1) / n2);
		Axes1.plot(nr, &buf[m], label);
		m += nr; idx++;
	}
	idx = 0;
	for (size_t i = 0; i < n; i++)
	for (int t = 0; t < 4; t++) {
		sprintf(label, "--%s/%d", eles[i], t);
		image->setColorRainbow((idx + 0.1) / (4*n));
		Axes2.plot(nr, &buf[m], label);
		m += nr; idx++;
	}
	idx = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++) {
		sprintf(label, "--%s/%s", eles[i], eles[j]);
		image->setColorRainbow((idx + 0.1) / n2);
		Axes3.plot(nr, &buf[m], label);
		m += nr; idx++;
	}

	Axes1.legend(0.75, 0.75).xlabel = "emb(rho)";
	Axes2.legend(0.75, 0.75).xlabel = "rho(r)";
	Axes3.legend(0.75, 0.75).xlabel = "phi(r)";

	image->show();

	return 0;
};




void PairMEAM::extra_check(int type) {
	void* comp = NULL;
	const char *name = NULL;

	switch (type){
	case 0:
		name = "MEAM/fs";
		
		comp = modify->addCompute("diar", "energy", "../../res/struct/dia.lammps");
		comp = modify->addCompute("diaf", "energy", "../../res/struct/C.dia.lmp");
		compStyle->setComputeEnergyNoRelax(comp);
		comp = modify->addCompute("dia_el", "elastic", "diar");

		comp = modify->addCompute("cost", "term", "none");
		compStyle->setComputeExternalTitle(comp, "3.567 7.370 1054  126  562");

		compStyle->setComputeExternalScript(comp,
			"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
			"    v = EAPOT.parseCompute(nparam, style, param)\n"
			"    diar, diaf, Ela = v\n"
			"    Ec        = -diar.energy/8\n"
			"    a0        =  diar.xx\n"
			"    c_C11     =  1.0*(Ela.C[0,0]/1054 - 1.0)**2\n"
			"    c_C12     =  1.0*(Ela.C[0,1]/126  - 1.0)**2\n"
			"    c_C33     =  1.0*(Ela.C[3,3]/562  - 1.0)**2\n"

			"    res[0] = c_C11 + c_C12 + c_C33\n"
			"    sum = '%5.3f %5.3f %4.0f %4.0f %4.0f'%"
			"(a0, Ec, Ela.C[0,0], Ela.C[0,1], Ela.C[3,3])\n"
			"    return EAPOT.packMsg(sum)\n");
		break;

	case 1:
		name = "MEAM/fc";
	case 2:
		if (!name) name = "MEAM/fc(File)";

		comp = modify->addCompute("BN1", "energy", "../../res/struct/BN.13151.lammps");
		comp = modify->addCompute("BN2", "energy", "../../res/struct/BN.1639.lammps");
		comp = modify->addCompute("BN3", "energy", "../../res/struct/BN.2653.lammps");
		comp = modify->addCompute("BB1", "energy", "../../res/struct/BB.1055985.lammps");
		//comp = modify->addCompute("BB2", "energy", "../../res/struct/BB.1202723.lammps");
		comp = modify->addCompute("NN1", "energy", "../../res/struct/NN.1176403.lammps");

		comp = modify->addCompute("BN2_el", "elastic", "BN2");
		compStyle->setComputeElasticMethod(comp, "relax");
		compStyle->setComputeElasticHalfLoad(comp, 0);
		//comp = modify->addCompute("BN3_el", "elastic", "BN3");

		comp = modify->addCompute("cost", "term", "none");
		compStyle->setComputeExternalTitle(comp, "4.424 3.626 2.554 1.711 2.174  6.908 7.010 6.992 5.685 4.183   790  217  448");
		compStyle->setComputeExternalScript(comp,
			"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
			"    v = EAPOT.parseCompute(nparam, style, param)\n"
			"    BN1,BN2,BN3,BB1,NN1,BN2_el = v\n"
			//"    BB2	= v['BB2']\n"

			"    BN1x,BN1y,BN1z,BN1e = BN1.xx,BN1.yy,BN1.zz,-BN1.energy/8 \n"
			"    BN2x,BN2y,BN2z,BN2e = BN2.xx,BN2.yy,BN2.zz,-BN2.energy/8 \n"
			"    BN3x,BN3y,BN3z,BN3e = BN3.xx,BN3.yy,BN3.zz,-BN3.energy/8 \n"
			"    BB1x,BB1y,BB1z,BB1e = BB1.xx,BB1.yy,BB1.zz,-BB1.energy/2 \n"
			//"    BB2x,BB2y,BB2z,BB2e = BB2.xx,BB2.yy,BB2.zz,-BB2.energy/48\n"
			"    NN1x,NN1y,NN1z,NN1e = NN1.xx,NN1.yy,NN1.zz,-NN1.energy/4 \n"

			"    BN1c = (BN1x/4.424223-1)**2 + (BN1y/4.424223-1)**2 + (BN1z/2.550356-1)**2 + 100*(BN1e/6.907710625-1)**2\n"
			"    BN2c = (BN2x/3.626002-1)**2 + (BN2y/3.626002-1)**2 + (BN2z/3.626002-1)**2 + 100*(BN2e/7.009610625-1)**2\n"
			"    BN3c = (BN3x/2.55394 -1)**2 + (BN3y/4.423554-1)**2 + (BN3z/4.226855-1)**2 + 100*(BN3e/6.992210625-1)**2\n"
			"    BB1c = (BB1x/1.711288-1)**2 + (BB1y/2.964038-1)**2 + (BB1z/3.735796-1)**2 + 100*(BB1e/5.68478677 -1)**2\n"
			//"    BB2c = (BB2x/7.408562-1)**2 + (BB2y/7.408562-1)**2 + (BB2z/7.408562-1)**2 + 100*(BB2e/6.06838677 -1)**2\n"
			"    NN1c = (NN1x/2.17446 -1)**2                                               + 100*(NN1e/5.18293448 -1)**2\n"

			"    C = BN2_el.cubic\n"
			"    BN2C11,BN2C12,BN2C33 = C[0], C[1], C[2]\n"
			"    BN2Cc  = 1.0*(BN2C11/790 - 1.0)**2 + 1.0*(BN2C12/217 - 1.0)**2 + 1.0*(BN2C33/448 - 1.0)**2\n"

			"    res[0] = BN1c + BN2c + BN3c + BB1c + NN1c + BN2Cc\n"
			"    sum = '%5.3f %5.3f %5.3f %5.3f %5.3f %6.3f %5.3f %5.3f %5.3f %5.3f %5.0f %4.0f %4.0f'%"
			"(BN1x, BN2x, BN3x, BB1x, NN1x, BN1e, BN2e, BN3e, BB1e, NN1e, BN2C11, BN2C12, BN2C33)\n"
			"    return EAPOT.packMsg(sum)\n");
		break;
	case 100: {
		name = "MEAM/f-ElaRlx";
		comp = modify->addCompute("BN2", "energy", "../../res/struct/BN.1639.lammps");
		comp = modify->addCompute("BN2_el", "elastic", "BN2");
		compStyle->setComputeElasticMethod(comp, "relax");
		compStyle->setComputeElasticHalfLoad(comp, 0);

		const char* cost[] = {
			"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
			"    v = EAPOT.parseCompute(nparam, style, param)\n"
			"    BN2, C = v[0], v[1].cubic\n"

			"    BN2x,BN2y,BN2z,BN2e = BN2.xx,BN2.yy,BN2.zz,-BN2.energy/8\n"
			"    BN2c = (BN2x/3.626002-1)**2 + (BN2y/3.626002-1)**2 + (BN2z/3.626002-1)**2 + 1*(BN2e/7.009610625-1)**2\n"

			"    BN2C11,BN2C12,BN2C33 = C[0], C[1], C[2]\n"
			"    BN2Cc  = 10.0*(BN2C11/790 - 1.0)**2 + 10.0*(BN2C12/217 - 1.0)**2 + 10.0*(BN2C33/448 - 1.0)**2\n"

			"    res[0] = BN2c + BN2Cc\n"
			"    sum = '%5.3f %5.3f %15.10f %15.10f %15.10f'%(BN2x, BN2e, BN2C11, BN2C12, BN2C33)\n"
			"    return EAPOT.packMsg(sum)\n", "3.626 7.010   790  217  448" 
		};

		runMDCompute(12, 0, 4, cost, NULL, "nms", NULL);

		break;
	}
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}

	error->add_chklog(0, name, "");
	if (type != 100) {
		if (0) {
			runMDCompute(5, RunDump | RunEcho, 5, CDiaCost, DiaChk, "nms", "C.*.tersoff");
			return;
		}
		else {
			runMDCompute(-1, 0, 10, NULL, NULL, NULL, NULL);
		}
	}


	switch (type){
	case 0: {
		double BoxChk[4], BoxRef[4] = { 3.567, 7.370, 3.567, 7.370, };
		double ElaChk[3], ElaRef[3] = {	1081.36, 124.84, 1709.54 };		
		evalCompute(BoxChk, ElaChk, 2, 2, 1);

		error->check(FLERR, 4, BoxChk, BoxRef, 1, name, "Box", 5e-9, 5e-10, 1.8008620480278892e-10, 1.8118094194859026e-10);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 5e-5, 2e-5, 3.7280270668444095e-05, 3.9747460101194209e-05);
		break;
	}
	case 1:
	case 2:
	{
		double BoxChk[20], BoxRef[20] = {
			// data from LAMMPS
			4.74789476749745,   4.747894767497042,  2.891455512213784,  6.852856960597242,
			3.898269020561523,  3.898269020561523,  3.898269020561523,  6.999599999861438,
			2.7564924712019048, 4.774385010834349,  4.50133330380227,   6.999599999861395,
			2.0248194722209227, 3.50709019380344,   1.8819577443101971, 6.37272375778642,
			2.491102148696978,  2.911062594717698,  2.976307916352861,  5.186153437290354
		}, ElaChk[3], ElaRef[3] = {
			// data from LAMMPS
			445.4752875913666, 234.89518940628324, 141.1544776871264
			// 445.4754435, 234.8954184, 518.1791469,			Ela calculated with unrelaxed
		};

		double* chk, * calc;
		int Natom[] = { 8, 8, 8, 2, 4 };		
		for (int i = 0; i < 5; i++) {
			chk = &BoxChk[4 * i];
			calc = modify->compute[i]->data.data();
			set_vector3(chk, calc);
			chk[3] = -calc[6] / Natom[i];
		}
		ComputeElastic::reduceElasticConstant3(ElaChk, (ComputeElastic*)modify->compute[5]);

		error->check(FLERR, 20, BoxChk, BoxRef, 1, name, "Box", 6e-8, 3e-8, 5.0571330817626361e-08, 3.0108472108950514e-07);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 5e-5, 2e-5, 3.1271391889896808e-05, 3.1965000918191416e-05);
		break;
	}
	case 100: {
		double BoxChk[2], BoxRef[2] = { 3.74199136, 6.58419807 };
		double ElaChk[3], ElaRef[3] = {	649.6086, 161.0668, 320.1295 };		
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, 2, BoxChk, BoxRef, 1, name, "Box", 5e-9, 5e-10, 7.1170965486213539e-10, 8.920113584572009e-10);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 5e-5, 2e-5, 4.4149051182403193e-06, 5.2266574166128588e-06);
		break;
	}
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}
};



PairMEAM2nd::PairMEAM2nd(EAPOT* eapot)
	: PairMEAM(eapot)
{
	styles.push_back("meam/second");
	secondFlag = 1;
}

void PairMEAM2nd::extra_check(int) {

	addMDComputeBcc();

#define NBox 2
#define NEla 3
	{
		const char* name = "MEAM-Fe/ss";
		error->add_chklog(0, name, "");
		runMDCompute(-1, RunDump | RunEcho, 10, NbBccCost, BccChk, NULL, NULL);

		// data from LAMMPS
		double BoxChk[NBox], BoxRef[NBox] = { 2.851000030984237, 4.289999945844356 };
		double ElaChk[NEla], ElaRef[NEla] = { 265.7755227107696, 127.30030941851346, 126.07992677895773 };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, NBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 7.5700121913307628e-10, 7.5700204727147341e-10);
		error->check(FLERR, NEla, ElaChk, ElaRef, 1, name, "Ela", 2e-6, 2e-6, 1.5002223129717354e-06, 2.9237376463332719e-06);
	}

	secondFlag = 0;
	{
		const char* name = "MEAM-Fe/fs";
		error->add_chklog(0, name, "");
		runMDCompute(-1, RunDump | RunEcho, 10, NbBccCost, BccChk, NULL, NULL);

		double BoxChk[NBox], BoxRef[NBox] = { 2.86064623216178, 5.085133749318171, };
		double ElaChk[NEla], ElaRef[NEla] = { 297.7867198069851, 184.30905174573866, 154.67959158877974 };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, NBox, BoxChk, BoxRef, 1, name, "Box", 5e-8, 2e-8, 6.6396675340923444e-10, 6.6396745205628172e-10);
		error->check(FLERR, NEla, ElaChk, ElaRef, 1, name, "Ela", 4e-6, 2e-6, 2.2552792473619885e-06, 4.4442649611082603e-06);
	}
#undef NBox
#undef NEla

}