#ifdef PAIR_CLASS
PairStyle(eam/zxwe, PairEAMZXWe)
PairStyle(eam/zhou, PairEAMZXW)
#else

#ifdef LIBAPI
LIBAPI(void, setPairEAMZXWRhoAxisLattice, (APITYPE void* pPair, int axis, double a0), (APINAME pPair, axis, a0));
LIBAPI(void, setPairEAMZXWRhoStructure, (APITYPE void* pPair, const char* pfile), (APINAME pPair, pfile));
LIBAPI(void, setPairEAMZXWScreenFile, (APITYPE void* pPair, const char* pfile), (APINAME pPair, pfile));
LIBAPI(void, setPairEAMZXWLogFile, (APITYPE void* pPair, const char* pfile), (APINAME pPair, pfile));
#else

#ifndef EAPOT_PAIR_EAM_ZXW_H
#define EAPOT_PAIR_EAM_ZXW_H

#include "pair_eam.h"
#include <string>
#include <vector>

using namespace std;

namespace EAPOT_NS {

	class PairEAMZXWe : public PairEAM
	{
	public:
		PairEAMZXWe(EAPOT *eapot);
		~PairEAMZXWe();

		double emb(int type, double);
		double rho(int itype, int jtype, double);
		double phi(int itype, int jtype, double);

		virtual void setFullParamsStyle();				// set initial parameter
		virtual void setFreeParamsStyle();				// alter parameter and create and calculate embedding energy interpolation coefficient
		virtual void extra_check(int);

		void write_style(class DumpFile* dump);
		void back_image(class DumpImage* dumpimage, void* paxesf, void* paxesr, void* paxesp);
		void getFnParams();									// Coefficient of the first half

	protected:
		double A, B, fe;
		double alpha, beta, kappa, lambd;
		double lre;

		int nn;
		double re, c1, c2;
		double Fn0, Fn1, Fn2, Fn3;
		double F0, F1, F2, F3;
		double Fe, eta, lrs;

	protected:
		virtual void function_check();
		virtual void testrun(int type);
	};

	class PairEAMZXW : public PairEAMZXWe
	{
		friend class PairStyle;
	public:
		PairEAMZXW(EAPOT* eapot);
		~PairEAMZXW();

		void setFreeParamsStyle();
		void extra_check(int);
		void init_style();

		double getLrs(double t);
		void getEta(double plrs, double &eta1, double &eta2);
		void getFemb2(double& pf0, double& pf1);
		void getFemb3(double& pf0, double& pf1);
		inline bool etaAccept(double v) {
			return (v <= etahi) && (v >= etalo);
		}

	protected:
		int axis;
		double a0;
		double rho2, f0, f1;
		double etalo, etahi;

		std::vector<double> rlist;
		std::string slog, screen, structure;

	protected:
		virtual void function_check();
		virtual void testrun(int type);
	};

}

#endif
#endif
#endif