#include "pair_eam_voterm.h"
#include "libLAMMPS/lammps_api.h"

#include <algorithm>
#include "Eigen/Dense"
#include "memory.h"
#include "error.h"

#include "option_pair.h"

using namespace EAPOT_NS;

PairEAMVoterm::PairEAMVoterm(EAPOT* eapot)
	: PairEAM(eapot)
	, log("none")
	, screen("none")
	, buff("")
	, structure("")
{
	styles.push_back("eam/voter");
	DM = aM = RM = rc = 0;
	b = s1 = u1 = RA = 0;
	s2 = u2 = RB = 0;
	a0 = Ec = B = v0 = roseCof = 0;

	NN = 20;
	rcn = u12 = 0;
	phicr = phidr = rhocr = rhodr = 0;

	eam_fsize = 8;
	eam_csize = 3;

	axis = 0;
	cof = NULL;
	pB = NULL;
	pA = NULL;
}

PairEAMVoterm::~PairEAMVoterm() {
	if (cof) memory->destroy(cof);
	if (pB) delete (Eigen::MatrixXd*)pB;
	if (pA) delete (Eigen::VectorXd*)pA;
}


double PairEAMVoterm::emb(int type, double lr) {

	if (!cof)return 0;

	int idx;
	int nSample = static_cast<int>(sample.size());
	for (idx = nSample - 2; idx > 0; idx--) {
		if (lr >= sample[idx].rho) break;
	}

	double *cofi = cof[idx];
	double dx = lr - sample[idx].rho;
	return ((cofi[0] * dx + cofi[1]) * dx + cofi[2]) * dx + cofi[3];
}


double PairEAMVoterm::rho(int itype, int jtype, double r) {
	if (r >= rc || r >= cutmax) return 0;
	return smooth(r, rhoc(r), rhocr, rhodr);
}

double PairEAMVoterm::phi(int itype, int jtype, double r) {

	if (r >= rc || r >= cutmax) return 0;

	double iphic = phic(r);
	double iphis = smooth(r, iphic, phicr, phidr);
	return iphis;
}

void PairEAMVoterm::setFullParamsStyle() {

	int idx = eam_fsize;
	a0 = paramVec[idx++];
	Ec = paramVec[idx++];
	B = paramVec[idx++];
	setFreeParamsStyle();
}

void PairEAMVoterm::setFreeParamsStyle() {

	int idx = 0;
	DM = paramVec[idx++];
	aM = paramVec[idx++];
	RM = paramVec[idx++];
	rc = paramVec[idx++];
	b =  paramVec[idx++];
	s1 = paramVec[idx++];
	u1 = paramVec[idx++];
	RA = paramVec[idx++];

	u12 = u1 * u1;
	rcn = rc / NN;

	phicr = phic(rc);
	phidr = phid(rc);
	rhocr = rhoc(rc);
	rhodr = rhod(rc);

	if (!sample.size() || !rlist.size()) return;

	// 1. get Cohensive Energy by Rose function
	double rhot, phit, sx, Et;
	const double eV = 1.6021765E-19 * 1E21;
	roseCof = sqrt((9 * v0 * B) / (Ec * eV));

	for (size_t ai = 0; ai < sample.size(); ai++) {
		rhot = phit = 0.0;
		auto& rlisti = rlist[ai];
		for (double r : rlisti) {
			rhot += rho(1, 1, r);
			phit += phi(1, 1, r);
		}

		sx = (rose_a0[ai] / a0 - 1) * roseCof;
		Et = -Ec * (1 + sx) * exp(-sx);

		sample[ai].rho = rhot;
		sample[ai].femb = Et - 0.5 * phit;
	}
	sort(sample.begin(), sample.end(), sampleCmp);

	// 2. prepare Spline Matrix
	const size_t N = sample.size() - 1;
	vector<double> x(N + 1, 0), y(N + 1, 0), h(N, 0);	
	for (size_t ai = 0; ai < N + 1; ai++) {
		x[ai] = sample[ai].rho;
		y[ai] = sample[ai].femb;
	}
	for (size_t ai = 0; ai < N; ai++) {
		h[ai] = x[ai + 1] - x[ai];
	}

	//Eigen::VectorXd B = Eigen::VectorXd::Zero(N + 1);
	//Eigen::MatrixXd A = Eigen::MatrixXd::Zero(N + 1, N + 1);
	Eigen::MatrixXd& A = *(Eigen::MatrixXd*)pA;
	Eigen::VectorXd& B = *(Eigen::VectorXd*)pB;
	for (size_t i = 1; i < N; i++) {
		A(i, i - 1) = h[i - 1];
		A(i, i) = 2 * (h[i - 1] + h[i]);
		A(i, i + 1) = h[i];
		B(i) = 6 * ((y[i+1] - y[i]) / h[i] - (y[i] - y[i-1]) / h[i - 1]);
	}
	B(0) = B(N) = 0;

	A(0, 0) = -h[1]; 
	A(0, 1) = h[0] + h[1]; 
	A(0, 2) = -h[0];

	A(N, N - 2) = -h[N - 1]; 
	A(N, N - 1) = h[N - 2] + h[N - 1];
	A(N, N - 0) = -h[N - 2];

	// 3. get interpolation coefficient
	Eigen::VectorXd m = A.lu().solve(B);  // Stable and fast. #include <Eigen/LU>
	for (size_t i = 0; i < N; i++) {
		double* cofi = cof[i];
		cofi[3] = y[i];
		cofi[2] = (y[i + 1] - y[i]) / h[i] - m[i] * h[i] / 2;
		cofi[2] -= (m[i + 1] - m[i]) * h[i] / 6;
		cofi[1] = m[i] / 2;
		cofi[0] = (m[i + 1] - m[i]) / h[i] / 6;
	}

	PairEAM::setFreeParamsStyle();
}

void PairStyle::setPairEAMVotermRoseSampleRange(void* pPair, double begin, double end, int nSample) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/voter", 1);
	auto pair = (PairEAMVoterm*)pPair;

	if (begin <= 0.1 || end <= begin) {
		error->all(FLERR, "Illegal PairEAMVoterm sample range");
	}
	if (nSample <= 3) {
		error->all(FLERR, "too less sample points");
	}

	size_t old = pair->rose_a0.size();
	pair->rose_a0.reserve(old + nSample);
	pair->sample.resize(old + nSample, { 0.0,0.0, });
	double delta = (end - begin) / nSample;

	for (int ai = 0; ai < nSample; ai++) {
		pair->rose_a0.push_back(begin + delta * ai);
	}
}

void PairStyle::setPairEAMVotermRoseSamplePoint(void* pPair, int nSample, double* point) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/voter", 1);
	auto pair = (PairEAMVoterm*)pPair;

	size_t old = pair->rose_a0.size();
	pair->rose_a0.reserve(old + nSample);
	pair->sample.resize(old + nSample, { 0.0,0.0, });

	for (int ai = 0; ai < nSample; ai++) {
		pair->rose_a0.push_back(point[ai]);
	}
}

void PairStyle::setPairEAMVotermRoseAxis(void* pPair, int axis) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/voter", 1);
	auto pair = (PairEAMVoterm*)pPair;
	pair->axis = axis;

	if (axis > 2 || axis < 0) {
		error->all(FLERR, "Illegal setPairEAMVotermRoseAxis sample axis: axis > 2 || axis < 0");
	}
}

void PairStyle::setPairEAMVotermRoseStructure(void* pPair, const char* pfile) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/voter", 1);
	auto pair = (PairEAMVoterm*)pPair;
	pair->structure = pfile;
}

void PairStyle::setPairEAMVotermScreenFile(void* pPair, const char* pfile) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/voter", 1);
	auto pair = (PairEAMVoterm*)pPair;
	pair->screen = pfile;
}

void PairStyle::setPairEAMVotermLogFile(void* pPair, const char* pfile) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/voter", 1);
	auto pair = (PairEAMVoterm*)pPair;
	pair->log = pfile;
}

void PairEAMVoterm::init_style()
{

	PairEAM::init_style();

	void* md = NULL;
	md_open_echo(screen.c_str(), log.c_str(), &md);
	md_set_callback(md, EAPOTcallback, eapot);

	double mcutforce = m_dump.cut;
	double mcutforcesq = mcutforce * mcutforce;

	// 1.head md.run
	set_echo(md, "none");
	set_newton(md, 0, 0);
	if (structure.empty()) error->all(FLERR, "reference structure is not set!");
	read_data(md, structure.c_str());
	neighbor_setup(md, mcutforce);
	//bool triclinic = is_triclinic(md);

	double ratio[6], lat[6], ref;
	const size_t N = sample.size() - 1;
	pB = new Eigen::VectorXd(N + 1);
	pA = new Eigen::MatrixXd(N + 1, N + 1);
	for (size_t i = 0; i < N + 1; i++) {
		(*(Eigen::VectorXd*)pB)(i) = 0.0;
		for (size_t j = 0; j < N + 1; j++) {
			(*(Eigen::MatrixXd*)pA)(i, j) = 0.0;
		}
	}

	// 2. memory alloc and define domain
	
	if(cof) memory->destroy(cof);
	memory->create(cof, sample.size(), 4, "PairEAMVoterm::cof");
	temp_memset0(cof[0], sample.size() * 4);
	
	double* boxhi = get_boxhi(md);
	double* boxlo = get_boxlo(md);
	double* tilt = get_tilt(md);

	minu_vector3(ratio, boxhi, boxlo);
	ref = ratio[axis];
	selfdivi_vector3(ratio, ref);
	ratio[3] = tilt[0] / ref;
	ratio[4] = tilt[1] / ref;
	ratio[5] = tilt[2] / ref;
	v0 = a0 * a0 * a0 * ratio[0] * ratio[1] * ratio[2] / get_atomnum(md);
	
	// 3. update rlist
	rlist.clear();
	for (size_t ai = 0; ai < sample.size(); ai++) {

		ref = rose_a0[ai];

		// 3.1 change box
		mult_vector6(lat, ratio, ref);

		// 3.2 update neighbor list
		change_box(md, lat);
		neighbor_build(md, 1);		

		// 3.3 get radial distribution
		double* x, rsq, xi[3], xj[3];
		int i, j, jj, jnum, * jlist;

		x = get_atomx1d(md);
		i = get_ilist(md)[0];		
		load_vector3(xi, x, i);
		jnum = get_numneigh(md)[i];
		jlist = get_firstneigh(md)[i];

		rlist.push_back(move(vector<double>()));
		auto& rlisti = rlist[ai];
		rlisti.reserve(jnum);

		for (jj = 0; jj < jnum; jj++) {
			j = jlist[jj];
			load_vector3(xj, x, j);
			rsq = dis2_vector3(xi, xj);
			if (rsq < mcutforcesq) {
				rlisti.push_back(sqrt(rsq));
			}
		}
	}
	md_close(md);
}

void PairEAMVoterm::extra_check(int) {

	addMDComputeFcc();
	runMDCompute(-1, RunDump | RunEcho, 10, CuFccCost, FccChk, "nms", "dump.*.eam");
	function_check();
	testrun(0);
}



double PairEAMVoterCu::rhoc(double r) {
	double tanhr2 = tanh((r * r) * 2.0E+1);
	double r6 = r * r * r * r * r * r;
	double expb2r = exp(b * r * -2.0);
	double expbr = exp(-b * r);
	double RAr = RA - r;
	double RAr2 = RAr * RAr;
	double RArh = RAr + 1.0 / 2.0;
	double RArh2 = RArh * RArh;
	double RAr2u12 = RAr2 * u12 * (-1.0 / 2.0);
	double expRArh2u12 = exp(RArh2 * u12 * (-1.0 / 2.0));
	double expbrexpb2r = expbr + expb2r * 5.12E+2;
	double RAu1 = RA * u1;

	double res =
		tanhr2 * (expbrexpb2r * r6 + (expRArh2u12 * s1) / 10 + (s1 * exp(RAr2u12
		)) / RAu1);

	return res;
}

double PairEAMVoterCu::rhod(double r) {
	double tanhr2 = tanh((r * r) * 2.0E+1);
	double tanhr22 = tanhr2 * tanhr2 - 1.0;
	double r6 = r * r * r * r * r * r;
	double r5 = r * r * r * r * r;
	double expb2r = exp(b * r * -2.0);
	double expbr = exp(-b * r);
	double RAr = RA - r;
	double RAr2 = RAr * RAr;
	double RArh = RAr + 1.0 / 2.0;
	double RArh2 = RArh * RArh;
	double RAr2u12 = RAr2 * u12 * (-1.0 / 2.0);
	double expRArh2u12 = exp(RArh2 * u12 * (-1.0 / 2.0));
	double expbrexpb2r = expbr + expb2r * 5.12E+2;
	double RAu1 = RA * u1;

	double res =
		tanhr2 * (6 * expbrexpb2r * r5 - r6 * (b * expbr + 1024 * b * expb2r) + (expRArh2u12
			* s1 * u12 * (2 * RAr + 1)) / 20 + (RAr * s1 * u1 * exp(RAr2u12)) / RA) - 40
		* r * tanhr22 * (expbrexpb2r * r6 + (expRArh2u12 * s1) / 10 + (s1 * exp(RAr2u12
		)) / RAu1);

	return res;
}

void PairEAMVoterCu::function_check() {

	const char* name = "EAMVoter1";
	error->add_chklog(0, name, "");
	const double G = -2.26532371697967923;
	//double f = df(1, 1, &t);

#define N 9
#define NS 30

	// 1. check by data from matlab
	double rhoSampleEval[NS], rhoSampleRef[NS] = {
		0.02579673361751788, 0.03224984919758344, 0.03993955255835006, 0.04903194476358528, 0.059706496789612,
		0.07224230195852459, 0.08687663643434657, 0.1038311447787681, 0.1233503466281363, 0.1457013647742744,
		0.1711741482975183, 0.2000816680300024, 0.2328910623413701, 0.2706049578848363, 0.313827532645429,
		0.3632758814174439, 0.4198719011650749, 0.4850323208642651, 0.5605186562515649, 0.648256016157165,
		0.751221361493957, 0.8735907869975251, 1.02006075862837, 1.197351013418608, 1.415191446627517,
		1.688301264145648, 2.034464305200506, 2.479859458869158, 3.060079852358272, 3.822088845590091
	};

	double fembSampleEval[NS], fembSampleRef[NS] = {
		0.2549252861372444, 0.2983363927155098, 0.3460282939770381, 0.3984462379451024, 0.4563155307763673,
		0.524081495097668, 0.6033141124270291, 0.694462241128238, 0.7985757350393079, 0.9172612929406881,
		1.052688421192434, 1.207639196669543, 1.391071102751193, 1.630058562102712, 1.928322230729328,
		2.291102502001027, 2.727999107532137, 3.263194922477789, 3.92297673527526, 4.727720516886141,
		5.725596579548495, 6.98019758994869, 8.534420692692835, 10.45880517149588, 12.86598799441168,
		15.9282814476202, 19.75159555506875, 24.54788212404688, 30.56968899733161, 38.10737084334831
	};


	for (size_t i = 0; i < sample.size(); i++) {
		rhoSampleEval[i] = sample[i].rho;
		fembSampleEval[i] = sample[i].femb + G * sample[i].rho;
	}

	error->check(FLERR, NS, rhoSampleEval, rhoSampleRef, 1, name, "rs", 
		1e-14, 5e-15, 1.921005758617978e-15, 2.2499536907908258e-14);
	error->check(FLERR, NS, fembSampleEval, fembSampleRef, 1, name, "fs", 
		1e-14, 5e-15, 5.3960007059600879e-15, 4.5722021108955552e-14);


	double cofRef[] = {
		   575.4904177278526,    -48.9816917099692, 9.284597924682718, 0.3133632386216146,
		   575.4904177278523,   -37.84057316751507, 8.724323814505247, 0.3713927409718136,
			 112.01119660371,   -24.56452136964252, 8.244447149313908, 0.4365043096330249,
		   795.4287803127928,    -21.5091721769466, 7.825527057244503, 0.5095194653076897,
		  -106.9128596772564,    3.963365518397059, 7.638233431229211, 0.5915700740116464,
		   -32.1072794280886, -0.05735081849907422, 7.687198470494041, 0.6877336950935213,
		   4.678332186595565,   -1.466956817277054, 7.664891242708043, 0.8001178173931753,
		   10.58111129238325,   -1.229000350990224, 7.619182614402453,  0.929673395956732,
		   11.44916459646885,  -0.6093958096702501, 7.583298588663418,  1.078004200753689,
		   7.115766426225703,   0.1583056472911447, 7.573216264258538,   1.24732205016016,
			12.1097024971028,   0.7020807806227871, 7.595132701483126,  1.440453279064599,
		   123.1690268146784,    1.752265172291317, 7.666081755547333,  1.660888944590762,
		  -70.26832054457508,    13.87556867542196, 8.178821518489498,  1.918644749745691,
		  -8.417896903059058,    5.925292372323261,  8.92558912371485,  2.243066391131519,
		  -11.35776094581491,    4.833762837664965, 9.390623191881909,  2.639243183472233,
		   6.656182986969822,     3.14889526411149, 9.785352453826304,   3.11403997198266,
		   -1.35024048521043,    4.279035655434659, 10.20574377883298,  3.679144883334729,
		  -7.640883694081455,    4.015088945301209,  10.7461924188543,  4.361950142433306,
		   1.989315623561481,     2.28474201774086, 11.22174357181379,  5.192732941091511,
		-0.09997966474389318,    2.808353920231601, 11.66859836315743,  6.196230244961729,
		  -4.389475382117522,    2.777470598110566, 12.24374471367925,  7.427356146442521,
		 -0.9590229298700796,    1.166057855795237, 12.72631202504068,  8.959163518669127,
		 -0.5866992676957933,   0.7446536718010353, 13.00617388828244,  10.84518852197397,
		  0.1349845008628762,   0.4326054838359368, 13.21489046393945,   13.1711928197427,
		  -1.163993515427914,    0.520820730269309, 13.42258524345287,  16.07185474252378,
		  0.1118282477488873,  -0.4328734395031065, 13.44660451198524,  19.75283034269611,
		-0.06103215107360532,  -0.3167410205533339, 13.18711569087341,  24.36031579698804,
		 0.01859057007320457,  -0.3982912934718045, 12.86864376349013,  30.16556657099957,
		 0.01859057007320459,  -0.3659314098226193, 12.42522616587133,  37.50176046273048,
	};

	int nSample = static_cast<int>(sample.size());
	error->check(FLERR, 4 * (nSample - 1), cof[0], cofRef, 1, name, "cof",
		3e-10, 1e-11, 2.1577228520686507e-10, 6.5186736999535881e-10);

	// data from EAM potential
	double fembRef[N] = {
		0.1827469870009458E+01, 0.4247061796136549E+01, 0.7192046732091582E+01,
		0.1039606904773421E+02, 0.1363853967952146E+02, 0.1683076603826043E+02,
		0.1906232803717724E+02, 0.1906232803717724E+02, 0.1906232803717724E+02,
	};
	double fembRefm[N] = {
		2.4905662158276649,  5.5906747694688494,  9.2140166280852736,
		13.0931027801393185, 17.0689801050503966, 21.0780345364061681,
		25.0261963040920747, 28.9138981049037866, 32.7347227236195337
	};
	double rhoRef[N] = {
		0.4315760043619850E+00, 0.3804187195751977E+00, 0.1224523764819136E+00,
		0.5887005950879715E-01, 0.2966211882004967E-01, 0.1275818301633744E-01,
		0.4406229084068084E-02, 0.1123093283719450E-02, 0.1518595272782996E-03,
	};
	double phiRef[N] = {
		0.4196849590097926E+02, 0.8926051331218680E+01, -0.2568810724625330E+01,
		-0.3383793158530749E+01, -0.2196108389325990E+01, -0.1195566763276068E+01,
		-0.5887956024988049E+00, -0.2455901848322714E+00, -0.5808093536738109E-01,
	};

	double x, rhoEval[N], phiEval[N], fembEval[N], fembEvalm[N];
	for (int i = 0; i < N; i++) {
		x = 0.1281429334268537 * 5 * (i + 1.0);
		rhoEval[i] = rho(1, 1, x);
		phiEval[i] = phi(1, 1, x) - G * 2 * rhoEval[i];
		phiEval[i] *= x;
		x = 0.5957203073046090E-01 * 5 * (i + 1.0);
		fembEvalm[i] = emb(1, x);
		fembEval[i] = fembEvalm[i] + G * x;
	}

	error->check(FLERR, N - 2, rhoEval, rhoRef, 1, name, "r", 
		8e-4, 2e-4, 0.00063481744710590013, 0.0010236467358593036);
	error->check(FLERR, N - 2, phiEval, phiRef, 1, name, "p", 
		1e-4, 2e-5, 8.1773586504587197e-05, 0.00011185006302280608);
	error->check(FLERR, N - 4, fembEval, fembRef, 1, name, "f", 
		1e-2, 5e-3, 0.0063767533379405546, 0.012425397272904702);
	error->check(FLERR, N, fembEvalm, fembRefm, 1, name, "fm", 
		5e-14, 5e-15, 3.5383562560799057e-15, 1.121520332855409e-14);

#undef N
#undef NS
}

void PairEAMVoterCu::testrun(int type) {

	const char* name = "EAMVoter1";
	error->add_chklog(0, name, "");

#define N 5
	double checkRef[N] = {
		3.615287030156296,	3.539260633747839,
		158.6723048881383,	111.3496293660487,	75.42345190988472,
	};
	double paperRef[N] = {
		3.61500374562475,	3.54000091900477,
		173.007388175352,	125.381931669611,	78.8334886985359,
	};

	addMDCheckCubic(FLERR, 0, name, "Box", &checkRef[0], 5.0876650569478421e-09, 5.0876655588483865e-09);
	addMDCheckCubic(FLERR, 1, name, "Ela",	  &checkRef[2], 3.1621888856074092e-05, 6.0788601258928687e-05);
	addMDCheckCubic(FLERR, 0, name, "Box", &paperRef[0], 0.00020912007478823681, 0.00028748871417299258);
	addMDCheckCubic(FLERR, 1, name, "Ela",	  &paperRef[2], 0.11188838001734584, 0.23797535057046817);

#undef N
}


PairEAMVoterCu::PairEAMVoterCu(EAPOT* eapot) :
	PairEAMVoterm(eapot) {
	styles.push_back("eam/voter1");
};

PairEAMVoterNi11::PairEAMVoterNi11(EAPOT* eapot) :
	PairEAMVoterm(eapot) 
{
	styles.push_back("eam/voter2");
	eam_fsize = 11;
};


void PairEAMVoterNi11::setFreeParamsStyle() {

	s2 = paramVec[8];
	u2 = paramVec[9];
	RB = paramVec[10];

	PairEAMVoterm::setFreeParamsStyle();
}


double PairEAMVoterNi11::rhoc(double r) {
	double tanhr2 = tanh((r * r) * 2.0E+1);
	double r6 = r * r * r * r * r * r;
	double expb2r = exp(b * r * -2.0);
	double expbr = exp(-b * r);
	double RBr = RB - r;
	double RBr2 = RBr * RBr;
	double RAr = RA - r;
	double RAr2 = RAr * RAr;
	double RArh = RAr + 1.0 / 2.0;
	double RArh2 = RArh * RArh;
	double RAr2u12 = RAr2 * u12 * (-1.0 / 2.0);
	double expRArh2u12 = exp(RArh2 * u12 * (-1.0 / 2.0));
	double expRBr2u2 = exp(RBr2 * u2 * (-1.0 / 2.0));
	double expbrexpb2r = expbr + expb2r * 5.12E+2;
	double RAu1 = RA * u1;
	double RAh = RA + 1.0 / 2.0;

	double res =
		tanhr2 * (expbrexpb2r * r6 + expRBr2u2 * s2 + (s1 * exp(RAr2u12)) / RAu1
		- (expRArh2u12 * s1) / (10 * RAh * u1));

	return res;
}

double PairEAMVoterNi11::rhod(double r) {
	double tanhr2 = tanh((r*r)*2.0E+1);
    double tanhr22 = tanhr2*tanhr2-1.0;
    double r6 = r*r*r*r*r*r;
    double r5 = r*r*r*r*r;
    double expb2r = exp(b*r*-2.0);
    double expbr = exp(-b*r);
    double RBr = RB-r;
    double RBr2 = RBr*RBr;
    double RAr = RA-r;
    double RAr2 = RAr*RAr;
    double RArh = RAr+1.0/2.0;
    double RArh2 = RArh*RArh;
    double RAr2u12 = RAr2*u12*(-1.0/2.0);
    double expRArh2u12 = exp(RArh2*u12*(-1.0/2.0));
    double expRBr2u2 = exp(RBr2*u2*(-1.0/2.0));
    double expbrexpb2r = expbr+expb2r*5.12E+2;
    double RAu1 = RA*u1;
    double RAh = RA+1.0/2.0;
    
    double res = 
    	tanhr2*(6*expbrexpb2r*r5 - r6*(b*expbr + 1024*b*expb2r) + RBr
    	*expRBr2u2*s2*u2 + (RAr*s1*u1*exp(RAr2u12))/RA - (expRArh2u12
    	*s1*u1*(2*RAr + 1))/(20*RAh)) - 40*r*tanhr22*(expbrexpb2r*r6 
    	+ expRBr2u2*s2 + (s1*exp(RAr2u12))/RAu1 - (expRArh2u12*s1)/
    	(10*RAh*u1));
    
    return res;
}

void PairEAMVoterNi11::function_check() {

	const char* name = "EAMVoter2";
	error->add_chklog(0, name, "");

#define N 9
	// data from Matlab
	double rhoRef[N] = {
		6.92413262810624763e-01, 7.29373237680219333e-01, 2.33348017412155190e-01,
		1.42291960787565425e-01, 7.39133722399757526e-02, 2.84226455278913902e-02,
		7.91629176586831212e-03, 1.55870668134393221e-03, 1.84453332857963771e-04,
	};
	double phiRef[N] = {
		 6.04098230752363250e+01,  1.25405003822467283e+01, -3.32019703304473879e+00, 
		-4.85108280156825877e+00, -3.30885726048398521e+00, -1.83829270458028304e+00, 
		-9.03181019773286131e-01, -3.78433591761185295e-01, -1.01971449715597129e-01, 
	};

	double x, rhoEval[N], phiEval[N];
	for (int i = 0; i < N; i++) {
		x = 0.1281429334268537 * 5 * (i + 1.0);
		rhoEval[i] = rho(1, 1, x);
		phiEval[i] = phi(1, 1, x);
		phiEval[i] *= x;
	}

	error->check(FLERR, N, rhoEval, rhoRef, 1, name, "r", 8e-14, 2e-14, 2.191333426410833e-15, 4.3740922945866278e-15);
	error->check(FLERR, N, phiEval, phiRef, 1, name, "p", 1e-14, 2e-15, 8.6046551048281441e-16, 2.9951479442615175e-15);

#undef N
}

void PairEAMVoterNi11::testrun(int type) {

	const char* name = "EAMVoter2";
	error->add_chklog(0, name, "");

#define N 5
	double checkRef[N] = {
		3.5127624280734877, 4.452045373677837, 
		256.7317385120328, 155.22434121646182, 129.48455941454506
	};
	double paperRef[N] = {
		3.5200003347020794, 4.449999997532053, 
		247.02218002232266, 147.99473778445474, 125.52159552658998
	};

	addMDCheckCubic(FLERR, 0, name, "Box", &checkRef[0], 3.7344453234779443e-08, 3.734447418217019e-08);
	addMDCheckCubic(FLERR, 1, name, "Ela", &checkRef[2], 2.9080369681098083e-06, 6.5373650484735445e-06);
	addMDCheckCubic(FLERR, 0, name, "Box", &paperRef[0], 0.0020562605461787596, 0.0025158956353947865);
	addMDCheckCubic(FLERR, 1, name, "Ela", &paperRef[2], 0.048853282068280969, 0.11973561482520265);

#undef N
}


PairEAMVoterNi8::PairEAMVoterNi8(EAPOT* eapot) :
	PairEAMVoterNi11(eapot)
{
	styles.push_back("eam/voter3");
	eam_fsize = 8;
	eam_csize = 6;
};

void PairEAMVoterNi8::setFullParamsStyle() {

	int idx = eam_fsize;
	s2 = paramVec[idx++];
	u2 = paramVec[idx++];
	RB = paramVec[idx++];

	a0 = paramVec[idx++];
	Ec = paramVec[idx++];
	B = paramVec[idx++];

	setFreeParamsStyle();
}


void PairEAMVoterNi8::setFreeParamsStyle() {
	PairEAMVoterm::setFreeParamsStyle();
}

