#include "eapot_math.h"
#include "math.h"
#include <stdlib.h>

double eqdist(){
	return (double)rand() / RAND_MAX;
}

double normdist()
{
	static int have_number = 0;
	static double nd2 = 0.0;
	double x1 = 0.0;
	double x2 = 0.0;
	double sqr = 0.0;

	if (!have_number) {
		do {
			x1 = 2.0 * eqdist() - 1.0;
			x2 = 2.0 * eqdist() - 1.0;
			sqr = x1 * x1 + x2 * x2;
		} while (sqr >= 1.0 || sqr == 0);
		// Box Muller Transformation
		double cnst = sqrt(-2.0 * log(sqr) / sqr);
		nd2 = x2 * cnst;
		have_number = 1;
		return x1 * cnst;
	}
	else {
		have_number = 0;
		return nd2;
	}
}

double dis2(double* u, double* v, const int n){
	double sum = 0.0;
	double t;
	for (int i = 0; i < n; i++){
		t = u[i] - v[i];
		sum += t*t;
	}
	return sum;
}

double norm2(double* p, const int n){
	double t = 0.0;
	for (int i = 0; i < n; i++){
		t += p[i] * p[i];
	}
	return t;
}


double norm(double* p, const int n){
	double t = 0.0;
	for (int i = 0; i < n; i++){
		t += p[i] * p[i];
	}
	return sqrt(t);
}

double normalize(double* p, const int n){
	double t = norm(p, n);
	for (int i = 0; i < n; i++){
		p[i] /= t;
	}
	return t;
}

