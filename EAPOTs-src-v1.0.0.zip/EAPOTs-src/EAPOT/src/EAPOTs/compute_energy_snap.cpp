#include "compute_energy.h"
#include "libLAMMPS/lammps_api.h"
#include "error.h"
#include "input.h"

using namespace EAPOT_NS;

#define MAXLINE 256
#define CHUNK 1024

void ComputeEnergy::snapAndReferenceMemCreate(tagint num) {
	
	refNum = num;
	snap_malloc(md);		// for reload
	snap_malloc(md);		// for save relax status 

	
	permute.resize((size_t)refNum, 0);
	current.resize((size_t)refNum, 0);

	refTag.resize((size_t)refNum + 1, 0);
	atomRelaxMode.resize(((size_t)refNum + 1) * 3);

	refEnergyValue.resize((size_t)refNum + 1);
	refForceValue.resize(((size_t)refNum + 1) * 3);
	refVirialValue.resize(((size_t)refNum + 1) * 6);

	refEnergyWeight.resize((size_t)refNum + 1);
	refForceWeight.resize(((size_t)refNum + 1) * 3);
	refVirialWeight.resize(((size_t)refNum + 1) * 6);

	temp_memset0(refEnergyValue.data(), refNum);
	temp_memset0(refForceValue.data(), refNum * 3);
	temp_memset0(refVirialValue.data(), refNum * 6);

	temp_memset(refEnergyWeight.data(), refNum, 1.0);
	temp_memset(refForceWeight.data(), refNum * 3, 1.0);
	temp_memset(refVirialWeight.data(), refNum * 6, 1.0);
}

void ComputeEnergy::snapAndReferenceMemDestroy() {
	if(md) snap_free(md);
}

/**************************************************************************************************************************
														|
read_ref												|
														|
________________________________________________________|__________________________________________________________________
														|
memory->destroy/create(xxx, refNum)						| create memory for:
														| load, refTag, refEnergy/Force/Virial, weightEnergy/Force/Virial
														|
fref = input->open(file, "r");							| open reference file
________________________________________________________|__________________________________________________________________
														|
LOOP <while (nread < refNum)>:							| Read data from all atoms
________________________________________________________|__________________________________________________________________
|														|
| input->read_lines_from_file(nchunk, buffer);			| Read #nchunk lines using input, by fgets() with loop
|														| for (int i = 0; i < nlines; i++):
|														|	if (!fgets(&buf[m], maxline, fp))
|														|
| if (!data_ref_initFlag) data_ref_init(buffer);		|
|	1. count Data number in each line					| nwords = input->count_words(buf);
|	2. eval Data offset for energy/force/virial 		| eptr = 0; fptr = 2; vptr = 8;
|	   for reference file in each line					|
|	3. Determine whether there is an atomic tag 		| if (nwords % 2) refTagFlag = 1
|		based on the number of columns					|
|														|
| data_ref(nread, nchunk, buffer);						|
|	1. loop over lines of atom data						| if (eptr >= 0):
|	   tokenize the line into values					|  	weightEnergy[idx] = atof(values[eptr]);
|	2. string to data by atof based on 	eptr/fptr/vptr	|  	refEnergy[idx] = atof(values[eptr + 1]);
________________________________________________________|__________________________________________________________________
														|
sort_setup()											|
	1. Calculate upper and lower limits for tag			| need refTag have been set ready first
	2. allocate Tag2Idx Mapping list					| 
														|
**************************************************************************************************************************/

void ComputeEnergy::setupRefWeightValue(tagint num, tagint* tag) {

	refContainTag = 0;
	refContainRelax = 0;
	refContainEnergy = 0;
	refContainForce = 0;
	refContainVirial = 0;

	if (refWeightValueFile == "NULL") {
		temp_memcpy(refTag.data(), tag, refNum);
	}
	else {
		int nwords = 0, nread = 0;
		int nchunk, eof, initFlag = 0;
		char* buffer = new char[CHUNK * MAXLINE];

		// open file 
		FILE* fref = input->open(refWeightValueFile.c_str(), "r");

		char* ceof = fgets(buffer, MAXLINE, fref);
		if (ceof == NULL) error->all(FLERR, "Unexpected head of data file");
		string head = buffer;				// file head information

		// Read all data
		while (nread < refNum) {
			nchunk = MIN(refNum - nread, CHUNK);
			eof = input->read_lines_from_file(fref, nchunk, MAXLINE, buffer);
			if (eof) error->all(FLERR, "Unexpected end of data file");

			if (!initFlag) {
				nwords = parseRefWeightValueFile(buffer, head);
				if (!refContainTag) temp_memcpy(refTag.data(), tag, refNum);
				initFlag = 1;
			}
			readRefWeightValueFile(nwords, nread, nchunk, buffer);
			nread += nchunk;
		}

		// close file
		fclose(fref);
	}

	// Check if the atom ID of two files are consistent
	tagint iTag, jTag;
	for (tagint i = 0; i < refNum; i++) {
		iTag = refTag[i];
		
		for (tagint j = 0; j < refNum; j++) {
			jTag = tag[j];
			if (iTag == tag[j]) {
				break;
			}
		}
		if (iTag != jTag) {
			ErrorAll("The atomic ids of the two files are inconsistent: %s %s", 
				refWeightValueFile.c_str(), modelName.c_str());
		}
	}

	tagmin = refTag[0];
	tagmax = refTag[0];

	for (tagint i = 1; i < refNum; i++) {
		if (refTag[i] < tagmin) tagmin = refTag[i];
		if (refTag[i] > tagmax) tagmax = refTag[i];
	}

	Tag2Idx.resize((size_t)tagmax - tagmin + 1);
}


#define ParseCostKeyWords(index)													\
	key = head.find_first_not_of(tab, head.find_first_of(tab, key));				\
																					\
	if (head.compare(key, 4, "norm") == 0) cost_mode[index] = 0;					\
	else if (head.compare(key, 3, "abs") == 0) cost_mode[index] = 1;				\
	else error->all(FLERR, "Illegal MDFitSet cost_eng keywords in reference file");


int ComputeEnergy::parseRefWeightValueFile(char* buf, string &head) {

	// parse keywords in first line
	if (head.find("id") != string::npos) {
		refContainTag = 1;
	}
	if (head.find("dynamics") != string::npos) {
		refContainRelax = 1;
	}
	if (head.find("energy") != string::npos) {
		refContainEnergy = 1;
	}
	if (head.find("force") != string::npos) {
		refContainForce = 1;
	}
	if (head.find("virial") != string::npos) {
		refContainVirial = 1;
	}
	// parse cost mode keywords in first line
	size_t key;
	const char* tab = " \t";

	key = head.find("cost_eng");
	if (key != string::npos) {
		ParseCostKeyWords(0);
	}

	key = head.find("cost_force");
	if (key != string::npos) {
		ParseCostKeyWords(1);
		ParseCostKeyWords(2);
		ParseCostKeyWords(3);
	}

	key = head.find("cost_virial");
	if (key != string::npos) {
		ParseCostKeyWords(4);
		ParseCostKeyWords(5);
		ParseCostKeyWords(6);
		ParseCostKeyWords(7);
		ParseCostKeyWords(8);
		ParseCostKeyWords(9);
	}

	// count total key words
	char* next = strchr(buf, '\n');
	*next = '\0';
	int nwords = input->count_words(buf);
	*next = '\n';

	return nwords;
}

/* ----------------------------------------------------------------------
   unpack N lines from Atom section of data file
   call style-specific routine to parse line
------------------------------------------------------------------------- */

void ComputeEnergy::readRefWeightValueFile(int nwords, int start, int n, char* buf)
{
	size_t idx;
	int m, ival;
	char* next, * values[NRefAtomKey];

	// loop over lines of atom data
	// tokenize the line into values

	for (size_t i = 0; i < n; i++) {
		next = strchr(buf, '\n');

		values[0] = strtok(buf, " \t\n\r\f");
		if (values[0] == NULL) {
			error->all(FLERR, "Incorrect atom format in reference file"); return;
		}
		for (m = 1; m < nwords; m++) {
			values[m] = strtok(NULL, " \t\n\r\f");
			if (values[m] == NULL) {
				error->all(FLERR, "Incorrect atom format in reference file"); return;
			}
		}

		ival = 0;
		idx = i + start;		
		

		if (refContainTag) {
			refTag[idx] = atoi(values[ival++]);
		}

		if (refContainRelax) {
			const char* key;
			refTag[idx + 0] = 1;
			refTag[idx + 1] = 1;
			refTag[idx + 2] = 1;

			key = values[ival++];
			if (strcmp(key, "f") == 0 || strcmp(key, "F") == 0) {
				refTag[idx + 0] = 0;
			}
			key = values[ival++];
			if (strcmp(key, "f") == 0 || strcmp(key, "F") == 0) {
				refTag[idx + 1] = 0;
			}
			key = values[ival++];
			if (strcmp(key, "f") == 0 || strcmp(key, "F") == 0) {
				refTag[idx + 2] = 0;
			}
		}

		if (refContainEnergy) {
			refEnergyWeight[idx] = atof(values[ival++]);
			refEnergyValue[idx] = atof(values[ival++]);
		}

		if (refContainForce) {
			refForceWeight[idx * 3 + 0] = atof(values[ival++]);
			refForceWeight[idx * 3 + 1] = atof(values[ival++]);
			refForceWeight[idx * 3 + 2] = atof(values[ival++]);

			refForceValue[idx * 3 + 0] = atof(values[ival++]);
			refForceValue[idx * 3 + 1] = atof(values[ival++]);
			refForceValue[idx * 3 + 2] = atof(values[ival++]);
		}

		if (refContainVirial) {
			refVirialWeight[idx * 6 + 0] = atof(values[ival++]);
			refVirialWeight[idx * 6 + 1] = atof(values[ival++]);
			refVirialWeight[idx * 6 + 2] = atof(values[ival++]);
			refVirialWeight[idx * 6 + 3] = atof(values[ival++]);
			refVirialWeight[idx * 6 + 4] = atof(values[ival++]);
			refVirialWeight[idx * 6 + 5] = atof(values[ival++]);

			refVirialValue[idx * 6 + 0] = atof(values[ival++]);
			refVirialValue[idx * 6 + 1] = atof(values[ival++]);
			refVirialValue[idx * 6 + 2] = atof(values[ival++]);
			refVirialValue[idx * 6 + 3] = atof(values[ival++]);
			refVirialValue[idx * 6 + 4] = atof(values[ival++]);
			refVirialValue[idx * 6 + 5] = atof(values[ival++]);
		}

		buf = next + 1;
	}
}


/* ----------------------------------------------------------------------
   copy reference data of atom I to atom J
------------------------------------------------------------------------- */

void ComputeEnergy::copy_ref(int i, int j)
{
	int* atomRelaxModei = &atomRelaxMode[(size_t)i * 3];
	int* atomRelaxModej = &atomRelaxMode[(size_t)j * 3];

	double* refForceValuei = &refForceValue[(size_t)i * 3];
	double* refForceValuej = &refForceValue[(size_t)j * 3];
	double* refForceWeighti = &refForceWeight[(size_t)i * 3];
	double* refForceWeightj = &refForceWeight[(size_t)j * 3];

	double* refVirialValuei = &refVirialValue[(size_t)i * 6];
	double* refVirialValuej = &refVirialValue[(size_t)j * 6];
	double* refVirialWeighti = &refVirialWeight[(size_t)i * 6];
	double* refVirialWeightj = &refVirialWeight[(size_t)j * 6];

	refTag[j] = refTag[i];
	set_vector3(atomRelaxModej, atomRelaxModei);

	refEnergyValue[j] = refEnergyValue[i];
	set_vector3(refForceValuej, refForceValuei);
	set_vector3(refVirialValuej, refVirialValuei);

	refEnergyWeight[j] = refEnergyWeight[i];
	set_vector3(refForceWeightj, refForceWeighti);
	set_vector6(refVirialWeightj, refVirialWeighti);
} 

/* ----------------------------------------------------------------------
   determind if sort needed: if refTag[i]!=idx[i]
------------------------------------------------------------------------- */

bool ComputeEnergy::sortIsEqual(tagint num, tagint* tag, tagint* tagAim) {
	for (tagint i = 1; i < num; i++) {
		if (tag[i] != tagAim[i])return false;
	}
	return true;
}



/**************************************************************************************************************************
														|
sort													|
														|
________________________________________________________|__________________________________________________________________
														|
1. eval Tag2Idx Mapping list							| Tag2Idx[tagAim[i] - tagmin] = i;
														|
2. prepare permute sequence								| permute[i] = Tag2Idx[refTag[i] - tagmin];
														|
3. current permutation									| current[i] = i;
________________________________________________________|__________________________________________________________________
														|
reorder atom list, when done, current = permute			|
														|
**************************************************************************************************************************/

void ComputeEnergy::sort(tagint* tagAim, int idx) {

	for (tagint i = 0; i < refNum; i++) {
		Tag2Idx[(size_t)refTag[i] - tagmin] = i;
	}

	// prepare permute sequence
	for (tagint i = 0; i < refNum; i++) {
		permute[i] = Tag2Idx[(size_t)tagAim[i] - tagmin];
	}

	// current = current permutation
	// current[I] = J means Ith current atom is Jth old atom
	for (tagint i = 0; i < refNum; i++) {
		current[i] = i;
	}

	// reorder atom list, when done, current = permute
	// perform "in place" using copy() to extra atom location at end of list
	// inner while loop processes one cycle of the permutation
	// copy before inner-loop moves an atom to end of atom list
	// copy after inner-loop moves atom at end of list back into list
	// empty = location in atom list that is currently empty

	tagint empty;
	for (tagint i = 0; i < refNum; i++) {
		if (current[i] == permute[i]) continue;
		copy_ref(i, refNum);
		empty = i;
		while (permute[empty] != i) {
			copy_ref(permute[empty], empty);
			empty = current[empty] = permute[empty];
		}
		copy_ref(refNum, empty);
		current[empty] = permute[empty];
	}

}

// 0. weight * (cal/ref - 1)^2	normal   mode
// 1. weight * (cal - ref)^2	absolute mode

// if ues absolute value or ref is illegal

#define COMPUTE_COST(idx) 							\
 	m++;											\
	w = weight[m];	if (!w)	continue;				\
	iref = ref[m];	ical = cal[m];					\
													\
	if (mode[idx] || !iref)	t = ical - iref;		\
	else					t = ical / iref - 1;	\
													\
	sum += w * t * t;		total++;


double ComputeEnergy::computeCostTemplate(double* cal, CostTarget type) {

	int* mode;
	tagint total = 0;

	double iref, ical;
	double w, t, sum = 0;

	double* ref, * weight;

	int m = -1;
	switch (type) {
	case CostTarget::ENERGY:

		mode = &cost_mode[0];		
		ref = refEnergyValue.data();
		weight = refEnergyWeight.data();

		for (tagint i = 0; i < refNum; i++) {
			COMPUTE_COST(0);
		}
		break;

	case CostTarget::FORCE:

		mode = &cost_mode[1];
		ref = refForceValue.data();
		weight = refForceWeight.data();

		if (useMaxForceFlag) {
			int imax = 0;
			double* iforce, inorm;
			double maxForce = norm2_vector3(cal);

			for (tagint i = 0; i < refNum; i++) {
				iforce = &cal[i * 3];
				inorm = norm2_vector3(iforce);
				if (inorm > maxForce) {
					maxForce = inorm;
					imax = i;					
				}
			}

			m = imax * 3 - 1;
			for (tagint i = imax; i < imax + 1; i++) {
				COMPUTE_COST(0);
				COMPUTE_COST(1);
				COMPUTE_COST(2);
			}
			break;
		}

		for (tagint i = 0; i < refNum; i++) {
			COMPUTE_COST(0);
			COMPUTE_COST(1);
			COMPUTE_COST(2);
		}
		break;

	case CostTarget::VIRIAL:

		mode = &cost_mode[4];
		ref = refVirialValue.data();
		weight = refVirialWeight.data();

		for (tagint i = 0; i < refNum; i++) {
			COMPUTE_COST(0);
			COMPUTE_COST(1);
			COMPUTE_COST(2);
			COMPUTE_COST(3);
			COMPUTE_COST(4);
			COMPUTE_COST(5);
		}
		break;

	default:
		break;
	}

	if (total) sum /= total;

	return sum;
}
