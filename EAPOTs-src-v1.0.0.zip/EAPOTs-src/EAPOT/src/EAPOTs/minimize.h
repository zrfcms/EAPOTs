#ifdef COMMAND_CLASS

CommandStyle(minimize, Minimize)

#else

#ifndef EAPOT_MINIMIZE_H
#define EAPOT_MINIMIZE_H

#include "pointers.h"

namespace EAPOT_NS {

	class Minimize : protected Pointers {
	public:
		Minimize(class EAPOT *);
		void command(void* cost, double etol, double ftol, int nstep, int neval);
	};

}

#endif
#endif
