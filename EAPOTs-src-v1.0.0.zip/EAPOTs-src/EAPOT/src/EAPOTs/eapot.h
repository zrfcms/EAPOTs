#ifndef EAPOT_EAPOT_H
#define EAPOT_EAPOT_H

#include <stdio.h>
#include <string>
#include "time.h"

void EAPOTcallback(void*, const char*, int, const char*, const char*);
typedef void (*PythonCallback)(void*, const char*, int, const char*);

namespace EAPOT_NS {

	class EAPOT
	{
	public:
		class Memory *memory;
		class Error* error;
		class Input* input;

		class Update* update;
		class Force* force;
		class Modify* modify;
		class Output* output;

		class PairStyle* pairStyle;
		class DumpStyle* dumpStyle;
		class CompStyle* compStyle;
		class MiniStyle* miniStyle;

		FILE *infile;                  // infile
		FILE *screen;                  // screen output
		FILE *logfile;                 // logfile
		
		void* caller;
		int once_initFlag;
		PythonCallback pythonCallback;

		EAPOT(int narg, char** argv);
		~EAPOT();

		void init();
		void create();
		void destroy();
		void once_init();
		void check(int mode, int);

	private:
		void help();

	public: //API
		void clear();
		
	};
}

#endif

