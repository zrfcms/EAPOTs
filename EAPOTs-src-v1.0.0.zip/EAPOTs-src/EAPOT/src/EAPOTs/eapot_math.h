#ifndef EAPOT_MATH_H
#define EAPOT_MATH_H

#include "string.h"
#include "math.h"

#define VECLOOP for(int i = 0; i < n; i++)
#define ROWLOOP for(int i = 0; i < m; i++)
#define COLLOOP for(int j = 0; j < n; j++)
#define KLOOP for(int k = 0; k < p; k++)

#define	ij	i*n+j
#define	ik	i*p+k
#define	kj	k*n+j

extern double eqdist();

extern double normdist();

extern double dis2(double*, double*, const int);

extern double norm2(double*, const int);

extern double norm(double*, const int);

extern double normalize(double*, const int);

inline double math_norm(double* a, const int n){
	double sum = 0;
	VECLOOP
		sum += a[i] * a[i];
	return sqrt(sum);
}

inline double math_norm2(double* a, const int n){
	double sum = 0;
	VECLOOP
		sum += a[i] * a[i];
	return sum;
}

inline double math_sum(double* a, const int n){
	double sum = 0;
	VECLOOP
		sum += a[i];
	return sum;
}

inline int math_sum(int* a, const int n) {
	int sum = 0;
	VECLOOP
		sum += a[i];
	return sum;
}

inline void math_sum_row(double* s, double** a, const int m, const int n){
	memset(s, 0, m * sizeof(double));
	ROWLOOP	COLLOOP
		s[i] += a[i][j];
}

inline void math_sum_col(double* s, double** a, const int m, const int n){
	memset(s, 0, n * sizeof(double));
	ROWLOOP	COLLOOP
		s[j] += a[i][j];
}

inline double math_dot(double* a, double* b, const int n){
	double sum = 0;
	VECLOOP	sum += a[i] * b[i];
	return sum;
}


inline void math_add(double* a, double b, const int n){			VECLOOP		a[i] += b; }

inline void math_sub(double* a, double b, const int n){			VECLOOP		a[i] -= b; }

inline void math_product(double* a, double b, const int n){		VECLOOP		a[i] *= b; }

inline void math_divided(double* a, double b, const int n){		VECLOOP		a[i] /= b; }


inline void math_add(double* a, double* b, const int n){		VECLOOP		a[i] += b[i]; }

inline void math_sub(double* a, double* b, const int n){		VECLOOP		a[i] -= b[i]; }

inline void math_product(double* a, double* b, const int n){	VECLOOP		a[i] *= b[i]; }

inline void math_divided(double* a, double* b, const int n){	VECLOOP		a[i] /= b[i]; }


inline void math_add(double* c, double* a, double b, const int n){		VECLOOP		c[i] = a[i] + b; }

inline void math_sub(double* c, double* a, double b, const int n){		VECLOOP		c[i] = a[i] - b; }

inline void math_product(double* c, double* a, double b, const int n){	VECLOOP		c[i] = a[i] * b; }

inline void math_divided(double* c, double* a, double b, const int n){	VECLOOP		c[i] = a[i] / b; }


inline void math_add(double* c, double* a, double* b, const int n){		VECLOOP		c[i] = a[i] + b[i]; }

inline void math_sub(double* c, double* a, double* b, const int n){		VECLOOP		c[i] = a[i] - b[i]; }

inline void math_product(double* c, double* a, double* b, const int n){ VECLOOP		c[i] = a[i] * b[i]; }

inline void math_divided(double* c, double* a, double* b, const int n){ VECLOOP		c[i] = a[i] / b[i]; }

// C(matrix:m*n) = A(matrix:m*p) * B(matrix:p*n)
inline void math_product(double* c, double* a, double* b, const int m, const int p, const int n){
	memset(c, 0, (size_t)m * n * sizeof(double));
	ROWLOOP	COLLOOP KLOOP
		c[ij] += a[ik] * b[kj];
}

// C(vector:m*1) = A(matrix:m*p) * B(vector:p*1)
inline void math_product_c(double* c, double* a, double* b, const int m, const int p){
	memset(c, 0, m * sizeof(double));
	ROWLOOP KLOOP
		c[i] += a[ik] * b[k];
}

// C(vector:1*n) = A(vector:1*p) * B(matrix:p*n)
inline void math_product_r(double* c, double* a, double* b, const int p, const int n){
	memset(c, 0, n * sizeof(double));
	COLLOOP KLOOP
		c[j] += a[k] * b[kj];
}

#undef VECLOOP

#endif