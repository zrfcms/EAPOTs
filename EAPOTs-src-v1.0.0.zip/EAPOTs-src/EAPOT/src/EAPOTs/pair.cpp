#include "pair.h"
#include "force.h"
#include "memory.h"
#include "error.h"
#include "modify.h"
#include "compute.h"
#include "output.h"
#include "dump_file.h"
#include "update.h"

#include "option_pair.h"
#include "option_dump.h"
#include "option_comp.h"

using namespace EAPOT_NS;

/* ---------------------------------------------------------------------- */

Pair::Pair(EAPOT *eapot) 
	: Pointers(eapot)
	, potCallback(NULL)
	, dofMapCallback(NULL)
	, potCaller(NULL)
	, dofMapCaller(NULL)
{
	styles.push_back("pair");
	fsize = 0;
	csize = 0;
	fsize_custom = 0;
	csize_custom = 0;

	fvec_allocated = 0;

	transByFileMode = false;
}

/* ---------------------------------------------------------------------- */

Pair::~Pair()
{
}

void Pair::add_fsize(int n) { 
	fsize += n; 
}

void Pair::add_csize(int n) { 
	csize += n;
}

int Pair::get_fsize() const { 
	return fsize_custom ? fsize_custom : fsize; 
};

int Pair::get_csize() const { 
	return csize_custom ? csize_custom : csize; 
};


void PairStyle::setPairDof(void* pPair, int nfree, int nconst)
{
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	auto pair = (Pair*)pPair;
	pair->fsize_custom = nfree;
	pair->csize_custom = nconst;
	pair->fvec_clear();
	pair->fvec_allocate();
}

void PairStyle::setPairDofScript(void* pPair, const char* script)
{
	if (script == NULL) return;

	std::string str(script);
	str += "\neapot.PairDofMapAPI = eapot.DofMapCallbackType(PairDofMapScript)\n"
		"eapot.setPairDofCallback(eapot.getPair(), eapot.PairDofMapAPI, None)";
	if (eapot->pythonCallback) eapot->pythonCallback(eapot->caller, FLERR, str.c_str());
}

void PairStyle::setPairDofCallback(void* pPair, DofMapCallback callback, void* caller) {
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	Pair* pair = (Pair*)pPair;
	pair->dofMapCallback = callback;
	pair->dofMapCaller = caller;
}

void PairStyle::setPairPotCallback(void* pPair, VoidCallback callback, void* caller) {
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	Pair* pair = (Pair*)pPair;
	pair->potCallback = callback;
	pair->potCaller = caller;
}

void PairStyle::setPairFullParams(void* pPair, double* vec)
{
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	((Pair*)pPair)->setFullParams(vec);
}

void PairStyle::setPairFreeParams(void* pPair, double* vec)
{
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	((Pair*)pPair)->setFreeParams(vec);
}

void PairStyle::setPairCommByFile(void* pPair, int flag)
{
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	auto pair = (Pair*)pPair;

	pair->transByFileMode = flag;
}

void PairStyle::setPairDumpImageLimitSampleValue(void* pPair, int figidx1, int figidx2, double x)
{
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	auto pair = (Pair*)pPair;

	int nmax = pair->dump_sample.size();
	int lo = 0, hi = MIN(figidx2, nmax);

	if (x <= 0) {
		error->all(FLERR, "Illegal setPairDumpImageLimitSampleValue command: x <= 0");
	}

	if (hi >= pair->xlim.size()) {
		pair->xlim.resize((size_t)hi + 1);
	}
	for (int idx = lo; idx < hi; idx++) {
		pair->dump_sample[idx] = x;
	}
}

void PairStyle::setPairDumpImageXLimit(void* pPair, int figidx, double lo, double hi)
{
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	auto pair = (Pair*)pPair;

	if (figidx >= pair->xlim.size()) {
		pair->xlim.resize((size_t)figidx + 1);
	}
	if (figidx < 0) {
		error->all(FLERR, "Illegal setPairDumpImageXLimit command: figidx < 0");
	}

	pair->xlim[figidx].customlo = lo;
	pair->xlim[figidx].customhi = hi;
}

void PairStyle::setPairDumpImageYLimit(void* pPair, int figidx, double lo, double hi)
{
	((Pair*)pPair)->styleCheck(FLERR, "pair", 1);
	auto pair = (Pair*)pPair;

	if (figidx >= pair->ylim.size()) {
		pair->ylim.resize((size_t)figidx + 1);
	}
	if (figidx < 0) {
		error->all(FLERR, "Illegal setPairDumpImageXLimit command: figidx < 0");
	}

	pair->ylim[figidx].customlo = lo;
	pair->ylim[figidx].customhi = hi;
}

/* ---------------------------------------------------------------------- */

void Pair::init()
{
	init_style();
	setFreeParams(NULL);
}


void Pair::fvec_allocate(){

	size_t pyDof = getPyParamNum();

	if (paramVec.size() != pyDof) {
		paramVec.resize(pyDof);
	}
	
	if (fvec.size() < (size_t)get_fsize()){
		fvec.resize(get_fsize(), 0);
	}
	if (cvec.size() < (size_t)get_csize()) {
		cvec.resize(get_csize(), 0);
	}
	fvec_allocated = 1;
}

void Pair::setFullParams(double *x) {

	if (x){
		temp_memcpy(fvec.data(), x, get_fsize());
		temp_memcpy(cvec.data(), x + get_fsize(), get_csize());
	}

	auto& res = paramVec;
	std::vector<const char*> name;
	for (size_t i = 0; i < paramName.size(); i++) {
		name.push_back(paramName[i].c_str());
	}
	for (size_t i = paramName.size(); i < res.size(); i++) {
		name.push_back("none");
	}

	if (res.data()) {
		if (dofMapCallback) {
			(*dofMapCallback)(dofMapCaller, res.size(), res.data(), get_fsize(), get_csize(), fvec.data(), cvec.data(), name.data());
		}
		else {
			defaultDofMap(fvec.data(), cvec.data());
		}
	}

	setFullParamsStyle(); 
};

void Pair::setFreeParams(double *x) {

	if (x){
		temp_memcpy(fvec.data(), x, get_fsize());
	}

	auto& res = paramVec;
	std::vector<const char*> name;
	for (size_t i = 0; i < paramName.size(); i++) {
		name.push_back(paramName[i].c_str());
	}
	for (size_t i = paramName.size(); i < res.size(); i++) {
		name.push_back("none");
	}

	if (res.data()) {
		if (dofMapCallback) {
			(*dofMapCallback)(dofMapCaller, res.size(), res.data(), get_fsize(), get_csize(), fvec.data(), cvec.data(), name.data());
		}
		else {
			defaultDofMap(fvec.data(), cvec.data());
		}
	}

	setFreeParamsStyle();
	for (int i = 0; i < modify->ncompute; i++) {
		modify->compute[i]->export_pair();
	}
};


int Pair::styleCheck(const char* file, int line, const char* style, int errorFlag) {
	for (int i = 0; i < styles.size(); i++) {
		if (strcmp(style, styles[i]) == 0) {
			return i;
		}
	}

	if (errorFlag) {
		sprintf(error->ErrCheckBuff, "input style does match pair setting: %s", style);
		error->all(file, line, error->ErrCheckBuff);
	}
	return 0;
}

void Pair::transByFile(const char* name) {	
	write(&DumpFile(eapot, "file", "file", name));
}


void Pair::pack_image(class DumpImage* dumpimage) {
	error->all(FLERR, "dump image is not not support for current pair style");
};

int Pair::image(class DumpImage* dumpimage) { 
	error->all(FLERR, "dump image is not not support for current pair style");
	return 0;
};


void Pair::updateAxisLimitByCustom() {

	for (auto& ilim : ylim) {
		ilim.update();
	}

	for (auto& ilim : xlim) {
		ilim.update();
	}
}

void Pair::runMDCompute(int step, int mode, int nther, CPCHAR costParam[], CPCHAR chk, CPCHAR minstyle, CPCHAR dumpfile) {
	if (step >= 0) {
		void* CompCost = modify->addCompute("cost", "term", "none");
		if (costParam && eapot->pythonCallback) {
			compStyle->setComputeExternalScript(CompCost, costParam[0]);
		}
		if (costParam) {
			compStyle->setComputeExternalTitle(CompCost, costParam[1]);
		}

		if (mode & AddMDCompEnum::RunDump) {

			output->addDump(nther, "file", "file", dumpfile);
			output->addDump(nther, "image", "image", "dump.*.jpg");
			if (chk) {
				void* check = output->addDump(nther, "exter", "external", "dump.log");
				dumpStyle->setDumpExternalScript(check, chk);
			}
		}

		if (mode & AddMDCompEnum::RunEcho) {
			output->setThermoStep(nther);
			if (chk) {
				const char* keys[] = { "step", "eval", "err", "pylog", "d_exter" };
				output->setThermoKeys("custom", 5, keys);
			}
			else {
				const char* keys[] = { "step", "eval", "err", "pylog" };
				output->setThermoKeys("custom", 4, keys);
			}
			output->setThermoFormatStyle("line", "%4d %4d %10.3e %s\n %s\n");
			update->setMinimizeStyle(minstyle);
		}
		else{
			output->setThermoBlank(1);
			update->setMinimizeStyle(minstyle);
			update->setMinimizeLogFlag(0);
		}
		
		update->runMinimize(CompCost, 1e-15, 1e-15, step, 2000);
	}
	else {
		eapot->init();
		for (int i = 0; i < modify->ncompute; i++) {
			modify->compute[i]->compute();
		}
	}
}

const char* Pair::CuFccCost[] = { 
"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
"    v = EAPOT.parseCompute(nparam, style, param)\n"
"    fcc, C = v[0], v[1].C\n"
"    res[0] = 10*(fcc.xx/3.615 - 1.0)**2 + 10*(fcc.Ec/3.540 - 1.0)**2"
"         + (C[0,0]/172 - 1)**2 + (C[0,1]/125 - 1)**2 + (C[3,3]/80 - 1)**2\n"

"    sum = '%5.3f %5.3f %3.0f %3.0f %3.0f %10.8g %10.8g'%"
"(fcc.xx, fcc.Ec, C[0,0], C[0,1], C[3,3], fcc.rhoAve, fcc.embAve)\n"
"    return EAPOT.packMsg(sum)\n", "3.615 3.540 175 125  80 -2.5000000 1.00000000" };

const char* Pair::NbBccCost[] = { 
"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
"    v = EAPOT.parseCompute(nparam, style, param)\n"
"    bcc, C = v[0], v[1].C\n"
"    res[0] = 10*(bcc.xx/3.1 - 1.0)**2 + 10*(bcc.Ec/4.0 - 1.0)**2"
"         + (C[0,0]/172 - 1)**2 + (C[0,1]/125 - 1)**2 + (C[3,3]/80 - 1)**2\n"

"    sum = '%5.3f %5.3f %3.0f %3.0f %3.0f %10.8g %10.8g'%"
"(bcc.xx, bcc.Ec, C[0,0], C[0,1], C[3,3], bcc.rhoAve, bcc.embAve)\n"
"    return EAPOT.packMsg(sum)\n", "3.615 3.540 175 125  80 -2.5000000 1.00000000" };


const char* Pair::CDiaCost[] = { 
"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
"    v = EAPOT.parseCompute(nparam, style, param)\n"
"    Ec, a0, C  =  v[0].Ec, v[0].xx, v[1].cubic\n"
"    c1     = 1.0*(a0/3.567 - 1.0)**2 + 10.0*(Ec/7.370 - 1.0)**2\n"
"    c2     = (C[0]/1054 - 1)**2 + (C[1]/126 - 1)**2 + (C[2]/562 - 1)**2\n"

"    res[0] = c1 + c2\n"
"    sum = '%5.3f %5.3f %4.0f %4.0f %4.0f'%(a0, Ec, C[0], C[1], C[2])\n"
"    return EAPOT.packMsg(sum)\n", "3.567 7.370 1054  126  562" };

const char* Pair::SiCDiaCost[] = { 
"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
"    v = EAPOT.parseCompute(nparam, style, param)\n"
"    Ec, a0, C = v[0].xx, v[0].Ec, v[1].cubic\n"
"    c1     = (a0/4.40-1)**2 + 100*(Ec/6.6-1)**2\n"
"    c2     = (C[0]/382 - 1)**2 + (C[1]/126 - 1)**2 + (C[2]/241 - 1)**2\n"

"    res[0] = c1 + c2\n"
"    sum = '%4.2f %6.4f %3.0f %3.0f %3.0f'%(a0, Ec, C[0], C[1], C[2])\n"
"    return EAPOT.packMsg(sum)\n", "4.40 6.600  382 126 241" };


const char* Pair::CuNiAlloyCost[] = { 
"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
"    v = EAPOT.parseCompute(nparam, style, param)\n"
"    AB3, A3B, B2, CAB3, CA3B, CB2 = v\n"

"    sum = '%5.3f %5.3f | %3.0f %3.0f %3.0f | %5.3f %5.3f | %3.0f %3.0f %3.0f | %5.3f %5.3f | %3.0f %3.0f %3.0f |'%("
"    AB3.xx, AB3.Ec, CAB3.C[0,0], CAB3.C[0,1], CAB3.C[3,3], "
"    A3B.xx, A3B.Ec, CA3B.C[0,0], CA3B.C[0,1], CA3B.C[3,3], "
"     B2.xx,  B2.Ec,  CB2.C[0,0],  CB2.C[0,1],  CB2.C[3,3])\n"
"    res[0] = (A3B.energy/3.6-1)**2\n"
"    return EAPOT.packMsg(sum)\n", "3.615 3.540 | 175 125  80 | 3.615 3.540 | 175 125  80 | 3.615 3.540 | 175 125  80 |" };

const char* Pair::VNbAlloyCost[] = {
"def computeCostScript(caller, np, p, nparam, style, param, res):\n"
"    v = EAPOT.parseCompute(nparam, style, param)\n"
"    AB3, A3B, B2, CAB3, CA3B, CB2 = v\n"

"    sum = '%5.3f %5.3f | %3.0f %3.0f %3.0f | %5.3f %5.3f | %3.0f %3.0f %3.0f | %5.3f %5.3f | %3.0f %3.0f %3.0f |'%("
"    AB3.xx, AB3.Ec, CAB3.C[0,0], CAB3.C[0,1], CAB3.C[3,3], "
"    A3B.xx, A3B.Ec, CA3B.C[0,0], CA3B.C[0,1], CA3B.C[3,3], "
"     B2.xx,  B2.Ec,  CB2.C[0,0],  CB2.C[0,1],  CB2.C[3,3])\n"
"    res[0] = (A3B.xx/4.0 - 1)**2 + (AB3.xx/4.0 - 1)**2 + (AB3.Ec/5.7 - 1)**2 + (A3B.Ec/6.7 - 1)**2\n"
"    return EAPOT.packMsg(sum)\n", "3.615 3.540 | 175 125  80 | 3.615 3.540 | 175 125  80 | 3.615 3.540 | 175 125  80 |" };


const char* Pair::FccChk   = "inter.add('fcc',   inter.ele)";
								
const char* Pair::BccChk   = "inter.add('bcc',   inter.ele)";
								
const char* Pair::AlloyChk = "inter.add('alloy', inter.ele)";

const char* Pair::DiaChk = "type = 'dia' if len(inter.ele) == 1 else 'SiC'\n inter.add(type, inter.ele)\n";

void Pair::addMDComputeBcc() {
	void* Ec = modify->addCompute("bcc", "energy", "../../res/struct/bcc.lammps");
	void* Ela = modify->addCompute("bcc_el", "elastic", "bcc");
}

void Pair::addMDComputeFcc() {
	void* Ec = modify->addCompute("fcc", "energy", "../../res/struct/fcc.lammps");
	void* Ela = modify->addCompute("fcc_el", "elastic", "fcc");
}

void Pair::addMDComputeAlloy() {
	void* AB3Ec = modify->addCompute("AB3", "energy", "../../res/struct/L12_AB3.lammps");
	void* A3BEc = modify->addCompute("A3B", "energy", "../../res/struct/L12_A3B.lammps");
	void* B2Ec = modify->addCompute("B2", "energy", "../../res/struct/B2.lammps");

	void* AB3Ela = modify->addCompute("AB3Ela", "elastic", "AB3");
	void* A3BEla = modify->addCompute("A3BEla", "elastic", "A3B");
	void* B2Ela = modify->addCompute("B2Ela", "elastic", "B2");
}

void Pair::addMDComputeCDia() {
	void* Ec = modify->addCompute("diar", "energy", "../../res/struct/dia.lammps");
	void* Ela = modify->addCompute("dia_el", "elastic", "diar");
}

void Pair::addMDComputeSiCDia() {
	void* Ec = modify->addCompute("SiC", "energy", "../../res/struct/SiC.beta.lammps");
	void* Ela = modify->addCompute("SiC_el", "elastic", "SiC");
}


void Pair::addMDCheckCubic(const char* file, int line, int icomp, const char* name,
	const char* title, double* ref, double smaxerr, double saveerr) {

#define N 5

	int nchk = 0;
	double fcal[N];
	Compute* com = NULL;

	switch (icomp) {
	case 0:
		nchk = 2;
		com = modify->compute[icomp];
		fcal[0] = com->data[0];
		fcal[1] = -com->data[6] / com->data[18];
		break;
	case 1:
		nchk = 3;
		com = modify->compute[icomp];
		fcal[0] = com->data[6*0+0];
		fcal[1] = com->data[6*0+1];
		fcal[2] = com->data[6*3+3];
		break;
	}

	error->check(FLERR, nchk, fcal, ref, 1, name, title, smaxerr * 2, smaxerr * 2, smaxerr, saveerr);

#undef N
}

void Pair::evalCompute(double* BoxChk, double* ElaChk, int nbox, int elalo, int nela) {

	for (int i = 0; i < nbox; i++) {
		Compute* pc = modify->compute[i];
		BoxChk[2 * i + 0] = pc->data[0];
		BoxChk[2 * i + 1] = -pc->data[6] / pc->data[18];
	}

	for (int i = 0; i < nela; i++) {
		Compute* pc = modify->compute[elalo + i];
		ElaChk[3 * i + 0] = pc->data[6*0+0];
		ElaChk[3 * i + 1] = pc->data[6*0+1];
		ElaChk[3 * i + 2] = pc->data[6*3+3];
	}
}


