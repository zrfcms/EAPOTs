#include "CubicSplineChain.h"
#include "float.h"

using namespace EAPOT_NS;

void CubicSplineChain::set(const double pa, const double pr0) {
	a = pa;
	r0 = pr0;
	a3 = a * 3.0;
	a6 = a * 6.0;
}

double CubicSplineChain::d(const int i, const double r) {

	if (r >= r0) return 0;

	switch (i) {

	case 0: {
		double dr = r - r0;
		double dr3 = dr * dr * dr;
		return -a * dr3;
	}
	case 1: {
		double dr = r - r0;
		double dr2 = dr * dr;
		return -a3 * dr2;
	}
	case 2: {
		double dr = r - r0;
		return -a6 * dr;
	}
	};

	return DBL_MAX;
}

double CubicSplineChain::p(const int i, const int j, const double r) {

	if (r >= r0) return 0;

	switch (i) {

	case 0:

		switch (j) {
		case 0: {
			double dr = r - r0;
			double dr3 = dr * dr * dr;
			return -dr3;
		}
		case 1: {
			double dr = r - r0;
			double dr2 = dr * dr;
			return a3 * dr2;
		}
		};

	case 1:

		switch (j) {
		case 0: {
			double dr = r - r0;
			double dr2 = dr * dr;
			return dr2 * -3.0;
		}
		case 1: {
			double dr = r - r0;
			return a6 * dr;
		}
		};

	case 2:

		switch (j) {
		case 0: {
			double dr = r - r0;
			return dr * -6.0;
		}
		case 1: {
			return a6;
		}
		};
	};

	return DBL_MAX;
}