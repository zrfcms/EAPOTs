#include "compute_elastic.h"
#include "libLAMMPS/lammps_api.h"

#include "error.h"
#include "modify.h"
#include "option_comp.h"

using namespace EAPOT_NS;

//#define TimeEval

ComputeElastic::ComputeElastic(EAPOT* eapot, const char* pid, const char* pstyle, const char* pfile)
	: Compute(eapot, pid, pstyle, pfile)
	, C{ {0,0,0,0,0,0},{0,0,0,0,0,0} }
	, stress0{ 0,0,0,0,0,0 }
{
	styles.push_back("elastic");
	param.id = id.c_str();
	vparam = &param;

	clmp = (ComputeEnergy*)modify->getCompute(pfile, "energy");

	cut = 0.0;
	delta = 1.0e-10;
	halfFlag = 1;

	etol = 0;
	ftol = 1e-5;
	iter = 5000;
	step = 5000;

	compute_method = CompEval::FORCE;
	data.resize(7 * 6);

	clmp->triclinicFlag = 1;
	clmp->saveRelaxFlag = 1;
}

ComputeElastic::~ComputeElastic() {

}

#define ComputeStyleCastCheck()								\
((Compute*)pcomp)->styleCheck(FLERR, "elastic", 1);			\
ComputeElastic* ela = (ComputeElastic*)pcomp;	


void CompStyle::setComputeElasticHalfLoad(void* pcomp, int halfFlag) {
	ComputeStyleCastCheck();
	ela->halfFlag = halfFlag;
}

void CompStyle::setComputeElasticMethod(void* pcomp, const char* method) {
	ComputeStyleCastCheck();
	if (strcmp(method, "run") == 0) ela->compute_method = ComputeElastic::CompEval::RUN;
	else if (strcmp(method, "force") == 0) ela->compute_method = ComputeElastic::CompEval::FORCE;
	else if (strcmp(method, "relax") == 0) ela->compute_method = ComputeElastic::CompEval::RELAX;
	else error->all(FLERR, "Illegal setComputeElasticMethod command");
}

void CompStyle::setComputeElasticMinimize(void* pcomp, double etol, double ftol, int iter, int step) {
	ComputeStyleCastCheck();
	ela->etol = etol;
	ela->ftol = ftol;
	ela->iter = iter;
	ela->step = step;
}

void CompStyle::setComputeElasticZeroCut(void* pcomp, double cut){
	ComputeStyleCastCheck();
	ela->cut = cut;
	if (cut < 0.0 || cut > 100.0) {
		error->all(FLERR, "Illegal setComputeElasticZeroCut command: cut < 0.0 || cut > 100.0");
	}
}

void CompStyle::setComputeElasticLoadDelta(void* pcomp, double delta) {
	ComputeStyleCastCheck();
	ela->delta = delta;
	if (delta <= 0.0 || delta > 0.1) {
		error->all(FLERR, "Illegal setComputeElasticZeroCut command: delta <= 0.0 || delta > 0.1");
	}
}

void ComputeElastic::elastic_displace(bool positive, int dir) {

	void* md = clmp->md;
	double* stress = NULL, dirdelta;
	double* box = clmp->data.data();

	dirdelta = positive ? delta : -delta;	
	snap_load_self(md, 1);
	
	double refAxis[] = {
		box[0], box[1], box[2],
		box[1], box[2], box[2],
	};


	switch (compute_method)
	{
	case EAPOT_NS::ComputeElastic::CompEval::FORCE:
	{
		box_uniaxial_serial(md, dir, dirdelta * refAxis[dir]);
		forward_comm(md);

		setup_minimal(md, 0);
		stress = get_globalsts(md, 1);
		break;
	}
	case EAPOT_NS::ComputeElastic::CompEval::RELAX: {
		box_uniaxial(md, dir, dirdelta * refAxis[dir]);
		minimize(md, etol, ftol, iter, step);
		stress = get_globalsts(md, 0);
		break;
	}
	default:
	case EAPOT_NS::ComputeElastic::CompEval::RUN:
	{
		box_uniaxial(md, dir, dirdelta * refAxis[dir]);
		run(md, 0);
		stress = get_globalsts(md, 0);
	}
	}

	//int n = get_atomnum(md);
	//double* fcom = new double[n], stscom[6];
	//temp_memcpy(fcom, get_atomf1d(md), n);
	//temp_memcpy(stscom, stress, 6);
	//run(md, 0);
	//double* frun = get_atomf1d(md);
	//double* stsrun = get_globalsts(md, 0);

	if (positive) {
		selfminu_vector6(C[dir], stress);
	}
	else {		
		set_vector6(C[dir], stress);
		if (halfFlag) {
			selfminu_vector6(C[dir], stress0);
		}
	}	
}

void ComputeElastic::reduceBulkShearModulus(double* res) {
	double Cii = C[0][0] + C[1][1] + C[2][2];
	double Cij = C[0][1] + C[0][2] + C[1][2];
	double Ckk = C[3][3] + C[4][4] + C[5][5];

	double B = (Cii + 2 * Cij) / 9;
	double G = (Cii - Cij + 3 * Ckk) / 15;
	double E = 9 * G * B / (3 * B + G);
	double v = (1 - E / (3 * B)) / 2;

	res[0] = B;
	res[1] = G;
	res[2] = v;
	res[3] = C[0][0];
	res[4] = C[1][1];
	res[5] = C[2][2];

}

void ComputeElastic::reduceElasticConstant3(double* res, ComputeElastic* el) {
	double* C = el->data.data();

	res[0] = (C[6*0+0] + C[6*1+1] + C[6*2+2]) / 3;
	res[1] = (C[6*0+1] + C[6*0+2] + C[6*1+0] + C[6*1+2] + C[6*2+0] + C[6*2+1]) / 6;
	res[2] = (C[6*3+3] + C[6*4+4] + C[6*5+5]) / 3;
}

void ComputeElastic::reduceElasticConstant6(double* res, ComputeElastic* el) {
	double* C = el->data.data();

	res[0] = (C[6 * 0 + 0] + C[6 * 1 + 1]) * 0.5;
	res[1] = (C[6 * 0 + 1] + C[6 * 1 + 0]) * 0.5;
	res[2] = (C[6 * 0 + 2] + C[6 * 2 + 0] + C[6 * 1 + 2] + C[6 * 2 + 1]) * 0.25;
	res[3] = C[6 * 2 + 2];
	res[4] = (C[6 * 3 + 3] + C[6 * 4 + 4]) * 0.5;
	res[5] = C[6 * 5 + 5];
}

#ifdef TimeEval
#include "time.h"
#endif

void ComputeElastic::compute() {

	for (size_t i = 0; i < 6; i++) {
		stress0[i] = clmp->data[7 + i];
	}

#ifdef TimeEval
	clock_t t1 = clock();
#endif

	elastic_displace(0, 0);
	elastic_displace(0, 1);
	elastic_displace(0, 2);
	elastic_displace(0, 3);
	elastic_displace(0, 4);
	elastic_displace(0, 5);

	if (!halfFlag) {
		elastic_displace(1, 0);
		elastic_displace(1, 1);
		elastic_displace(1, 2);
		elastic_displace(1, 3);
		elastic_displace(1, 4);
		elastic_displace(1, 5);
	}

#ifdef TimeEval
	clock_t t2 = clock();
	double dt = ((double)t2 - t1) / CLOCKS_PER_SEC;
	printf("timecost:%f\n", dt);
#endif

	// -------------------------- Evaluate Elastic Constant from Stress ------------------------------
	double ave, ratio = 0.0001 / delta;
	if (!halfFlag) { ratio *= 0.5; }

	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 6; j++) {
			C[i][j] *= ratio;
			if (fabs(C[i][j]) < cut) C[i][j] = 0.0;
		}
	}

	// for symmetry
	for (int i = 0; i < 6; i++) {			
		for (int j = 0; j < i; j++) {
			ave = (C[i][j] + C[j][i]) * 0.5;
			C[j][i] = C[i][j] = ave;
		}
	}
	

	double tmp[6];
	reduceBulkShearModulus(C[6]);
	param.Bulk = C[6][0];
	param.Shear = C[6][1];
	param.Poisson = C[6][2];
	param.Youngx = C[6][3];
	param.Youngy = C[6][4];
	param.Youngz = C[6][5];

	memcpy(data.data(), C, sizeof(C));
	memcpy(param.Cdata, C, 36 * sizeof(double));

	reduceElasticConstant3(tmp, this);
	set_vector3(param.cubic, tmp);

	reduceElasticConstant6(tmp, this);
	set_vector6(param.hex, tmp);

	//error->all(FLERR, PY_STRING_AS_STRING(PyObject_Str(instance)));
}

void ComputeElastic::extracheck(int type) {

#define NUM  40

	double fchk[NUM], * fref = NULL;
	switch (type)
	{
	case 0: {

		static double tref[] = {
			 158.819,      137.096,      137.096,            0,            0,            0,
			 137.096,      158.819,      137.096,            0,            0,            0,
			 137.096,      137.096,      158.819,            0,            0,            0,
				   0,            0,            0,      43.6912,            0,            0,
				   0,            0,            0,            0,      43.6912,            0,
				   0,            0,            0,            0,            0,      43.6912,
			 144.337,      30.5593,      0.401117,     158.819,      158.819,      158.819,
		};
		fref = tref;
		break;
	}
	case 1: {

		static double tref[] = {
			 144.588,      96.1721,      45.7244,            0,            0,            0,
			 96.1721,      144.588,      45.7245,            0,            0,            0,
			 45.7244,      45.7245,       243.88,            0,            0,            0,
				   0,            0,            0,      24.2079,            0,            0,
				   0,            0,            0,            0,     -19.3498,            0,
				   0,            0,            0,            0,            0,     -19.3498,
			 100.922,      20.1306,      0.406484,     144.588,      144.588,       243.88,
		};
		fref = tref;
		break;
	}
	case 2: {
		static double tref[] = {
			 400.651,       51.595,       51.595,            0,            0,            0,
			  51.595,      400.651,       51.595,            0,            0,            0,
			  51.595,       51.595,      400.651,            0,            0,            0,
				   0,            0,            0,      14.9992,            0,            0,
				   0,            0,            0,            0,      14.9992,            0,
				   0,            0,            0,            0,            0,      14.9992,
			 167.947,      78.8107,     0.297107,      400.651,      400.651,      400.651,
		};
		fref = tref;
		break;
	}
	}

	cut = 1;
#if 1
	

	// ----------------------------- full with FORCE ----------------------------- 
	halfFlag = 0;
	compute_method = CompEval::FORCE;
	compute();
	memcpy(fchk, data.data(), sizeof(fchk));

	// ------------------------------ half with RUN ------------------------------ 
	halfFlag = 1;
	compute_method = CompEval::RUN;
	compute();

	switch (type) {
	case 0: error->check(FLERR, NUM, data.data(), fchk, 2, "halfRUN", "L12",
		5e-5, 5e-6, 1.5608183804197441e-06, 1.6905621046039534e-05); break;
	case 1: error->check(FLERR, NUM, data.data(), fchk, 2, "halfRUN", "Hex",
		5e-5, 5e-6, 1.1107501405790506e-05, 7.3709923670059189e-05); break;
	case 2: error->check(FLERR, NUM, data.data(), fchk, 2, "halfRUN", "B1",
		5e-5, 5e-6, 1.9286739050152044e-05, 0.00012155840335149365); break;
	}

	memcpy(fchk, data.data(), sizeof(fchk));

	// ----------------------------- half with FORCE ----------------------------- 
	halfFlag = 1;
	compute_method = CompEval::FORCE;
	compute();

	switch (type) {
	case 0: error->check(FLERR, NUM, data.data(), fchk, 2, "halfForce", "L12",
		5e-5, 5e-6, 3.4963237876116076e-06, 2.085433317500658e-05); break;
	case 1: error->check(FLERR, NUM, data.data(), fchk, 2, "halfForce", "Hex",
		5e-5, 5e-6, 9.7905092135663711e-06, 5.4876786620560946e-05); break;
	case 2: error->check(FLERR, NUM, data.data(), fchk, 2, "halfForce", "B1",
		5e-5, 5e-6, 1.9094074635535959e-05, 0.00012177080661156199); break;
	}

	memcpy(fchk, data.data(), sizeof(fchk));
	

	// ------------------------ check with reference data ------------------------ 

	switch (type) {
	case 0: error->check(FLERR, NUM, fchk, fref, 1, "ComMDEla", "L12", 
		5e-4, 5e-5, 6.2923480455157054e-06, 2.9617579401731015e-05); break;
	case 1: error->check(FLERR, NUM, fchk, fref, 1, "ComMDEla", "Hex",
		5e-4, 5e-5, 9.8644438553037201e-06, 7.0245404645727667e-05); break;
	case 2: error->check(FLERR, NUM, fchk, fref, 1, "ComMDEla", "B1",
		5e-4, 5e-5, 4.7202408045015463e-06, 2.1508808435444261e-05); break;
	}
#else
	compute_vector2d();
	memcpy(fchk, vector2d[0], sizeof(fchk));

	/*---------------------------------------------------------------------------------------*/
	// Display data, (check data source)
	/*---------------------------------------------------------------------------------------*/

	int i, s = 0;
	const char* fmt = "%12.6g, ";

	for (i = 0; i < NUM; i++) {
		if (i % 6 == 0)printf("\n");
		printf(fmt, fchk[s + i]);
	}
	printf("\n"); s += i;
#endif

#undef NUM

}