#ifdef MINIMIZE_CLASS
MinimizeStyle(de/a, MinDE)
#else

#ifdef LIBAPI
LIBAPI(void, setDifferentialEvolutionGeneNum,   (APITYPE int n), (APINAME n));
LIBAPI(void, setDifferentialEvolutionInitRange, (APITYPE double val), (APINAME val));
LIBAPI(void, setDifferentialEvolutionMutRat,    (APITYPE double val), (APINAME val));
LIBAPI(void, setDifferentialEvolutionCrossRat,  (APITYPE double val), (APINAME val));
#else

#ifndef EAPOT_MIN_DEA_H
#define EAPOT_MIN_DEA_H

#include "min.h"

#include <vector>

namespace EAPOT_NS {

	struct Gene {
		double eval;
		std::vector<double> v;
	};

	class MinDE : public Min {
		friend class MiniStyle;
	public:
		MinDE(class EAPOT*);
		~MinDE();
		void init();
		void setup_style();
		void reset_vectors();
		int iterate(int);

	protected:
		int geneNum;
		double mut, crossp;
		double bestEval, range;

		int bestIdx;
		std::vector<double> gmin;
		std::vector<double> diff;
		std::vector<double> gmax;
		std::vector<Gene> genes;
		void geneCopy(Gene&, double*);
	};

	class MinDEA : public Min {
		friend class Update;
	public:
		MinDEA(class EAPOT *);
		~MinDEA();
		void init();
		void setup_style();
		void reset_vectors();

		/* Particle Swarm Optimization */
		int iterate(int);

		// initialize population with random numbers
		void init_population(double**, double*, double*);

	protected:
		int NP;
		int D;

		double** X;
		double* cost;
		double* trial;			 // vector with new configuration
		double* xi_opt;
		double** pop_1;				
		double** pop_2;
	};

}

#endif
#endif
#endif
