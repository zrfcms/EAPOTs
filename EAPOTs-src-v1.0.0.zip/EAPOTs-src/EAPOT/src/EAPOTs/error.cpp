#include "stdlib.h"
#include "string.h"
#include "output.h"
#include "error.h"
#include "input.h"

using namespace EAPOT_NS;

static const char* truncpath(const char* path)
{
	if (path) {
		int len = strlen(path);
		for (int i = len - 4; i > 0; --i) {
			if (strncmp("src/", path + i, 4) == 0)
				return path + i;
		}
		for (int i = len - 4; i > 0; --i) {
			if (strncmp("src\\", path + i, 4) == 0)
				return path + i;
		}
	}
	return path;
}

Error::Error(EAPOT *eapot)
: Pointers(eapot) 
, ErrCheckBuff("")
, ErrCheckBuff1("")
, ErrCheckBuff2("")
{
	selfCheckMode = 0;

	log0 = -1;
	log1 = -1;
	log2 = -1;

#ifdef EAPOT_EXCEPTIONS
	last_error_message = NULL;
	last_error_type = ERROR_NONE;
#endif
};

Error::~Error(){
}


void Error::all(const char *file, int line, const char *str)
{
	const char *lastcmd = (const char*)"(unknown)";

	if (output) delete output;
	
	if (selfCheckMode) {
		FILE* f1 = freopen("con", "r", stdin);
		FILE* f2 = freopen("con", "w", stdout);
	}

	if (input && !input->lastCommand.empty()) lastcmd = input->lastCommand.c_str();
	if (screen) fprintf(screen, "ERROR: %s (%s:%d)\n"
		"Last command: %s\n", str, truncpath(file), line, lastcmd);
	if (logfile) fprintf(logfile, "ERROR: %s (%s:%d)\n"
		"Last command: %s\n", str, truncpath(file), line, lastcmd);

	if (screen && screen != stdout) fclose(screen);
	if (logfile) fclose(logfile);

#ifdef EAPOT_EXCEPTIONS
	char msg[100];
	sprintf(msg, "ERROR: %s (%s:%d)\n", str, file, line);
	throw EAPOTException(msg);
#else
	if (screen && screen != stdout) fclose(screen);
	if (logfile) fclose(logfile);

	exit(1);
#endif

}

/* ----------------------------------------------------------------------
called by one proc in world
only write to screen if non-NULL on this proc since could be file
------------------------------------------------------------------------- */

void Error::warning(const char *file, int line, const char *str, int logflag)
{
	if (screen) fprintf(screen, "WARNING: %s (%s:%d)\n", str, file, line);
	if (logflag && logfile) fprintf(logfile, "WARNING: %s (%s:%d)\n",
		str, file, line);
}

/* ----------------------------------------------------------------------
called by one proc in world, typically proc 0
write message to screen and logfile (if logflag is set)
------------------------------------------------------------------------- */

void Error::message(const char *file, int line, const char *str, int logflag)
{
	if (screen) fprintf(screen, "%s (%s:%d)\n", str, file, line);
	if (logflag && logfile) fprintf(logfile, "%s (%s:%d)\n", str, file, line);
}

void Error::done(int status)
{
	if (screen && screen != stdout) fclose(screen);
	if (logfile) fclose(logfile);
	exit(status);
}


bool Error::check(const char* file, int line, const char* sf1, const char* sf2) {

	FILE* f1 = input->open(sf1, "rb");
	FILE* f2 = input->open(sf2, "rb");

	fseek(f1, 0, SEEK_END);
	long fsize1 = ftell(f1);

	fseek(f2, 0, SEEK_END);
	long fsize2 = ftell(f2);

	rewind(f1);
	rewind(f2);

	if (fsize1 != fsize2) {
		sprintf(ErrCheckBuff, "file %s is not same to file %s", sf1, sf2);
		all(file, line, ErrCheckBuff);
		return false;
	}

	long fsize = fsize1;

	char* s1 = (char*)malloc(((size_t)fsize + 1) * sizeof(char));
	char* s2 = (char*)malloc(((size_t)fsize + 1) * sizeof(char));

	if (s1 == NULL || s2 == NULL) {
		all(file, line, "memory malloc error");
		return false;
	}

	fread(s1, sizeof(char), fsize, f1); s1[fsize] = 0;
	fread(s2, sizeof(char), fsize, f2); s2[fsize] = 0;

	int res = strncmp(s1, s2, fsize);

	if (res != 0) {
		const char* src = s1;
		const char* dst = s2;

		while (!(*(unsigned char*)src - *(unsigned char*)dst) && *dst)
		{
			++src;
			++dst;
		}

		size_t lo = src - s1 - 64;
		size_t hi = src - s1 + 64;
		lo = lo > 0 ? lo : 0;
		hi = hi < (size_t)fsize1 ? hi : fsize;
		size_t len = hi - lo;

		if (len >= ERRORBUFFSIZE) len = ERRORBUFFSIZE - 1;
		strncpy(ErrCheckBuff, &s1[lo], len);
		ErrCheckBuff[len] = 0;
		input->print(ErrCheckBuff);

		strncpy(ErrCheckBuff, &s2[lo], len);
		ErrCheckBuff[len] = 0;
		input->print(ErrCheckBuff);

		sprintf(ErrCheckBuff, "file %s is not same to file %s", sf1, sf2);
		if (selfCheckMode) {
			all(file, line, ErrCheckBuff);
		} else {
			warning(file, line, ErrCheckBuff);
		}			
		return false;
	}

	return true;
}


void Error::check(const char* file, int line, int iup, int* pchk, int* pref,
	int level, const char* title, const char* message) {

	chk.Reset();
	int tref, tchk;
	for (int i = 0; i < iup; i++)
	{
		tref = pref[i];
		tchk = pchk[i];

		if (tref != tchk) {
			sprintf(ErrCheckBuff, "%20s check error with (%d):\n ref/chk: %d %d"
				, chk.name, i, tref, tchk);
			all(file, line, ErrCheckBuff);
		}
	}

	add_chklog(level, title, message);
	add_reflog(file, line, level, 0.0, 0.0);
}

void Error::check(const char* file, int line, int iup, double* pchk, double* pref,
	int level, const char* title, const char* message,
	double cmax, double call, double pmax, double pall) {

	chk.Reset(cmax, call);
	int mi = 0;
	double maxerr = 0, allerr = 0;
	double pmaxcut = chk.maxcut;
	double pallcut = chk.allcut;
	double err, tref, tchk;

	for (int i = 0; i < iup; i++)
	{
		tref = pref[i];
		tchk = pchk[i];

		err = fabs(tref - tchk);
		if (tref) err /= fabs(tref);

		if (err > pmaxcut) {
			sprintf(ErrCheckBuff, "%20s check error with (%d):\n ref/chk: %.20g %.20g err:%.20g"
				, chk.name, i, tref, tchk, err);
			all(file, line, ErrCheckBuff);
		}

		allerr += err;
		if (maxerr < err) {
			maxerr = err;
			mi = i;
		}
	}

	chk.Merge(iup, maxerr, allerr);
	chk.SetIndex(mi, 0, 0);

	double aveerr = allerr / iup;
	if (aveerr > pallcut) {
		sprintf(ErrCheckBuff, "%20s check error with %.20g aveerr\n", chk.name, aveerr);
		all(file, line, ErrCheckBuff);
	}
	
	add_chklog(level, title, message);

	switch (level) {
	case 0:
		break;
	case 1:
		chklog[log0].Merge(chk.num, chk.max, chk.all);
		break;
	case 2:
		chklog[log0].Merge(chk.num, chk.max, chk.all);
		chklog[log1].Merge(chk.num, chk.max, chk.all);
		break;
	}
	chklog.back().Merge(chk.num, chk.max, chk.all);

	add_reflog(file, line, level, pmax, pall);
}


int Error::add_chklog(int level, const char *title, const char *message){

	size_t logIdx = chklog.size();
	chklog.push_back(CHKLOG());
	CHKLOG& plog = chklog.back();

	if (strlen(title) >= CHKLOGBUFFSIZE)
		error->all(FLERR, "string lenth of title larger than size of CHKLOGTITLE!");

	if (strlen(message) + 3 >= CHKLOGBUFFSIZE)
		error->all(FLERR, "string lenth of message larger than size of CHKLOGMESSAGE!");

	plog.level = level;
 	switch (level){
	case 0:
		log0 = logIdx;
		strcpy(plog.title, title);
		break;
	case 1:
		log1 = logIdx;
		strcat(chklog[log0].message, message);

		plog.title[0] = ' ';
		strcpy(&plog.title[1], title);
		break;
	case 2:
		log2 = logIdx;
		strcat(chklog[log1].message, message);

		plog.title[0] = ' ';
		plog.title[1] = ' ';
		strcpy(&plog.title[2], title);
		break;
	default:
		error->all(FLERR, "Illegal log level!");
	}

	// Organize information format
	if (title != NULL){
		sprintf(plog.message,"%-20s | %s", plog.title, message);
	}
	else{
		strcpy(plog.message, message);
	}

	return int(chklog.size() - 1);
}

void Error::add_reflog(const char *file, int line, int level, double smax, double sall){

	if (chklog.empty()) {
		error->all(file, line, "No check defined!"); return;
	}

	CHKLOG* plog = NULL;
	switch (level)
	{
	case 0:	
		plog = &chklog[log0]; 
		break;
	case 1:			
		plog = &chklog[log1];
		chklog[log0].mergeRef(smax, sall);
		break;
	case 2:	
		plog = &chklog[log2]; 
		chklog[log0].mergeRef(smax, sall);
		chklog[log1].mergeRef(smax, sall);
		break;
	default: 
		error->all(file, line, "Illegal log level!");
	}
	if (plog == NULL) {
		error->all(file, line, "Illegal log level!"); return;
	}
	plog->ref_max = smax;
	plog->ref_all = sall;

	// If the check is abnormal, an error message is output
	if (plog->max != smax || plog->all != sall){

		sprintf(error->ErrCheckBuff1, "%-40s | max/all: %.17g, %.17g\n",
			"Does not match the default:", smax, sall);

		sprintf(error->ErrCheckBuff2, "%-40s | max/all: %.17g, %.17g\n",
			plog->message, plog->max, plog->all);

		sprintf(ErrCheckBuff, "\n%s%s", error->ErrCheckBuff1, error->ErrCheckBuff2);

		if (selfCheckMode) {
			warning(file, line, ErrCheckBuff);
		} else {
			all(file, line, ErrCheckBuff);
		}	
	}
}

void Error::print_chklog(int start, int level){

	double rat;
	int index = 0;
	sprintf(ErrCheckBuff, "idx        label         |            items            |    calc   ave/max |     ref   ave/max | del/ref\n");
	input->print(ErrCheckBuff);

	for (auto& plog : chklog){
		if (plog.level > level) continue;

		rat = plog.ref_max ? fabs(plog.max / plog.ref_max - 1) : plog.max;

		sprintf(ErrCheckBuff, "%3d %-50s | %8.3g %8.3g | %8.3g %8.3g | %7.2e\n",
			index++, plog.message,	plog.all / plog.num, plog.max, 
			plog.ref_all / plog.num, plog.ref_max, rat);
		input->print(ErrCheckBuff);
	}
}

#ifdef EAPOT_EXCEPTIONS
/* ----------------------------------------------------------------------
return the last error message reported by EAPOT (only used if
compiled with -DEAPOT_EXCEPTIONS)
------------------------------------------------------------------------- */

char * Error::get_last_error() const
{
	return last_error_message;
}

/* ----------------------------------------------------------------------
return the type of the last error reported by EAPOT (only used if
compiled with -DEAPOT_EXCEPTIONS)
------------------------------------------------------------------------- */

ErrorType Error::get_last_error_type() const
{
	return last_error_type;
}

/* ----------------------------------------------------------------------
set the last error message and error type
(only used if compiled with -DEAPOT_EXCEPTIONS)
------------------------------------------------------------------------- */

void Error::set_last_error(const char * msg, ErrorType type)
{
	delete[] last_error_message;

	if (msg) {
		last_error_message = new char[strlen(msg) + 1];
		strcpy(last_error_message, msg);
	}
	else {
		last_error_message = NULL;
	}
	last_error_type = type;
}
#endif
