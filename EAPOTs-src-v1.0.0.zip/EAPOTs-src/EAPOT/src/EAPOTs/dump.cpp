#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "dump.h"

#include "update.h"
#include "output.h"
#include "memory.h"

#include "input.h"
#include "error.h"
#include "option_dump.h"

#include <ctime>



using namespace EAPOT_NS;

/* ---------------------------------------------------------------------- */

Dump::Dump(EAPOT *eapot, const char* pid, const char* pstyle, const char* pfile)
	: Pointers(eapot)
	, tasksDir("task/")
	, sLine(1024)
	, sDelta(1048576)
{
	id = pid; 
	styles.push_back("dump");

	fileList.push_back(pfile);
	fileDump.push_back("");

	timeFlag = 0;
	firstFlag = 0;
	clearstep = 0;
	padflag = 0;

	ndme = 0;
	maxdbuf  = 0;
	dbuf = NULL;

	nsme = 0;
	maxsbuf = 0;
	sbuf = NULL;

	// parse filename for special syntax
	// if contains '%', write one file per proc and replace % with proc-ID
	// if contains '*', write one file per timestep and replace * with timestep
	// check file suffixes
	//   if ends in .bin = binary file
	//   else if ends in .gz = gzipped text file
	//   else ASCII text file

	fp = NULL;
	singlefile_opened = 0;
	multifile = 0;
	binary = 0;

	// if one file per timestep, replace '*' with current timestep	
	if (fileList[0].find('*') != std::string::npos) {
		multifile = 1;
	}
}

/* ---------------------------------------------------------------------- */

Dump::~Dump()
{
	memory->destroy(dbuf);
	memory->destroy(sbuf);

	// XTC style sets fp to NULL since it closes file in its destructor

	if (multifile == 0 && fp != NULL) {
		fclose(fp);
		fp = NULL;
	}
}

/* ---------------------------------------------------------------------- */

int Dump::styleCheck(const char* file, int line, const char* style, int errorFlag) {
	for (int i = 0; i < styles.size(); i++) {
		if (strcmp(style, styles[i]) == 0) {
			return i;
		}
	}

	if (errorFlag) {
		sprintf(error->ErrCheckBuff, "input style does match pair setting: %s", style);
		error->all(file, line, error->ErrCheckBuff);
	}
	return 0;
}

/* ---------------------------------------------------------------------- */

void Dump::init()
{
	init_style();
}

/* ----------------------------------------------------------------------
generic opening of a dump file
ASCII or binary or gzipped
some derived classes override this function
------------------------------------------------------------------------- */

void Dump::openfile(int ifile)
{
	std::string& ref = fileList[ifile];
	std::string& cur = fileDump[ifile];

	// single file, already opened, so just return
	if (fp || singlefile_opened) return;

	if (multifile) {

		index.clear();
		if (timeFlag) index.append(input->timestr);
		sprintf(error->ErrCheckBuff, "%06d", update->ntimestep);
		index.append(error->ErrCheckBuff);

		size_t p = ref.find('*');
		size_t lenth = ref.size() - p - 1;

		cur = tasksDir + ref.substr(0, p);
		cur += index + ref.substr(p + 1, lenth);
	}
	else {
		singlefile_opened = 1;
		cur = ref;
	}

	// each proc with filewriter = 1 opens a file

	if (binary) {
		fp = fopen(cur.c_str(), "wb");
	}
	else {
		fp = fopen(cur.c_str(), "w");
	}

	if (fp == NULL) {
		ErrorAll("Cannot open dump file: %s", cur.c_str());
	}
}

void Dump::closefile() {
	fclose(fp);
	fp = NULL;
};

double* Dump::requestDbuf(int num){

	ndme = num;	
	if (ndme <= maxdbuf) return dbuf;

	if (ndme > INT_MAX) error->all(FLERR, "Too much per-proc info for DumpImage");
	maxdbuf = ndme;
	memory->destroy(dbuf);
	memory->create(dbuf, maxdbuf, "DumpImage:buf");
	return dbuf;
}


void Dump::sbufChk(const char* file, int line, int off) {
	
	if (off + sLine > maxsbuf) {
		if (maxsbuf + sDelta > INT_MAX) {
			error->all(file, line, "Too much buffered per-proc info for dump");
		}
		maxsbuf += sDelta;
		memory->grow(sbuf, maxsbuf, "dump:sbuf");
	}		
}

void DumpStyle::setDumpTimeLabel(void* pidump, int flag)
{
	Dump* idump = (Dump*)pidump;
	idump->styleCheck(FLERR, "image", 1);

	idump->timeFlag = flag;
}

void DumpStyle::setDumpFirstFlag(void* pidump, int flag)
{
	Dump* idump = (Dump*)pidump;
	idump->styleCheck(FLERR, "image", 1);

	idump->firstFlag = flag;
}

void DumpStyle::setDumpPadStep(void* pidump, int step)
{
	Dump* idump = (Dump*)pidump;
	idump->styleCheck(FLERR, "image", 1);

	idump->padflag = step;
}

