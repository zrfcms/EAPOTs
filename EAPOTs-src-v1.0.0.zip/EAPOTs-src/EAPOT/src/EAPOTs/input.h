#ifndef EAPOT_INPUT_H
#define EAPOT_INPUT_H

#include "pointers.h"
#include <string>
#include <map>

namespace EAPOT_NS {

	class Input : protected Pointers
	{
		friend class Error;
	public:
		Input(class EAPOT *);
		~Input();

		int count_words(const char*);		
		int read_lines_from_file(FILE*, int, int, char*);
		int int_between_brackets(char*& ptr, int varallow);
		FILE* open(char const* _FileName, char const* _Mode);
		void getRange(int n, double* v, double& lo, double& hi);
		
		static int ele2int(const char* ele);
		static const char* int2ele(const int num);
		static double getAtomicMass(const int num);

	public:
		static const char splitWord[];

		double numeric(const char *file, int line, const char *str);
		int inumeric(const char *file, int line, const char *str);

		void numerics(const char* file, int line, char* str, int n, 
			double* data, char const* Delimiter = splitWord, bool chkFlag = true);
		void inumerics(const char* file, int line, char* str, int n, 
			int* data, char const* Delimiter, bool chkFlag = true);
		
		void numerics(const char* file, int line, const char* str, int n, 
			double* data, char const* Delimiter = splitWord, bool chkFlag = true);
		void inumerics(const char* file, int line, const char* str, int n, 
			int* data, char const* Delimiter = splitWord,  bool chkFlag = true);

	public:
		int echo_screen;             // 0 = no, 1 = yes
		int echo_log;                // 0 = no, 1 = yes
		int time_label;		
		char timestr[32];
		std::string lastCommand;		
		void print(const char* buff);

	public: // API
		void setEcho(int screen, int log);
		void setLog(const char* file, const char* mode);

		bool shell_getcwd(char *, int);
		bool shell_cd(const char*);
		bool shell_mkdir(int, const char**);
		bool shell_mv(const char*, const char*);
		bool shell_rm(int, const char**);
		bool shell_rmdir(int, const char**);
		bool shell_putenv(int, const char**);
		static bool exists(const char* parg);
		char* shell_failed_message(const char* cmd, int errnum);
		
	private:
		int tmpBuffSize;
		char* tmpBuff, * tmpBuffCheck(int size);
	};
}

#endif

