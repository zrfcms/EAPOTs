#pragma once

#if defined(_MSC_VER)
	#define EAPOTAPI __declspec(dllexport)
#else
	#define EAPOTAPI
#endif

#include "dump.h"
#include "pair.h"
#include "eapot.h"
#include "dump_external.h"
#include "compute_external.h"
typedef void (*TestFunc)(void*, void*);

struct TestParam {
	int i, * pi, ** p2i;
	double d, * pd, ** p2d;
	const char* s, ** ps;
};

#ifdef __cplusplus
extern "C" {
#endif

EAPOTAPI void eapot_open(int, char**, void**);
EAPOTAPI void eapot_close(void*);
EAPOTAPI void eapot_check(void*, int, int);
EAPOTAPI void eapot_printStyleAPI();
EAPOTAPI void eapot_printStylePythonAPI(const char* file);

// eapot.h
EAPOTAPI void eapot_clear(void*);
EAPOTAPI void eapot_setPythonCallback(void*, PythonCallback, void*);

// input.h
EAPOTAPI void eapot_setEcho(void*, int screen, int log);
EAPOTAPI void eapot_setLog(void*, const char* file, const char* mode);

// force.h
EAPOTAPI void eapot_setMass(void*, int n, double* mass);
EAPOTAPI void eapot_setElement(void*, int n, const char** ele);
EAPOTAPI void* eapot_addPair(void*, const char* style);
EAPOTAPI void* eapot_getPair(void*);
EAPOTAPI const char* eapot_getPotScript(void*, void*);

// update.h
EAPOTAPI void eapot_setTimestep(void*, int);
EAPOTAPI void eapot_setRandomSeed(void*, int);
EAPOTAPI void eapot_setMinimizeLogFlag(void*, int);
EAPOTAPI void eapot_setMinimizeStyle(void*, const char* style);
EAPOTAPI void eapot_runMinimize(void*, void* cost, double etol, double ftol, int nstep, int neval);

// modify.h
EAPOTAPI void* eapot_addCompute(void*, const char* id, const char* style, const char* file);
EAPOTAPI void* eapot_getCompute(void*, const char* id, const char* style);

// output.h
EAPOTAPI void eapot_runDumpOnce(void*);
EAPOTAPI void eapot_delThermoFormat(void*);

EAPOTAPI void* eapot_addDump(void* ptr, int step, const char* id, const char* style, const char* file);
EAPOTAPI void* eapot_getDump(void* ptr, const char* id, const char* style);

#undef APITYPE
#undef APINAME
#define APITYPE void* ptr,
#define APINAME ptr, 

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) EAPOTAPI TYPE eapot_##NAME##PTYPE

#define OUTPUTAPI
#include "extraAPI.h"
#undef  OUTPUTAPI

#include "style_pair.h"
#include "style_dump.h"
#include "style_compute.h"
#include "style_minimize.h"
#undef LIBAPI

#undef APITYPE
#undef APINAME
#define APITYPE
#define APINAME

EAPOTAPI void  test_callback(void*, TestFunc);
EAPOTAPI void  test_vstruct(void*, void*);
EAPOTAPI void  test_struct(void*, TestParam);

#ifdef __cplusplus
}
#endif