#include "eapotaux.h"

using namespace EAPOT_NS;
using namespace std;

double* MathAux::domain_inv_lammps(double* h_inv, double* h) {

	h_inv[0] = 1.0 / h[0];
	h_inv[1] = 1.0 / h[1];
	h_inv[2] = 1.0 / h[2];

	h_inv[3] = -h[3] / (h[1] * h[2]);
	h_inv[4] = (h[3] * h[5] - h[1] * h[4]) / (h[0] * h[1] * h[2]);
	h_inv[5] = -h[5] / (h[0] * h[1]);

	return h_inv;
}

void MathAux::lamda2x_lammps(double* h, int n, double** x)
{
	for (int i = 0; i < n; i++) {
		x[i][0] = h[0] * x[i][0] + h[5] * x[i][1] + h[4] * x[i][2];
		x[i][1] = h[1] * x[i][1] + h[3] * x[i][2];
		x[i][2] = h[2] * x[i][2];
	}
}

void MathAux::x2lamda_lammps(double* h_inv, int n, double** x)
{
	double delta[3];

	for (int i = 0; i < n; i++) {
		delta[0] = x[i][0];
		delta[1] = x[i][1];
		delta[2] = x[i][2];

		x[i][0] = h_inv[0] * delta[0] + h_inv[5] * delta[1] + h_inv[4] * delta[2];
		x[i][1] = h_inv[1] * delta[1] + h_inv[3] * delta[2];
		x[i][2] = h_inv[2] * delta[2];
	}
}

double MathAux::volum33(double* m) {
	double v =
		m[0] * m[4] * m[8] - m[0] * m[5] * m[7] - m[1] * m[3] * m[8]
		+ m[1] * m[5] * m[6] + m[2] * m[3] * m[7] - m[2] * m[4] * m[6];

	return v;
}

bool MathAux::inverse33(double* i, double* m) {

	double pv = volum33(m);
	if (!pv) return false;
	pv = 1.0 / pv;


	i[0] = m[4] * m[8] - m[5] * m[7];
	i[1] = m[2] * m[7] - m[1] * m[8];
	i[2] = m[1] * m[5] - m[2] * m[4];

	i[3] = m[5] * m[6] - m[3] * m[8];
	i[4] = m[0] * m[8] - m[2] * m[6];
	i[5] = m[2] * m[3] - m[0] * m[5];

	i[6] = m[3] * m[7] - m[4] * m[6];
	i[7] = m[1] * m[6] - m[0] * m[7];
	i[8] = m[0] * m[4] - m[1] * m[3];

	for (int k = 0; k < 9; k++) {
		i[k] *= pv;
	}

	return true;
}

void MathAux::productN33(double* C, const int N, double* A, double* b) {

	double B[3][3] = {
		{ b[0], b[3], b[6], },
		{ b[1], b[4], b[7], },
		{ b[2], b[5], b[8], },
	};

	double* iA, * jB, sum;
	for (int i = 0; i < N; i++) {
		iA = &A[i * 3];

		for (int j = 0; j < 3; j++) {
			jB = B[j];

			sum = iA[0] * jB[0] 
				+ iA[1] * jB[1]
				+ iA[2] * jB[2];

			C[i * 3 + j] = sum;
		}
	}
}