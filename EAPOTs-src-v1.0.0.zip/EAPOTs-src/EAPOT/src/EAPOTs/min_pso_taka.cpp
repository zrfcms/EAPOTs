/*Sample Program of Particle Swarm Optimization */
#include "stdlib.h"
#include "string.h"

#include "min_pso_taka.h"
#include "update.h"
#include "modify.h"
#include "memory.h"
#include "error.h"

#include "pair.h"
#include "force.h"
#include "output.h"

#include "option_mini.h"

using namespace EAPOT_NS;

/* Random number generator in [0, 1] */
#define Rand()		((double)rand()/RAND_MAX)


/* The value of inertia weight at t=0 (W_0) and t=T_MAX (W_T) */
#define W_0			0.9
#define W_T			0.4

/* The cognitive parameter (c1) and the social parameter (c2) */
#define c1			2.0
#define c2			2.0

/* Objective function for minimization: problem dependent */
#define better(y1, y2)	(y1<y2)

MinPSOTaka::MinPSOTaka(EAPOT *eapot) : Min(eapot)
{
	styles.push_back("pso/taka");
	iG = 0;
	linestyle = 0;

	X = NULL;
	V = NULL;
	Xbest = NULL;

	Y = NULL;
	Ybest = NULL;

	XG = NULL;
	YG = 1e10;

	Nparticle = 50;
}

/* ---------------------------------------------------------------------- */

MinPSOTaka::~MinPSOTaka()
{
	memory->destroy(X);
	memory->destroy(V);
	memory->destroy(Xbest);
	memory->destroy(Y);
	memory->destroy(Ybest);
	memory->destroy(XG);

	X = NULL;
	V = NULL;
	Xbest = NULL;
	Y = NULL;
	Ybest = NULL;
	XG = NULL;
}

/* ---------------------------------------------------------------------- */

void MinPSOTaka::init()
{
	Min::init();
}

void MiniStyle::setParticleSwarmTakaParticles(int n)
{
	update->minimize->styleCheck(FLERR, "pso/taka", 1);
	((MinPSOTaka*)update->minimize)->Nparticle = n;
}

/* ---------------------------------------------------------------------- */

void MinPSOTaka::setup_style()
{
	memory->destroy(X);
	memory->destroy(V);
	memory->destroy(Xbest);
	memory->destroy(Y);
	memory->destroy(Ybest);
	memory->destroy(XG);

	const int m = Nparticle;
	const int n = nvec;

	memory->create(X, m, n, "MinPSOTaka::X");
	memory->create(V, m, n, "MinPSOTaka::V");
	memory->create(Xbest, m, n, "MinPSOTaka::Xbest");
	memory->create(Y, m, "MinPSOTaka::Y");
	memory->create(Ybest, m, "MinPSOTaka::Ybest");
	memory->create(XG, n, "MinPSOTaka::Xglobal");
}

void MinPSOTaka::UpdateBest(int i){

	temp_memcpy(Xbest[i], X[i], nvec);
	Ybest[i] = Y[i];
}

void MinPSOTaka::UpdateGlobal(int i){
	iG = i;
	temp_memcpy(XG, X[i], nvec);
	YG = Y[i];
}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinPSOTaka::reset_vectors()
{
	double *pX, *pV;
	const int m = Nparticle;
	const int n = nvec;

	pX = X[0];
	pV = V[0];
	temp_memcpy(pX, xvec, n);
	temp_memset0(pV, n);
	Y[0] = func(pX);
	UpdateBest(0);
	UpdateGlobal(0);

	for (int i = 1; i < m; i++) {
		pX = X[i];
		pV = V[i];

		for (int j = 0; j < n; j++) {
			pX[j] = xvec[j] * (0.9 + 0.2*Rand());
			pV[j] = 0.0;
		}
		Y[i] = func(pX);
		UpdateBest(i);
		if (better(Y[i], YG)) UpdateGlobal(i);
	}
	temp_memcpy(xvec, X[0], n);
	ecurrent = YG;
}



// EPS_ENERGY = minimum normalization for energy tolerance

#define EPS_ENERGY 1.0e-8

double MinPSOTaka::currenterr(const int n){

	return 1;

	double t, *xt;
	double maxdelta = 0;
	double Y0 = Y[0];
	double cut = update->etol;
	for (int i = 1; i <= n; i++){
		t = fabs(Y[i] - Y0);
		maxdelta = MAX(maxdelta, t);
		if (maxdelta > cut) return maxdelta;

		xt = X[i];
		double* X0 = X[0];
		for (int j = 0; i < n; i++){
			t = fabs(xt[j] - X0[j]);
			maxdelta = MAX(maxdelta, t);
			if (maxdelta > cut) return maxdelta;
		}
	}
	return maxdelta;
}


int MinPSOTaka::iterate(int maxiter)
{
	int ntimestep;
	double err;
	double *pX, *pV, *pXbest;

	const int m = Nparticle;
	const int n = nvec;

	double w;

	w = W_0;
	for (int iter = 0; iter < maxiter; iter++) {

		ntimestep = ++update->ntimestep;
		niter++;

		eprevious = ecurrent;

		// function evaluation criterion
		if (neval >= update->max_eval) return return_final(MAXEVAL, XG);;

		// energy tolerance criterion
		err = currenterr(n);
		if (err < update->etol) {
			return return_final(ETOL, XG);;
		}

		for (int i = 0; i < m; i++) {
			pX = X[i];
			pV = V[i];
			pXbest = Xbest[i];

			for (int j = 0; j < n; j++) {
				pV[j] = w*pV[j]
					+ c1*Rand()*(pXbest[j] - pX[j])
					+ c2*Rand()*(XG[j] - pX[j]);
				if (pV[j] < -dmax)
					pV[j] = -dmax;
				else if (pV[j] > dmax)
					pV[j] = dmax;
				pX[j] += pV[j];
			}
			Y[i] = func(pX);
			if (better(Y[i], Ybest[i])) {
				if (better(Y[i], YG)) UpdateGlobal(i);
				UpdateBest(i);
			}
		}
		
		w -= (W_0 - W_T) / maxiter;

		ecurrent = YG;

		if (output->next == ntimestep) {
			func(XG); neval--;
			output->write(ntimestep);
		}
	}

	return return_final(MAXITER, XG);;
}
