#include <string.h>
#include "dump_file.h"
#include "output.h"
#include "update.h"
#include "memory.h"
#include "error.h"

#include "force.h"
#include "pair.h"
#include "option_dump.h"

using namespace EAPOT_NS;

/* ---------------------------------------------------------------------- */

DumpFile::DumpFile(EAPOT *lmp, const char* pid, const char* pstyle, const char* pfile)
	: Dump(lmp, pid, pstyle, pfile)
{
	styles.push_back("file");
	if (multifile) {
		for (auto& ifile : fileList)
		if (ifile.find('*') == std::string::npos) {
			ErrorAll("filename %s does not contain the character '*'", ifile.c_str());
		}
	}
}

void DumpStyle::setDumpFileExtra(void* pidump, int num, const char** files) {
	Dump* idump = (Dump*)pidump;
	idump->styleCheck(FLERR, "file", 1);
	((DumpFile*)idump)->setFileExtra(num, files);
}

/* ---------------------------------------------------------------------- */

void DumpFile::setFileExtra(int num, const char** files) {
	for (int i = 0; i < num; i++) {
		fileList.push_back(files[i]);
	}
	fileDump.resize(fileList.size());
}


void DumpFile::init_style()
{
	if (multifile == 0)	error->all(FLERR, "Dump file requires one snapshot per file");
}

/* ---------------------------------------------------------------------- */

void DumpFile::write()
{
	force->pair->write(this);
}

