#ifdef PAIR_CLASS
PairStyle(eam/mishin, PairEAMMishin)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_MISHIN_H
#define EAPOT_PAIR_EAM_MISHIN_H

#include "pair_eam.h"

namespace EAPOT_NS {

	class PairEAMMishin : public PairEAM
	{
	public:
		PairEAMMishin(EAPOT *eapot);
		~PairEAMMishin();

		double emb(int type, double);
		double rho(int itype, int jtype, double);
		double phi(int itype, int jtype, double);

		void setFullParamsStyle();
		void setFreeParamsStyle();
		void extra_check(int);
	private:

		double rc, h, E1, E2, r1, r2, a1, a2, sig;
		double a, r3, r4, b1, b2, F0, F2, q2, q3, q4, Q1, Q2;

		double rs1, rs2, rs3, S1, S2, S3;

		double q1, h17, h16, h13, h12;
		double h9, h8, h5, h4;
		double Q2_3, Q2_2;
		double a1_3, a2_3, b1_3;
		double b2_3, b1_2, b2_2;
		double a1_2, a2_2;

		void function_check();
		void testrun(int type);

	};

}

#endif
#endif
#endif