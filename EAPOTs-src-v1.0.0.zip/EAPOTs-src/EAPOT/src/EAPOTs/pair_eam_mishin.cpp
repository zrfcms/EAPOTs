#include "pair_eam_mishin.h"
#include "float.h"
#include "memory.h"
#include "error.h"
#include "force.h"

using namespace EAPOT_NS;

PairEAMMishin::PairEAMMishin(EAPOT *eapot)
	: PairEAM(eapot)
{
	styles.push_back("eam/mishin");
	eam_fsize = 19;
	eam_csize = 8;


	rc = h = E1 = E2 = r1 = r2 = a1 = a2 = sig = 0;
	a = r3 = r4 = b1 = b2 = F0 = F2 = q2 = q3 = q4 = Q1 = Q2 = 0;

	rs1 = rs2 = rs3 = S1 = S2 = S3 = 0;

	q1 = h17 = h16 = h13 = h12 = 0;
	h9 = h8 = h5 = h4 = 0;
	Q2_3 = Q2_2 = 0;
	a1_3 = a2_3 = b1_3 = 0;
	b2_3 = b1_2 = b2_2 = 0;
	a1_2 = a2_2 = 0;
};

PairEAMMishin::~PairEAMMishin() {

};


void PairEAMMishin::setFullParamsStyle()
{
	int idx = eam_fsize;
	Q1  = paramVec[idx++];
	Q2  = paramVec[idx++];
	rs1 = paramVec[idx++];
	rs2 = paramVec[idx++];
	rs3 = paramVec[idx++];
	S1  = paramVec[idx++];
	S2  = paramVec[idx++];
	S3  = paramVec[idx++];


	Q2_3 = Q2 * Q2 * Q2;
	Q2_2 = Q2 * Q2;

	setFreeParamsStyle();
};

void PairEAMMishin::setFreeParamsStyle()
{
	int idx = 0;
	rc = paramVec[idx++];
	h  = paramVec[idx++];
	E1 = paramVec[idx++];
	E2 = paramVec[idx++];
	r1 = paramVec[idx++];
	r2 = paramVec[idx++];
	a1 = paramVec[idx++];
	a2 = paramVec[idx++];
	sig= paramVec[idx++];
	a  = paramVec[idx++];
	r3 = paramVec[idx++];
	r4 = paramVec[idx++];
	b1 = paramVec[idx++];
	b2 = paramVec[idx++];
	F0 = paramVec[idx++];
	F2 = paramVec[idx++];
	q2 = paramVec[idx++];
	q3 = paramVec[idx++];
	q4 = paramVec[idx++];

	q1 = F0 + F2 * (1.0 / 2.0) + q2 - q3 + q4;
	h17 = 1.0 / pow(h, 1.7E1);
	h16 = 1.0 / pow(h, 1.6E1);
	h13 = 1.0 / pow(h, 1.3E1);
	h12 = 1.0 / pow(h, 1.2E1);
	h9 = 1.0 / (h * h * h * h * h * h * h * h * h);
	h8 = 1.0 / (h * h * h * h * h * h * h * h);
	h5 = 1.0 / (h * h * h * h * h);
	h4 = 1.0 / (h * h * h * h);
	a1_3 = a1 * a1 * a1;
	a2_3 = a2 * a2 * a2;
	b1_3 = b1 * b1 * b1;
	b2_3 = b2 * b2 * b2;
	b1_2 = b1 * b1;
	b2_2 = b2 * b2;
	a1_2 = a1 * a1;
	a2_2 = a2 * a2;

	PairEAM::setFreeParamsStyle();
};

double PairEAMMishin::emb(int type, double lr) {

	if (lr <= 1) {
		double nlr = lr - 1.0;
		double nlr6 = nlr * nlr * nlr * nlr * nlr * nlr;
		double nlr5 = nlr * nlr * nlr * nlr * nlr;
		double nlr4 = nlr * nlr * nlr * nlr;
		double nlr3 = nlr * nlr * nlr;
		double nlr2 = nlr * nlr;
		double F2nlr2 = F2 * nlr2 * (1.0 / 2.0);
		double res = F0 + F2nlr2 + nlr3 * q1 + nlr4 * q2 + nlr5 * q3 + nlr6 * q4;
		return res;
	}
	else {
		double nlr = lr - 1.0;
		double nlr4 = nlr * nlr * nlr * nlr;
		double nlr3 = nlr * nlr * nlr;
		double nlr2 = nlr * nlr;
		double mQ2nlr3 = 1.0 / (Q2 * nlr3 + 1.0);
		double F2nlr2 = F2 * nlr2 * (1.0 / 2.0);
		double F0F2nlr2Q1nlr4nlr3q1 = F0 + F2nlr2 + Q1 * nlr4 + nlr3 * q1;
		double res = F0F2nlr2Q1nlr4nlr3q1 * mQ2nlr3;
		return res;
	}

	return DBL_MAX;
};


double PairEAMMishin::rho(int itype, int jtype, double r) {

	if (r >= rc || r >= cutmax) return 0;
	double drc = r - rc;
	double drc4 = drc * drc * drc * drc;
	double dr3 = r - r3;
	double dr4 = r - r4;
	double mdrc4h4 = 1.0 / (drc4 * h4 + 1.0);
	double dr3_2 = dr3 * dr3;
	double expb2dr4 = exp(-b2 * dr4);
	double expb1dr3_2 = exp(-b1 * dr3_2);
	double res = drc4 * h4 * mdrc4h4 * (expb2dr4 + a * expb1dr3_2);
	return res;
};

double PairEAMMishin::phi(int itype, int jtype, double r) {

	double drc = r - rc;
	double drc4 = drc * drc * drc * drc;
	double dr1 = r - r1;
	double dr2 = r - r2;
	double mdrc4h4 = 1.0 / (drc4 * h4 + 1.0);
	double expa1dr1 = exp(-a1 * dr1);
	double exp2a1dr1 = exp(a1 * dr1 * -2.0);
	double expa2dr2 = exp(-a2 * dr2);
	double exp2a2dr2 = exp(a2 * dr2 * -2.0);
	double res = -drc4 * h4 * mdrc4h4 * (E1 * (2 * expa1dr1 - exp2a1dr1) - sig + E2 * (2 * expa2dr2 - exp2a2dr2));

	double dr;
	if (r < rs1) {
		dr = rs1 - r;
		dr2 = dr * dr;
		res -= S1 * dr2 * dr2;
	}
	if (r < rs2) {
		dr = rs2 - r;
		dr2 = dr * dr;
		res -= S2 * dr2 * dr2;
	}
	if (r < rs3) {
		dr = rs3 - r;
		dr2 = dr * dr;
		res -= S3 * dr2 * dr2;
	}

	return res;
}


#define Nf	3
#define Np	6

#define Nlr	3
#define Nr	3
void PairEAMMishin::function_check() {

	const char* name = "EAMMishin";
	double fChk[Nf], rChk[Np], fRef[] = {
	  -2.0163901562500000e+00, -2.2823500000000001e+00, -1.9095538461538459e+00,
	}, rRef[] = {
	   1.1246375397444541e-01, -2.6742628100722653e-02,
	   4.9207278194619807e-02, -1.6654182604648959e-01,
	   1.4608226047611705e-03, -5.0119533404479541e-03,
	};


	double lrlist[Nlr] = { 0.5, 1.0, 2.0 };
	double rlist[Nr] = { 2.3, 2.8, 4.5 };

	int idx = 0;
	error->add_chklog(0, name, "");

	/* df check */
	idx = 0;
	for (int ir = 0; ir < Nlr; ir++) {
		fChk[idx++] = emb(1, lrlist[ir]);
	}
	error->check(FLERR, Nf, fChk, fRef, 1, name, "f", 8e-14, 2e-14, 3.4884264516384102e-16, 3.4884264516384102e-16);


	/* dr dp check */
	idx = 0;
	for (int ir = 0; ir < Nlr; ir++) {		
		rChk[idx++] = rho(1, 1, rlist[ir]);
		rChk[idx++] = phi(1, 1, rlist[ir]);
	}
	error->check(FLERR, Np, rChk, rRef, 1, name, "rp", 5e-13, 5e-14, 2.018672000712579e-13, 2.0347809641380513e-13);
}


void PairEAMMishin::testrun(int type) {

	const char* name = "EAMMishin";
	error->add_chklog(0, name, "");

#define N 5
	double ref[N] = {
		3.614925067741947, 3.540218330286347,
		169.89814621718736, 122.6062458516619, 76.20610755869023
	};

	addMDCheckCubic(FLERR, 0, name, "Box", &ref[0], 3.3068943901476679e-10, 3.3069106975027219e-10);
	addMDCheckCubic(FLERR, 1, name, "Ela", &ref[2], 1.2347618891008496e-06, 2.3599409649157786e-06);

#undef N
}


void PairEAMMishin::extra_check(int) {
	addMDComputeFcc();
	runMDCompute(-1, RunDump | RunEcho, 10, CuFccCost, FccChk, "nms", "dump.*.eam");
	function_check();
	testrun(0);
}

