#ifdef PAIR_CLASS
PairStyle(fs/dai, PairEAMDai)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_EAM_DXD_H
#define EAPOT_PAIR_EAM_DXD_H

#include "pair_eam.h"


namespace EAPOT_NS {

	class PairEAMDai : public PairEAM
	{
	public:
		PairEAMDai(EAPOT *eapot);
		~PairEAMDai();

		double emb(int type, double);
		double rho(int itype, int jtype, double);
		double phi(int itype, int jtype, double);

		void setFullParamsStyle();
		void setFreeParamsStyle();
		void extra_check(int);

	private:
		double rc1, rc2, c0, c1, c2, c3, c4;
		double a, b, m, n, r, r0;

		double b2, b3, r0T, r02T, r03T, r04T;

		void function_check();
		void testrun(int type);
	};

}

#endif
#endif
#endif