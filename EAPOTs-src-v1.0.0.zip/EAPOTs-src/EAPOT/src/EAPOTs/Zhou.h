#ifndef ZHOU_H
#define ZHOU_H

extern int fZhousi[3][2];
extern int fZhoudsi[3][3];
extern double(*pfZhou[14])(const double x[15]);
extern double(*pdfZhou[156])(const double x[15]);

extern bool fdF0[2][3][13];
extern bool fdf0[1][3][13];
extern bool fdp0[1][3][13];

extern double(*psZhou[14])(const double x[15]);
extern double(*pdsZhou[156])(const double x[15]);

#endif