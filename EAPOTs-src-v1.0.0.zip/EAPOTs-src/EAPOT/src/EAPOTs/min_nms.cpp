#include "stdlib.h"
#include "string.h"

#include "min_nms.h"
#include "update.h"
#include "modify.h"
#include "memory.h"
#include "error.h"
#include "pair.h"
#include "force.h"
#include "output.h"

using namespace EAPOT_NS;

//#define MinNMSDevTest

int ysortfunc(const void *p, const void *q)
{
	return (((ysortstruct*)p)->y > ((ysortstruct*)q)->y ? 1 : -1);
}
/* ---------------------------------------------------------------------- */

MinNMS::MinNMS(EAPOT *eapot) : Min(eapot)
{
	styles.push_back("nms");
	linestyle = 0;

	pXf = NULL;
	pXs = NULL;
	X = NULL;
	Y = NULL;
	ysort = NULL;
	proc_state = 0;
	Xp = NULL;


}

/* ---------------------------------------------------------------------- */

MinNMS::~MinNMS()
{
	if (pXs) pXs[0] = pXf;
	memory->destroy(pXs);
	memory->destroy(Y);
	memory->destroy(ysort);

	pXs = NULL;
	pXf = NULL;
	X = NULL;
	Y = NULL;
	Xp = NULL;
}

/* ---------------------------------------------------------------------- */

void MinNMS::init()
{
	Min::init();

}

/* ---------------------------------------------------------------------- */

void MinNMS::setup_style()
{
	if (pXs) pXs[0] = pXf;
	memory->destroy(pXs);
	memory->destroy(Y);
	memory->destroy(ysort);

#ifdef MinNMSDevTest
	nvec = 3;
#endif

	const int n = nvec;
	const int np = n + 1;

	memory->create(pXs, np + 3, n, "MinNMS::X");
	memory->create(Y, np, "MinNMS::Y");
	memory->create(ysort, np, "MinNMS::ysort");
	X = pXs;
	pXf = pXs[0];
}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinNMS::reset_vectors()
{
	const int n = nvec;
	if (update->nsteps) {
		double xvecii0;
		double initadd = 1.05;
		//X[i] = x0; X[i][i] = x0 * 1.05; Y[i] = f(X[i]);
		for (int i = 0; i < n; i++) {
			xvecii0 = xvec[i];

			if (xvecii0)
				xvec[i] *= initadd;
			else
				xvec[i] = initadd*initadd;

			temp_memcpy(X[i], xvec, n);
			Y[i] = func(X[i]);

			xvec[i] = xvecii0;
		}

		temp_memcpy(X[n], xvec, n);
		Y[n] = func(X[n]);

		listsort();//sort first
	}
	// If you only run 0 times, then there is no need to initialize
	else {
		for (int i = 0; i < n; i++) {
			temp_memcpy(X[i], xvec, n);
			Y[i] =0;
		}
		temp_memcpy(X[n], xvec, n);
		Y[n] = 0;
	}
}


using namespace EAPOT_NS;

// EPS_ENERGY = minimum normalization for energy tolerance

#define EPS_ENERGY 1.0e-8

/* ----------------------------------------------------------------------
minimization via Nelder-Mead simplex algorithm
------------------------------------------------------------------------- */

const char* MinNMS::GetProcedure(int type){
	switch (type){
	case 0:	
		return "initial simplex";
	case 1:
		return "expand";
	case 2:	
		return "reflect";
	case 3:	
		return "shrink";
	case 4:	
		return "contract inside";
	case 5:	
		return "contract outside";
	default:
		error->all(FLERR, "Illegal Procedure type");
	}
	return NULL;
}

void MinNMS::listsort(){
	const int np = nvec + 1;
	for (int i = 0; i < np; i++){
		ysort[i].y = Y[i];
		ysort[i].x = X[i];
	}

	size_t lenth = sizeof(ysortstruct);
	qsort(ysort, np, lenth, ysortfunc);

	for (int i = 0; i < np; i++){
		Y[i] = ysort[i].y;
		X[i] = ysort[i].x;
	}
}


void MinNMS::accept(double* x, double y, int state){
	proc_state = state;

	temp_memcpy(Xp, x, nvec);
	Y[nvec] = y;
}

inline void minnms_swap(double &a, double &b){
	double t = a;
	a = b;
	b = t;
}

inline void minnms_swap(double* &a, double* &b){
	double *t = a;
	a = b;
	b = t;
}

double MinNMS::expand(double* xe, double* m, const int n){
	for (int j = 0; j < n; j++)
		xe[j] = 3 * m[j] - 2 * Xp[j];
	return func(xe);
}

double MinNMS::reflect(double* xr, double* m, const int n){
	for (int j = 0; j < n; j++)
		xr[j] = 2 * m[j] - Xp[j];
	return func(xr);
}

double MinNMS::contract(double* xc, double* m, double* x, const int n){
	for (int j = 0; j < n; j++)
		xc[j] = (m[j] + x[j])*0.5;
	return func(xc);
}

void MinNMS::shrink(const int n){
	double* X0 = X[0];
	for (int i = 1; i <= n; i++){
		for (int j = 0; j < n; j++)
			X[i][j] = (X[i][j] + X0[j])*0.5;
		Y[i] = func(X[i]);
	}

	listsort();//
	proc_state = 3;
}

void MinNMS::average_meams(double* m, const int n){
	temp_memcpy(m, X[0], n);
	for (int i = 1; i < n; i++)
	for (int j = 0; j < n; j++)
		m[j] += X[i][j];

	for (int j = 0; j < n; j++) m[j] /= n;
}
double MinNMS::currenterr(const int n){

	double t, *xt;
	double maxdelta = 0;
	double Y0 = Y[0];
	double cut = update->etol;
	for (int i = 1; i <= n; i++){
		t = fabs(Y[i] - Y0);
		maxdelta = MAX(maxdelta, t);
		if (maxdelta > cut) return maxdelta;

		xt = X[i];
		double* X0 = X[0];
		for (int j = 0; i < n; i++){
			t = fabs(xt[j] - X0[j]);
			maxdelta = MAX(maxdelta, t);
			if (maxdelta > cut) return maxdelta;
		}
	}
	return maxdelta;
}


int MinNMS::iterate(int maxiter)
{
	int ntimestep;


	const int n = nvec;
	const int np = nvec + 1;

	double *xt, *m, Yp, err;

	double *xr, *xe, *xc;
	double yr, ye, yc;

	Xp = X[n];
	m = X[np];
	xr = X[np + 1];
	xt = X[np + 2];
	xe = xc = xt;	

	bool doShrink = false;

	for (int iter = 0; iter < maxiter; iter++) {
		ntimestep = ++update->ntimestep;
		niter++;

		eprevious = ecurrent;

		Yp = Y[n];

//#ifdef MinNMSDevTest
//		printf("%3d %3d %20.17g %s\n", iter, neval, Y[0], GetProcedure(proc_state));
//#endif
		// function evaluation criterion
		if (neval >= update->max_eval) return return_final(MAXEVAL, X[0]);

		// energy tolerance criterion
		err = currenterr(n);
		if (err < update->etol) {
#ifdef MinNMSDevTest
			check();
#endif		
			return return_final(ETOL, X[0]);
		}
		
		average_meams(m, n);
		yr = reflect(xr, m, n);

		//If f(r) < f(x(0))
		if (yr < Y[0]){
			ye = expand(xe, m, n);

			if (ye < yr)
				accept(xe, ye, 1);		// accept s and terminate the iteration. Expand			
			else			
				accept(xr, yr, 2);		// accept r and terminate the iteration. Reflect		
		}
		else if (yr < Y[n - 1]){		// If f(x(1)) �� f(r) < f(x(n))	
			accept(xr, yr, 2);			// accept r and terminate this iteration.Reflect
		}
		else if (yr < Yp){				// If f(r) < f(x(n + 1)) (that is, r is better than x(n + 1)),
			yc = contract(xc, m, xr, n);

			if (yc < yr)				// If f(c) < f(r)				
				accept(xc, yc, 5);		// accept c and terminate the iteration.Contract outside			
			else						// Otherwise, continue with Step 7 (Shrink).
				doShrink = true;
		}
		else{
			yc = contract(xc, m, Xp, n);

			if (yc < Yp)				// If f(c) < f(x(n + 1))				
				accept(xc, yc, 4);		// accept c and terminate the iteration.Contract inside
			else			
				doShrink = true;		// Otherwise, continue with Step 7 (Shrink).
		}

		if (doShrink){					// Shrink
			doShrink = false;
			shrink(n);
		}
		else{
			for (int k = n, km; k > 0; k--){
				km = k - 1;
				if (Y[k] > Y[km]) continue;	//no need to swap
				minnms_swap(Y[k], Y[km]);
				minnms_swap(X[k], X[km]);
			}
		}
		Xp = X[n];

		ecurrent = Y[0];

		if (output->next == ntimestep) {
			func(X[0]);
			output->write(ntimestep);
		}
	}
	return return_final(MAXITER, X[0]);
}



//double MinNMS::chk_func(double* x)
//{
//	double sx = x[0];
//	double sy = x[1];
//	double sz = x[2];
//	double su = (5 - (sx*sx + sy*sy + sz*sz))*cos(sx * 100) * sin(sy * 100) * cos(sz * 100);
//	return su;
//}
//
//void MinNMS::check(){
//	if (neval != 132)
//		error->all(FLERR, "neval != 132");
//
//	double pchk[] = { Y[0], Y[0] };
//	double pref[] = { -26.726963171474583, -26.726963171472526 };
//	error->check(FLERR, 2, pchk, pref, 0, "MinNMS", "check", 1e-13, 1e-13, 0.123456789, 0.123456789);
//	printf("MinNMSDevTest: %.4e ]n", error->chk.max);
//
//	//error->check(chk, "MinNMSDevTest", Y[0], -26.726963171474583, 1e-15);
//	//printf("MinNMSDevTest: %.4e /", chk.max);
//	//error->check(chk, "MinNMSDevTest", Y[0], -26.726963171472526, 1e-13);
//	//printf(" %.4e \n", chk.max);
//}

/*
	ErrorCheck& check(ErrorCheck& chk, const char* str,	const double dchk, const double dref, const double cut){
		double err = fabs(1 - dchk / dref);
		if (err > cut) {
			sprintf(ErrCheckBuff, "%s check error :%25.16e : %25.16e : %25.16e\n", str, dchk, dref, err);
			error->all(FLERR, ErrCheckBuff);
		}
		chk.Merge(1, err, err);
		return chk;
	}
*/