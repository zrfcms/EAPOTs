#ifdef DUMP_CLASS
DumpStyle(external, DumpExternal)
#else

#ifdef LIBAPI
LIBAPI(void, setDumpExternalFile, (APITYPE void* pDump, void* pDumpRef), (APINAME pDump, pDumpRef));
LIBAPI(void, setDumpExternalImage, (APITYPE void* pDump, void* pDumpRef), (APINAME pDump, pDumpRef));
LIBAPI(void, setDumpExternalScript, (APITYPE void* pDump, const char* script), (APINAME pDump, script));
LIBAPI(void, setDumpExternalCallback, (APITYPE void* pDump, StrCallback callback, void* caller), (APINAME pDump, callback, caller));
#else

#ifndef EAPOT_DUMP_CHECK_H
#define EAPOT_DUMP_CHECK_H

#include "dump.h"

#include <string>
#include <vector>

struct DumpCallbackParam {
	int mode, step, nparam;
	double* param, costValue;

	int nfile;
	const char** files;
	const char* figure;
};

namespace EAPOT_NS {

	class DumpExternal : public Dump {
	public:
		DumpExternal(EAPOT *, const char* id, const char* style, const char* file);

		std::string pythonScript;
		const class DumpFile* fileDump;		// Pointer of dump for output file		
		const class DumpImage* imageDump;	// Pointer of dump for output image		

		void* caller;
		StrCallback callback;
		DumpCallbackParam param;

	protected:
		void write();
		void init_style();

		std::vector<const char*> files;
		DumpCallbackParam* updateParam(int mode);
	};

}

#endif
#endif
#endif
