#ifdef MINIMIZE_CLASS
MinimizeStyle(nms, MinNMS)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_MIN_SIMPLEX_H
#define EAPOT_MIN_SIMPLEX_H

#include "min.h"

namespace EAPOT_NS {

	struct ysortstruct
	{
		double y;
		double* x;
	};

	class MinNMS : public Min {
		friend class MiniStyle;
	public:
		MinNMS(class EAPOT *);
		~MinNMS();
		void init();
		void setup_style();
		void reset_vectors();
		int iterate(int);

	protected:
		// vectors needed by linesearch minimizers
		// xvec,fvec are stored by Pair class

		double **X, *pXf, **pXs;
		double *Y, *Xp;
		int proc_state;
		ysortstruct* ysort;

		void listsort();
		void accept(double*, double, int);
		const char* GetProcedure(int);

		double currenterr(const int n);
		void average_meams(double*, const int n);
		double expand(double*, double*, const int n);
		double reflect(double*, double*, const int n);
		double contract(double*, double*, double*, const int n);
		void shrink(const int n);
	};

}

#endif
#endif
#endif


/*
Reference
Lagarias, J. C., J. A. Reeds, M. H. Wright, and P. E. Wright. 
��Convergence Properties of the Nelder-Mead Simplex Method in Low Dimensions.�� 
SIAM Journal of Optimization, Vol. 9, Number 1, 1998, pp. 112�C147.
*/