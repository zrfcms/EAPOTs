#ifdef DUMP_CLASS
DumpStyle(file, DumpFile)
#else

#ifdef LIBAPI
LIBAPI(void, setDumpFileExtra, (APITYPE void* pDump, int n, const char** files), (APINAME pDump, n, files));
#else

#ifndef EAPOT_DUMP_FILE_H
#define EAPOT_DUMP_FILE_H

#include "dump.h"

namespace EAPOT_NS {

	class DumpFile : public Dump {
	public:
		DumpFile(EAPOT *, const char* id, const char* style, const char* file);
		void setFileExtra(int n, const char** files);
	protected:
		void init_style();
		void write();
	};

}

#endif
#endif
#endif
