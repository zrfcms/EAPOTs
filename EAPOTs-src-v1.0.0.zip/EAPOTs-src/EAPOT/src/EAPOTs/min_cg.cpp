#include <math.h>
#include <string.h>
#include "min_cg.h"
#include "update.h"
#include "output.h"

using namespace EAPOT_NS;

// EPS_ENERGY = minimum normalization for energy tolerance

#define EPS_ENERGY 1.0e-8

/* ---------------------------------------------------------------------- */

MinCG::MinCG(class EAPOT *eapot)
	: MinLineSearch(eapot) 
{
	styles.push_back("cg");
	dmax = 0.1;
}

/* ----------------------------------------------------------------------
minimization via conjugate gradient iterations
------------------------------------------------------------------------- */

int MinCG::iterate(int maxiter)
{
	int i, fail, ntimestep;
	double beta, gg, dotall[2];

	// nlimit = max # of CG iterations before restarting
	// set to ndoftotal unless too big

	int nlimit = static_cast<int> (MIN(INT_MAX, nvec));

	// initialize working vectors

	for (i = 0; i < nvec; i++) h[i] = g[i] = -fvec[i];
	gg = fnorm_sqr();

	for (int iter = 0; iter < maxiter; iter++) {
		ntimestep = ++update->ntimestep;
		niter++;

		// line minimization along direction h from current atom->x
		eprevious = ecurrent;
		fail = (this->*linemin)(ecurrent, alphaFinal);
		if (fail) return fail;

		// function evaluation criterion
		if (neval >= update->max_eval) return MAXEVAL;
		// energy tolerance criterion
		if (fabs(ecurrent - eprevious) <
			update->etol * 0.5*(fabs(ecurrent) + fabs(eprevious) + EPS_ENERGY))
			return ETOL;

		// force tolerance criterion
		dotall[0] = dotall[1] = 0.0;
		for (i = 0; i < nvec; i++) {
			dotall[0] += fvec[i] * fvec[i];
			dotall[1] += -fvec[i] * g[i];
		}
		if (dotall[0] < update->ftol*update->ftol) return FTOL;

		// update new search direction h from new f = -Grad(x) and old g
		// this is Polak-Ribieri formulation
		// beta = dotall[0]/gg would be Fletcher-Reeves
		// reinitialize CG every ndof iterations by setting beta = 0.0

		beta = MAX(0.0, (dotall[0] - dotall[1]) / gg);
		if ((niter + 1) % nlimit == 0) beta = 0.0;
		gg = dotall[0];
		for (i = 0; i < nvec; i++) {
			g[i] = -fvec[i];
			h[i] = g[i] + beta*h[i];
		}

		// reinitialize CG if new search direction h is not downhill
		dotall[0] = 0.0;
		for (i = 0; i < nvec; i++) dotall[0] += g[i] * h[i];
		if (dotall[0] <= 0.0) {
			for (i = 0; i < nvec; i++) h[i] = g[i];
		}

		if (output->next == ntimestep) {
			output->write(ntimestep);
		}
	}

	return MAXITER;
}
