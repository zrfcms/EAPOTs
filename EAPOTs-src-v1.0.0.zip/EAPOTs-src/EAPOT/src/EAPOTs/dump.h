#ifdef DUMP_CLASS
#else

#ifdef LIBAPI
LIBAPI(void, setDumpTimeLabel, (APITYPE void* pDump, int flag), (APINAME pDump, flag));
LIBAPI(void, setDumpFirstFlag, (APITYPE void* pDump, int flag), (APINAME pDump, flag));
LIBAPI(void, setDumpPadStep,   (APITYPE void* pDump, int step), (APINAME pDump, step));
#else

#ifndef EAPOT_DUMP_H
#define EAPOT_DUMP_H

#include <cstdio>
#include <string>
#include <vector>
#include "pointers.h"

namespace EAPOT_NS {

	class Dump : protected Pointers {
		friend class DumpStyle;
	public:
		std::string id;							// user-defined name of Dump
		std::vector<const char*> styles;		// style of Dump
		std::vector<std::string> fileList;		// user-specified file
		std::vector<std::string> fileDump;		// user-specified file with index

		std::string index;						// index for each dump file
		std::string tasksDir;					// Dir for save dump files. default = "task/"

		int timeFlag;							// 0 if no time in file name, 1 if yes
		int firstFlag;							// 0 if no initial dump, 1 if yes initial dump
		int clearstep;							// 1 if dump invokes computes, 0 if not
		int singlefile_opened;					// 1 = one big file, already opened, else 0

		std::string dumpHeadinfo;				// dump thermo first print
		std::string dumpAbstract;				// dump thermo print info

		int sLine, sDelta;

		int styleCheck(const char* file, int line, const char* style, int errorFlag);
		Dump(class EAPOT *, const char* id, const char* style, const char* file);		
		virtual ~Dump();
		void init();

		void openfile(int ifile);
		void closefile();

		void sbufChk(const char* file, int line, int off);
		double* requestDbuf(int);
		
		virtual void write() = 0;

	public:

		FILE *fp;                  // file to write dump to
		
		int ndme, maxdbuf;         // # of double data, size of dbuf
		double *dbuf;              // memory for double format

		int nsme, maxsbuf;         // # of char data, size of sbuf
		char *sbuf;                // memory for string format

	protected:

		int binary;                // 1 if dump file is written binary, 0 no
		int multifile;             // 0 = one big file, 1 = one file per timestep
		int padflag;               // timestep padding in filename		

		virtual void init_style() = 0;
	};

}

#endif
#endif
#endif

