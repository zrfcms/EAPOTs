#ifdef COMPUTE_CLASS
ComputeStyle(energy, ComputeEnergy)
#else

#ifdef LIBAPI
LIBAPI(void, setComputeEnergyTriclinic, (APITYPE void* pComp, int flag), (APINAME pComp, flag));
LIBAPI(void, setComputeEnergyMinimize, (APITYPE void* pComp, double etol, double ftol, int niter, int nstep), (APINAME pComp, etol, ftol, niter, nstep));
LIBAPI(void, setComputeEnergyDumpStep, (APITYPE void* pComp, int dumpStep), (APINAME pComp, dumpStep));
LIBAPI(void, setComputeEnergyRunScript, (APITYPE void* pComp, const char* script), (APINAME pComp, script));
LIBAPI(void, setComputeEnergyInitScript, (APITYPE void* pComp, const char* script), (APINAME pComp, script));
LIBAPI(void, setComputeEnergyScreenFile, (APITYPE void* pComp, const char* pfile), (APINAME pComp, pfile));
LIBAPI(void, setComputeEnergyLogFile, (APITYPE void* pComp, const char* pfile), (APINAME pComp, pfile));
LIBAPI(void, setComputeEnergyEcho, (APITYPE void* pComp, const char* mode), (APINAME pComp, mode));
LIBAPI(void, setComputeEnergyEnergyAtom, (APITYPE void* pComp, int atomflag), (APINAME pComp, atomflag));
LIBAPI(void, setComputeEnergyVirial, (APITYPE void* pComp, int atomflag, int globalflag), (APINAME pComp, atomflag, globalflag));
LIBAPI(void, setComputeEnergyRefFile, (APITYPE void* pComp, const char* pfile), (APINAME pComp, pfile));
LIBAPI(void, setComputeEnergyNoRelax, (APITYPE void* pComp), (APINAME pComp));
LIBAPI(void, setComputeEnergyRelaxAtom, (APITYPE void* pComp, int* flag), (APINAME pComp, flag));
LIBAPI(void, setComputeEnergyRelaxBox, (APITYPE void* pComp, const char* mode, double* sts), (APINAME pComp, mode, sts));
LIBAPI(void, setComputeEnergyReload, (APITYPE void* pComp, int flag), (APINAME pComp, flag));
LIBAPI(void, setComputeEnergyUseMaxForce, (APITYPE void* pComp, int flag), (APINAME pComp, flag));
LIBAPI(void, setComputeEnergyRemapStyle, (APITYPE void* pComp, void* pCompRef, const char* mode), (APINAME pComp, pCompRef, mode));
LIBAPI(void, setComputeEnergyRemapCustom, (APITYPE void* pComp, void* pCompRef, int* mode), (APINAME pComp, pCompRef, mode));
LIBAPI(void, setComputeEnergyTiltLimit, (APITYPE void* pComp, int flag), (APINAME pComp, flag));
#else

#ifndef EAPOT_COMPUTE_ENERGY_H
#define EAPOT_COMPUTE_ENERGY_H

struct ComputeEnergyParam {
	const char* id;
	int atomNum;

	double energy, Ec;
	double lattice[6], stress[6];
	double energyCost, forceCost, virialCost;
	double rhoAve, embAve;

	int* tag, * type;
	double* pos;

	double* energyV, * forceV, * virialV;
	double* energyW, * forceW, * virialW;
	double* energyR, * forceR, * virialR;
};

#include "compute.h"
#include "md_fit_set.h"

#include <string>

#define NRefAtomKey			64
#define COMPUTE_LAMMPS_BUFF 128

using namespace std;

namespace EAPOT_NS {

	enum class CostTarget {
		ENERGY, FORCE, VIRIAL
	};

	class ComputeEnergy :
		public Compute
	{
		friend class Thermo;
		friend class CompStyle;
		friend class ComputeElastic;
	public:
		ComputeEnergy(EAPOT* eapot, const char* pid, const char* pstyle, const char* pfile);
		~ComputeEnergy();

		class ComputeEnergy* remapRefInstance;

		int dumpStep;					// number of dump step
		int saveRelaxFlag;				// save the atom snap after relax, e.g. for elastic compute
		int reloadFlag; 				// reload initial atom snap from atom data file		
		int remapMode[6];				// remap matehod, xyz or volumn

		int relaxAtomFlag[3];			// relax atoms
		int relaxBoxMode; 				// relax mode, iso, aniso, full
		int tiltLimitFlag;				// tilt value = small(1) or large(0)
		int triclinicFlag;				// open triclinic freedom for domain box, e.g. for elastic compute
		int useMaxForceFlag;			// only use max force in force calculation

		void* md;						// core md API
		ComputeEnergyParam param;
		string screen, log, echo, modelName;	// md open settings
		string CustomRunScript, CustomInitScript;

		int iter, step;					// relax items
		double etol, ftol;				// relax precision
		double relaxStressTarget[6];	// relax target
		
	public:		
		virtual void init();		
		virtual void compute();
		virtual void export_pair();
		virtual void extracheck(int);

	private:
		// load refEnergy/Force/VirialFlag from reference file
		string refWeightValueFile;
		void setupRefWeightValue(tagint num, tagint* idx);
		int parseRefWeightValueFile(char*, std::string&);
		void readRefWeightValueFile(int nwords, int start, int n, char* buf);

		void snapAndReferenceMemDestroy();
		void snapAndReferenceMemCreate(tagint);

	private:

		// 1. Ref data: data from reference file		
		std::vector<tagint> refTag;									// atom Tag		
		std::vector<int> atomRelaxMode;								// relax atom configuration

		std::vector<double> refEnergyValue, refEnergyWeight;		// Fitting targets/weights for Energy
		std::vector<double> refForceValue, refForceWeight;			// Fitting targets/weights for Force
		std::vector<double> refVirialValue, refVirialWeight;		// Fitting targets/weights for Virial


		// 2. Sort data:
		tagint refNum, tagmin, tagmax;								// atom tags for sort
		std::vector<tagint> permute, current, Tag2Idx;				// sort buff

		void sort(tagint* tag, int idx = -1);						// sort atoms sequence for reference data
		void copy_ref(int i, int j);								// copy data
		static bool sortIsEqual(tagint, tagint*, tagint*);			// determind if sort needed: if refTag[i]!=idx[i]


		// 3. Cost function calculation				
		int cost_mode[NRefAtomKey];									// 0. weight * (cal/ref - 1)^2	 normal   mode
																	// 1. weight * (cal - ref)^2	 absolute mode			
		double computeCostTemplate(double* cal, CostTarget type);	// compute cost value

		// evaluate settings: if eval error of atom energy, global virial, atom virial
		int evalEnergyAtom, evalVirialGlobal, evalVirialAtom;

		// reference file information, if atom energy, force, virial contains in reference file
		int refContainTag, refContainRelax, refContainEnergy, refContainForce, refContainVirial;


	};

}

#endif
#endif
#endif
