#include "min_powell.h"
#include "math.h"
#include "eapot_math.h"

#include "memory.h"
#include "error.h"
#include "update.h"
#include "pair.h"
#include "force.h"
#include "output.h"

#include "min_chkfunc.h"
#include "option_mini.h"

using namespace EAPOT_NS;

MinPowell::MinPowell(EAPOT *eapot) : Min(eapot)
{
	styles.push_back("powell");
	linestyle = 0;

	dmax = 1e-3;
	dir = NULL;
	X = NULL; 
	X0 = NULL;

	gbuff = NULL;
	gdir = NULL;
	gX = NULL;

	linemin = &MinPowell::fminexp;
}

MinPowell::~MinPowell()
{
	memory->destroy(dir);
	memory->destroy(gX);
	memory->destroy(gbuff);
	memory->destroy(X);
	memory->destroy(X0);
}


void MinPowell::init()
{
	Min::init();
}

/* ---------------------------------------------------------------------- */

void MinPowell::setup_style()
{
	memory->destroy(dir);
	memory->destroy(gX);
	memory->destroy(gbuff);
	memory->destroy(X0);

	memory->create(dir, nvec + 1, nvec, "MinDEA::dir");
	memory->create(gX, nvec, "MinDEA::gX");
	memory->create(gbuff, nvec, "MinDEA::gbuff");

	memory->create(X, nvec, "MinDEA::X");
	memory->create(X0, nvec, "MinDEA::X0");

}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinPowell::reset_vectors()
{
	temp_memset0(dir[0], (nvec + 1) * nvec);
	for (int i = 0; i < nvec; i++)
		dir[i][i] = 1.0;

	temp_memcpy(X, xvec, nvec);
	temp_memcpy(X0, xvec, nvec);
}

/****************************************************************
*  differential evolution
****************************************************************/


int MinPowell::iterate(int maxiter)
{
	int ntimestep = 0;
	const int ndim = force->pair->get_fsize();

	const double ftol = update->ftol*update->ftol;

	double lamda;
	double F0, F;
	double F_new;
	double dirnorm;
	F = F0 = ecurrent;

	int m;
	double dfmin;

	for (int iter = 0; iter < maxiter; iter++) {
		ntimestep = ++update->ntimestep;
		niter++;

		eprevious = ecurrent;

		// function evaluation criterion
		if (neval >= update->max_eval) return return_final(MAXEVAL, NULL);

		m = 0;
		dfmin = 0;
		for (int i = 0; i < ndim; i++){
			F_new = linesearch(F, lamda, X, dir[i]);

			if (F_new - F <= dfmin){
				m = i;
				dfmin = F_new - F;
			}
			F = F_new;
		}
		if (dis2(X, X0, nvec) < ftol) return return_final(FTOL, X);

		// (3)
		for (int i = 0; i < ndim; i++){
			dir[ndim][i] = X[i] - X0[i];
		}
		dirnorm = normalize(dir[ndim], ndim);
		if (dirnorm <= 0) return return_final(FTOL, X);

		F_new = linesearch(F, lamda, X, dir[ndim]);
		F = F_new;
		if (dis2(X, X0, nvec) < ftol) return return_final(FTOL, X);

		// (4)
		if (lamda > sqrt((F0 - F) / dfmin)){
			for (int i = m; i < ndim; i++){
				temp_memcpy(dir[i], dir[i + 1], ndim);
			}
		}
		F0 = F; temp_memcpy(X0, X, ndim);

		ecurrent = F;
		if (output->next == ntimestep) {
			func(X); neval--;
			output->write(ntimestep);
		}
	}
	return return_final(MAXITER, X);
}


double MinPowell::linefunc(double x){

	for (int i = 0; i < nvec; i++)
		gbuff[i] = x*gdir[i] + gX[i];

	return Min::func(gbuff);
}


double MinPowell::linesearch(double F, double &x, double *pX, double* pdir){
	x = 0;
	gdir = pdir;
	temp_memcpy(gX, X, nvec);

	double s = 0;	
	double F_new;

	s = 0;
	F_new = (this->*linemin)(F, s, 0, dmax);

	if (F_new >= F){
		s = 0;
		for (int i = 0; i < nvec; i++)
			pdir[i] = -pdir[i];

		F_new = (this->*linemin)(F, s, 0, dmax);

		if (F_new >= F){
			x = 0;
			return F;
		}
	}

	for (int i = 0; i < nvec; i++)
		pX[i] += s * pdir[i];

	x = s;
	return F_new;
}


double MinPowell::fminexp(double F, double &s, double a, double b){
	double q;
	double r;
	int i;

	if (1){
		q = b;
		for (i = 0; i < 8; i++){
			q *= 0.0125;
			r = linefunc(q);
			if (r < F) break;
		}
		if (r > F) return F;

		q *= 200;
		for (i = 0; i < 8; i++){
			q *= 0.4;
			r = linefunc(q);
			if (r < F) break;
		}
		if (r > F) {
			return F;
		}

		q *= 3.125;
		for (i = 0; i < 10; i++){
			q *= 0.8;
			r = linefunc(q);
			if (r < F) break;
		}
		if (r > F) {
			return F;
		}
	}
	else{
		q = b;
		for (i = 0; i < 10; i++){
			q *= 0.01;
			r = linefunc(q);
			if (r < F) break;
		}
		if (r > F) return F;

		q *= 170;
		for (i = 0; i < 10; i++){
			q *= 0.6;
			r = linefunc(q);
			if (r < F) break;
		}
		if (r > F) {
			return F;
		}
	}	

	s = 0;
	//r = fminbnd(F, s, 0, q);
	q *= 0.5;
	s = q;
	r = linefunc(q);

	return r;
}

double MinPowell::fminbnd(double F, double &s, double a, double b)
{
	double f;
	int iter;
	double v;
	double w;
	double xf;
	double d;
	double e;
	int funccount;
	double fv;
	double fw;
	double xm;
	double tol1;
	double tol2;
	bool exitg1;
	int gs;
	double r;
	double q;
	double p;
	double b_r;
	iter = 0;

	int maxiter = 100;
	double tol = 1e-8;
	double seps = 1.4901161193847656e-08;
	double c = 0.5*(3.0 - sqrt(5.0));
	xf = w = v = a + c*(b - a);

	e = d = 0.0;
	fw = fv = f = linefunc(xf);

	funccount = 1;

	xm = 0.5*(a + b);;
	tol1 = seps*fabs(xf) + tol / 3.0;
	tol2 = 2.0*tol1;
	exitg1 = false;

	while ((!exitg1) && (fabs(xf - xm) > tol2 - 0.5 * (b - a))) {
		gs = 1;
		if (fabs(e) > tol1) {
			gs = 0;
			r = (xf - w) * (f - fv);
			q = (xf - v) * (f - fw);
			p = (xf - v) * q - (xf - w) * r;
			q = 2.0 * (q - r);
			if (q > 0.0) {
				p = -p;
			}

			q = fabs(q);
			r = e;
			e = d;
			if ((fabs(p) < fabs(0.5 * q * r)) && (p > q * (a - xf)) &&
				(p < q * (b - xf))) {
				d = p / q;
				q = xf + d;
				if ((q - a < tol2) || (b - q < tol2)) {
					q = xm - xf;
					if (q < 0.0) {
						q = -1.0;
					}
					else if (q > 0.0) {
						q = 1.0;
					}
					else {
						if (q == 0.0) {
							q = 0.0;
						}
					}

					d = tol1 * (q + (double)(xm - xf == 0.0));
				}
			}
			else {
				gs = 1;
			}
		}

		if (gs != 0) {
			if (xf >= xm) {
				e = a - xf;
			}
			else {
				e = b - xf;
			}

			d = 0.3819660112501051 * e;
		}

		q = d;
		if (d < 0.0) {
			q = -1.0;
		}
		else if (d > 0.0) {
			q = 1.0;
		}
		else {
			if (d == 0.0) {
				q = 0.0;
			}
		}

		r = fabs(d);
		if ((r > tol1) || isnan(tol1)) {
			b_r = r;
		}
		else {
			b_r = tol1;
		}

		q = xf + (q + (double)(d == 0.0)) * b_r;
		r = linefunc(q);
		funccount++;
		iter++;
		if (r <= f) {
			if (q >= xf) {
				a = xf;
			}
			else {
				b = xf;
			}

			v = w;
			fv = fw;
			w = xf;
			fw = f;
			xf = q;
			f = r;
		}
		else {
			if (q < xf) {
				a = q;
			}
			else {
				b = q;
			}

			if ((r <= fw) || (w == xf)) {
				v = w;
				fv = fw;
				w = q;
				fw = r;
			}
			else {
				if ((r <= fv) || (v == xf) || (v == w)) {
					v = q;
					fv = r;
				}
			}
		}

		xm = 0.5 * (a + b);
		tol1 = 1.4901161193847656E-8 * fabs(xf) + 3.3333333333333335E-5;
		tol2 = 2.0 * tol1;
		if ((funccount >= maxiter) || (iter >= maxiter)) {
			exitg1 = true;
		}
	}

	s = xf;
	return f;
}