
#include <stdlib.h>
#include <string.h>
#include "style_pair.h"
#include "style_bond.h"
#include "pair.h"
#include "pair_hybrid.h"
#include "bond.h"
#include "bond_hybrid.h"

#include "pointers.h"
#include "force.h"
#include "memory.h"
#include "error.h"
#include "input.h"

using namespace EAPOT_NS;

/* ---------------------------------------------------------------------- */

Force::Force(EAPOT *lmp) : Pointers(lmp)
{
	pair_style = NULL;
	pair_top = NULL;
	pair = NULL;

	bond_style = NULL;
	bond_top = NULL;
	bond = NULL;

	char *str = (char *) "none";
	int n = strlen(str) + 1;
	pair_style = new char[n];
	strcpy(pair_style, str);
	bond_style = new char[n];
	strcpy(bond_style, str);

	set_elestr(1, (char*)"Cu");
	set_ntypes(1);

	// fill pair map with pair styles listed in style_pair.h

	pair_map = new PairCreatorMap();

#define PAIR_CLASS
#define PairStyle(key,Class) \
	(*pair_map)[#key] = &pair_creator<Class>;
#include "style_pair.h"
#undef PairStyle
#undef PAIR_CLASS

	bond_map = new BondCreatorMap();

#define BOND_CLASS
#define BondStyle(key,Class) \
	(*bond_map)[#key] = &bond_creator<Class>;
#include "style_bond.h"
#undef BondStyle
#undef BOND_CLASS

}

/* ---------------------------------------------------------------------- */

Force::~Force()
{
	delete[] pair_top;
	delete[] pair_style;
	delete[] bond_top;
	delete[] bond_style;

	if (pair) delete pair;
	if (bond) delete bond;

	pair = NULL;
	bond = NULL;

	delete pair_map;
	delete bond_map;
}

/* ---------------------------------------------------------------------- */

int Force::get_eleidx(int n) {
	if (n < 0 || n >= (int)elestr.size()) {
		ErrorAll("The type of the %d th element is not defined", n);
	}
	return eleidx[n];
}

const char* Force::get_elestr(int n) {
	if (n < 0 || n >= (int)elestr.size()) {
		ErrorAll("The type of the %d th element is not defined", n);
	}
	return elestr[n].c_str();
}

void Force::set_elestr(int n, const char* ele) {
	if (n < 0 || n >= 255) error->all(FLERR, "The element idx must be a positive integer and < 255");

	if (n >= elestr.size()) {
		elestr.resize((size_t)n + 1, "n");
		eleidx.resize((size_t)n + 1, 0);
	}

	elestr[n] = ele;
	eleidx[n] = input->ele2int(ele);
}

/* ---------------------------------------------------------------------- */

int Force::get_ntypes()
{
	return ntypes;
}

/* ---------------------------------------------------------------------- */

void Force::set_ntypes(int n) 
{
	if (n <= 0) error->all(FLERR, 
		"The element type must be a positive integer");
	ntypes = n;

	massVec.resize((size_t)n + 1, 1.0);
	for (int i = 1; i <= n; i++) {
		int idx = get_eleidx(i);
		massVec[i] = Input::getAtomicMass(idx);
	}
}

/* ---------------------------------------------------------------------- */

void Force::setMass(int num, double* pmass) {
	for (size_t i = 0; i < num; i++) {
		massVec[i + 1] = pmass[i];
	}
}

void Force::setElement(int num, const char** pele) {

	for (int i = 0; i < num; i++) {
		set_elestr(i + 1, pele[i]);
	}
	set_ntypes(num);
}

const char* Force::getPotScript(void* pPair) {
	((Pair*)pPair)->styleCheck(FLERR, "eam/python", 1);
	return ((PairEAMPython*)pPair)->pythonScript.c_str();
}

/* ---------------------------------------------------------------------- */

void Force::init()
{
	if (pair) pair->init();
	if (bond) bond->init();
}

/* ---------------------------------------------------------------------- */

void Force::setup()
{
}

/* ----------------------------------------------------------------------
create a pair style, called from input script or restart file
------------------------------------------------------------------------- */

void* Force::addPair(const char *style)
{
	delete[] pair_style;
	if (pair) delete pair;
	pair_style = NULL;
	pair_top = NULL;
	pair = NULL;

	if (strcmp(style, "none") == 0) {
		pair = NULL;
	}
	else if (pair_map->find(style) != pair_map->end()) {
		PairCreator pair_creator = (*pair_map)[style];
		pair = pair_creator(eapot);
	}
	else {
		ErrorAll("Unknown pair style %s", style);
	}

	store_style(pair_top, pair_style, style);
	eapot->once_initFlag = 0;
	pair->fvec_allocate();
	return pair;
}


/* ----------------------------------------------------------------------
one instance per pair style in style_pair.h
------------------------------------------------------------------------- */

template <typename T>
Pair *Force::pair_creator(EAPOT *lmp)
{
	return new T(lmp);
}

/* ----------------------------------------------------------------------
create a bond style, called from input script or restart file
------------------------------------------------------------------------- */

void Force::create_bond(const char *style, int trysuffix)
{
	delete[] bond_style;
	if (bond) delete bond;

	int sflag;
	bond = new_bond(style, trysuffix, sflag);
	store_style(bond_top, bond_style, style);

	eapot->once_initFlag = 0;
}

/* ----------------------------------------------------------------------
generate a bond class, fist with suffix appended
------------------------------------------------------------------------- */

Bond *Force::new_bond(const char *style, int trysuffix, int &sflag)
{
	sflag = 0;
	eapot->once_initFlag = 0;

	if (strcmp(style, "none") == 0) return NULL;
	if (bond_map->find(style) != bond_map->end()) {
		BondCreator bond_creator = (*bond_map)[style];
		return bond_creator(eapot);
	}

	char str[128];
	sprintf(str, "Unknown bond style %s", style);
	error->all(FLERR, str);

	return NULL;
}

/* ----------------------------------------------------------------------
one instance per bond style in style_bond.h
------------------------------------------------------------------------- */

template <typename T>
Bond *Force::bond_creator(EAPOT *lmp)
{
	return new T(lmp);
}

void Force::store_style(char *&top, char *&str, const char *style)
{
	char* pcut;
	int n = strlen(style) + 1;
	top = new char[n];
	str = new char[n];
	strcpy(str, style);	

	pcut = strchr(str, '/');
	if (pcut) *pcut = '\0';
	strcpy(top, str);

	strcpy(str, style);
}


string& Force::eleLineFormat(const char* fmt) {
	
	ele_line = get_elestr(1);
	for (int i = 2; i <= ntypes; i++) {
		ele_line.append(fmt);
		ele_line.append(get_elestr(i));
	}
	return ele_line;
}

vector<const char*> Force::getEles() {
	vector<const char*> res(1 + (size_t)ntypes, NULL);
	for (int i = 0; i <= ntypes; i++) {
		res[i] = elestr[i].c_str();
	}
	return res;
}