#include "modify.h"
#include "math.h"
#include "style_compute.h"

#include "memory.h"
#include "error.h"
#include "update.h"
#include "force.h"

#include "min.h"

#include "compute.h"
#include "pair.h"

#include "compute_external.h"

using namespace EAPOT_NS;

#define DELTA 4 

Modify::Modify(EAPOT *eapot)
: Pointers(eapot)
{	
	compute = NULL;
	ncompute = maxcompute = 0;
	compute_map = new ComputeCreatorMap();

#define COMPUTE_CLASS
#define ComputeStyle(key,Class) \
	(*compute_map)[#key] = &compute_creator<Class>;
#include "style_compute.h"
#undef ComputeStyle
#undef COMPUTE_CLASS
};

Modify::~Modify()
{
	for (int i = 0; i < ncompute; i++) {
		delete compute[i];
		compute[i] = NULL;
	}

	memory->sfree(compute);
	compute = NULL;
}


void Modify::init()
{
	int i;
	for (i = 0; i < ncompute; i++) {
		compute[i]->init(); 
	}
}

/* ----------------------------------------------------------------------
   setup for run, calls setup() of all fixes and computes
   called from Verlet, RESPA, Min
------------------------------------------------------------------------- */

void Modify::setup(int vflag)
{
}

void* Modify::addCompute(CPCHAR id, CPCHAR style, CPCHAR file){

	for (int icompute = 0; icompute < ncompute; icompute++)
	if (id == compute[icompute]->id)
		error->all(FLERR, "Reuse of compute ID");

	if (ncompute == maxcompute) {
		maxcompute += DELTA;
		compute = (Compute **)
			memory->srealloc(compute, maxcompute*sizeof(Compute *), "modify:compute");
	}
	compute[ncompute] = NULL;

	if (compute_map->find(style) != compute_map->end()) {
		ComputeCreator compute_creator = (*compute_map)[style];
		compute[ncompute] = compute_creator(eapot, id, style, file);
	}
	if (compute[ncompute] == NULL) {
		ErrorAll("Unknown compute style %s", style);
	}

	eapot->once_initFlag = 0;
	ncompute++;
	return compute[ncompute - 1];
}


template <typename T>
Compute *Modify::compute_creator(EAPOT *pmainstruct, CPCHAR id, CPCHAR style, CPCHAR file)
{
	return new T(pmainstruct, id, style, file);
}

int Modify::find_compute(const char *id)
{
	if (id == NULL) return -1;
	int icompute;
	for (icompute = 0; icompute < ncompute; icompute++)
	if (id == compute[icompute]->id) break;
	if (icompute == ncompute) return -1;
	return icompute;
}

void* Modify::getCompute(const char *id, const char* style)
{
	int idx = find_compute(id);
	if (idx < 0) {
		ErrorAll("can not find Compute: %s", id);
	}

	if (style) compute[idx]->styleCheck(FLERR, style, 1);
	return compute[idx];
}

void Modify::clearstep_compute()
{
	for (int icompute = 0; icompute < ncompute; icompute++)
		compute[icompute]->invokedFlag = 0;
}