#ifndef EAPOT_DUMPSTYLE_H
#define EAPOT_DUMPSTYLE_H

#include "pointers.h"

namespace EAPOT_NS {

	class DumpStyle : protected Pointers {
	public:

		DumpStyle(class EAPOT* eapot) : Pointers(eapot) {};

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE NAME##PTYPE
#include "style_dump.h"
#undef  LIBAPI

	};

}

#endif