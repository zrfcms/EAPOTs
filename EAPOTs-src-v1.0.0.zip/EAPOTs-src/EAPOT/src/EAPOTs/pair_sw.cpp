#include "pair_sw.h"

#include "error.h"
#include "input.h"
#include "force.h"
#include "dump_file.h"
#include "dump_image.h"
#include "image.h"

#include "memory.h"
#include "option_pair.h"
#include "libLAMMPS/lammps_api.h"

using namespace EAPOT_NS;

/*
		element					1 (the center atom in a 3-body interaction)
		element					2
		element					3
epsilon	both					epsilon (energy units)
sigma	both					sigma (distance units)
a		both					a
lambda	only for three-body		lambda
gamma	only for three-body		gamma
cos0	only for three-body		cos theta0
A		only for two-body		A
B		only for two-body		B
p		only for two-body		p
q		only for two-body		q
tol								tol
*/


PairSW::PairSW(EAPOT* eapot)
	: PairTribody(eapot)
{
	styles.push_back("sw");
	paramNum = 11;

	key = {
		"epsilon", "sigma", "a", "lambda", "gamma",
		"cos0", "A", "B", "p", "q","tol",
	};
	chkStyle = "sw";

	xlim.resize(3);
	ylim.resize(3);
	dump_sample.resize(3, 1.25);
	dump_sample[0] = xlim[0].customlo = 1.0;
	dump_sample[1] = xlim[1].customlo = 1.25;
};

PairSW::~PairSW() {

}

void PairSW::fvec_allocate() {

	int n = force->get_ntypes();

	add_fsize(2*n*(n + 1)/2 + 4 + MIN(n*n*n, 3));
	add_csize(4);
	Pair::fvec_allocate();
}

void PairSW::defaultDofMap(double* f, double* c) {

	double* p = paramVec.data();
	int idx, n = force->get_ntypes();	

	idx = 0;
	idx = TribodyLoop3(p, f, idx, 0, n);
	idx = TribodyLoopN2h(p, f, idx, 1, n);
	idx = TribodyLoopN2h(p, f, idx, 2, n);

	idx = TribodyLoopN3(p, f, idx, 3, n);
	idx = TribodyLoopN3(p, f, idx, 4, n);
	idx = TribodyLoopN3(p, f, idx, 6, n);
	idx = TribodyLoopN3(p, f, idx, 7, n);

	idx = 0;
	idx = TribodyLoopN3(p, c, idx, 5, n);
	idx = TribodyLoopN3(p, c, idx, 8, n);
	idx = TribodyLoopN3(p, c, idx, 9, n);
	idx = TribodyLoopN3(p, c, idx, 10, n);
}


void PairSW::export_pair(void* md) {

	export_pair_template(md, "temp/temp.sw");

	if (!transByFileMode) {
		const int n = force->get_ntypes();
		set_sw_params(md, n, triTitle.c_str(), val.data());
	}
}


void PairSW::export_init(void* md) {

	std::string telt = force->eleLineFormat(" ");

	if (transByFileMode) {
		transByFile("temp/temp.sw");
		pair_style(md, "sw");
		pair_coeff(md, "temp/temp.sw", telt.c_str());
	}
	else {
		pair_style(md, "sw/ex");
		pair_coeff(md, "NULL", telt.c_str());
	}

	for (int i = 1; i <= force->get_ntypes(); i++) {
		set_mass(md, i, force->massVec[i]);
	}
}


#define IDX(i,j,k) (i*n2+j*n+k)
#define Val(iParam, itri) paramVec[iParam*n3 + itri]
#ifndef PI
#define PI 3.14159265358979323
#endif
#define EPS 0.9999

#define PACK(N, CMD)						\
for (int ii = 0; ii < N; ii++){				\
	buf[m++] = CMD;							\
}	


double f2(double A, double eps, double B, double sigma, double p, double q, double a, double r) {
	if (r >= a * sigma * EPS || r < 1e-10) return 0;

	double sr = sigma / r;
	double powitem = B * pow(sr, p) - pow(sr, q);
	double expitem = exp(sigma / (r - a * sigma));
	return A * eps * powitem * expitem;
}

double f3(double lam, double eps, double g1, double s1, double a1, double g2, double s2, double a2, double r) {
	if (r >= a1 * s1 * EPS || r >= a2 * s2 * EPS) return 0;

	double expitem1 = exp(g1 * s1 / (r - a1 * s1));
	double expitem2 = exp(g2 * s2 / (r - a2 * s2));
	return lam * eps * expitem1 * expitem2;
}

double gT(double cost0, double t) {
	double delta = cos(t) - cost0;
	return delta * delta;
}

int PairSW::image(class DumpImage* dumpimage)
{
	Image* image = dumpimage->image;
	if (image->axes.empty()) image->subplots(3, 1);
	size_t n = force->get_ntypes();
	auto eles = force->getEles();
	eles.erase(eles.begin());

	// 1. get number of points to draw and malloc memory
	int nr = image->axes[0].width;

	size_t n2 = n * n, n3 = n * n * n;
	double* buf = dumpimage->requestDbuf(nr * (n2 + 2 * n3));

	// 2. get cutoff
	double f2max = 0, f3max = 0, cut = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++) {
		{
			const size_t itri = IDX(i, j, j);
			double A = Val(6, itri), eps = Val(0, itri);
			double B = Val(7, itri), sigma = Val(1, itri);
			double p = Val(8, itri), q = Val(9, itri), a = Val(2, itri);
			f2max = fmax(f2max, f2(A, eps, B, sigma, p, q, a, dump_sample[0]));
		}

		for (size_t k = 0; k < n; k++) {
			const size_t tri1 = IDX(i, j, j);
			const size_t tri2 = IDX(i, k, k);

			double lam = Val(3, tri1), eps = Val(0, tri1);
			double g1 = Val(4, tri1), s1 = Val(1, tri1), a1 = Val(2, tri1);
			double g2 = Val(4, tri2), s2 = Val(1, tri2), a2 = Val(2, tri2);
			f3max = fmax(f3max, f3(lam, eps, g1, s1, a1, g2, s2, a2, dump_sample[1]));

			cut = fmax(cut, a1 * s1);
			cut = fmax(cut, a2 * s2);
		}
	}

	xlim[0].set(0.0, cut).update();
	xlim[1].set(0.0, cut).update();
	xlim[2].set(0.0, 2 * PI).update();

	// 3. pack image data
	double dr = (xlim[0].hi - xlim[0].lo) / nr;
	double dt = (xlim[2].hi - xlim[2].lo) / nr;
	double rlo = xlim[0].lo, tlo = xlim[2].lo;

	int idx = 0, m = 0, off = 0;
	for (size_t i = 0; i < n; i++)
		for (size_t j = 0; j < n; j++) {
			const size_t itri = IDX(i, j, j);
			double A = Val(6, itri), eps = Val(0, itri);
			double B = Val(7, itri), sigma = Val(1, itri);
			double p = Val(8, itri), q = Val(9, itri), a = Val(2, itri);			
			PACK(nr, f2(A, eps, B, sigma, p, q, a, rlo + ii * dr));
		}
	for (size_t i = 0; i < n; i++)
		for (size_t j = 0; j < n; j++)
			for (size_t k = 0; k < n; k++) {
				const size_t tri1 = IDX(i, j, j);
				const size_t tri2 = IDX(i, k, k);

				double lam = Val(3, tri1), eps = Val(0, tri1);
				double g1 = Val(4, tri1), s1 = Val(1, tri1), a1 = Val(2, tri1);
				double g2 = Val(4, tri2), s2 = Val(1, tri2), a2 = Val(2, tri2);
				PACK(nr, f3(lam, eps, g1, s1, a1, g2, s2, a2, rlo + ii * dr));
		}
	for (size_t i = 0; i < n; i++)
		for (size_t j = 0; j < n; j++)
			for (size_t k = 0; k < n; k++) {
				const size_t itri = IDX(i, j, k);
				double cost0 = Val(5, itri);
				PACK(nr, gT(cost0, tlo + ii * dt));
			}

	// 4. evaluate the drawing range
	double lo = 0, hi = 0;

	off = 0;
	input->getRange(nr * n2, &buf[off], lo, hi);
	if (lo < 0) {
		lo = fmin(-0.02, lo);
		ylim[0].set(lo * 1.1, -lo * 2.2).update();
	} else {
		ylim[0].set(0.0, f2max).update();
	}

	off += nr * n2;
	input->getRange(nr * n3, &buf[off], lo, hi);
	ylim[1].set(fmin(lo, 0), f3max).update();

	off += nr * n3;
	input->getRange(nr * n3, &buf[off], lo, hi);
	ylim[2].set(0.0, hi * 1.1).update();

	/**********************************************     Plotting     **********************************************/

	char label[32];
	Axes& Axes1 = image->axes[0].limit(xlim[0], ylim[0]);
	Axes& Axes2 = image->axes[1].limit(xlim[1], ylim[1]);
	Axes& Axes3 = image->axes[2].limit(xlim[1], ylim[2]);

	image->setColoru(0, 255, 0);							// set plot color as green
	PlotLine line = { 0.0, 0.0, 1.0, 0, 5, 5 };				// y = 0, x = [0 1], horizontal, (5, 5) for dotted line
	Axes1.line(line);										// Green dotted line for marking y = 0 boundary

	idx = m = 0;
	for (size_t i = 0; i < n; i++)
		for (size_t j = 0; j < n; j++) {
			sprintf(label, "--%s/%s", eles[i], eles[j]);
			image->setColorRainbow((idx + 0.1) / n2);
			Axes1.plot(nr, &buf[m], label);
			m += nr; idx++;
		}
	idx = 0;
	for (size_t i = 0; i < n; i++)
		for (size_t j = 0; j < n; j++)
			for (size_t k = 0; k < n; k++) {
				sprintf(label, "--%s/%s/%s", eles[i], eles[j], eles[k]);
				image->setColorRainbow((idx + 0.1) / n2);
				Axes2.plot(nr, &buf[m], label);
				m += nr; idx++;
			}
	idx = 0;
	for (size_t i = 0; i < n; i++)
		for (size_t j = 0; j < n; j++)
			for (size_t k = 0; k < n; k++) {
				sprintf(label, "--%s/%s/%s", eles[i], eles[j], eles[k]);
				image->setColorRainbow((idx + 0.1) / n3);
				Axes3.plot(nr, &buf[m], label);
				m += nr; idx++;
			}

	Axes1.legend(0.75, 0.75).xlabel = "2-body";
	Axes2.legend(0.75, 0.75).xlabel = "3-body";
	Axes3.legend(0.75, 0.75).xlabel = "g(theta)";

	image->show();
	return 0;
};


void PairSW::extra_check(int type) {
	const char* name = NULL;

	switch (type) {
	case 0:
		name = "SWs";
		addMDComputeCDia();
		break;
	case 1:
		name = "SWc";
		addMDComputeSiCDia();
		break;
	case 2:
		name = "SWc(File)";	
		addMDComputeSiCDia();
		break;
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}

	if (0) {
		// run test
		switch (type) {
		case 0: {
			double param[] = { 2.0, 2.0, 1.80, 20, 1.2, 7.0, 0.6,   -0.333333333333, 4.0, 0.0, 0.0 };
			pairStyle->setPairFullParams(force->pair, param);
			runMDCompute(100, RunDump | RunEcho, 40, CDiaCost, DiaChk, "nms", "C.*.tersoff");
			break;
		}
		case 1: case 2: {
			double param[] = { 1, 2, 1.6, 2, 1.6, 1.3, 1.6, 1.8, 1.8, 32, 1.2, 8.0, 0.7, -0.333333333333, 4.0, 0.0, 0.0 };
			pairStyle->setPairFullParams(force->pair, param);

			runMDCompute(200, RunDump | RunEcho, 20, SiCDiaCost, DiaChk, "nms", "SiC.*.tersoff");
			break;
		}
		}
		return;
	}
	else {
		runMDCompute(-1, 0, 10, NULL, NULL, NULL, NULL);
	}

	error->add_chklog(0, name, "");

	switch (type) {
	case 0: {
		// data from LAMMPS
		double BoxChk[2], BoxRef[2] = { 5.430949778642078, 4.336599999917266, };
		double ElaChk[3], ElaRef[3] = { 151.4244784812905, 76.42208402552166, 109.75648197307744, };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, 2, BoxChk, BoxRef, 1, name, "Box", 5e-10, 4e-10, 3.8387602897715635e-10, 3.8387623378701191e-10);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 1e-06, 5e-06, 6.9921319147504541e-07, 8.3164056780845218e-07);
		break;
	}
	case 1:
	case 2: {
		// data from LAMMPS
		double BoxChk[2], BoxRef[2] = { 4.512185687505076, 4.340900088835048,  };
		double ElaChk[3], ElaRef[3] = { 318.21176982289006, 149.58049899261997, 225.8001903565263 };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, 2, BoxChk, BoxRef, 1, name, "Box", 5e-9, 3e-9, 4.1860344671314949e-09, 4.1860350809524085e-09);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 5e-6, 3e-6, 3.5023674959363628e-06, 5.3440440489530558e-06);
		break;
	}
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}
};