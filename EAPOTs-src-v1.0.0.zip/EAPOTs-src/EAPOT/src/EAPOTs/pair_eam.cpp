#include "pair_eam.h"
#include "string.h"
#include <stdlib.h>

#include "error.h"
#include "memory.h"
#include "force.h"
#include "input.h"

#include "compute_energy.h"
#include "libLAMMPS/lammps_api.h"

#include "dump_file.h"
#include "dump_image.h"
#include "image.h"

#include "option_pair.h"

using namespace std;
using namespace EAPOT_NS;

PairEAM::PairEAM(EAPOT* eapot)
	: Pair(eapot)
	, exportAsFsFlag(false)
{
	styles.push_back("eam");
	eam_fsize = 0;
	eam_csize = 0;

	// file dump settings
	m_dump.nrho = 5000; 
	m_dump.nr = 5000;

	m_dump.drho = 0.01;
	m_dump.dr = 1e-3;
	m_dump.cut = 5;

	unExportFlag = 0;
	export_frho = NULL;
	export_rhor = NULL;
	export_z2r = NULL;
	
	// image dump settings
	dump_sample_fmult = 2.0;

	dump_sample.resize(3, 2.5);
	xlim.resize(3);
	ylim.resize(3);

	xlim[2].customlo = xlim[1].customlo = 2.0;

	element_title.resize((size_t)force->get_ntypes() + 1, "");
	chkStyle = "eam/alloy";
};

PairEAM::~PairEAM(){
}

int PairEAM::getPyParamNum() {
	return eam_fsize + eam_csize;
}

void PairEAM::defaultDofMap(double* f, double* c) {

	size_t nf = get_fsize();
	for (int i = 0; i < get_fsize(); i++) {
		paramVec[i] = f[i];
	}
	for (int i = 0; i < get_csize(); i++) {
		paramVec[nf + i] = c[i];
	}
}


#define ExportRhoData(FUNC, I, J)							\
	for (int m = 0; m < m_dump.nr; m++) {					\
		data[m] = safedump(FUNC(I, J, m_dump.dr * m));		\
	}

#define ExportPhiData(FUNC, I, J)							\
	for (int m = 0; m < m_dump.nr; m++) {					\
		x = m_dump.dr * m;									\
		data[m] = safedump(FUNC(I, J, m_dump.dr * m)) * x;	\
	}

void PairEAM::setFreeParamsStyle() {

	if (unExportFlag || export_frho == NULL) return;

	double x = 0.0;
	double* data = NULL;
	int idx, nele = force->get_ntypes();

	for (int i = 1; i <= nele; i++) {

		data = &export_frho[i - 1][1];
		for (int m = 0; m < m_dump.nrho; m++) {
			data[m] = safedump(emb(i, m_dump.drho * m));
		}

		if (exportAsFsFlag)			
		for (int j = 1; j <= nele; j++) {
			idx = (i - 1) * nele + (j - 1);
			data = &export_rhor[idx][1];
			ExportRhoData(rho, i, j)
		}
		else {
			idx = (i - 1);
			data = &export_rhor[idx][1];
			ExportRhoData(rho, i, i)
		}

		for (int j = 1; j <= i; j++) {
			idx = (i - 1) * nele + (j - 1);
			data = &export_z2r[idx][1];			
			ExportPhiData(phi, i, j)
		}
	}
}


void PairEAM::export_init(void* md) {
	
	char export_pair_style[64];
	sprintf(export_pair_style, "%s/ex", chkStyle.c_str());

	pair_style(md, export_pair_style);

	const char* ele = force->eleLineFormat(" ").c_str();
	sprintf(error->ErrCheckBuff, "%d %s", force->get_ntypes(), ele);
	set_EAM_head(md, error->ErrCheckBuff, &force->massVec[1]);

	pair_coeff(md, "NULL", ele);
}

void PairEAM::export_pair(void* md) {

	PairEAMFmt& m_ex = m_dump;
	int ntypes = force->get_ntypes();
	set_EAM_format(md, m_ex.nrho, m_ex.drho, m_ex.nr, m_ex.dr, m_dump.cut);

	double* pfrho, * prhor, * pfz2r;
	get_EAM_listdata(md, &pfrho, &prhor, &pfz2r);

	int nrhor = exportAsFsFlag ? ntypes * ntypes : ntypes;

	temp_memcpy(pfrho, export_frho[0], ntypes * (m_ex.nrho + 1));
	temp_memcpy(prhor, export_rhor[0], nrhor * (m_ex.nr + 1));
	temp_memcpy(pfz2r, export_z2r[0], ntypes * ntypes * (m_ex.nr + 1));
}

void PairEAM::export_computeMD(void* pcom) {
	
	ComputeEnergy* com = (ComputeEnergy*)pcom;

	int nlocal = get_atomnum(com->md);
	double rhot = 0, Fembt = 0;
	double* rho, * Femb;
	get_EAM_atomdata(com->md, &rho, &Femb);
	for (int i = 0; i < nlocal; i++) {
		rhot += rho[i];
		Fembt += Femb[i];
	}	
	com->data[16] = rhot / nlocal;
	com->data[17] = Fembt / nlocal;
}

void PairEAM::fvec_allocate(){
	
	add_fsize(eam_fsize);
	add_csize(eam_csize);
	
	Pair::fvec_allocate();
}

//	int dump_nelements, m_dump.nrho, m_dump.nr;
//	double m_dump.drho, m_dump.dr, m_dump.cut;

void PairEAM::init_style(){
	cutmax = m_dump.cut;

	int ntypes = force->get_ntypes();
	if (export_frho) memory->destroy(export_frho);
	if (export_rhor) memory->destroy(export_rhor);
	if (export_z2r) memory->destroy(export_z2r);

	int nrhor = exportAsFsFlag ? ntypes * ntypes : ntypes;

	memory->create(export_frho, ntypes, m_dump.nrho + 1, "PairEAM::export_frho");
	memory->create(export_rhor, nrhor, m_dump.nr + 1, "PairEAM::export_rhor");
	memory->create(export_z2r, ntypes * ntypes, m_dump.nr + 1, "PairEAM::export_z2r");
}


const char* PairEAM::ele_title(int n){
	static char titleBuff[128];
	sprintf(titleBuff, "%d	%f	3.0	fcc", n, input->getAtomicMass(n));
	return titleBuff;
}

#define SafePrint dump->sbufChk(FLERR, off); off += sprintf
	
#define LineBreakIFNeed()					\
	if (i % 5 == 4) { 						\
		dump->sbufChk(FLERR, off); 			\
		off += sprintf(&sbuf[off], "\n"); 	\
	}


void PairEAM::write(DumpFile* dump){

	// --------------------------------- open --------------------------------- //
	dump->openfile(0);
	// ------------------------------------------------------------------------ //

	int off = 0;
	FILE* fp = dump->fp;
	double x = 0, y = 0;
	char* &sbuf = dump->sbuf;

	int ntypes = force->get_ntypes();
	const char* fmt = "%.15e\t";
	const char* eleLine = force->eleLineFormat(" ").c_str();

	// 1. EAPOT info line, eg:
	// #20 dof: (parameters)	

	fprintf(fp, "# %s at %s by EAPOT\n", dump->fileDump[0].c_str(), input->timestr);
	fprintf(fp, "# %d dof %d params:\n#", get_fsize(), (int)paramVec.size());
	for (auto& val : paramVec) fprintf(fp, FDBLFMTG " ", val);	// parameters

	write_style(dump);
	fprintf(fp, "\n");

	// 2. head info: e.g. 
	// 2 Cu Ni
	// 5000 8.000000000000000e-02 5000 1.154595007892378e-03 5.744395955108117e+00

	fprintf(fp, "%d %s\n", ntypes, eleLine);	
	fprintf(fp, "%d\t" FDBLFMTG "\t%d\t"  FDBLFMTG "\t" FDBLFMTG "\n",
		m_dump.nrho, m_dump.drho, m_dump.nr, m_dump.dr, m_dump.cut);

	// 3. write data
	for (int itype = 1; itype <= ntypes; itype++) {

		if (element_title[itype].empty()) {
			element_title[itype] = ele_title(force->get_eleidx(itype));
		}
		SafePrint(&sbuf[off], "%s\n", element_title[itype].c_str());

		for (int i = 0; i < m_dump.nrho; i++) {
			x = i * m_dump.drho;
			y = safedump(emb(itype, x));
			SafePrint(&sbuf[off], fmt, y);
			LineBreakIFNeed();
		}

		if (exportAsFsFlag)
		for (int jtype = 1; jtype <= ntypes; jtype++) {
			for (int i = 0; i < m_dump.nr; i++) {
				x = i * m_dump.dr;
				y = safedump(rho(itype, jtype, x));
				SafePrint(&sbuf[off], fmt, y);
				LineBreakIFNeed();
			}
		}
		else {
			for (int i = 0; i < m_dump.nr; i++) {
				x = i * m_dump.dr;
				y = safedump(rho(itype, itype, x));
				SafePrint(&sbuf[off], fmt, y);
				LineBreakIFNeed();
			}
		}
	}

	for (int itype = 1; itype <= ntypes; itype++)
	for (int jtype = 1; jtype <= itype; jtype++) {
		for (int i = 0; i < m_dump.nr; i++) {
			x = i * m_dump.dr;
			y = safedump(phi(itype, jtype, x));
			SafePrint(&sbuf[off], fmt, x * y);
			LineBreakIFNeed();
		}
	}
	
	// ------------------------------- output --------------------------------- //
	dump->nsme = off;
	fwrite(dump->sbuf, sizeof(char), dump->nsme, fp);
	dump->closefile();
	// ------------------------------------------------------------------------ //
}


void PairStyle::setPairEAMDumpFormat(void* pPair, int Nrho, double drho, int Nr, double dr, double cut) {
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;
	
	pair->m_dump.nrho = Nrho;
	pair->m_dump.drho = drho;
	pair->m_dump.nr = Nr;
	pair->m_dump.dr = dr;
	pair->m_dump.cut = cut;

	if (Nrho < 10 || Nr < 10) {
		error->all(FLERR, "Illegal setPairEAMNrho command: num < 10");
	}
	if (drho <= 0.0 || dr <= 0.0) {
		error->all(FLERR, "Illegal setPairEAMdrho command: delta <= 0.0");
	}
	if (cut <= 0.0) {
		error->all(FLERR, "Illegal setPairEAMCutoff command: cut <= 0.0");
	}
}


void PairStyle::setPairEAMDumpNrho(void* pPair, int num)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	pair->m_dump.nrho = num;
	if (num < 10) {
		error->all(FLERR, "Illegal setPairEAMNrho command: num < 10");
	}
}

void PairStyle::setPairEAMDumpNr(void* pPair, int num)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	pair->m_dump.nr = num;
	if (num < 10) {
		error->all(FLERR, "Illegal setPairEAMNr command: num < 10");
	}
}

void PairStyle::setPairEAMDumpdrho(void* pPair, double delta)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	pair->m_dump.drho = delta;
	if (delta <= 0.0) {
		error->all(FLERR, "Illegal setPairEAMdrho command: delta <= 0.0");
	}
}

void PairStyle::setPairEAMDumpdr(void* pPair, double delta)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	pair->m_dump.dr = delta;
	if (delta <= 0.0) {
		error->all(FLERR, "Illegal setPairEAMdr command: delta <= 0.0");
	}
}

void PairStyle::setPairEAMDumpCutoff(void* pPair, double cut)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	pair->m_dump.cut = cut;
	if (cut <= 0.0) {
		error->all(FLERR, "Illegal setPairEAMCutoff command: cut <= 0.0");
	}
}

void PairStyle::setPairEAMDumpImageEmbXMult(void* pPair, double ratio)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	pair->dump_sample_fmult = ratio;
	if (ratio <= 0.0) {
		error->all(FLERR, "Illegal setPairEAMDumpImageEmbSampleXMult command: ratio <= 0.0");
	}
}

void PairStyle::setPairEAMDumpImageLimitRlo(void* pPair, double lo)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	pair->xlim[2].customlo = pair->xlim[1].customlo = lo;
	if (lo < 0.0) {
		error->all(FLERR, "Illegal setPairEAMDumpImageLimitRlo command: lo < 0.0");
	}
}

void PairStyle::setPairEAMDumpFileElementTitle(void* pPair, int type, const char* title)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	if (type < 1 || type > force->get_ntypes()) {
		error->all(FLERR, "Illegal setPairEAMDumpFileElementTitle command: type < 1 || type > ntype");
	}
	pair->element_title[type] = title;
}

void PairStyle::setPairEAMOutputMode(void* pPair, const char* mode)
{
	((Pair*)pPair)->styleCheck(FLERR, "eam", 1);
	auto pair = (PairEAM*)pPair;

	if (strcmp(mode, "alloy") == 0) {
		pair->exportAsFsFlag = false;
		pair->chkStyle = "eam/alloy";
	}
	else if(strcmp(mode, "fs") == 0) {
		pair->exportAsFsFlag = true;
		pair->chkStyle = "eam/fs";
	}
	else {
		ErrorAll("Illegal setPairEAMOutputMode mode: %s", mode);
	}
}


#define PACK(N, CMD)						\
for (int ii = 0; ii < N; ii++){				\
	buf[m++] = safedump(CMD);				\
}	

int PairEAM::image(class DumpImage* dumpimage)
{
	Image* image = dumpimage->image;
	if(image->axes.empty()) image->subplots(3, 1);
	int ntypes = force->get_ntypes();
	auto eles = force->getEles();

	// 1. get number of points to draw and malloc memory
	int nR = image->axes[0].width;
	int nr = image->axes[1].width;

	int nz2r = ntypes * (ntypes + 1) / 2;
	int nrhor = exportAsFsFlag ? ntypes * ntypes : ntypes;
	double* buf = dumpimage->requestDbuf(nR * ntypes + nr * nrhor + nr * nz2r);

	// 2. get sampling point features
	double rhomax = 0, phimax = 0, tmp;
	for (int itype = 1; itype <= ntypes; itype++) {
		int jlo = exportAsFsFlag ? 1 : itype;
		int jhi = exportAsFsFlag ? ntypes : itype;

		for (int jtype = jlo; jtype <= jhi; jtype++) {
			tmp = safedump(rho(itype, jtype, dump_sample[1]));
			rhomax = MAX(rhomax, tmp);
		}
		for (int jtype = 1; jtype <= itype; jtype++) {
			tmp = safedump(phi(itype, jtype, dump_sample[2]));
			phimax = MAX(phimax, tmp);
		}
	}

	double embmax = 0, embmin = 0;
	double Rsample1 = 14 * rhomax;
	double Rsample2 = Rsample1 * dump_sample_fmult;

	for (int itype = 1; itype <= ntypes; itype++) {
		embmax = MAX(embmax, safedump(emb(itype, Rsample1)));
		embmin = MIN(embmin, safedump(emb(itype, Rsample1)));
		embmax = MAX(embmax, safedump(emb(itype, Rsample2)));
		embmin = MIN(embmin, safedump(emb(itype, Rsample2)));
	}
	embmax *= embmax > 0 ? 1.1 : 0.9;
	embmin *= embmin < 0 ? 1.1 : 0.9;

	xlim[0].set(0.0, Rsample2).update();
	xlim[1].set(0.0, m_dump.cut).update();
	xlim[2].set(0.0, m_dump.cut).update();

	// 3. pack image data

	double dR = (xlim[0].hi - xlim[0].lo) / nR;
	double dr = (xlim[1].hi - xlim[1].lo) / nr;
	double Rlo = xlim[0].lo, rlo = xlim[1].lo;

	int idx = 0, m = 0, off = 0;
	for (int itype = 1; itype <= ntypes; itype++) {
		PACK(nR, emb(itype, Rlo + ii * dR))
	}

	for (int itype = 1; itype <= ntypes; itype++) {
		int jlo = exportAsFsFlag ? 1 : itype;
		int jhi = exportAsFsFlag ? ntypes : itype;
		for (int jtype = jlo; jtype <= jhi; jtype++) {
			PACK(nr, rho(itype, jtype, rlo + ii * dr));
		}
	}

	for (int itype = 1; itype <= ntypes; itype++) {
		for (int jtype = 1; jtype <= itype; jtype++) {
			PACK(nr, phi(itype, jtype, rlo + ii * dr));
		}
	}

	// 4. evaluate the drawing range

	double lo = 0, hi = 0;
	input->getRange(nR * ntypes, &buf[off], lo, hi);
	ylim[0].set(fmin(lo, embmin), embmax).update();

	ylim[1].set(0.0, rhomax * 1.2).update();

	off = nR * ntypes + nr * nrhor;
	input->getRange(nr * nz2r, &buf[off], lo, hi);
	if (lo < 0) {
		lo = MIN(-0.02, lo);
		ylim[2].set(lo * 1.2, -lo * 1.2).update();
	} else {
		ylim[2].set(lo * 0.8, phimax * 1.2).update();
	}

	/**********************************************     Plotting     **********************************************/

	char label[10];	
	Axes& fAxes = image->axes[0].limit(xlim[0], ylim[0]);
	Axes& rAxes = image->axes[1].limit(xlim[1], ylim[1]);
	Axes& pAxes = image->axes[2].limit(xlim[1], ylim[2]);
	back_image(dumpimage, &fAxes, &rAxes, &pAxes);

	/************************************ Embedding energy and Electron density ************************************/

	m = 0;
	for (int itype = 1; itype <= ntypes; itype++) {
		sprintf(label, "--%s", eles[itype]);				// legend information
		image->setColorRainbow((itype - 0.9) / ntypes);		// set plot color
		fAxes.plot(nR, &buf[m], label);						// plot line
		m += nR;											// next data
	}

	idx = 0;
	for (int itype = 1; itype <= ntypes; itype++) {		
		int jlo = exportAsFsFlag ? 1 : itype;
		int jhi = exportAsFsFlag ? ntypes : itype;
		for (int jtype = jlo; jtype <= jhi; jtype++) {
			sprintf(label, "--%s/%s", eles[itype], eles[jtype]);
			image->setColorRainbow((idx + 0.1) / nrhor);
			rAxes.plot(nr, &buf[m], label);					// input plot number and data
			m += nr; idx++;									// next data			
		}
	}

	/************************************** y = 0 boundary and Pair function ***************************************/

	image->setColoru(0, 255, 0);							// set plot color as green
	PlotLine line = { 0.0, 0.0, 1.0, 0, 5, 5 };				// y = 0, x = [0 1], horizontal, (5, 5) for dotted line
	pAxes.line(line);										// Green dotted line for marking y = 0 boundary
	
	idx = 0;
	for (int itype = 1; itype <= ntypes; itype++)
	for (int jtype = 1; jtype <= itype; jtype++){					
		sprintf(label, "--%s/%s", eles[itype], eles[jtype]);
		image->setColorRainbow((idx + 0.1) / nz2r);			// set plot color
		pAxes.plot(nr, &buf[m], label);						// input plot number and data
		m += nr; idx++;
	}						

	fAxes.legend(0.8, 0.8).xlabel = "F(rho)";
	rAxes.legend(0.8, 0.8).xlabel = "rho(r)";
	pAxes.legend(0.8, 0.8).xlabel = "phi(r)";

	image->show();
	return 0;
};

void printFunc(const int idx, double* ptr) {
	int kk = idx - 1;
	printf(FDBLFMTG ", ", ptr[kk]);
	if (kk % 4 == 3) printf("\n");	
}

void PairEAM::chkListFunc(int Nrho, double rholo, double drho, int Nr, 
	double rlo, double dr, double* fChk, double* rChk, double* pChk, int fs, int printFlag) {


	double x;
	int idx, ntypes = force->get_ntypes();

	idx = 0;
	for (int m = 1; m <= ntypes; m++) {
		for (int i = 0; i < Nrho; i++) {
			x = rholo + i * drho;
			fChk[idx++] = emb(m, x);

			if (printFlag) printFunc(idx, fChk);
		}
	}

	idx = 0;

	if(fs)
	for (int m = 1; m <= ntypes; m++) {
		for (int n = 1; n <= ntypes; n++) {
			for (int i = 0; i < Nr; i++) {
				x = rlo + i * dr;
				rChk[idx++] = rho(m, n, x);
				if (printFlag) printFunc(idx, rChk);


			}
		}
	}
	else {
		for (int m = 1; m <= ntypes; m++) {
			for (int i = 0; i < Nr; i++) {
				x = rlo + i * dr;
				rChk[idx++] = rho(m, m, x);
				if (printFlag) printFunc(idx, rChk);
			}
		}
	}

	idx = 0;
	for (int m = 1; m <= ntypes; m++) {
		for (int n = 1; n <= m; n++) {
			for (int i = 0; i < Nr; i++) {
				x = rlo + i * dr;
				pChk[idx++] = phi(m, n, x);
				if (printFlag) printFunc(idx, pChk);
			}
		}
	}

}