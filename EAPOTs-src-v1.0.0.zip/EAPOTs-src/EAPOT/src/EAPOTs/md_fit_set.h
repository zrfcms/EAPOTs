//#ifndef EAPOT_MD_FIT_SET_H
//#define EAPOT_MD_FIT_SET_H
//
//#include "pointers.h"
//#include <string>
//#include <vector>
//
//using namespace std;
//#define NRefAtomKey 22
//
//namespace EAPOT_NS {
//
//	enum class CostTarget {
//		ENERGY, FORCE, VIRIAL
//	};
//
//	class MDFitSet : public Pointers {
//	public:
//		MDFitSet(EAPOT* eapot);
//		~MDFitSet();
//
//		void* md;
//		int settings(int narg, char** arg);							// Analyze command user input
//		void referLoadMmemoryCreate(tagint, void* md);
//		void referLoadMmemoryDestroy(void* md);
//
//		void init(tagint num, tagint* idx, void* md);				// Read reference file	
//		double computeCostTemplate(double* cal, CostTarget type);
//		void compute(tagint* tagAim, double* eatom, double* fatom, double* vatom);		
//		
//		void sort_setup();											// prepare Tag2Idx and tagmin/max
//		static bool sortIsEqual(tagint, tagint*, tagint*);			// determind if sort needed: if refTag[i]!=idx[i]
//		void sort(tagint* tag, int idx = -1);						// sort atoms sequence for reference data
//		void copy_ref(int i, int j);								// copy data
//
//	public:
//		int reloadFlag, remapMode;
//
//		int relaxBoxFlag;
//		int relaxAtomFlag;
//		int relaxTriclinicFlag;
//		int useMaxForceFlag;
//
//		string remapReference;
//		double relaxStressTarget[6];
//
//		int cost_mode[NRefAtomKey];			// Cost function calculation mode
//											// 0. weight * (cal/ref - 1)^2	 normal   mode
//											// 1. weight * (cal - ref)^2	 absolute mode
//
//		double computeResults[3];			// Cost function calculation result
//		
//	public:
//		int setEvalEnergy(const char* arg);
//		int setEvalVirial(const char* arg);
//
//		bool evalEnergyAtom, evalVirialGlobal, evalVirialAtom;
//
//	public:
//		tagint tagmin, tagmax, * Tag2Idx;
//		tagint refNum, * refTag, * permute, * current;
//
//		double* refEnergy;					// Fitting targets for Energy
//		double** refForce;					// Fitting targets for Force
//		double** refVirial;					// Fitting targets for Virial
//
//		double* weightEnergy;				// Fitting weights for Energy
//		double** weightForce;				// Fitting weights for Force
//		double** weightVirial;				// Fitting weights for Virial
//
//	private:
//		string refName;
//		int refEnergyFlag;					// if energy in reference file
//		int refForceFlag;					// if force  in reference file
//		int refVirialFlag;					// if virial in reference file
//
//		// determind refEnergy/Force/VirialFlag
//		int data_reference_init(char*, std::string&);	
//		void data_reference(int nwords, int start, int n, char* buf);
//	};
//
//}
//
//#endif
