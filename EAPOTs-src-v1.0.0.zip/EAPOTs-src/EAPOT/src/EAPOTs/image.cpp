#include <math.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "image.h"
#include "error.h"
#include "force.h"
#include "memory.h"

#ifdef USE_LIBJPEG
extern "C" {
#include "jpeglib.h"
}
#endif

using namespace std;
using namespace EAPOT_NS;


#define NCOLORS 140
#define NELEMENTS 109
#define EPSILON 1.0e-6
#define BMP_Header_Length 54

#define FONTW 8
#define FONTH 16

enum{ NUMERIC, MINVALUE, MAXVALUE };
enum{ CONTINUOUS, DISCRETE, SEQUENTIAL };
enum{ ABSOLUTE, FRACTIONAL };
enum{ NO, YES };

/* ---------------------------------------------------------------------- */

Axes::Axes(Image* pimage)
	: image(pimage)
	, xrange{ 0,0,0 }
	, yrange{ 0,0,0 }
{
	xlo = 0;
	ylo = 0;
	width = 32;
	height = 32;
	xhi = 32;
	yhi = 32;

	box = true;
	xlabel = "X Axis";				//label in x axis
	ylabel = "Y Axis";				//label in y axis
}

Axes& Axes::legend(double cx, double cy) {

	if (!labelText.size()) return *this;

	double fontw = (double)image->font.width / width;
	double fonth = (double)image->font.height / height;
	size_t num = labelText.size();


	size_t len = labelText[0].size();
	for (size_t i = 0; i < labelText.size(); i++) {
		len = MAX(len, labelText[i].size());
	}

	double halfW = fontw * len * 0.5;
	double halfH = fonth * num * 0.5;

	for (int i = 0; i < (int)labelText.size(); i++) {
		Color& c = plotColor[i];
		image->setColoru(c.r, c.g, c.b);
		text(cx - halfW, cy + halfH, labelText[i].c_str(), 0, -(1.0 + i));
	}

	image->setColord(0, 0.0, 0.0);
	frame(cx - halfW, cx + halfW, cy - halfH, cy + halfH, 5, true);

	plotColor.clear();
	labelText.clear();
	return *this;
}

void Axes::show() {

	if (box) {
		image->setColord(0, 0.0, 0.0);
		frame(0, 1, 0, 1, 0);
	}
	if (!xlabel.empty()) {
		image->setColord(0, 0.0, 0.0);
		int half = static_cast<int>(strlen(xlabel.c_str()));
		text(0.5, 0.0, xlabel.c_str(), -half / 2, -1.5);
	}
}


Axes& Axes::setRange(double dx, double dy, double dwidth, double dheight) {

	// Convert to absolute coordinates
	xlo = static_cast<int>(image->width * dx);
	ylo = static_cast<int>(image->height * dy);
	width = static_cast<int>(image->width * dwidth);
	height = static_cast<int>(image->height * dheight);

	// Legality check
	if (xlo >= image->width) xlo = image->width - 1;
	if (ylo >= image->height) ylo = image->height - 1;
	if (xlo < 0) xlo = 0;
	if (ylo < 0) ylo = 0;

	if (xlo + width >= image->width)
		width = image->width - 1 - xlo;
	if (ylo + height >= image->height)
		height = image->height - 1 - ylo;
	if (width < 0) width = 0;
	if (height < 0) height = 0;

	xhi = width + xlo;
	yhi = height + ylo;
	return *this;
}


Axes& Axes::limit(const AxisLimit& x, const AxisLimit& y) {
	return limit(x.lo, x.hi, y.lo, y.hi);
}

// Data limits in the x and y directions when drawing
// just like axis(), ylim(), xlim() in matlab,
Axes& Axes::limit(double x1, double x2, double y1, double y2) {

	xrange[0] = x1;
	xrange[1] = x2;

	yrange[0] = y1;
	yrange[1] = y2;

	xrange[2] = xrange[1] - xrange[0];
	yrange[2] = yrange[1] - yrange[0];
	return *this;
}



Axes& Axes::plot(int n, double* y, const char* label) {

	if (n < width) return *this;;

	double dy, lastdy;
	int m = 0;

	image->yUnitize(n, y, yrange[0], yrange[1], ylo, yhi);

	lastdy = y[m++];
	for (int ix = xlo + 1; ix < xhi; ix++) {
		dy = y[m++];

		if (fabs(dy - lastdy) <= 1.0)
			image->drawColor_y(ix, dy);
		else {
			image->Bresenhamy(ix - 1, ix, lastdy, dy);
		}
		lastdy = dy;
	}

	if (label) {
		plotColor.push_back(image->color);
		labelText.push_back(string(label));
	}
	return *this;
}

Axes& Axes::line(PlotLine line) {

	int start, finish;
	double data = line.data;						// point coordinates in a axis	

	if (line.start < 0)line.start = 0;				// Range between 0 and 1
	if (line.finish > 1)line.finish = 1;			// Range between 0 and 1

	if (line.vertical) {							// Convert to absolute coordinates
		image->xUnitize(1, &data, xrange[0], xrange[1], xlo, xhi);
		start = static_cast<int>(ylo + line.start * height);
		finish = static_cast<int>(ylo + line.finish * height);
	}
	else {											// Convert to absolute coordinates
		image->yUnitize(1, &data, yrange[0], yrange[1], ylo, yhi);
		start = static_cast<int>(xlo + line.start * width);
		finish = static_cast<int>(xlo + line.finish * width);
	}

	int m = start;
	int reallen = line.reallen;						// Solid line length in dashed line
	int imagelen = line.imagelen;					// Blank length in dashed line

	if (line.vertical) {
		while (m < finish) {
			image->drawColor_x(data, m++);			// draw Solid line and jump Blank length 
			if (m % reallen == 0) m += imagelen;
		}
	}
	else {
		while (m < finish) {
			image->drawColor_y(m++, data);			// draw Solid line and jump Blank length 
			if (m % reallen == 0) m += imagelen;
		}
	}
	return *this;
}

Axes& Axes::frame(double dxlo, double dxhi,
	double dylo, double dyhi, int margin, bool check) {

	int gxlo = static_cast<int>(xlo + dxlo * width) - margin;
	int gxhi = static_cast<int>(xlo + dxhi * width) + margin;

	int gylo = static_cast<int>(ylo + dylo * height) - margin;
	int gyhi = static_cast<int>(ylo + dyhi * height) + margin;

	if (check) {
		gxlo = MAX(MIN(gxlo, xhi), xlo);
		gxhi = MAX(MIN(gxhi, xhi), xlo);
		gylo = MAX(MIN(gylo, yhi), ylo);
		gyhi = MAX(MIN(gyhi, yhi), ylo);
	}

	image->drawFrameLineY(gxlo, gylo, gyhi);
	image->drawFrameLineY(gxhi, gylo, gyhi);
	image->drawFrameLineX(gylo, gxlo, gxhi);
	image->drawFrameLineX(gyhi, gxlo, gxhi);
	return *this;
}

Axes& Axes::text(double dx, double dy, const char* str, double xoffset, double yoffset) {

	if (!str) return *this;;
	size_t len = strlen(str);
	if (len > 32) len = 32;

	int xs = static_cast<int>(xlo + width * dx + xoffset * FONTW);
	int ys = static_cast<int>(ylo + height * dy + yoffset * FONTH);

	int ilen = len;
	if (xs < 0 || xs + FONTW * ilen >= image->width) return *this;;
	if (ys < 0 || ys + FONTH >= image->height) return *this;;


	ubyte line;
	bool colored[FONTW][FONTH];

	for (size_t ic = 0; ic < len; ic++) {
		const ubyte* ASC = image->ascii(str[ic]);
		memset(colored, 0, sizeof(colored));
		for (int j = 0; j < 8; j++) {
			line = ASC[8 + j];
			colored[j][0] = (line & 128) != 0;
			colored[j][1] = (line & 64) != 0;
			colored[j][2] = (line & 32) != 0;
			colored[j][3] = (line & 16) != 0;
			colored[j][4] = (line & 8) != 0;
			colored[j][5] = (line & 4) != 0;
			colored[j][6] = (line & 2) != 0;
			colored[j][7] = (line & 1) != 0;

			line = ASC[j];
			colored[j][8] = (line & 128) != 0;
			colored[j][9] = (line & 64) != 0;
			colored[j][10] = (line & 32) != 0;
			colored[j][11] = (line & 16) != 0;
			colored[j][12] = (line & 8) != 0;
			colored[j][13] = (line & 4) != 0;
			colored[j][14] = (line & 2) != 0;
			colored[j][15] = (line & 1) != 0;
		}

		for (int mix = 0; mix < FONTH; mix++)
			for (int njy = 0; njy < FONTW; njy++) {
				int jx = njy + ic * 8 + xs;
				int iy = mix + ys;

				if (colored[njy][mix]) image->drawColor_s(jx, iy);
			}
	}
	return *this;
}




Image::Image(EAPOT* eapot, int nmap_caller)
	: Pointers(eapot)
	, color{ 0,0,0 }
	, backColor{ 255, 255, 255 }
{
	// defaults for 3d viz

	width = 768;
	height = 384;
	format = ImageFormat::BMP;
	quality = 90;

	font.width = FONTW;
	font.height = FONTH;

	linewidth = 1;

	npixels = 0;
	imageBuffer = NULL;
}

/* ---------------------------------------------------------------------- */

Image::~Image()
{
	memory->destroy(imageBuffer);
}

/* ----------------------------------------------------------------------
allocate image and depth buffers
called after image size is set
------------------------------------------------------------------------- */

void Image::buffers()
{
	if (format == ImageFormat::BMP || format == ImageFormat::JPG){
		//Calculate the actual length of the pixel data
		linewidth = width * 3;				// get the pixel data length of each line
		while (linewidth % 4 != 0)			// Add data until the multiple of i is
			linewidth++;					// There is still a faster algorithm, but here only the pursuit
											// of intuitive, not too high speed requirements
	}
	npixels = linewidth * height;

	if (imageBuffer) memory->destroy(imageBuffer);
	memory->create(imageBuffer, npixels, "image:imageBuffer");
}


/* ----------------------------------------------------------------------
initialize image to background color and depth buffer
no need to init surfaceBuffer, since will be based on depth
------------------------------------------------------------------------- */

void Image::clear()
{
	int ix, iy, off;
	unsigned char *pBuffer;
	for (iy = 0; iy < height; iy++)
	for (ix = 0; ix < width; ix++) {
		off = iy * linewidth + ix * 3;
		pBuffer = &imageBuffer[off];
		pBuffer[0] = backColor.r;
		pBuffer[1] = backColor.g;
		pBuffer[2] = backColor.b;
	}
}

void Image::show() {
	for (auto& iaxes : axes) {
		iaxes.show();
	}
}

/* ---------------------------------------------------------------------- */

void Image::drawPixel(int ix, int iy, double *c)
{
	c[0] = saturate(c[0]);
	c[1] = saturate(c[1]);
	c[2] = saturate(c[2]);

	int off = iy * linewidth + ix * 3;;
	unsigned char *pBuffer = &imageBuffer[off];
	pBuffer[0] = static_cast<int>(c[0] * 255.0);
	pBuffer[1] = static_cast<int>(c[1] * 255.0);
	pBuffer[2] = static_cast<int>(c[2] * 255.0);
}

void Image::drawColor(int ix, int iy)
{
	int off = iy * linewidth + ix * 3;;
	unsigned char *pBuffer = &imageBuffer[off];
	pBuffer[0] = color.r;
	pBuffer[1] = color.g;
	pBuffer[2] = color.b;
}

void Image::drawColor_s(int ix, int iy)
{
	if (ix < 0 || iy < 0 || ix >= width || iy >= height)
		return;
	drawColor(ix, iy);
}

void Image::drawColor(int ix, int iy, double alpha)
{
	double alpham = 1 - alpha;
	int off = iy * linewidth + ix * 3;;
	ubyte *pBuffer = &imageBuffer[off];
	pBuffer[0] = static_cast<ubyte>(alpha*color.r + alpham * pBuffer[0]);
	pBuffer[1] = static_cast<ubyte>(alpha*color.g + alpham * pBuffer[1]);
	pBuffer[2] = static_cast<ubyte>(alpha*color.b + alpham * pBuffer[2]);
}

void Image::drawColor_s(int ix, int iy, double alpha)
{
	if (ix < 0 || iy < 0 ||	ix >= width || iy >= height)
		return;
	drawColor(ix, iy, alpha);
}

void Image::drawColor_y(int ix, double dy, double alpha)
{
	int iy = static_cast<int> (dy);
	double dy1 = dy - iy; 
	double dy2 = 1 - dy1;
	double beta = 1.4 - 1.6*(dy1 - 0.5)*(dy1 - 0.5);
	beta *= alpha;
	drawColor_s(ix, iy, MIN(dy2*beta, 1.0));
	drawColor_s(ix, iy + 1, MIN(dy1*beta, 1.0));
}

void Image::drawColor_x(double dx, int iy, double alpha)
{
	int ix = static_cast<int> (dx);
	double dx1 = dx - ix;
	double dx2 = 1 - dx1;
	double beta = 1.4 - 1.6*(dx1 - 0.5)*(dx1 - 0.5);
	beta *= alpha;

	drawColor_s(ix, iy, MIN(dx2*beta, 1.0));
	drawColor_s(ix + 1, iy, MIN(dx1*beta, 1.0));
}

void Image::BGRTrans(ubyte& r, ubyte& g, ubyte& b){
	unsigned char t;
	t = b;
	b = r;
	r = t;
}

void Image::setColord(double r, double g, double b){
	color.r = static_cast<int>(r * 255.0);
	color.g = static_cast<int>(g * 255.0);
	color.b = static_cast<int>(b * 255.0);
	if (format == ImageFormat::BMP) 
		BGRTrans(color.r, color.g, color.b);
}

void Image::setColoru(ubyte r, ubyte g, ubyte b){
	color.r = r;
	color.g = g;
	color.b = b;
	if (format == ImageFormat::BMP)
		BGRTrans(color.r, color.g, color.b);
}

Color Image::setColorRainbow(double x) {

	if (x < 1.0 / 3) {
		setColord(1.0, 3 * x, 0);
	}
	else if (x < 2.0 / 3) {
		setColord(2 - 3 * x, 1.0, 3 * x - 1);
	}
	else {
		setColord(0, 3 - 3 * x, 1.0);		
	}
	return color;
}


inline void swap(int& m, int& n){
	int t = m;
	m = n;
	n = t;
}
inline void swap(double& m, double& n){
	double t = m;
	m = n;
	n = t;
}

void Image::Bresenhamy(int ix1, int ix2, double dy1, double dy2){

	//need dy1 < dy2
	if (dy1 > dy2){
		swap(dy1, dy2);
		swap(ix1, ix2);
	}

	//x = ky + b
	double k = ((double)ix2 - ix1) / (dy2 - dy1);
	double b = ix1 - k*dy1;

	int begin = static_cast<int>(dy1 + 0.5);
	int finsh = static_cast<int>(dy2 + 0.5);

	double dx = k*((double)begin-1) + b;
	for (int iy = begin; iy <= finsh; iy++){
		dx += k;
		drawColor_x(dx, iy);
	}
}

void Image::drawFrameLineY(int x, int y1, int y2){
	for (int i = y1; i <= y2; i++)
		drawColor(x, i);
}
void Image::drawFrameLineX(int y, int x1, int x2){
	for (int i = x1; i <= x2; i++)
		drawColor(i, y);
}

void Image::xUnitize(int n, double* x, double xlo,
	double xhi, double unitlo, double unithi){

	double t;
	double delta = (unithi - unitlo) / (xhi - xlo);
	if (delta <= 0) return;

	for (int i = 0; i < n; i++){
		t = x[i];
		x[i] = (t - xlo) * delta + unitlo;

		if (x[i] >= unithi)x[i] = unithi;
		if (x[i] <= unitlo)x[i] = unitlo;
	}
}

void Image::yUnitize(int n, double* y, double ylo, 
	double yhi, double unitlo, double unithi){

	double t;
	double delta = (unithi - unitlo)/(yhi - ylo);
	if (delta <= 0) return;

	for (int i = 0; i < n; i++){
		t = y[i];
		y[i] = (t - ylo) * delta + unitlo;

		if (y[i] >= unithi)y[i] = unithi;
		if (y[i] <= unitlo)y[i] = unitlo;
	}
}


// create the drawing area size, in relative coordinates
void Image::createAxes(double dx,
	double dy, double dwidth, double dheight){

	axes.push_back(std::move(Axes(this)));
	axes.back().setRange(dx, dy, dwidth, dheight);
}

std::vector<Axes>& Image::subplots(int nx, int ny) {

	double tHeight = (double)font.height / height;
	double xplot = 0.9 / nx;
	double yplot = 0.9 / ny;

	double xlo, ylo;
	double xframe = 0.1 / (nx + 1.0);
	double yframe = 0.1 / (ny + 1.0);

	for (int i = 0; i < ny; i++) {
		int yidx = (size_t)ny - i - 1;
		ylo = yplot * yidx + yframe * (yidx + 1.0);

		for (int j = 0; j < nx; j++) {
			xlo = xplot * j + xframe * (j + 1.0);
			createAxes(xlo, ylo + tHeight, xplot, yplot - tHeight);
		}
	}
	return axes;
}




/* ---------------------------------------------------------------------- */

void Image::write(FILE* fp) {
	switch (format)
	{
	case EAPOT_NS::Image::ImageFormat::BMP:
		writeBMP(fp);
		break;
	case EAPOT_NS::Image::ImageFormat::JPG:
		writeJPG(fp);
		break;
	case EAPOT_NS::Image::ImageFormat::PNG:
		writeBMP(fp);
		break;
	default:
		writeBMP(fp);
		break;
	}
}

void Image::writeBMP(FILE *fp)
{
	//fprintf(fp, "P6\n%d %d\n255\n", width, height);
	//for (int y = height - 1; y >= 0; y--)
	//	fwrite(&writeBuffer[y*width * 3], 3, width, fp);

	unsigned char mHeader[BMP_Header_Length] = {
		0x42, 0x4d, 0x36, 0xf3, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 0xc0, 0x00,
		0x00, 0x00, 0x6c, 0x00, 0x00, 0x00, 0x01, 0x00, 0x18, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0xf3, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00,
	};

	fwrite(mHeader, BMP_Header_Length, 1, fp);
	fseek(fp, 0x0012, SEEK_SET);

	fwrite(&width, sizeof(width), 1, fp);   //write length, height
	fwrite(&height, sizeof(height), 1, fp);

	fseek(fp, 0, SEEK_END);	// move to the end of the file
	fwrite(imageBuffer, npixels, 1, fp);
}


void Image::writeJPG(FILE* fp)
{
#ifdef USE_LIBJPEG
	struct jpeg_compress_struct jcs;
	struct jpeg_error_mgr jem;
	jcs.err = jpeg_std_error(&jem);
	jpeg_create_compress(&jcs);

	jpeg_stdio_dest(&jcs, fp);
	jcs.image_width = width;		//
	jcs.image_height = height;		//
	jcs.input_components = 3;		//
	jcs.in_color_space = JCS_RGB;	//JCS_GRAYSCALE
	jpeg_set_defaults(&jcs);
	jpeg_set_quality(&jcs, quality, 1);

	jpeg_start_compress(&jcs, 1);
	for (int i = 0; i < height; i++) {
		unsigned char* iline = &imageBuffer[(height - i - 1) * linewidth];
		jpeg_write_scanlines(&jcs, &iline, 1);
	}
	jpeg_finish_compress(&jcs);
	jpeg_destroy_compress(&jcs);
#else
	write_BMP(fp);
#endif
}

/* ----------------------------------------------------------------------
if index > 0, return ptr to index-1 color from rgb
if index < 0, return ptr to -index-1 color from userrgb
if index = 0, search the 2 lists of color names for the string color
search user-defined color names first, then the list of NCOLORS names
return a pointer to the 3 floating point RGB values or NULL if didn't find
------------------------------------------------------------------------- */

double *Image::color2rgb(const char *color, int index)
{
	static const char *name[NCOLORS] = {
		"aliceblue",
		"antiquewhite",
		"aqua",
		"aquamarine",
		"azure",
		"beige",
		"bisque",
		"black",
		"blanchedalmond",
		"blue",
		"blueviolet",
		"brown",
		"burlywood",
		"cadetblue",
		"chartreuse",
		"chocolate",
		"coral",
		"cornflowerblue",
		"cornsilk",
		"crimson",
		"cyan",
		"darkblue",
		"darkcyan",
		"darkgoldenrod",
		"darkgray",
		"darkgreen",
		"darkkhaki",
		"darkmagenta",
		"darkolivegreen",
		"darkorange",
		"darkorchid",
		"darkred",
		"darksalmon",
		"darkseagreen",
		"darkslateblue",
		"darkslategray",
		"darkturquoise",
		"darkviolet",
		"deeppink",
		"deepskyblue",
		"dimgray",
		"dodgerblue",
		"firebrick",
		"floralwhite",
		"forestgreen",
		"fuchsia",
		"gainsboro",
		"ghostwhite",
		"gold",
		"goldenrod",
		"gray",
		"green",
		"greenyellow",
		"honeydew",
		"hotpink",
		"indianred",
		"indigo",
		"ivory",
		"khaki",
		"lavender",
		"lavenderblush",
		"lawngreen",
		"lemonchiffon",
		"lightblue",
		"lightcoral",
		"lightcyan",
		"lightgoldenrodyellow",
		"lightgreen",
		"lightgrey",
		"lightpink",
		"lightsalmon",
		"lightseagreen",
		"lightskyblue",
		"lightslategray",
		"lightsteelblue",
		"lightyellow",
		"lime",
		"limegreen",
		"linen",
		"magenta",
		"maroon",
		"mediumaquamarine",
		"mediumblue",
		"mediumorchid",
		"mediumpurple",
		"mediumseagreen",
		"mediumslateblue",
		"mediumspringgreen",
		"mediumturquoise",
		"mediumvioletred",
		"midnightblue",
		"mintcream",
		"mistyrose",
		"moccasin",
		"navajowhite",
		"navy",
		"oldlace",
		"olive",
		"olivedrab",
		"orange",
		"orangered",
		"orchid",
		"palegoldenrod",
		"palegreen",
		"paleturquoise",
		"palevioletred",
		"papayawhip",
		"peachpuff",
		"peru",
		"pink",
		"plum",
		"powderblue",
		"purple",
		"red",
		"rosybrown",
		"royalblue",
		"saddlebrown",
		"salmon",
		"sandybrown",
		"seagreen",
		"seashell",
		"sienna",
		"silver",
		"skyblue",
		"slateblue",
		"slategray",
		"snow",
		"springgreen",
		"steelblue",
		"tan",
		"teal",
		"thistle",
		"tomato",
		"turquoise",
		"violet",
		"wheat",
		"white",
		"whitesmoke",
		"yellow",
		"yellowgreen"
	};

	static double rgb[NCOLORS][3] = {
		{ 240 / 255.0, 248 / 255.0, 255 / 255.0 },
		{ 250 / 255.0, 235 / 255.0, 215 / 255.0 },
		{ 0 / 255.0, 255 / 255.0, 255 / 255.0 },
		{ 127 / 255.0, 255 / 255.0, 212 / 255.0 },
		{ 240 / 255.0, 255 / 255.0, 255 / 255.0 },
		{ 245 / 255.0, 245 / 255.0, 220 / 255.0 },
		{ 255 / 255.0, 228 / 255.0, 196 / 255.0 },
		{ 0 / 255.0, 0 / 255.0, 0 / 255.0 },
		{ 255 / 255.0, 255 / 255.0, 205 / 255.0 },
		{ 0 / 255.0, 0 / 255.0, 255 / 255.0 },
		{ 138 / 255.0, 43 / 255.0, 226 / 255.0 },
		{ 165 / 255.0, 42 / 255.0, 42 / 255.0 },
		{ 222 / 255.0, 184 / 255.0, 135 / 255.0 },
		{ 95 / 255.0, 158 / 255.0, 160 / 255.0 },
		{ 127 / 255.0, 255 / 255.0, 0 / 255.0 },
		{ 210 / 255.0, 105 / 255.0, 30 / 255.0 },
		{ 255 / 255.0, 127 / 255.0, 80 / 255.0 },
		{ 100 / 255.0, 149 / 255.0, 237 / 255.0 },
		{ 255 / 255.0, 248 / 255.0, 220 / 255.0 },
		{ 220 / 255.0, 20 / 255.0, 60 / 255.0 },
		{ 0 / 255.0, 255 / 255.0, 255 / 255.0 },
		{ 0 / 255.0, 0 / 255.0, 139 / 255.0 },
		{ 0 / 255.0, 139 / 255.0, 139 / 255.0 },
		{ 184 / 255.0, 134 / 255.0, 11 / 255.0 },
		{ 169 / 255.0, 169 / 255.0, 169 / 255.0 },
		{ 0 / 255.0, 100 / 255.0, 0 / 255.0 },
		{ 189 / 255.0, 183 / 255.0, 107 / 255.0 },
		{ 139 / 255.0, 0 / 255.0, 139 / 255.0 },
		{ 85 / 255.0, 107 / 255.0, 47 / 255.0 },
		{ 255 / 255.0, 140 / 255.0, 0 / 255.0 },
		{ 153 / 255.0, 50 / 255.0, 204 / 255.0 },
		{ 139 / 255.0, 0 / 255.0, 0 / 255.0 },
		{ 233 / 255.0, 150 / 255.0, 122 / 255.0 },
		{ 143 / 255.0, 188 / 255.0, 143 / 255.0 },
		{ 72 / 255.0, 61 / 255.0, 139 / 255.0 },
		{ 47 / 255.0, 79 / 255.0, 79 / 255.0 },
		{ 0 / 255.0, 206 / 255.0, 209 / 255.0 },
		{ 148 / 255.0, 0 / 255.0, 211 / 255.0 },
		{ 255 / 255.0, 20 / 255.0, 147 / 255.0 },
		{ 0 / 255.0, 191 / 255.0, 255 / 255.0 },
		{ 105 / 255.0, 105 / 255.0, 105 / 255.0 },
		{ 30 / 255.0, 144 / 255.0, 255 / 255.0 },
		{ 178 / 255.0, 34 / 255.0, 34 / 255.0 },
		{ 255 / 255.0, 250 / 255.0, 240 / 255.0 },
		{ 34 / 255.0, 139 / 255.0, 34 / 255.0 },
		{ 255 / 255.0, 0 / 255.0, 255 / 255.0 },
		{ 220 / 255.0, 220 / 255.0, 220 / 255.0 },
		{ 248 / 255.0, 248 / 255.0, 255 / 255.0 },
		{ 255 / 255.0, 215 / 255.0, 0 / 255.0 },
		{ 218 / 255.0, 165 / 255.0, 32 / 255.0 },
		{ 128 / 255.0, 128 / 255.0, 128 / 255.0 },
		{ 0 / 255.0, 128 / 255.0, 0 / 255.0 },
		{ 173 / 255.0, 255 / 255.0, 47 / 255.0 },
		{ 240 / 255.0, 255 / 255.0, 240 / 255.0 },
		{ 255 / 255.0, 105 / 255.0, 180 / 255.0 },
		{ 205 / 255.0, 92 / 255.0, 92 / 255.0 },
		{ 75 / 255.0, 0 / 255.0, 130 / 255.0 },
		{ 255 / 255.0, 240 / 255.0, 240 / 255.0 },
		{ 240 / 255.0, 230 / 255.0, 140 / 255.0 },
		{ 230 / 255.0, 230 / 255.0, 250 / 255.0 },
		{ 255 / 255.0, 240 / 255.0, 245 / 255.0 },
		{ 124 / 255.0, 252 / 255.0, 0 / 255.0 },
		{ 255 / 255.0, 250 / 255.0, 205 / 255.0 },
		{ 173 / 255.0, 216 / 255.0, 230 / 255.0 },
		{ 240 / 255.0, 128 / 255.0, 128 / 255.0 },
		{ 224 / 255.0, 255 / 255.0, 255 / 255.0 },
		{ 250 / 255.0, 250 / 255.0, 210 / 255.0 },
		{ 144 / 255.0, 238 / 255.0, 144 / 255.0 },
		{ 211 / 255.0, 211 / 255.0, 211 / 255.0 },
		{ 255 / 255.0, 182 / 255.0, 193 / 255.0 },
		{ 255 / 255.0, 160 / 255.0, 122 / 255.0 },
		{ 32 / 255.0, 178 / 255.0, 170 / 255.0 },
		{ 135 / 255.0, 206 / 255.0, 250 / 255.0 },
		{ 119 / 255.0, 136 / 255.0, 153 / 255.0 },
		{ 176 / 255.0, 196 / 255.0, 222 / 255.0 },
		{ 255 / 255.0, 255 / 255.0, 224 / 255.0 },
		{ 0 / 255.0, 255 / 255.0, 0 / 255.0 },
		{ 50 / 255.0, 205 / 255.0, 50 / 255.0 },
		{ 250 / 255.0, 240 / 255.0, 230 / 255.0 },
		{ 255 / 255.0, 0 / 255.0, 255 / 255.0 },
		{ 128 / 255.0, 0 / 255.0, 0 / 255.0 },
		{ 102 / 255.0, 205 / 255.0, 170 / 255.0 },
		{ 0 / 255.0, 0 / 255.0, 205 / 255.0 },
		{ 186 / 255.0, 85 / 255.0, 211 / 255.0 },
		{ 147 / 255.0, 112 / 255.0, 219 / 255.0 },
		{ 60 / 255.0, 179 / 255.0, 113 / 255.0 },
		{ 123 / 255.0, 104 / 255.0, 238 / 255.0 },
		{ 0 / 255.0, 250 / 255.0, 154 / 255.0 },
		{ 72 / 255.0, 209 / 255.0, 204 / 255.0 },
		{ 199 / 255.0, 21 / 255.0, 133 / 255.0 },
		{ 25 / 255.0, 25 / 255.0, 112 / 255.0 },
		{ 245 / 255.0, 255 / 255.0, 250 / 255.0 },
		{ 255 / 255.0, 228 / 255.0, 225 / 255.0 },
		{ 255 / 255.0, 228 / 255.0, 181 / 255.0 },
		{ 255 / 255.0, 222 / 255.0, 173 / 255.0 },
		{ 0 / 255.0, 0 / 255.0, 128 / 255.0 },
		{ 253 / 255.0, 245 / 255.0, 230 / 255.0 },
		{ 128 / 255.0, 128 / 255.0, 0 / 255.0 },
		{ 107 / 255.0, 142 / 255.0, 35 / 255.0 },
		{ 255 / 255.0, 165 / 255.0, 0 / 255.0 },
		{ 255 / 255.0, 69 / 255.0, 0 / 255.0 },
		{ 218 / 255.0, 112 / 255.0, 214 / 255.0 },
		{ 238 / 255.0, 232 / 255.0, 170 / 255.0 },
		{ 152 / 255.0, 251 / 255.0, 152 / 255.0 },
		{ 175 / 255.0, 238 / 255.0, 238 / 255.0 },
		{ 219 / 255.0, 112 / 255.0, 147 / 255.0 },
		{ 255 / 255.0, 239 / 255.0, 213 / 255.0 },
		{ 255 / 255.0, 239 / 255.0, 213 / 255.0 },
		{ 205 / 255.0, 133 / 255.0, 63 / 255.0 },
		{ 255 / 255.0, 192 / 255.0, 203 / 255.0 },
		{ 221 / 255.0, 160 / 255.0, 221 / 255.0 },
		{ 176 / 255.0, 224 / 255.0, 230 / 255.0 },
		{ 128 / 255.0, 0 / 255.0, 128 / 255.0 },
		{ 255 / 255.0, 0 / 255.0, 0 / 255.0 },
		{ 188 / 255.0, 143 / 255.0, 143 / 255.0 },
		{ 65 / 255.0, 105 / 255.0, 225 / 255.0 },
		{ 139 / 255.0, 69 / 255.0, 19 / 255.0 },
		{ 250 / 255.0, 128 / 255.0, 114 / 255.0 },
		{ 244 / 255.0, 164 / 255.0, 96 / 255.0 },
		{ 46 / 255.0, 139 / 255.0, 87 / 255.0 },
		{ 255 / 255.0, 245 / 255.0, 238 / 255.0 },
		{ 160 / 255.0, 82 / 255.0, 45 / 255.0 },
		{ 192 / 255.0, 192 / 255.0, 192 / 255.0 },
		{ 135 / 255.0, 206 / 255.0, 235 / 255.0 },
		{ 106 / 255.0, 90 / 255.0, 205 / 255.0 },
		{ 112 / 255.0, 128 / 255.0, 144 / 255.0 },
		{ 255 / 255.0, 250 / 255.0, 250 / 255.0 },
		{ 0 / 255.0, 255 / 255.0, 127 / 255.0 },
		{ 70 / 255.0, 130 / 255.0, 180 / 255.0 },
		{ 210 / 255.0, 180 / 255.0, 140 / 255.0 },
		{ 0 / 255.0, 128 / 255.0, 128 / 255.0 },
		{ 216 / 255.0, 191 / 255.0, 216 / 255.0 },
		{ 253 / 255.0, 99 / 255.0, 71 / 255.0 },
		{ 64 / 255.0, 224 / 255.0, 208 / 255.0 },
		{ 238 / 255.0, 130 / 255.0, 238 / 255.0 },
		{ 245 / 255.0, 222 / 255.0, 179 / 255.0 },
		{ 255 / 255.0, 255 / 255.0, 255 / 255.0 },
		{ 245 / 255.0, 245 / 255.0, 245 / 255.0 },
		{ 255 / 255.0, 255 / 255.0, 0 / 255.0 },
		{ 154 / 255.0, 205 / 255.0, 50 / 255.0 }
	};

	if (index > 0) {
		if (index > NCOLORS) return NULL;
		return rgb[index - 1];
	}

	for (int i = 0; i < NCOLORS; i++)
	if (strcmp(color, name[i]) == 0) return rgb[i];
	return NULL;
}

/* ----------------------------------------------------------------------
return number of default colors
------------------------------------------------------------------------- */

int Image::default_colors()
{
	return NCOLORS;
}

/* ----------------------------------------------------------------------
search the list of element names for the string element
return a pointer to the 3 floating point RGB values
this list is used by AtomEye and is taken from its Mendeleyev.c file
------------------------------------------------------------------------- */

double *Image::element2color(char *element)
{
	static const char *name[NELEMENTS] = {
		"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
		"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
		"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
		"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
		"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
		"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
		"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
		"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
		"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
		"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
		"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt"
	};

	static double rgb[NELEMENTS][3] = {
		{ 0.8, 0.8, 0.8 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.7, 0.7, 0.7 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.9, 0.4, 0 },
		{ 0.35, 0.35, 0.35 },
		{ 0.2, 0.2, 0.8 },
		{ 0.8, 0.2, 0.2 },
		{ 0.7, 0.85, 0.45 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6, 0.6, 0.6 },
		{ 0.6, 0.6, 0.7 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6901960784, 0.768627451, 0.8705882353 },
		{ 0.1, 0.7, 0.3 },
		{ 0.95, 0.9, 0.2 },
		{ 0.15, 0.5, 0.1 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.5, 0.5, 0.5 },
		{ 0.8, 0.8, 0.7 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0, 0.8, 0 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.5176470588, 0.5764705882, 0.6529411765 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.257254902, 0.2666666667, 0.271372549 },
		{ 0.95, 0.7900735294, 0.01385869565 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.9, 0, 1 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 1, 1, 0.3 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.5, 0.08, 0.12 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.5, 0.1, 0.5 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.8, 0.8, 0 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 1, 0.8431372549, 0 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.9, 0.8, 0 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.8, 0.2, 0.2 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.1, 0.7, 0.3 },
		{ 0.1, 0.3, 0.7 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.9, 0.8, 0 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 },
		{ 0.6431372549, 0.6666666667, 0.6784313725 }
	};

	for (int i = 0; i < NELEMENTS; i++)
	if (strcmp(element, name[i]) == 0) return rgb[i];
	return NULL;
}

/* ----------------------------------------------------------------------
search the list of element names for the string element
return a pointer to the 3 floating point RGB values
this list is used by AtomEye and is taken from its Mendeleyev.c file
------------------------------------------------------------------------- */

double Image::element2diam(char *element)
{
	static const char *name[NELEMENTS] = {
		"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
		"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
		"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
		"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
		"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
		"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
		"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
		"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
		"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
		"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
		"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt"
	};

	static double diameter[NELEMENTS] = {
		0.35, 1.785, 1.45, 1.05, 0.85, 0.72, 0.65, 0.6, 0.5, 1.5662,
		1.8, 1.5, 1.4255, 1.07, 1, 1, 1, 1.8597, 2.2, 1.8,
		1.6, 1.4, 1.51995, 1.44225, 1.4, 1.43325, 1.35, 1.35, 1.278, 1.35,
		1.3, 1.25, 1.15, 1.15, 1.15, 2.0223, 2.35, 2, 1.8, 1.55,
		1.6504, 1.3872, 1.35, 1.3, 1.35, 1.4, 1.6, 1.55, 1.55, 1.45,
		1.45, 1.4, 1.4, 2.192, 2.6, 2.15, 1.95, 1.85, 1.85, 1.85,
		1.85, 1.85, 1.85, 1.8, 1.75, 1.75, 1.75, 1.75, 1.75, 1.75,
		1.75, 1.55, 1.6529, 1.5826, 1.35, 1.3, 1.35, 1.35, 1.35, 1.5,
		1.9, 1.8, 1.6, 1.9, 1.6, 1.0, 1.0, 2.15, 1.95, 1.8,
		1.8, 1.75, 1.75, 1.75, 1.75, 1.0, 1.0, 1.6, 1.6, 1.0,
		1.0, 1.0, 1.0, 1.0, 1.6, 1.0, 1.0, 1.0, 1.0
	};

	for (int i = 0; i < NELEMENTS; i++)
	if (strcmp(element, name[i]) == 0) return diameter[i];
	return 0.0;
}





const unsigned char* Image::ascii(char idx){
	static const ubyte ASCII816[96][FONTH] = {
		// !
		{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, },
		{0x00, 0x00, 0x00, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x33, 0x30, 0x00, 0x00, 0x00, },
		//"#��																					    
		{0x00, 0x10, 0x0C, 0x06, 0x10, 0x0C, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, },
		{0x40, 0xC0, 0x78, 0x40, 0xC0, 0x78, 0x40, 0x00, 0x04, 0x3F, 0x04, 0x04, 0x3F, 0x04, 0x04, 0x00, },
		//$% ��																						    
		{0x00, 0x70, 0x88, 0xFC, 0x08, 0x30, 0x00, 0x00, 0x00, 0x18, 0x20, 0xFF, 0x21, 0x1E, 0x00, 0x00, },
		{0xF0, 0x08, 0xF0, 0x00, 0xE0, 0x18, 0x00, 0x00, 0x00, 0x21, 0x1C, 0x03, 0x1E, 0x21, 0x1E, 0x00, },
		//&'��																						    
		{0x00, 0xF0, 0x08, 0x88, 0x70, 0x00, 0x00, 0x00, 0x1E, 0x21, 0x23, 0x24, 0x19, 0x27, 0x21, 0x10, },
		{0x10, 0x16, 0x0E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, },
		//() ��																						    
		{0x00, 0x00, 0x00, 0xE0, 0x18, 0x04, 0x02, 0x00, 0x00, 0x00, 0x00, 0x07, 0x18, 0x20, 0x40, 0x00, },
		{0x00, 0x02, 0x04, 0x18, 0xE0, 0x00, 0x00, 0x00, 0x00, 0x40, 0x20, 0x18, 0x07, 0x00, 0x00, 0x00, },
		//*+��																						    
		{0x40, 0x40, 0x80, 0xF0, 0x80, 0x40, 0x40, 0x00, 0x02, 0x02, 0x01, 0x0F, 0x01, 0x02, 0x02, 0x00, },
		{0x00, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x01, 0x1F, 0x01, 0x01, 0x01, 0x00, },
		//,-��																						    
		{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0xB0, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00, },
		{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, },
		//./ ��																						    
		{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, },
		{0x00, 0x00, 0x00, 0x00, 0x80, 0x60, 0x18, 0x04, 0x00, 0x60, 0x18, 0x06, 0x01, 0x00, 0x00, 0x00, },
		//01��																						    
		{0x00, 0xE0, 0x10, 0x08, 0x08, 0x10, 0xE0, 0x00, 0x00, 0x0F, 0x10, 0x20, 0x20, 0x10, 0x0F, 0x00, },
		{0x00, 0x10, 0x10, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x3F, 0x20, 0x20, 0x00, 0x00, },
		//23��																						    
		{0x00, 0x70, 0x08, 0x08, 0x08, 0x88, 0x70, 0x00, 0x00, 0x30, 0x28, 0x24, 0x22, 0x21, 0x30, 0x00, },
		{0x00, 0x30, 0x08, 0x88, 0x88, 0x48, 0x30, 0x00, 0x00, 0x18, 0x20, 0x20, 0x20, 0x11, 0x0E, 0x00, },
		//45��																						    
		{0x00, 0x00, 0xC0, 0x20, 0x10, 0xF8, 0x00, 0x00, 0x00, 0x07, 0x04, 0x24, 0x24, 0x3F, 0x24, 0x00, },
		{0x00, 0xF8, 0x08, 0x88, 0x88, 0x08, 0x08, 0x00, 0x00, 0x19, 0x21, 0x20, 0x20, 0x11, 0x0E, 0x00, },
		//67��																						    
		{0x00, 0xE0, 0x10, 0x88, 0x88, 0x18, 0x00, 0x00, 0x00, 0x0F, 0x11, 0x20, 0x20, 0x11, 0x0E, 0x00, },
		{0x00, 0x38, 0x08, 0x08, 0xC8, 0x38, 0x08, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x00, 0x00, 0x00, 0x00, },
		//89��																						    
		{0x00, 0x70, 0x88, 0x08, 0x08, 0x88, 0x70, 0x00, 0x00, 0x1C, 0x22, 0x21, 0x21, 0x22, 0x1C, 0x00, },
		{0x00, 0xE0, 0x10, 0x08, 0x08, 0x10, 0xE0, 0x00, 0x00, 0x00, 0x31, 0x22, 0x22, 0x11, 0x0F, 0x00, },
		//:;��																						    
		{0x00, 0x00, 0x00, 0xC0, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x30, 0x00, 0x00, 0x00, },
		{0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x60, 0x00, 0x00, 0x00, 0x00, },
		//<=��																						    
		{0x00, 0x00, 0x80, 0x40, 0x20, 0x10, 0x08, 0x00, 0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x00, },
		{0x40, 0x40, 0x40, 0x40, 0x40, 0x40, 0x40, 0x00, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x00, },
		//>?��																						    
		{0x00, 0x08, 0x10, 0x20, 0x40, 0x80, 0x00, 0x00, 0x00, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01, 0x00, },
		{0x00, 0x70, 0x48, 0x08, 0x08, 0x08, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x30, 0x36, 0x01, 0x00, 0x00, },
		//@A																							 
		{0xC0, 0x30, 0xC8, 0x28, 0xE8, 0x10, 0xE0, 0x00, 0x07, 0x18, 0x27, 0x24, 0x23, 0x14, 0x0B, 0x00, },
		{0x00, 0x00, 0xC0, 0x38, 0xE0, 0x00, 0x00, 0x00, 0x20, 0x3C, 0x23, 0x02, 0x02, 0x27, 0x38, 0x20, },
		//BC��																						    
		{0x08, 0xF8, 0x88, 0x88, 0x88, 0x70, 0x00, 0x00, 0x20, 0x3F, 0x20, 0x20, 0x20, 0x11, 0x0E, 0x00, },
		{0xC0, 0x30, 0x08, 0x08, 0x08, 0x08, 0x38, 0x00, 0x07, 0x18, 0x20, 0x20, 0x20, 0x10, 0x08, 0x00, },
		//DE																							 
		{0x08, 0xF8, 0x08, 0x08, 0x08, 0x10, 0xE0, 0x00, 0x20, 0x3F, 0x20, 0x20, 0x20, 0x10, 0x0F, 0x00, },
		{0x08, 0xF8, 0x88, 0x88, 0xE8, 0x08, 0x10, 0x00, 0x20, 0x3F, 0x20, 0x20, 0x23, 0x20, 0x18, 0x00, },
		//FG?																							 
		{0x08, 0xF8, 0x88, 0x88, 0xE8, 0x08, 0x10, 0x00, 0x20, 0x3F, 0x20, 0x00, 0x03, 0x00, 0x00, 0x00, },
		{0xC0, 0x30, 0x08, 0x08, 0x08, 0x38, 0x00, 0x00, 0x07, 0x18, 0x20, 0x20, 0x22, 0x1E, 0x02, 0x00, },
		//HI��																						    
		{0x08, 0xF8, 0x08, 0x00, 0x00, 0x08, 0xF8, 0x08, 0x20, 0x3F, 0x21, 0x01, 0x01, 0x21, 0x3F, 0x20, },
		{0x00, 0x08, 0x08, 0xF8, 0x08, 0x08, 0x00, 0x00, 0x00, 0x20, 0x20, 0x3F, 0x20, 0x20, 0x00, 0x00, },
		//JK																							 
		{0x00, 0x00, 0x08, 0x08, 0xF8, 0x08, 0x08, 0x00, 0xC0, 0x80, 0x80, 0x80, 0x7F, 0x00, 0x00, 0x00, },
		{0x08, 0xF8, 0x88, 0xC0, 0x28, 0x18, 0x08, 0x00, 0x20, 0x3F, 0x20, 0x01, 0x26, 0x38, 0x20, 0x00, },
		//LM																							 
		{0x08, 0xF8, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x3F, 0x20, 0x20, 0x20, 0x20, 0x30, 0x00, },
		{0x08, 0xF8, 0xF8, 0x00, 0xF8, 0xF8, 0x08, 0x00, 0x20, 0x3F, 0x00, 0x3F, 0x00, 0x3F, 0x20, 0x00, },
		//NO��																						    
		{0x08, 0xF8, 0x30, 0xC0, 0x00, 0x08, 0xF8, 0x08, 0x20, 0x3F, 0x20, 0x00, 0x07, 0x18, 0x3F, 0x00, },
		{0xE0, 0x10, 0x08, 0x08, 0x08, 0x10, 0xE0, 0x00, 0x0F, 0x10, 0x20, 0x20, 0x20, 0x10, 0x0F, 0x00, },
		//PQ��																						    
		{0x08, 0xF8, 0x08, 0x08, 0x08, 0x08, 0xF0, 0x00, 0x20, 0x3F, 0x21, 0x01, 0x01, 0x01, 0x00, 0x00, },
		{0xE0, 0x10, 0x08, 0x08, 0x08, 0x10, 0xE0, 0x00, 0x0F, 0x18, 0x24, 0x24, 0x38, 0x50, 0x4F, 0x00, },
		//RS��																						    
		{0x08, 0xF8, 0x88, 0x88, 0x88, 0x88, 0x70, 0x00, 0x20, 0x3F, 0x20, 0x00, 0x03, 0x0C, 0x30, 0x20, },
		{0x00, 0x70, 0x88, 0x08, 0x08, 0x08, 0x38, 0x00, 0x00, 0x38, 0x20, 0x21, 0x21, 0x22, 0x1C, 0x00, },
		//TU��																						    
		{0x18, 0x08, 0x08, 0xF8, 0x08, 0x08, 0x18, 0x00, 0x00, 0x00, 0x20, 0x3F, 0x20, 0x00, 0x00, 0x00, },
		{0x08, 0xF8, 0x08, 0x00, 0x00, 0x08, 0xF8, 0x08, 0x00, 0x1F, 0x20, 0x20, 0x20, 0x20, 0x1F, 0x00, },
		//VW��																						    
		{0x08, 0x78, 0x88, 0x00, 0x00, 0xC8, 0x38, 0x08, 0x00, 0x00, 0x07, 0x38, 0x0E, 0x01, 0x00, 0x00, },
		{0xF8, 0x08, 0x00, 0xF8, 0x00, 0x08, 0xF8, 0x00, 0x03, 0x3C, 0x07, 0x00, 0x07, 0x3C, 0x03, 0x00, },
		//XY��																						    
		{0x08, 0x18, 0x68, 0x80, 0x80, 0x68, 0x18, 0x08, 0x20, 0x30, 0x2C, 0x03, 0x03, 0x2C, 0x30, 0x20, },
		{0x08, 0x38, 0xC8, 0x00, 0xC8, 0x38, 0x08, 0x00, 0x00, 0x00, 0x20, 0x3F, 0x20, 0x00, 0x00, 0x00, },
		//Z[��																						    
		{0x10, 0x08, 0x08, 0x08, 0xC8, 0x38, 0x08, 0x00, 0x20, 0x38, 0x26, 0x21, 0x20, 0x20, 0x18, 0x00, },
		{0x00, 0x00, 0x00, 0xFE, 0x02, 0x02, 0x02, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x40, 0x40, 0x40, 0x00, },
		//\]��																						    
		{0x00, 0x0C, 0x30, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x06, 0x38, 0xC0, 0x00, },
		{0x00, 0x02, 0x02, 0x02, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x40, 0x40, 0x40, 0x7F, 0x00, 0x00, 0x00, },
		//^_																							 
		{0x00, 0x00, 0x04, 0x02, 0x02, 0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, },
		{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, },
		//`a																							 
		{0x00, 0x02, 0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, },
		{0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x00, 0x00, 0x00, 0x19, 0x24, 0x22, 0x22, 0x22, 0x3F, 0x20, },
		//bc
		{0x08, 0xF8, 0x00, 0x80, 0x80, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x11, 0x20, 0x20, 0x11, 0x0E, 0x00, },
		{0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0x00, 0x00, 0x00, 0x0E, 0x11, 0x20, 0x20, 0x20, 0x11, 0x00, },
		//de��
		{0x00, 0x00, 0x00, 0x80, 0x80, 0x88, 0xF8, 0x00, 0x00, 0x0E, 0x11, 0x20, 0x20, 0x10, 0x3F, 0x20, },
		{0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x00, 0x00, 0x00, 0x1F, 0x22, 0x22, 0x22, 0x22, 0x13, 0x00, },
		//fg��
		{0x00, 0x80, 0x80, 0xF0, 0x88, 0x88, 0x88, 0x18, 0x00, 0x20, 0x20, 0x3F, 0x20, 0x20, 0x00, 0x00, },
		{0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0x00, 0x00, 0x6B, 0x94, 0x94, 0x94, 0x93, 0x60, 0x00, },
		//hi��
		{0x08, 0xF8, 0x00, 0x80, 0x80, 0x80, 0x00, 0x00, 0x20, 0x3F, 0x21, 0x00, 0x00, 0x20, 0x3F, 0x20, },
		{0x00, 0x80, 0x98, 0x98, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x3F, 0x20, 0x20, 0x00, 0x00, },
		//jk
		{0x00, 0x00, 0x00, 0x80, 0x98, 0x98, 0x00, 0x00, 0x00, 0xC0, 0x80, 0x80, 0x80, 0x7F, 0x00, 0x00, },
		{0x08, 0xF8, 0x00, 0x00, 0x80, 0x80, 0x80, 0x00, 0x20, 0x3F, 0x24, 0x02, 0x2D, 0x30, 0x20, 0x00, },
		//lm��
		{0x00, 0x08, 0x08, 0xF8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x3F, 0x20, 0x20, 0x00, 0x00, },
		{0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x00, 0x20, 0x3F, 0x20, 0x00, 0x3F, 0x20, 0x00, 0x3F, },
		//no
		{0x80, 0x80, 0x00, 0x80, 0x80, 0x80, 0x00, 0x00, 0x20, 0x3F, 0x21, 0x00, 0x00, 0x20, 0x3F, 0x20, },
		{0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x00, 0x00, 0x00, 0x1F, 0x20, 0x20, 0x20, 0x20, 0x1F, 0x00, },
		//pq��
		{0x80, 0x80, 0x00, 0x80, 0x80, 0x00, 0x00, 0x00, 0x80, 0xFF, 0xA1, 0x20, 0x20, 0x11, 0x0E, 0x00, },
		{0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x00, 0x00, 0x0E, 0x11, 0x20, 0x20, 0xA0, 0xFF, 0x80, },
		//rs��
		{0x80, 0x80, 0x80, 0x00, 0x80, 0x80, 0x80, 0x00, 0x20, 0x20, 0x3F, 0x21, 0x20, 0x00, 0x01, 0x00, },
		{0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0x00, 0x00, 0x33, 0x24, 0x24, 0x24, 0x24, 0x19, 0x00, },
		//tu?
		{0x00, 0x80, 0x80, 0xE0, 0x80, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x20, 0x20, 0x00, 0x00, },
		{0x80, 0x80, 0x00, 0x00, 0x00, 0x80, 0x80, 0x00, 0x00, 0x1F, 0x20, 0x20, 0x20, 0x10, 0x3F, 0x20, },
		//vw��
		{0x80, 0x80, 0x80, 0x00, 0x00, 0x80, 0x80, 0x80, 0x00, 0x01, 0x0E, 0x30, 0x08, 0x06, 0x01, 0x00, },
		{0x80, 0x80, 0x00, 0x80, 0x00, 0x80, 0x80, 0x80, 0x0F, 0x30, 0x0C, 0x03, 0x0C, 0x30, 0x0F, 0x00, },
		//xy
		{0x00, 0x80, 0x80, 0x00, 0x80, 0x80, 0x80, 0x00, 0x00, 0x20, 0x31, 0x2E, 0x0E, 0x31, 0x20, 0x00, },
		{0x80, 0x80, 0x80, 0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x81, 0x8E, 0x70, 0x18, 0x06, 0x01, 0x00, },
		//z{��
		{0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x00, 0x00, 0x21, 0x30, 0x2C, 0x22, 0x21, 0x30, 0x00, },
		{0x00, 0x00, 0x00, 0x00, 0x80, 0x7C, 0x02, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x40, 0x40, },
		//|}��
		{0x00, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0x00, },
		{0x00, 0x02, 0x02, 0x7C, 0x80, 0x00, 0x00, 0x00, 0x00, 0x40, 0x40, 0x3F, 0x00, 0x00, 0x00, 0x00, },
		//~��
		{0x00, 0x06, 0x01, 0x01, 0x02, 0x02, 0x04, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, },
	};

	return ASCII816[idx - 32];
}