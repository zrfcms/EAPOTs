#ifndef EAPOT_CHKFUNC_H
#define EAPOT_CHKFUNC_H

namespace EAPOT_NS {
	class ChkFunc
	{
	public:
		ChkFunc(){
			dim = 0;
		};
		virtual ~ChkFunc(){};

		int dim;
		virtual double func(double*) = 0;
		virtual void reset(double*) = 0;
		virtual void resetbound(double*, double*, double*) = 0;
		virtual bool check(double, double*) = 0;
	};

	class AnnealFunc : public ChkFunc
	{
		friend class MiniStyle;
	public:
		AnnealFunc();
		~AnnealFunc();

		double func(double* x);
		void reset(double* x);
		void resetbound(double*, double*, double*);
		bool check(double, double*);
	};
}
#endif