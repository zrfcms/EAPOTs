#ifdef MINIMIZE_CLASS
MinimizeStyle(sa/a, MinSAA)
#else

#ifdef LIBAPI
LIBAPI(void, setSimulatedAnnealingAMode, (APITYPE const char* mode), (APINAME mode));
#else

#ifndef EAPOT_MIN_SAA_H
#define EAPOT_MIN_SAA_H

#include "min.h"

namespace EAPOT_NS {

	class MinSAA : public Min {
		friend class MiniStyle;
	public:
		MinSAA(class EAPOT *);
		~MinSAA();
		void init();
		void setup_style();
		void reset_vectors();

		/* Particle Swarm Optimization */
		int iterate(int);

		//Function to generate random parameters for analytic/tabulated potentials.
		void randomize_parameter(const int n, double* xi, double* v);

		// Function to determine annealing starting temperature.
		double get_annealing_temperature(const int, 
			const double*, double*, double*, double F);

	protected:
		int NEPS;
		int NSTEP;
		int NTEMP;
		int acceptFlag;

		//record solution is used to determine whether to exit
		double* F_old;		// backlog of previous F values 

		double** X;
		double* v;			// displacement vectors 
		double* xi;			// current optimal solution vectors
		double* xi_opt;		// historical optimal solution vectors
		double* xi_new;		// temporary new solution vectors
		int* naccept;		//number of accepted changes

		bool loop_again(double, double);
	};

}

#endif
#endif
#endif