#ifdef COMPUTE_CLASS
ComputeStyle(elastic, ComputeElastic)
#else

#ifdef LIBAPI
LIBAPI(void, setComputeElasticHalfLoad, (APITYPE void* pComp, int halfFlag), (APINAME pComp, halfFlag));
LIBAPI(void, setComputeElasticMethod, (APITYPE void* pComp, const char* method), (APINAME pComp, method));
LIBAPI(void, setComputeElasticMinimize, (APITYPE void* pComp, double etol, double ftol, int niter, int nstep), (APINAME pComp, etol, ftol, niter, nstep));
LIBAPI(void, setComputeElasticZeroCut, (APITYPE void* pComp, double cut), (APINAME pComp, cut));
LIBAPI(void, setComputeElasticLoadDelta, (APITYPE void* pComp, double delta), (APINAME pComp, delta));
#else

#ifndef EAPOT_COMPUTE_ELASTIC_H
#define EAPOT_COMPUTE_ELASTIC_H

struct ComputeElasticParam {
	const char* id;
	double Cdata[36];
	double(*C)[6];
	double cubic[3], hex[6];
	double Bulk, Shear, Poisson;
	double Youngx, Youngy, Youngz;
};

#include "compute_energy.h"

namespace EAPOT_NS {

	class ComputeElastic : public Compute
	{
		friend class Thermo;
		friend class CompStyle;
	public:
		ComputeElastic(EAPOT* eapot, const char* pid, const char* pstyle, const char* pfile);
		~ComputeElastic();

		ComputeEnergy* clmp;
		ComputeElasticParam param;
		virtual void extracheck(int);

	public:
		double cut;
		double delta, etol, ftol;
		double C[7][6];
		double stress0[6];
		int halfFlag, iter, step;

		enum class CompEval {
			RUN, FORCE, RELAX
		};

		CompEval compute_method;

		void compute();
		void elastic_displace(bool positive, int dir);		
		void reduceBulkShearModulus(double* res);
		static void reduceElasticConstant3(double* res, ComputeElastic* el);
		static void reduceElasticConstant6(double* res, ComputeElastic* el);
	};

}

#endif
#endif
#endif
