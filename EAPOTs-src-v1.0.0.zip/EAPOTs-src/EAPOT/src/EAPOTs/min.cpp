#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include "min.h"

#include "error.h"
#include "memory.h"

#include "update.h"
#include "force.h"
#include "modify.h"
#include "output.h"

#include "pair.h"
#include "modify.h"
#include "compute.h"

#include "option_mini.h"
#include "min_chkfunc.h"

using namespace EAPOT_NS;

//#define MinNMSDevTest

/* ---------------------------------------------------------------------- */

Min::Min(EAPOT *eapot) : Pointers(eapot)
{
	styles.push_back("min");
	dmax = 1;
	linestyle = 1;
	logFlag = 0;
	forceDelta = 1.0e-8;
	gradientDependFlag = 0;

	stopstr = NULL;
	xvec = NULL;
	cost = NULL;

	einitial = 0;
	efinal = 0;
	eprevious = 0;
	alphaFinal = 0;
	niter = 0;
	neval = 0;
	stop_condition = 0;

	ecurrent = 0;
	nvec = 0;
}

/* ---------------------------------------------------------------------- */

Min::~Min()
{
}

/* ---------------------------------------------------------------------- */

int Min::styleCheck(const char* file, int line, const char* style, int errorFlag)
{
	for (int i = 0; i < styles.size(); i++) {
		if (strcmp(style, styles[i]) == 0) {
			return i;
		}
	}

	if (errorFlag) {
		sprintf(error->ErrCheckBuff, "input style does match min setting: %s", style);
		error->all(file, line, error->ErrCheckBuff);
	}
	return 0;
}

void MiniStyle::setMinDmax(double dmax)
{
	update->minimize->dmax = dmax;
}

void MiniStyle::setMinDelta(double delta)
{
	update->minimize->forceDelta = delta;
}


/* ---------------------------------------------------------------------- */

void Min::init()
{
	niter = neval = 0;
	cost = update->cost;
}

/* ----------------------------------------------------------------------
setup before run
------------------------------------------------------------------------- */

void Min::setup(int flag)
{
	if (screen && logFlag) {
		fprintf(screen, "Setting up %s style minimization ...\n", update->minimize_style);
		if (flag) {
			fprintf(screen, "  Current step  : %d\n", update->ntimestep);
		}
	}
	update->setupflag = 1;
	nvec = force->pair->get_fsize();
	modify->setup(0);

	setup_style();

	xvec = force->pair->get_fvec();
	ecurrent = func(NULL);
	fvec.resize(nvec, 0.0);
	force_clear();
	neval = 0;

	reset_vectors();

	ecurrent = energy_force(0, gradientDependFlag);
	einitial = ecurrent;

	output->setup(flag);
	update->setupflag = 0;
}


/* ----------------------------------------------------------------------
perform minimization, calling iterate() for N steps
------------------------------------------------------------------------- */

void Min::run(int n)
{
	// minimizer iterations
	stop_condition = iterate(n);
	stopstr = stopstrings(stop_condition);

	if (stop_condition != MAXITER) {
		update->nsteps = niter;
		ecurrent = energy_force(0, 0);
	}
}

/* ---------------------------------------------------------------------- */

double Min::func(double* x){
	neval++;
	if (x) temp_memcpy(xvec, x, nvec);	
	return energy_force(0, 0);
}

int Min::return_final(int type, double* x){
	if(x) temp_memcpy(xvec, x, nvec);
	return type;
}

/* ---------------------------------------------------------------------- */

#define evalEnergyFromCostFunction()					\
	force->pair->setFreeParams(NULL);					\
	for (int i = 0; i < modify->ncompute; i++) {		\
		modify->compute[i]->compute();					\
	}													\
	res = cost->data[0];								\
	energy = isfinite(res) ? res : 1.0e100;

double Min::energy_force(int resetflag, int gradientFlag)
{
	double energy, res;

	if (gradientFlag) {		
		double Eng1, Eng2, dx, tx;

		for (int i = 0; i < nvec; i++) {
			tx = xvec[i];
			dx = tx ? tx * forceDelta : forceDelta;

			xvec[i] = tx - dx;
			evalEnergyFromCostFunction();
			Eng1 = energy;

			xvec[i] = tx + dx;
			evalEnergyFromCostFunction();
			Eng2 = energy;

			fvec[i] = (Eng2 - Eng1) / (2 * dx);
			xvec[i] = tx;
			force->pair->setFreeParams(NULL);
		}
	}

	evalEnergyFromCostFunction();
	return energy;
}

double Min::fnorm_sqr()
{
	int i;
	double norm2_sqr = 0.0;
	for (i = 0; i < nvec; i++) 
		norm2_sqr += fvec[i] * fvec[i];
	return norm2_sqr;
}

void Min::force_clear()
{
	memset(fvec.data(), 0, fvec.size()*sizeof(double));
}


const char *Min::stopstrings(int n)
{
	const char *strings[] = { "max iterations",
		"max force evaluations",
		"energy tolerance",
		"force tolerance",
		"search direction is not downhill",
		"linesearch alpha is zero",
		"forces are zero",
		"quadratic factors are zero",
		"trust region too small",
		"HFTN minimizer error",
		"walltime limit reached" };
	return (char *)strings[n];
}
