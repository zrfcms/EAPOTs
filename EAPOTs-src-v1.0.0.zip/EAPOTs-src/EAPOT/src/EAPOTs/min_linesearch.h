#ifdef MINIMIZE_CLASS
#else

#ifdef LIBAPI
LIBAPI(void, setLineSearchMethod, (APITYPE const char* style), (APINAME style));
#else


#ifndef EAPOT_MIN_LSRCH_H
#define EAPOT_MIN_LSRCH_H

#include "min.h"

namespace EAPOT_NS {

	class MinLineSearch : public Min {
		friend class MiniStyle;
	public:
		MinLineSearch(class EAPOT *);
		~MinLineSearch();
		void init();
		void setup_style();
		void reset_vectors();

	protected:
		// vectors needed by linesearch minimizers
		// allocated and stored by fix_minimize
		// x,f are stored by parent or Atom class or Pair class

		double *x0;                 // coords at start of linesearch
		double *g;                  // old gradient vector
		double *h;                  // search direction vector


		typedef int (MinLineSearch::*FnPtr)(double, double &);
		FnPtr linemin;
		int linemin_backtrack(double, double &);

		double alpha_step(double, int, int);
	};

}

#endif
#endif
#endif

