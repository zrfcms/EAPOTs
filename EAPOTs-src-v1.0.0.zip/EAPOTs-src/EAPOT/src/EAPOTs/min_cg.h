#ifdef MINIMIZE_CLASS
MinimizeStyle(cg, MinCG)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_MIN_CG_H
#define EAPOT_MIN_CG_H

#include "min_linesearch.h"

namespace EAPOT_NS {

	class MinCG : public MinLineSearch {
		friend class MiniStyle;
	public:

		MinCG(class EAPOT *);
		int iterate(int);

	};

}

#endif
#endif
#endif
