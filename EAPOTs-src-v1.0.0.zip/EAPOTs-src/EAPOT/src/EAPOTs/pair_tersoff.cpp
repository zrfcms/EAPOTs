#include "pair_tersoff.h"

#include "error.h"
#include "input.h"
#include "force.h"
#include "dump_file.h"
#include "dump_image.h"
#include "image.h"

#include "math.h"
#include "memory.h"
#include "option_pair.h"
#include "libLAMMPS/lammps_api.h"

using namespace EAPOT_NS;

/*
iele	element 1 (the center atom in a 3-body interaction)
jele	element 2 (the atom bonded to the center atom)
kele	element 3 (the atom influencing the 1-2 bond in a bond-order sense)
powerm	m
gamma	gamma
lam3	lambda3 (1/distance units)
c		c
d		d
h		cos theta0 (can be a value < -1 or > 1)
powern	n
beta	beta
lam2	lambda2 (1/distance units)
bigb	B (energy units)
bigr	R (distance units)
bigd	D (distance units)
lam1	lambda1 (1/distance units)
biga	A (energy units)
*/

PairTersoff::PairTersoff(EAPOT* eapot)
	: PairTribody(eapot)
{
	styles.push_back("bop/tersoff");
	paramNum = 14;

	key = {
	"m", "gamma", "lam3", "c", "d",
	"cos0", "n", "beta", "lam2", "B",
	"R", "D", "lam1", "A", };
	chkStyle = "tersoff";

	xlim.resize(3);
	ylim.resize(3);
	dump_sample.resize(3, 1.25);
	xlim[0].customlo = xlim[1].customlo = 1.25;
};

PairTersoff::~PairTersoff() {

}

void PairTersoff::fvec_allocate() {

	int n = force->get_ntypes();
	int nc = n == 1 ? 5 : 5 + 2 * n;

	add_fsize(5 * n + 4 * n * (n + 1) / 2);
	add_csize(nc);
	
	Pair::fvec_allocate();
}

void PairTersoff::defaultDofMap(double* f, double* c) {

	double* p = paramVec.data();
	int idx, n = force->get_ntypes();
	
	if (n == 1) {
		p[0] = c[0];
		p[1] = c[1];
		p[2] = c[2];

		p[3] = f[0];
		p[4] = f[1];
		p[5] = f[2];
		p[6] = f[3];
		p[7] = f[4];
		p[8] = f[5];
		p[9] = f[6];

		p[10] = c[3];
		p[11] = c[4];

		p[12] = f[7];
		p[13] = f[8];
		return;
	}

	idx = 0;
	idx = TribodyLoopN(p, f, idx, 3, n);
	idx = TribodyLoopN(p, f, idx, 4, n);
	idx = TribodyLoopN(p, f, idx, 5, n);
	idx = TribodyLoopN(p, f, idx, 6, n);
	idx = TribodyLoopN(p, f, idx, 7, n);
	idx = TribodyLoopN2h(p, f, idx, 8, n);
	idx = TribodyLoopN2h(p, f, idx, 9, n);
	idx = TribodyLoopN2h(p, f, idx, 12, n);
	idx = TribodyLoopN2h(p, f, idx, 13, n);

	idx = 0;
	idx = TribodyLoopN3(p, c, idx, 0, n);
	idx = TribodyLoopN3(p, c, idx, 1, n);
	idx = TribodyLoopN3(p, c, idx, 2, n);
	idx = TribodyLoopNg(p, c, idx, 10, n);
	idx = TribodyLoopNg(p, c, idx, 11, n);

}


void PairTersoff::export_pair(void* md) {
	
	export_pair_template(md, "temp/temp.tersoff");

	if (!transByFileMode) {
		const int n = force->get_ntypes();
		set_tersoff_params(md, n, triTitle.c_str(), val.data());
	}
}


void PairTersoff::export_init(void* md) {

	std::string telt = force->eleLineFormat(" ");

	if (transByFileMode) {
		transByFile("temp/temp.tersoff");
		pair_style(md, "tersoff");
		pair_coeff(md, "temp/temp.tersoff", telt.c_str());
	}
	else {
		pair_style(md, "tersoff/ex");
		pair_coeff(md, "NULL", telt.c_str());
	}

	for (int i = 1; i <= force->get_ntypes(); i++) {
		set_mass(md, i, force->massVec[i]);
	}
}

#define IDX(i,j,k) (i*n2+j*n+k)
#define Val(iParam, itri) paramVec[iParam*n3 + itri]
#ifndef PI
#define PI 3.14159265358979323
#endif

#define PACK(N, CMD)						\
for (int ii = 0; ii < N; ii++){				\
	buf[m++] = CMD;							\
}	

double fR(double A, double lam, double R, double D, double r) {
	if (r > R + D) return 0;

	double res = A * exp(-lam * r);

	if (r > R - D) {
		double ang = PI * (r - R) / (2 * D);
		return res * 0.5 * (1 - sin(ang));
	}
	else {
		return res;
	}
}

double gT(double g, double c, double d, double cost0, double t) {

	double delta = cos(t) - cost0;
	double c2 = c * c, d2 = d * d;

	double res = 1 + c2 / d2;
	res -= c2 / (d2 + delta * delta);

	return g * res;
}

int PairTersoff::image(class DumpImage* dumpimage)
{
	Image* image = dumpimage->image;
	if (image->axes.empty()) image->subplots(3, 1);
	size_t n = force->get_ntypes();
	auto eles = force->getEles();
	eles.erase(eles.begin());

	// 1. get number of points to draw and malloc memory
	int nr = image->axes[0].width;

	size_t n2 = n * n, n3 = n * n * n;
	double* buf = dumpimage->requestDbuf(nr * (2 * n2 + n3));

	// 2. get cutoff
	double fAmax = 0, fBmin = 0, cut = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++) {
		const size_t itri = IDX(i, j, j);
		double R = Val(10, itri), D = Val(11, itri);
		double A = Val(13, itri), k1 = Val(12, itri);
		double B = -Val(9, itri), k2 = Val(8, itri);

		fAmax = fmax(fAmax, fR(A, k1, R, D, dump_sample[0]));
		fBmin = fmin(fBmin, fR(B, k2, R, D, dump_sample[1]));

		for (size_t k = 0; k < n; k++) {
			const size_t itri = IDX(i, j, k);
			cut = fmax(cut, Val(10, itri) + Val(11, itri));
		}
	}
	
	xlim[0].set(0.0, cut).update();
	xlim[1].set(0.0, cut).update();
	xlim[2].set(0.0, 2*PI).update();

	// 3. pack image data
	double dr = (xlim[0].hi - xlim[0].lo) / nr;
	double dt = (xlim[2].hi - xlim[2].lo) / nr;
	double rlo = xlim[0].lo, tlo = xlim[2].lo;

	int idx = 0, m = 0, off = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++){
		const size_t itri = IDX(i, j, j);
		double R = Val(10, itri), D = Val(11, itri);
		double A = Val(13, itri), k1 = Val(12, itri);
		PACK(nr, fR(A, k1, R, D, rlo + ii * dr));
	}
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++){
		const size_t itri = IDX(i, j, j);
		double R = Val(10, itri), D = Val(11, itri);
		double B = -Val(9, itri), k2 = Val(8, itri);
		PACK(nr, fR(B, k2, R, D, rlo + ii * dr));
	}
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++)
	for (size_t k = 0; k < n; k++) {
		const size_t itri = IDX(i, j, k);
		double g = Val(1, itri), c = Val(3, itri);
		double d = Val(4, itri), cost0 = Val(5, itri);
		PACK(nr, gT(g, c, d, cost0, tlo + ii * dt));
	}

	// 4. evaluate the drawing range
	double lo = 0, hi = 0;

	off = 0;
	input->getRange(nr * n2, &buf[off], lo, hi);
	ylim[0].set(fmin(lo, 0), fAmax).update();

	off += nr * n2;
	input->getRange(nr * n2, &buf[off], lo, hi);
	ylim[1].set(fBmin, fmax(hi, 0)).update();

	off += nr * n2;
	input->getRange(nr * n3, &buf[off], lo, hi);
	ylim[2].set(0.0, hi * 1.1).update();

	/**********************************************     Plotting     **********************************************/

	char label[32];
	Axes& Axes1 = image->axes[0].limit(xlim[0], ylim[0]);
	Axes& Axes2 = image->axes[1].limit(xlim[1], ylim[1]);
	Axes& Axes3 = image->axes[2].limit(xlim[1], ylim[2]);


	idx = m = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++){
		sprintf(label, "--%s/%s", eles[i], eles[j]);
		image->setColorRainbow((idx + 0.1) / n2);
		Axes1.plot(nr, &buf[m], label);
		m += nr; idx++;
	}
	idx = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++){
		sprintf(label, "--%s/%s", eles[i], eles[j]);
		image->setColorRainbow((idx + 0.1) / n2);
		Axes2.plot(nr, &buf[m], label);
		m += nr; idx++;
	}
	idx = 0;
	for (size_t i = 0; i < n; i++)
	for (size_t j = 0; j < n; j++)
	for (size_t k = 0; k < n; k++) {
		sprintf(label, "--%s/%s/%s", eles[i], eles[j], eles[k]);
		image->setColorRainbow((idx + 0.1) / n3);
		Axes3.plot(nr, &buf[m], label);
		m += nr; idx++;
	}

	Axes1.legend(0.75, 0.75).xlabel = "fR(r)";
	Axes2.legend(0.75, 0.75).xlabel = "fA(r)";
	Axes3.legend(0.75, 0.75).xlabel = "g(theta)";

	image->show();
	return 0;
};



void PairTersoff::extra_check(int type) {
	const char *name = NULL;

	switch (type){
	case 0:
		name = "Tersoffs";		 
		addMDComputeCDia();		
		break;
	case 1:
		name = "Tersoffc";		 
		addMDComputeSiCDia();		
		break;
	case 2:
		name = "Tersoffc(File)"; 
		addMDComputeSiCDia();		
		break;
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}

	if (0) {
		// run test
		switch (type) {
		case 0: {
			double param[] = { 19900, 7.0, -0.34, 0.99, 4.2E-06, 2.30, 389, 3.5, 1544, 3, 1, 0, 1.95, 0.15 };
			pairStyle->setPairFullParams(force->pair, param);
			runMDCompute(100, RunDump | RunEcho, 40, CDiaCost, DiaChk, "nms", "C.*.tersoff");
			break;
		}
		case 1: case 2: {
			pairStyle->setPairDof(force->pair, 22, 9);
			double param[] = { 19900, 100400, 7.0, 16.2,
				-0.339, -0.598,  0.990, 0.787, 4.16E-06, 1.10E-06,
				2.30, 2.01, 1.73,  389, 432.1, 471,  3.46, 2.97, 2.47,  1544, 1681, 1830,
				3, 1, 0, 1.95, 2.85, 2.35726, 0.15, 0.15271, 0.152719 };
			pairStyle->setPairFullParams(force->pair, param);

			runMDCompute(200, RunDump | RunEcho, 20, SiCDiaCost, DiaChk, "nms", "SiC.*.tersoff");
			break;
		}
		}	
		return;
	}
	else {
		runMDCompute(-1, 0, 10, NULL, NULL, NULL, NULL);
	}

	error->add_chklog(0, name, "");

	switch (type){
	case 0: {
		// data from LAMMPS
		double BoxChk[2], BoxRef[2] = { 3.556293280574872, 7.472988510456348 };
		double ElaChk[3], ElaRef[3] = { 1007.7415420195915, 168.83099246073704, 545.108929945727 };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, 2, BoxChk, BoxRef, 1, name, "Box", 5e-8, 4e-8, 1.5653104677522201e-09, 1.56531106201141e-09);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 1e-4, 5e-5, 9.9857623651613007e-05, 0.00011538500438251216);
		break;
	}
	case 1:
	case 2: {
		// data from LAMMPS
		int Natom[] = { 8,};
		double BoxChk[2], BoxRef[2] = { 4.279594682807735, 6.433833351360659 };
		double ElaChk[3], ElaRef[3] = { 446.64200848299805, 138.13290163643632, 292.6709709663819 };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, 2, BoxChk, BoxRef, 1, name, "Box", 5e-7, 3e-7, 4.0949944425509922e-07, 5.6694434851290467e-07);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 5e-5, 2e-5, 1.0913137526440909e-05, 2.2982036660065382e-05);
		break;
	}
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}
};

