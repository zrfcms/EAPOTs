#include <string.h>
#include "dump_image.h"
#include "output.h"
#include "update.h"
#include "memory.h"
#include "error.h"

#include "image.h"
#include "force.h"
#include "pair.h"
#include "option_dump.h"

using namespace EAPOT_NS;

#define BMP_Header_Length 54

/* ---------------------------------------------------------------------- */

DumpImage::DumpImage(EAPOT *lmp, const char* pid, const char* pstyle, const char* pfile)
	: Dump(lmp, pid, pstyle, pfile)
{
	binary = 1;
	image = new Image(lmp, 1);
	styles.push_back("image");

	if (fileList[0].rfind(".jpg") != std::string::npos ||
		fileList[0].rfind(".jpeg") != std::string::npos) {
		image->format = Image::ImageFormat::JPG;
	}
}

DumpImage::~DumpImage() {
	delete image;
}


void DumpStyle::setDumpImageSize(void* pidump, int width, int height) {
	Dump* idump = (Dump*)pidump;
	idump->styleCheck(FLERR, "image", 1);
	DumpImage* dump = (DumpImage*)idump;
	int iarg = 5;

	if (width <= 0 || height <= 0) {
		error->all(FLERR, "setDumpImageSize: Illegal dump image size");
	}		

	dump->image->width = width;
	dump->image->height = height;
}

/* ---------------------------------------------------------------------- */

void DumpImage::init_style()
{
	if (multifile == 0)	error->all(FLERR, "Dump file requires one snapshot per file");
	image->buffers();
}

/* ---------------------------------------------------------------------- */

void DumpImage::write()
{
	// if file per timestep, open new file
	if (multifile == 0)	error->all(FLERR, "Dump file requires one snapshot per file");
	openfile(0);

	image->clear();
	force->pair->image(this);
	image->write(fp);

	fclose(fp);
	fp = NULL;
}
