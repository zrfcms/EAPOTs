#include "bond.h"
#include "memory.h"
#include "error.h"


using namespace EAPOT_NS;

// allocate space for static class instance variable and initialize it

int Bond::instance_total = 0;

/* ---------------------------------------------------------------------- */

Bond::Bond(EAPOT *eapot) : Pointers(eapot)
{
	instance_me = instance_total++;
}

/* ---------------------------------------------------------------------- */

Bond::~Bond()
{
}

/* ---------------------------------------------------------------------- */

void Bond::init()
{

}

/* ----------------------------------------------------------------------
reset all type-based params by invoking init_one() for each I,J
called by fix adapt after it changes one or more params
------------------------------------------------------------------------- */

void Bond::reinit()
{

}

double Bond::memory_usage()
{
	return 0;
}

