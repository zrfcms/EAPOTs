#include "library.h"

#include "pair.h"
#include "eapot.h"
#include "error.h"
#include "input.h"
#include "force.h"
#include "update.h"
#include "modify.h"
#include "output.h"

#include "compute_energy.h"
#include "compute_elastic.h"

#include "option_dump.h"
#include "option_pair.h"
#include "option_comp.h"
#include "option_mini.h"

#define SetLastCommand(NAME, PTYPE) ((EAPOT*)ptr)->input->lastCommand = #NAME #PTYPE

using namespace EAPOT_NS;

// ----------------------------------------------------------------------
// library API functions to create/destroy an instance of EAPOT
//   and communicate commands to it
// ----------------------------------------------------------------------
/* ----------------------------------------------------------------------
   create an instance of EAPOT and return pointer to it
   pass in command-line args
------------------------------------------------------------------------- */

void eapot_open(int argc, char** argv, void** ptr)
{
	EAPOT* eapot = new EAPOT(argc, argv);
	*ptr = (void*)eapot;
}
/* ----------------------------------------------------------------------
   destruct an instance of EAPOT
------------------------------------------------------------------------- */

void eapot_close(void* ptr)
{
	EAPOT* eapot = (EAPOT*)ptr;
	delete eapot;
}

void eapot_check(void* ptr, int mode, int chkLogLevel) {
	((EAPOT*)ptr)->check(mode, chkLogLevel);
}

/* ----------------------------------------------------------------------
	eapot.h
------------------------------------------------------------------------- */
void eapot_clear(void* ptr) {
	SetLastCommand(clear, (void* ptr));
	((EAPOT*)ptr)->clear();
}

void eapot_setPythonCallback(void* ptr, PythonCallback pythonCallback, void* caller) {
	SetLastCommand(setPythonCallback, (void* ptr, PythonCallback pythonCallback, void* caller));
	EAPOT* eapot = (EAPOT*)ptr;
	eapot->caller = caller;
	eapot->pythonCallback = pythonCallback;
}

/* ----------------------------------------------------------------------
	input.h
------------------------------------------------------------------------- */
void eapot_setEcho(void* ptr, int screen, int log) {
	SetLastCommand(setEcho, (void* ptr, int screen, int log));
	((EAPOT*)ptr)->input->setEcho(screen, log);
}

void eapot_setLog(void* ptr, const char* file, const char* mode) {
	SetLastCommand(setLog, (void* ptr, const char* file, const char* mode));
	((EAPOT*)ptr)->input->setLog(file, mode);
}

/* ----------------------------------------------------------------------
	force.h
------------------------------------------------------------------------- */
void eapot_setMass(void* ptr, int n, double* mass) {
	SetLastCommand(setMass, (void* ptr, int n, double* mass));
	EAPOT* eapot = (EAPOT*)ptr;
	eapot->force->setMass(n, mass);
}

void eapot_setElement(void* ptr, int n, const char** ele) {
	SetLastCommand(setElement, (void* ptr, int n, const char** ele));
	((EAPOT*)ptr)->force->setElement(n, ele);
}

void* eapot_addPair(void* ptr, const char* style) {
	SetLastCommand(addPair, (void* ptr, const char* style));
	return ((EAPOT*)ptr)->force->addPair(style);
}

void* eapot_getPair(void* ptr) {
	SetLastCommand(getPair, (void* ptr));
	return ((EAPOT*)ptr)->force->pair;
}

const char* eapot_getPotScript(void* ptr, void* pPair) {
	SetLastCommand(eapot_getPotScript, (void* ptr, void* pPair));
	return ((EAPOT*)ptr)->force->getPotScript(pPair);
}

/* ----------------------------------------------------------------------
	update.h
------------------------------------------------------------------------- */
void eapot_setTimestep(void* ptr, int step) {
	SetLastCommand(setTimestep, (void* ptr, int step));
	((EAPOT*)ptr)->update->setTimestep(step);
}

void eapot_setRandomSeed(void* ptr, int seed) {
	SetLastCommand(setRandomSeed, (void* ptr, int seed));
	((EAPOT*)ptr)->update->setRandomSeed(seed);
}

void eapot_setMinimizeLogFlag(void* ptr, int flag) {
	SetLastCommand(setMinimizeLogFlag, (void* ptr, int flag));
	((EAPOT*)ptr)->update->setMinimizeLogFlag(flag);
}

void eapot_setMinimizeStyle(void* ptr, const char* style) {
	SetLastCommand(setMinimizeStyle, (void* ptr, const char* style));
	((EAPOT*)ptr)->update->setMinimizeStyle(style);
}

void eapot_runMinimize(void* ptr, void* cost, double etol, double ftol, int nstep, int neval) {
	SetLastCommand(runMinimize, (void* ptr, void* cost, double etol, double ftol, int nstep, int neval));
	((EAPOT*)ptr)->update->runMinimize(cost, etol, ftol, nstep, neval);
}

/* ----------------------------------------------------------------------
	modify.h
------------------------------------------------------------------------- */
void* eapot_addCompute(void* ptr, const char* id, const char* style, const char* file) {
	SetLastCommand(addCompute, (void* ptr, const char* id, const char* style, const char* file));
	return ((EAPOT*)ptr)->modify->addCompute(id, style, file);
}

void* eapot_getCompute(void* ptr, const char* id, const char* style) {
	SetLastCommand(getCompute, (void* ptr, const char* id, const char* style));
	return ((EAPOT*)ptr)->modify->getCompute(id, style);
}



#undef APITYPE
#undef APINAME
#define APITYPE void* ptr,
#define APINAME

/* ----------------------------------------------------------------------
	output.h
------------------------------------------------------------------------- */
void* eapot_addDump(void* ptr, int step, const char* id, const char* style, const char* file) {
	SetLastCommand(addDump, (void* ptr, int step, const char* id, const char* style, const char* file));
	return ((EAPOT*)ptr)->output->addDump(step, id, style, file);
}

void* eapot_getDump(void* ptr, const char* id, const char* style) {
	SetLastCommand(getDump, (void* ptr, const char* id, const char* style));
	return ((EAPOT*)ptr)->output->getDump(id, style);
}

void eapot_runDumpOnce(void* ptr) {
	SetLastCommand(runDumpOnce, (void* ptr));
	((EAPOT*)ptr)->output->runDumpOnce();
}

void eapot_delThermoFormat(void* ptr) {
	SetLastCommand(delThermoFormat, (void* ptr));
	((EAPOT*)ptr)->output->delThermoFormat();
}


#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE eapot_##NAME##PTYPE { SetLastCommand(NAME, PTYPE); ((EAPOT*)ptr)->output->NAME##PNAME; }
#define OUTPUTAPI
#include "extraAPI.h"
#undef  OUTPUTAPI
#undef  LIBAPI



#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE eapot_##NAME##PTYPE { SetLastCommand(NAME, PTYPE); ((EAPOT*)ptr)->pairStyle->NAME##PNAME; }
#include "style_pair.h"
#undef LIBAPI

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE eapot_##NAME##PTYPE { SetLastCommand(NAME, PTYPE); ((EAPOT*)ptr)->dumpStyle->NAME##PNAME; }
#include "style_dump.h"
#undef LIBAPI

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE eapot_##NAME##PTYPE { SetLastCommand(NAME, PTYPE); ((EAPOT*)ptr)->compStyle->NAME##PNAME; }
#include "style_compute.h"
#undef LIBAPI

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE eapot_##NAME##PTYPE { SetLastCommand(NAME, PTYPE); ((EAPOT*)ptr)->miniStyle->NAME##PNAME; }
#include "style_minimize.h"
#undef LIBAPI

void eapot_printStyleAPI() {
	FILE* fp = stdout;

	// general help message about command line and flags
	fprintf(fp,
		"\nEAPOT - " EAPOT_VERSION "\n\n"
		"For generating the empirical interatomic potentials \n"
		"List of command line options supported by this nEAPOT executable:\n");
	fprintf(fp, "List of style APIs included in this EAPOT executable\n");

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) fprintf(fp, #TYPE " eapot_" #NAME #PTYPE "\n");

	fprintf(fp, "\n* Output\n\n");
#define OUTPUTAPI
#include "extraAPI.h"
#undef  OUTPUTAPI

	fprintf(fp, "\n* Pair styles\n\n");
#include "style_pair.h"
	fprintf(fp, "\n* Dump styles\n\n");
#include "style_dump.h"
	fprintf(fp, "\n* Compute styles\n\n");
#include "style_compute.h"
	fprintf(fp, "\n* Minimize styles\n\n");
#include "style_minimize.h"

#undef LIBAPI
}

void eapot_printStylePythonAPI(const char* file) {

	FILE* fp = fopen(file, "w");
#define LIBAPI(TYPE, NAME, PTYPE, PNAME)			\
	fprintf(fp, #TYPE ", " #NAME ", " #PTYPE "\n");

	fprintf(fp, "    #  Output\n\n");
#define OUTPUTAPI
#include "extraAPI.h"
#undef  OUTPUTAPI

	fprintf(fp, "    #  Pair styles\n\n");
#include "style_pair.h"
	fprintf(fp, "    #  Dump styles\n\n");
#include "style_dump.h"
	fprintf(fp, "    #  Compute styles\n\n");
#include "style_compute.h"
	fprintf(fp, "    #  Minimize styles\n\n");
#include "style_minimize.h"

	fclose(fp);

#undef LIBAPI
}

#undef APITYPE
#undef APINAME
#define APITYPE
#define APINAME


void test_callback(void* ptr, TestFunc pfunc) {
	EAPOT* eapot = (EAPOT*)ptr;
	double v[4] = { -1.1, -2.2, -3.3, -4.4 };
	double w[4] = { 0.05, 0.06, 0.07, 0.08 };
	double r[4] = { -1.0, -2.0, -3.0, -4.0 };
	ComputeEnergyParam a = {
		"a",
		4, -20.0, -2.0,
		{ 4.0, 4.1, 4.2, 0.0, 0.0, 0.0 },
		{ 0.2, 0.2, 0.2, 0.0, 0.0, 0.0 },
		1.0e-2, 1.0e-4, 1.0e-6,
		1.5, -0.8,
		NULL, NULL,
		v , NULL, NULL,
		w, NULL, NULL,
		r, NULL, NULL,
	};
	ComputeElasticParam b;
	memset(&b, 0, sizeof(b));
	b.C = (double(*)[6])b.Cdata;

	for (int i = 0; i < 36; i++) {
		b.Cdata[i] = i;
	}
	set_vector3d(b.cubic, 2, 3, 4);
	set_vector6d(b.hex, 2, 3, 4, 5, 6, 7);

	pfunc(&a, &b);
}

void test_vstruct(void* ptr, void* p) {
	EAPOT* eapot = (EAPOT*)ptr;

	TestParam s = *(TestParam*)p;

	printf("%d\n", s.i);
}

void test_struct(void* ptr, TestParam p) {
	EAPOT* eapot = (EAPOT*)ptr;

	TestParam s = p;
	printf("%d\n", s.i);
}
