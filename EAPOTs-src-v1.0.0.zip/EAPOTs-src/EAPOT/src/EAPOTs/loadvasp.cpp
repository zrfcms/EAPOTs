#include "loadvasp.h"

#include "error.h"
#include "input.h"
#include "force.h"
#include "stdio.h"
#include "string.h"

using namespace std;
using namespace EAPOT_NS;
using namespace LoadConfig_NS;

LoadVasp::LoadVasp(class EAPOT* eapot)
	: Pointers(eapot)
	, load()
{
	checkFlag = 0;
}

LoadVasp::~LoadVasp() {
	
}

void LoadVasp::command(int narg, char** arg) {

	LoadErrorType err;
	int dump_lammpsFlag = 1;
	MDFitData & target = load.target;

	target.Structure_Name = arg[0];
	load.CONTCAR = arg[1];

	int iarg = 2;
	while (iarg < narg) {
		if (strcmp(arg[iarg], "OUTCAR") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp OUTCAR command");

			load.OUTCAR = arg[iarg + 1];
			iarg += 2;
		}
		else {
			iarg++;
		}
	}

	err = load.parse();
	CheckIfErrorOccurs(err);


	// Atom Type MAp Target
	const int ntype = force->get_ntypes();
	std::vector<std::string> AtomType(ntype);
	for (int i = 0; i < ntype; i++) {
		AtomType[i] = force->get_elestr(i + 1);
	}

	// Ground state energy of bare atoms in vacuum for each type atom		
	std::vector<double> GroundEnergy(ntype, 0);

	iarg = 1;
	while (iarg < narg) {

		if (strcmp(arg[iarg], "check") == 0) {
			checkFlag = 1;
			iarg += 1;
		}
		else if (strcmp(arg[iarg], "dump") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp dump command");

			if (strcmp(arg[iarg + 1], "no") == 0) dump_lammpsFlag = 0;
			else if (strcmp(arg[iarg + 1], "yes") == 0) dump_lammpsFlag = 1;
			else error->all(FLERR, "Illegal LoadVasp dump command");

			iarg += 2;
		}

		/************************************************************************************************/
		// 1.Relax and Reference Settings
		else if (strcmp(arg[iarg], "Energy_Reference") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Energy_Cohesive_Reference command");

			target.Energy_Reference = arg[iarg + 1];
			iarg += 2;
		}

		/************************************************************************************************/
		// 2.Domain and Stress Target
		else if (strcmp(arg[iarg], "Domain_Target") == 0) {
			if (iarg + 7 > narg) error->all(FLERR, "Illegal LoadVasp Domain_Target command");

			target.Domain_Target[0] = input->numeric(FLERR, arg[iarg + 1]);
			target.Domain_Target[1] = input->numeric(FLERR, arg[iarg + 2]);
			target.Domain_Target[2] = input->numeric(FLERR, arg[iarg + 3]);
			target.Domain_Target[3] = input->numeric(FLERR, arg[iarg + 4]);
			target.Domain_Target[4] = input->numeric(FLERR, arg[iarg + 5]);
			target.Domain_Target[5] = input->numeric(FLERR, arg[iarg + 6]);
			iarg += 7;
		}
		else if (strcmp(arg[iarg], "Domain_Weight") == 0) {
			if (iarg + 7 > narg) error->all(FLERR, "Illegal LoadVasp Domain_Weight command");

			target.Domain_Weight[0] = input->numeric(FLERR, arg[iarg + 1]);
			target.Domain_Weight[1] = input->numeric(FLERR, arg[iarg + 2]);
			target.Domain_Weight[2] = input->numeric(FLERR, arg[iarg + 3]);
			target.Domain_Weight[3] = input->numeric(FLERR, arg[iarg + 4]);
			target.Domain_Weight[4] = input->numeric(FLERR, arg[iarg + 5]);
			target.Domain_Weight[5] = input->numeric(FLERR, arg[iarg + 6]);

			for (int i = 0; i < 6; i++) {
				if (target.Stress_Global_Weight[i] < 0) {
					error->all(FLERR, "Illegal LoadVasp Stress_Global_Weight command");
				}
			}
			iarg += 7;
		}
		else if (strcmp(arg[iarg], "Stress_Global_Target") == 0) {
			if (iarg + 7 > narg) error->all(FLERR, "Illegal LoadVasp Stress_Global_Target command");

			target.Stress_Global_Target[0] = input->numeric(FLERR, arg[iarg + 1]);
			target.Stress_Global_Target[1] = input->numeric(FLERR, arg[iarg + 2]);
			target.Stress_Global_Target[2] = input->numeric(FLERR, arg[iarg + 3]);
			target.Stress_Global_Target[3] = input->numeric(FLERR, arg[iarg + 4]);
			target.Stress_Global_Target[4] = input->numeric(FLERR, arg[iarg + 5]);
			target.Stress_Global_Target[5] = input->numeric(FLERR, arg[iarg + 6]);
			iarg += 7;
		}
		else if (strcmp(arg[iarg], "Stress_Global_Weight") == 0) {
			if (iarg + 7 > narg) error->all(FLERR, "Illegal LoadVasp Stress_Global_Weight command");

			target.Stress_Global_Weight[0] = input->numeric(FLERR, arg[iarg + 1]);
			target.Stress_Global_Weight[1] = input->numeric(FLERR, arg[iarg + 2]);
			target.Stress_Global_Weight[2] = input->numeric(FLERR, arg[iarg + 3]);
			target.Stress_Global_Weight[3] = input->numeric(FLERR, arg[iarg + 4]);
			target.Stress_Global_Weight[4] = input->numeric(FLERR, arg[iarg + 5]);
			target.Stress_Global_Weight[5] = input->numeric(FLERR, arg[iarg + 6]);

			for (int i = 0; i < 6; i++) {
				if (target.Stress_Global_Weight[i] < 0) {
					error->all(FLERR, "Illegal LoadVasp Stress_Global_Weight command");
				}
			}
			iarg += 7;
		}
		/************************************************************************************************/
		// 3.Energy, Force, and Virial Fitting Target
		else if (strcmp(arg[iarg], "Energy_Target") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Energy_Cohesive_Target command");

			target.Energy_Target = input->numeric(FLERR, arg[iarg + 1]);
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "Energy_Weight") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Energy_Cohesive_Weight command");

			target.Energy_Weight = input->numeric(FLERR, arg[iarg + 1]);

			if (target.Energy_Weight < 0) {
				error->all(FLERR, "Illegal LoadVasp Energy_Cohesive_Weight command");
			}
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "Energy_Cost_Target") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Energy_Cost_Target command");

			target.Energy_Cost_Target = input->numeric(FLERR, arg[iarg + 1]);
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "Energy_Cost_Weight") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Energy_Cost_Weight command");

			target.Energy_Cost_Weight = input->numeric(FLERR, arg[iarg + 1]);

			if (target.Energy_Cost_Weight < 0) {
				error->all(FLERR, "Illegal LoadVasp Energy_Cost_Weight command");
			}
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "Force_Cost_Target") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Force_Cost_Target command");

			target.Force_Cost_Target = input->numeric(FLERR, arg[iarg + 1]);
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "Force_Cost_Weight") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Force_Cost_Weight command");

			target.Force_Cost_Weight = input->numeric(FLERR, arg[iarg + 1]);

			if (target.Force_Cost_Weight < 0) {
				error->all(FLERR, "Illegal LoadVasp Force_Cost_Weight command");
			}
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "Virial_Cost_Target") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Stress_Cost_Target command");

			target.Virial_Cost_Target = input->numeric(FLERR, arg[iarg + 1]);
			iarg += 2;
		}
		else if (strcmp(arg[iarg], "Virial_Cost_Weight") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp Stress_Cost_Weight command");

			target.Virial_Cost_Weight = input->numeric(FLERR, arg[iarg + 1]);

			if (target.Virial_Cost_Weight < 0) {
				error->all(FLERR, "Illegal LoadVasp Stress_Cost_Weight command");
			}
			iarg += 2;
		}
		/************************************************************************************************/
		else if (strcmp(arg[iarg], "GroundEnergy") == 0) {
			if (iarg + 2 > narg) error->all(FLERR, "Illegal LoadVasp GroundEnergy command");

			int nele = input->inumeric(FLERR, arg[iarg + 1]);

			GroundEnergy.clear();
			for (int i = 0; i < nele; i++) {
				GroundEnergy.push_back(input->numeric(FLERR, arg[iarg + i + 2]));
			}
			iarg += nele + 2;
		}
		else {
			iarg++;
		}
	}

	if (AtomType.size() >= (size_t)load.config.ntype) {
		AtomType.resize(load.config.ntype);
		err = load.updateType(AtomType);
		CheckIfErrorOccurs(err);
	}

	if (GroundEnergy.size() >= (size_t)load.config.ntype) {
		GroundEnergy.resize(load.config.ntype);
		err = load.updateEnergy(GroundEnergy);
		CheckIfErrorOccurs(err);
	}


	err = load.exportData("temp", dump_lammpsFlag);
	CheckIfErrorOccurs(err);

	if (checkFlag) check();
}

void LoadVasp::CheckIfErrorOccurs(LoadErrorType err) {

	if (err == LoadErrorType::NONE) return;

	ErrorAll("load vasp error with :%s", AtomConfigLoad::error_msg(err));
}

void LoadVasp::check() {
	
	MDFitData& target = load.target;
	AtomConfigData& config = load.config;

	double fchk[256], fref[256];

	int type = -1;

	if (target.Structure_Name == "Mg.03.05") { type = 0; }

	else if (target.Structure_Name == "Mg.03.10") { type = 1; }

	else if (target.Structure_Name == "Mg.07.05") { type = 2; }

	else if (target.Structure_Name == "Mg.07.10") { type = 3; }

	else if (target.Structure_Name == "Mg.10.15") { type = 4; }

	else if (target.Structure_Name == "B2.1") { type = 5; }

	else if (target.Structure_Name == "CaF2.tri") { type = 6; }

	switch (type) {
	case 0: {
		static double tref[] = {
			3.1928000449999998,	5.5300998687999998,	31.027999877900001,
			0,      0.95784000000000002,              1.84336648,

			1,       3.1928090838082963,       3.6867692092186681,       1.2932295036167369,
			1,       1.5964090618083004,      0.92171911021863795,       1.2932295036167369,
			1,       3.1927931129632015,       1.8433348782706105,       3.8782754305476379,
			1,       1.5963930909632058,       4.6083846482705857,       3.8782754305476379,
			1,       3.1928337523540931,       3.6868166839225975,        6.465155288559159,
			1,       1.5964337303540974,      0.92176658492260743,        6.465155288559159,
			1,       3.1928043289492125,       1.8433564634754738,       9.0500753300476511,
			1,       1.5964043069492169,       4.6084062334754883,       9.0500753300476511,
			1,       3.1921692486018913,       3.6855378440927389,        11.61506611268671,
			1,       1.5957692266018957,      0.92048774509274833,        11.61506611268671,
			1,       3.1907939015833779,       1.8394873888736001,       14.156076905739459,
			1,       1.5943938795833819,       4.6045371588735753,       14.156076905739459,
			1,      0.95984614341663721,       5.5339791241264278,        16.87192389726053,
			1,       2.5562461664166185,       2.7689290251263983,        16.87192389726053,
			1,      0.95847079639810606,       3.6879286689072805,       19.412933765313159,
			1,         2.55487081939811,       6.4529784389072553,       19.412933765313159,
			1,      0.95783571605076978,       5.5301100495245112,       21.977923623952368,
			1,       2.5542357390507737,       2.7650599505245212,       21.977923623952368,
			1,      0.95780629264590411,       3.6866498290773917,       24.562845513440791,
			1,       2.5542063156459083,        6.451699599077406,       24.562845513440791,
			1,      0.95784693203680293,       5.5301316347294227,       27.149724447452456,
			1,       2.5542469550367843,       2.7650815357294318,       27.149724447452456,
			1,      0.95783096119170186,       3.6866973037813553,       29.734769565383157,
			1,       2.5542309841917055,       6.4517470737813305,       29.734769565383157,
		};
		memcpy(fref, tref, sizeof(tref));
		break;
	}
	case 1: {
		static double tref[] = {
			3.1928000449999998,  5.5300998687999998, 31.027999877900001,
			0, 0.95784000000000002, -1.8433669087999998,

			1,       3.1928037260109532,       3.6867659822372856,       1.2930559446347711,
			1,       1.5964037040109578,      0.92171588323729514,       1.2930559446347711,
			1,       3.1927875165085253,       1.8432999967474248,       3.8780941405670517,
			1,       1.5963874945085295,       4.6083497667474003,       3.8780941405670517,
			1,       3.1927912989388179,       3.6867181503484105,       6.4637800645510213,
			1,       1.5963912769388224,      0.92166805134841989,       6.4637800645510213,
			1,       3.1921839445091251,       1.8409768438367791,       9.0299787707775767,
			1,       1.5957839225091306,       4.6060266138367929,       9.0299787707775767,
			1,       3.1910273125674018,        3.679928554281771,        11.57807455758492,
			1,       1.5946272905674062,      0.91487845528174283,        11.57807455758492,
			1,       3.1897822729155787,       1.8317327928229628,       14.123306490867504,
			1,       1.5933822509155828,       4.5967825628229377,       14.123306490867504,
			1,      0.96085777208443623,       1.8550003313770349,       16.904694312132481,
			1,       2.5572577950844178,     -0.91004976762295542,       16.904694312132481,
			1,      0.95961273243259515,    0.0068045699182086583,       19.449925320414945,
			1,       2.5560127554325991,       2.7718543399182227,       19.449925320414945,
			1,      0.95845610049085594,        1.845756280363209,       21.998020183222433,
			1,       2.5548561234908598,      -0.9192938186367805,       21.998020183222433,
			1,      0.95784874606117865,   1.4973851587329889e-05,       24.564220737448931,
			1,        2.554248769061183,       2.7650647438515623,       24.564220737448931,
			1,      0.95785252849147884,       1.8434331274526194,       27.149905737433038,
			1,       2.5542525514914596,     -0.92161697154740907,       27.149905737433038,
			1,      0.95783631898904431,  -3.2858037297023301e-05,       29.734943124365124,
			1,       2.5542363419890481,       2.7650169119626771,       29.734943124365124,
		};
		memcpy(fref, tref, sizeof(tref));
		break;
	}
	case 2: {
		static double tref[] = {
			3.1928000449999998, 5.5300998687999998, 31.027999877900001,
            0, -0.95784004499999975, 1.84336648,			
			
			1,   2.3262501150693449e-05,       3.6867710006140393,       1.2932596568260912,
			1,       1.5964232855011546,       0.9217209016140101,       1.2932596568260912,
			1,  -1.4346978343057759e-05,       1.8433363857954104,         3.87830080557741,
			1,       1.5963856760216608,       4.6083861557953858,         3.87830080557741,
			1,   3.5954486310579847e-05,       3.6867814688013665,       6.4645625389409362,
			1,       1.5964359774863146,      0.92173136980137604,       6.4645625389409362,
			1,   -1.404394739640269e-05,       1.8433366357314394,       9.0497415845628808,
			1,       1.5963859790526078,       4.6083864057314523,       9.0497415845628808,
			1,   -0.0014513864938789922,       3.6855547289459829,       11.615350322706853,
			1,       1.5949486365061252,       0.9205046299459928,       11.615350322706853,
			1,   -0.0046126837272873478,       1.8395437363400406,       14.157025360211653,
			1,       1.5917873392726944,       4.6045935063400165,       14.157025360211653,
			1,       2.2395726837272933,       5.5339227766599866,       16.870975442788342,
			1,      0.64317266172729726,        2.768872677659957,       16.870975442788342,
			1,       2.2364113864938804,       3.6879117840540356,       19.412649555293015,
			1,      0.64001136449386153,       6.4529615540540108,       19.412649555293015,
			1,       2.2349740439473926,       5.5301298772685445,       21.978257369437138,
			1,       0.6385740219473961,        2.765079778268555,       21.978257369437138,
			1,       2.2349240455136909,       3.6866850441986228,       24.563438263059016,
			1,      0.63852402351369497,       6.4517348141986375,       24.563438263059016,
			1,       2.2349743469783609,       5.5301301272046226,       27.149699072422685,
			1,      0.63857432497834199,       2.7650800282046313,       27.149699072422685,
			1,       2.2349367374988294,       3.6866955123859828,       29.734739412173802,
			1,      0.63853671549883262,       6.4517452823859589,       29.734739412173802,
		};
		memcpy(fref, tref, sizeof(tref));
		break;
	}
	case 3: {
		static double tref[] = {
			3.1928000449999998, 5.5300998687999998, 31.027999877900001,
			0, -0.95784004499999975, -1.8433669087999998,

			1,   -1.385107199940866e-05,       3.6867289656252367,       1.2927444082564699,
			1,        1.596386171928005,       0.9216788666252469,       1.2927444082564699,
			1,  -3.7275394809216378e-05,       1.8432867304603382,       3.8779824898566364,
			1,       1.5963627476051951,       4.6083365004603145,       3.8779824898566364,
			1,  -0.00010295692811015944,       3.6865819788797518,       6.4626340286545325,
			1,       1.5962970660718931,      0.92153187987976071,       6.4626340286545325,
			1,   -0.0024514607209170647,       1.8393043519777943,       9.0159028727509494,
			1,       1.5939485622790868,       4.6043541219778072,       9.0159028727509494,
			1,   -0.0048337985593158717,       3.6787781032979718,       11.568392220032363,
			1,       1.5915662244406881,      0.91372800429794165,       11.568392220032363,
			1,   -0.0075908966597894034,       1.8308264696570165,        14.11567876317813,
			1,       1.5888091263401918,       4.5958762396569917,        14.11567876317813,
			1,       2.2425508966597953,       1.8559066545429808,       16.912322039821863,
			1,      0.64615087465979926,     -0.90914344445701001,       16.912322039821863,
			1,        2.239793798559317,    0.0079550209020078366,       19.459607657967506,
			1,      0.64339377655929764,       2.7730047909020223,       19.459607657967506,
			1,       2.2374114607209132,       1.8474287722221954,       22.012096081249069,
			1,      0.64101143872091682,     -0.91762132677779418,       22.012096081249069,
			1,       2.2350629569281115,   0.00015114532024607108,       24.565366773345424,
			1,      0.63866293492811566,       2.7652009153202206,       24.565366773345424,
			1,       2.2349972753948268,       1.8434463937397076,       27.150017388143468,
			1,        0.638597253394808,     -0.92160370526032087,       27.150017388143468,
			1,       2.2349738510719792,    4.158574750778854e-06,       29.735254660743422,
			1,      0.63857382907198268,       2.7650539285747255,       29.735254660743422,
		};
		memcpy(fref, tref, sizeof(tref));
		break; 
	}
	case 4: {
		static double tref[] = {
			3.1928000449999998, 5.5300998687999998, 31.027999877900001,
			0, -4.4999999726513806e-08, -4.287999999519343e-07,

			1,  -2.1326018263650308e-14,       3.6867518139999818,       1.2929367029998913,
			1,       1.5964000229999826,      0.92170171499999143,       1.2929367029998913,
			1,   1.3014702014566524e-16,       1.8433482189999948,       3.8784999850000776,
			1,       1.5964000230000039,       4.6083979890000091,       3.8784999850000776,
			1,  -1.2666808311597992e-15,       3.6867518139999791,       6.4640633819999245,
			1,       1.5964000230000031,      0.92170171499998843,       6.4640633819999245,
			1,  -2.1606432899519417e-14,       1.8433482189999926,       9.0499365569999046,
			1,       1.5964000229999831,       4.6083979889999673,       9.0499365569999046,
			1,  -3.1705228375565897e-16,       3.6867518139999764,       11.635499953999972,
			1,       1.5964000230000048,      0.92170171499998721,       11.635499953999972,
			1,  -1.0063867875597463e-15,       1.8433482190000268,       14.221063352000078,
			1,       1.5964000230000031,        4.608397989000002,       14.221063352000078,
			1,       3.1928000000000001,         3.68675138519998,       16.806937450999914,
			1,       1.5963999779999811,      0.92170128619998959,       16.806937450999914,
			1,       3.1927999999999996,       1.8433477901999646,       19.392499923999903,
			1,       1.5963999779999805,       4.6083975601999789,       19.392499923999903,
			1,       3.1928000000000223,       3.6867513852000404,       21.978062397000116,
			1,       1.5963999780000022,      0.92170128620001068,       21.978062397000116,
			1,       3.1927999999999996,       1.8433477901999884,       24.563937420000034,
			1,       1.5963999780000042,       4.6083975602000029,       24.563937420000034,
			1,       3.1927999999999996,       3.6867513851999871,       27.149499893000016,
			1,       1.5963999780000042,      0.92170128619999547,       27.149499893000016,
			1,       3.1928000000000001,       1.8433477902000097,       29.735062366000005,
			1,        1.596399978000004,       4.6083975601999834,       29.735062366000005,
		};
		memcpy(fref, tref, sizeof(tref));
		break;
	}
	case 5: {
		static double tref[] = {
			2.8418618111020852, 2.8331703124683019, 2.8229712188115537,
			-0.22209127391387912, -0.22209127391387912, -0.24018225832343743,

			1,                        0,                        0,                        0,
			2,       1.1988396316371634,       1.2964940270724321,       1.4114856094057768,
		};
		memcpy(fref, tref, sizeof(tref));
		break;
	}
	case 6: {
		static double tref[] = {
			4.2426406871192848, 3.6742346141747668, 3.4641016151377539,
			2.1213203435596424, 2.1213203435596424, 1.2247448713915894,
			
			1,       4.2426406871192848,       2.4494897427831779,       1.7320508075688767,
			2,       2.1213203435596424,       1.2247448713915889,      0.86602540378443837,
			2,       6.3639610306789276,       3.6742346141747673,       2.5980762113533151,
		};
		memcpy(fref, tref, sizeof(tref));
		break;
	}
	}

	int idx = 6, iatom = 0;
	double (*v)[3] = config.basis;

	set_vector6d(fchk, v[0][0], v[1][1], v[2][2], v[1][0], v[2][0], v[2][1]);

	for (size_t itype = 0; itype < config.eleNum.size(); itype++) {

		for (int i = 0; i < config.eleNum[itype]; i++) {

			fchk[idx++] = double(itype) + 1;
			fchk[idx++] = config.pos[3*iatom+0];
			fchk[idx++] = config.pos[3*iatom+1];
			fchk[idx++] = config.pos[3*iatom+2];
			iatom++;
		}
	}

	switch (type) {
	case 0: 
		error->add_chklog(0, "ComputeEnergy", "");
		error->check(FLERR, idx, fchk, fref, 1, "LoadVasp", "Ys0", 5e-14, 5e-15, 0, 0); break;
	case 1: 												
		error->check(FLERR, idx, fchk, fref, 1, "LoadVasp", "Ys1", 5e-14, 5e-15, 0, 0); break;
	case 2:												
		error->check(FLERR, idx, fchk, fref, 1, "LoadVasp", "Ys2", 5e-14, 5e-15, 0, 0); break;
	case 3:													
		error->check(FLERR, idx, fchk, fref, 1, "LoadVasp", "Ys3", 5e-14, 5e-15, 0, 0); break;
	case 4:													
		error->check(FLERR, idx, fchk, fref, 1, "LoadVasp", "Ys4", 5e-14, 5e-15, 0, 0); break;
	case 5:														
		error->check(FLERR, idx, fchk, fref, 1, "LoadVasp", "B1",  5e-14, 5e-15, 0, 0); break;
	case 6:													
		error->check(FLERR, idx, fchk, fref, 1, "LoadVasp", "CaF2",5e-14, 5e-15, 0, 0); break;
	}

	string name1 = "temp/" + target.Structure_Name + ".json";
	string name2 = "../tools/" + target.Structure_Name + ".json";
	error->check(FLERR, name1.c_str(), name2.c_str());

}


