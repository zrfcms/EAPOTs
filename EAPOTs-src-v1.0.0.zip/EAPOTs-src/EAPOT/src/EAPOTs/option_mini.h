#ifndef EAPOT_MINISTYLE_H
#define EAPOT_MINISTYLE_H

#include "pointers.h"

namespace EAPOT_NS {

	class MiniStyle : protected Pointers {
	public:

		MiniStyle(class EAPOT* eapot) :Pointers(eapot) {};

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE NAME##PTYPE
#include "style_minimize.h"
#undef  LIBAPI

	};

}

#endif