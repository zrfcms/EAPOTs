#ifdef COMPUTE_CLASS
ComputeStyle(term, ComputeTerm)
#else

#ifdef LIBAPI
typedef const char* (*CompCallback)(void*, int, double*, int, const char**, void**, double*);
LIBAPI(void, setComputeExternalTitle, (APITYPE void* pComp, const char* title), (APINAME pComp, title));
LIBAPI(void, setComputeExternalScript, (APITYPE void* pComp, const char* script), (APINAME pComp, script));
LIBAPI(void, setComputeExternalCallback, (APITYPE void* pComp, CompCallback callback, void* caller), (APINAME pComp, callback, caller));
#else

#ifndef EAPOT_COMPUTE_TERM_H
#define EAPOT_COMPUTE_TERM_H

#include "compute.h"
#include <string>
#include <vector>

typedef const char* (*CompCallback)(void*, int, double*, int, const char**, void**, double*);

namespace EAPOT_NS {

	class ComputeTerm : public Compute
	{
		friend class Thermo;
		friend class CompStyle;
	public:
		ComputeTerm(EAPOT *eapot, const char* pid, const char* pstyle, const char* pfile);
		~ComputeTerm();

		void init();
		void compute();
		void extracheck(int type);

		void* caller;
		CompCallback callback;
		
		std::string pythonScript;
		std::string costThermoHead;
		std::string costThermoLog;
	};

}


#endif
#endif
#endif