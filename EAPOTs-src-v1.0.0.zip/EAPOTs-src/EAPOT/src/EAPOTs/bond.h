#ifndef EAPOT_BOND_H
#define EAPOT_BOND_H

#include "pointers.h"

namespace EAPOT_NS {

	class Bond : protected Pointers {

	public:
		Bond(class EAPOT *);
		virtual ~Bond();

		static int instance_total;     // # of Pair classes ever instantiated

		// top-level Pair methods
		void init();
		virtual void reinit();
		virtual void setup() {}

		double memory_usage();

	protected:
		int instance_me;        // which Pair class instantiation I am
	};

}

#endif
