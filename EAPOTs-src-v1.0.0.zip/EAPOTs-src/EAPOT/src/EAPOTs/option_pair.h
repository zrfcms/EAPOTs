#ifndef EAPOT_PAIRSTYLE_H
#define EAPOT_PAIRSTYLE_H

#include "pointers.h"

namespace EAPOT_NS {

	class PairStyle : protected Pointers {
	public:

		PairStyle(class EAPOT* eapot) : Pointers(eapot) {};

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE NAME##PTYPE
#include "style_pair.h"
#undef  LIBAPI

	};

}

#endif