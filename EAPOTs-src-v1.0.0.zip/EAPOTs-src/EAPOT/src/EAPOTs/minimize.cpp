#include <stdlib.h>
#include <string.h>
#include "minimize.h"

#include "error.h"
#include "input.h"
#include "update.h"
#include "min.h"

#include "force.h"
#include "pair.h"

using namespace EAPOT_NS;

/* ---------------------------------------------------------------------- */

Minimize::Minimize(EAPOT *eapot) : Pointers(eapot) {}

/* ---------------------------------------------------------------------- */


void Minimize::command(void* cost, double etol, double ftol, int nstep, int neval)
{
	update->cost = (Compute*)cost;
	update->etol = etol;
	update->ftol = ftol;
	update->nsteps = nstep;
	update->max_eval = neval;

	if (!update->cost || update->etol < 0.0 || update->ftol < 0.0) {
		error->all(FLERR, "Illegal minimize command");
	}		

	update->whichflag = 2;
	update->firststep = update->ntimestep;
	update->laststep = update->firststep + update->nsteps;
	if (update->laststep < 0) {
		error->all(FLERR, "Too many iterations");
	}		

	eapot->init();
	update->minimize->setup();				
	update->minimize->run(update->nsteps);	

	update->whichflag = 0;
	update->firststep = update->laststep = 0;

	if (input->echo_screen && screen) fprintf(eapot->screen, "%s\n", update->minimize->stopstr);
	if (input->echo_log && logfile) fprintf(eapot->logfile, "%s\n", update->minimize->stopstr);

	double* p = force->pair->get_fvec();
	int freesize = force->pair->get_fsize();
	for (int i = 0; i < freesize; i++){
		if (input->echo_screen && screen) fprintf(eapot->screen, "%.16g, ", p[i]);
		if (input->echo_log && logfile) fprintf(eapot->logfile, "%.16g, ", p[i]);
		if (i % 5 == 4 || i == freesize - 1){
			if (input->echo_screen && screen) fprintf(eapot->screen, "\n");
			if (input->echo_log && logfile) fprintf(eapot->logfile, "\n");
		}
	}
}
