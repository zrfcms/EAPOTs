#ifdef PAIR_CLASS
PairStyle(sw, PairSW)
#else

#ifdef LIBAPI
#else

#ifndef EAPOT_PAIR_SW_H
#define EAPOT_PAIR_SW_H

#include "pair_tribody.h"
#include <vector>
#include <string>

namespace EAPOT_NS {

	class PairSW : public PairTribody
	{
	public:

		PairSW(EAPOT* eapot);
		~PairSW();

		void fvec_allocate();						// Note that it is need to consistent with getPresetScript()

		void export_pair(void*);
		void export_init(void*);
		void extra_check(int);
		int image(class DumpImage* dumpimage);

	private:
		void defaultDofMap(double*, double*);
	};
}

#endif
#endif
#endif