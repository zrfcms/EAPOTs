#ifndef EAPOT_POINTERS_H
#define EAPOT_POINTERS_H

#include <stdio.h>
#include "eapot.h"
#include "string.h"
#include "set_vector3.h"

#define FLERR __FILE__,__LINE__

#define MIN(A,B) ((A) < (B) ? (A) : (B))
#define MAX(A,B) ((A) > (B) ? (A) : (B))

#define FDBLFMTG		"%.17g"
#define FDBLFMTGTab		"%23.17g\t"
#define EAPOT_VERSION	"1.0.0"

#define APITYPE
#define APINAME

typedef int			tagint;
typedef void		(*VoidCallback)(void*, void*);
typedef const char* (*StrCallback)(void*, void*);

namespace EAPOT_NS {

	class Pointers {
		friend class MDPointers;
	public:
		Pointers(EAPOT *ptr) :
			eapot(ptr),
			memory(ptr->memory),
			error(ptr->error),
			input(ptr->input),			
			
			update(ptr->update),
			force(ptr->force),
			modify(ptr->modify),
			output(ptr->output),

			pairStyle(ptr->pairStyle),
			dumpStyle(ptr->dumpStyle),
			compStyle(ptr->compStyle),
			miniStyle(ptr->miniStyle),

			infile(ptr->infile),
			screen(ptr->screen),
			logfile(ptr->logfile)
		{};
		virtual ~Pointers() {};

	protected:
		class EAPOT *eapot;
		class Memory *&memory;
		class Error *&error;
		class Input *&input;		
		
		class Update *&update;		
		class Force *&force;
		class Modify *&modify;
		class Output *&output;

		class PairStyle* &pairStyle;
		class DumpStyle* &dumpStyle;
		class CompStyle* &compStyle;
		class MiniStyle* &miniStyle;

		FILE *&infile;
		FILE *&screen;
		FILE *&logfile;
	};

	template <typename TYPE>
	TYPE *temp_memset(TYPE *marray, const int n, TYPE val)
	{
		int i;
		for (i = 0; i < n; i++){
			marray[i] = val;
		}
		return marray;
	}

	template <typename TYPE>
	void *temp_memset0(TYPE *marray, const int n)
	{
		return memset(marray, 0, n*sizeof(TYPE));
	}

	template <typename TYPE>
	void *temp_memcpy(TYPE *_Dst, const TYPE *_Src, const int n)
	{
		return memcpy(_Dst, _Src, n*sizeof(TYPE));
	}

}

#endif

