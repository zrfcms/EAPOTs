#include "compute_energy.h"

#include "libLAMMPS/lammps_api.h"
#include "memory.h"
#include "error.h"
#include "input.h"
#include "force.h"
#include "modify.h"
#include "pair.h"

#include "option_comp.h"

using namespace EAPOT_NS;

ComputeEnergy::ComputeEnergy(EAPOT* eapot, const char* pid, const char* pstyle, const char* pfile)
	: Compute(eapot, pid, pstyle, pfile)
	, md(NULL)
	, screen("none"), log("none"), echo("none")

	, remapMode{-1, -1, -1}
	, relaxStressTarget{ 0.0,0.0,0.0,0.0,0.0,0.0, }
	, cost_mode{ 1,0,0,0,0,0,0,0,0,0 }

	, refNum(0), refWeightValueFile("NULL")

	, remapRefInstance(NULL)

	, evalEnergyAtom(0), evalVirialGlobal(0), evalVirialAtom(0)	
	, refContainEnergy(0), refContainForce(0), refContainVirial(0)
{
	styles.push_back("energy");
	param.id = id.c_str();
	vparam = &param;

	dumpStep = 0;
	saveRelaxFlag = 0;
	reloadFlag = 1;

	set_vector3d(relaxAtomFlag, 1, 1, 1);
	relaxBoxMode = RelaxANISO;
	useMaxForceFlag = 0;
	tiltLimitFlag = 1;
	triclinicFlag = 0;

	etol = 0;
	ftol = 1e-5;
	iter = 5000;
	step = 5000;

	modelName = pfile;
	fclose(input->open(modelName.c_str(), "r"));

}


#define ComputeStyleCastCheck()								\
((Compute*)pcomp)->styleCheck(FLERR, "energy", 1);				\
ComputeEnergy* eng = (ComputeEnergy*)pcomp;

void CompStyle::setComputeEnergyTriclinic(void* pcomp, int flag) {
	ComputeStyleCastCheck();
	eng->triclinicFlag = flag;
}

void CompStyle::setComputeEnergyMinimize(void* pcomp, double etol, double ftol, int iter, int step) {
	ComputeStyleCastCheck();
	eng->etol = etol;
	eng->ftol = ftol;
	eng->iter = iter;
	eng->step = step;
}

void CompStyle::setComputeEnergyDumpStep(void* pcomp, int dumpStep) {
	ComputeStyleCastCheck();
	eng->dumpStep = dumpStep;
	if (dumpStep < 0) {
		error->all(FLERR, "Illegal setComputeElasticDumpStep command: dump step");
	}
}

void CompStyle::setComputeEnergyRunScript(void* pcomp, const char* script) {
	ComputeStyleCastCheck();
	eng->CustomRunScript = script;
}

void CompStyle::setComputeEnergyInitScript(void* pcomp, const char* script) {
	ComputeStyleCastCheck();
	eng->CustomInitScript = script;
}

void CompStyle::setComputeEnergyScreenFile(void* pcomp, const char* pfile) {
	ComputeStyleCastCheck();
	eng->screen = pfile;
}

void CompStyle::setComputeEnergyLogFile(void* pcomp, const char* pfile) {
	ComputeStyleCastCheck();
	eng->log = pfile;
}

void CompStyle::setComputeEnergyEcho(void* pcomp, const char* mode) {
	ComputeStyleCastCheck();
	eng->echo = mode;
}

void CompStyle::setComputeEnergyEnergyAtom(void* pcomp, int atomflag) {
	ComputeStyleCastCheck();
	eng->evalEnergyAtom = atomflag;
}
		
void CompStyle::setComputeEnergyVirial(void* pcomp, int atomflag, int globalflag) {
	ComputeStyleCastCheck();
	eng->evalVirialAtom = atomflag;
	eng->evalVirialGlobal = globalflag;
}

void CompStyle::setComputeEnergyRefFile(void* pcomp, const char* pfile) {
	ComputeStyleCastCheck();
	eng->refWeightValueFile = pfile;
}

void CompStyle::setComputeEnergyNoRelax(void* pcomp) {
	ComputeStyleCastCheck();
	zero_vector3(eng->relaxAtomFlag);
	eng->relaxBoxMode = RelaxNONE;
}

void CompStyle::setComputeEnergyRelaxAtom(void* pcomp, int* flag) {
	ComputeStyleCastCheck();
	set_vector3(eng->relaxAtomFlag, flag);
}

void CompStyle::setComputeEnergyRelaxBox(void* pcomp, const char* mode, double* sts) {
	ComputeStyleCastCheck();

	if (strcmp(mode, "none") == 0) {
		eng->relaxBoxMode = RelaxNONE;
	}
	else if (strcmp(mode, "iso") == 0) {
		double s = (sts[0] + sts[1] + sts[2]);
		eng->relaxBoxMode = RelaxISO;		
		set_vector3d(eng->relaxStressTarget, s, s, s);
	}
	else if (strcmp(mode, "aniso") == 0) {
		eng->relaxBoxMode = RelaxANISO;
		set_vector3(eng->relaxStressTarget, sts);
	}
	else if (strcmp(mode, "full") == 0) {
		eng->relaxBoxMode = RelaxFULL;
		set_vector6(eng->relaxStressTarget, sts);
	}
	else {
		ErrorAll("Illegal setComputeEnergyRelaxBox mode: %s", mode);
	}
}

void CompStyle::setComputeEnergyReload(void* pcomp, int flag) {
	ComputeStyleCastCheck();
	eng->reloadFlag = flag;
}

void CompStyle::setComputeEnergyUseMaxForce(void* pcomp, int flag) {
	ComputeStyleCastCheck();
	eng->useMaxForceFlag = flag;
}

void CompStyle::setComputeEnergyRemapStyle(void* pcomp, void* pref, const char* mode) {
	ComputeStyleCastCheck();

	if (pref == NULL) {
		eng->remapRefInstance = NULL; return;
	} 
	((Compute*)pref)->styleCheck(FLERR, "energy", 1);
	eng->remapRefInstance = (ComputeEnergy*)pref;


	int* remapMode = eng->remapMode;
	if (strcmp(mode, "shape") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 1, 2, 2);
	}

	else if (strcmp(mode, "xxy") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 0, 0, 1);
	}
	else if (strcmp(mode, "xxz") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 0, 0, 2);
	}

	else if (strcmp(mode, "xzy") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 0, 2, 1);
	}
	else if (strcmp(mode, "xzz") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 0, 2, 2);
	}

	else if (strcmp(mode, "yxy") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 1, 0, 1);
	}
	else if (strcmp(mode, "yxz") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 1, 0, 2);
	}

	else if (strcmp(mode, "yzy") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 1, 2, 1);
	}
	else if (strcmp(mode, "yzz") == 0) {
		set_vector6d(remapMode, 0, 1, 2, 1, 2, 2);
	}

	else if (strcmp(mode, "v") == 0) {
		set_vector6d(remapMode, -1, -1, -1, -1, -1, -1);
	}
	else {
		ErrorAll("Illegal setComputeEnergyRemapStyle mode: %s", mode);
	}
}

void CompStyle::setComputeEnergyRemapCustom(void* pcomp, void* pref, int* mode) {
	ComputeStyleCastCheck();

	if (pref == NULL) {
		eng->remapRefInstance = NULL; return;
	}
	((Compute*)pref)->styleCheck(FLERR, "energy", 1);
	eng->remapRefInstance = (ComputeEnergy*)pref;
	
	for (int i = 0; i < 6; i++) {
		eng->remapMode[i] = mode[i];
		if (mode[i] > 5) {
			ErrorAll("Illegal setComputeEnergyRemapCustom Axis: %d", mode[i]);
		}
	}
}

void CompStyle::setComputeEnergyTiltLimit(void* pcomp, int flag) {
	ComputeStyleCastCheck();
	eng->tiltLimitFlag = flag;	
}


ComputeEnergy::~ComputeEnergy() {
	snapAndReferenceMemDestroy();
	md_close(md);
}

/*---------------------------------------------------------------------------------------*/
// export pair data
/*---------------------------------------------------------------------------------------*/

void ComputeEnergy::export_pair() {
	if (md) force->pair->export_pair(md);
}

void ComputeEnergy::init() {

	data.resize(19, 0.0);

	if (relaxBoxMode == RelaxFULL) {
		triclinicFlag = 1;
	}

	if (remapRefInstance && remapRefInstance->md == NULL) {
		sprintf(error->ErrCheckBuff, "cannot find the remap compute:");
		error->all(FLERR, "cannot find the remap compute:");
	}

	md_open_echo(screen.c_str(), log.c_str(), &md);
	md_set_callback(md, EAPOTcallback, eapot);
	set_echo(md, echo.c_str());

	// 2.prepare and add lammps command

	if (!CustomInitScript.empty()) {
		md_command(md, CustomRunScript.c_str());
	} else {
		set_units(md, "metal");
		if (!tiltLimitFlag) set_tilt_limit(md, tiltLimitFlag);
		read_data(md, modelName.c_str());
		if (triclinicFlag) set_triclinic(md, 1);
		force->pair->export_init(md);

		thermo_style(md, "step pe atoms lx ly lz press pxx pyy pzz fmax");
		set_systemcompute(md, evalEnergyAtom, evalVirialGlobal, evalVirialAtom);
		if (dumpStep > 0) {
			sprintf(error->ErrCheckBuff, "temp/%s.lmp", id.c_str());
			const char* keys = evalEnergyAtom ? "x y z fx fy fz c_eatom" : "x y z fx fy fz";
			const char* fmts = evalEnergyAtom ? "%d %d %f %f %f %f %f %f %20.18f" : "%d %d %f %f %f %f %f %f";
			add_dump(md, dumpStep, error->ErrCheckBuff, "eng", keys, fmts);
		}
	}	

	// 3. load atom reference and setup sort after refTag have been set
	int atomnum = get_atomnum(md);
	if (get_snapnum(md)) snapAndReferenceMemDestroy();
	snapAndReferenceMemCreate(atomnum);
	setupRefWeightValue(atomnum, get_atomtag(md));

	// 4, set initial sructure
	if (remapRefInstance) {
		x2lamda(md);
	}
	snap_save_self(md, 0);

	if (remapRefInstance) {
		void* refmd = remapRefInstance->md;
		snap_initRemap(md, 0, get_snap_boxlo(refmd, 0), get_snap_boxhi(refmd, 0), get_snap_tilt(refmd, 0));
		lamda2x(md);
	}

	// 5.export pair data
	export_pair();
}



/*
	note:
	The unit of pressure in lammps is bar 
	The unit of virial force results is eV*Angst
	The conversion method is: 

	scalar = (virial[0] + virial[1] + virial[2]) / 3.0 * inv_volume * nktv2p;
	vector[i] = virial[i] * inv_volume * nktv2p;		(nktv2p = 1602176.5)
	
	  1 eV/(Angst^3)
	= 1.6021765 * 10^-19 J / (1.0 * 10^-10 m)^3
	= 1.6021765 * 10^11 N/m^2
	= 1.6021765 * 10^11 Pa
	= 1.6021765 * 10^6 Bar
	= 1602176.5
	
	unit of virial in force (pair/bond...) is (eV*Angst)
	unit of stress from compute_press have been convert to bar

*/



void ComputeEnergy::compute() {

	temp_memset0(data.data(), data.size());
	
	// 1. reload structure if necessary
	if (reloadFlag) {

		// only update Box
		if (remapRefInstance) snap_updateRemap(md, 0, remapRefInstance->data.data(), remapMode);
		
		snap_load_self(md, 0);

		if (remapRefInstance) lamda2x(md);
	}		

	// 2. run LAMMPS
	if (!CustomRunScript.empty()) {
		md_command(md, CustomRunScript.c_str());
	}
	else if (relaxBoxMode || relaxAtomFlag[0] || relaxAtomFlag[1] || relaxAtomFlag[2]) {
		set_minimize(md, relaxBoxMode, relaxAtomFlag, relaxStressTarget);
		minimize(md, etol, ftol, step, iter);
		unset_minimize(md);
	}
	else {
		run(md, 0);
	}
	// recalculate force only when minimize with fix setforce
	if (relaxBoxMode && (!relaxAtomFlag[0] || !relaxAtomFlag[1] || !relaxAtomFlag[2])) {
		setup_minimal(md, 0);
	}

	// 3. extract compute
	double pe_glob = get_globalpe(md, 0);
	double* stress_glob = get_globalsts(md, 0);
	double* pe_atom = evalEnergyAtom ? get_atompe(md, 0) : NULL;
	double* stress_atom = evalVirialAtom ? get_atomsts(md, 0) : NULL;

	// 4. compute atom cost function
	double* fatom = get_atomf1d(md);
	tagint* tagAim = get_atomtag(md);
	if (!sortIsEqual(refNum, refTag.data(), tagAim)) {
		sort(tagAim);
	}	
	if (pe_atom && refContainEnergy && evalEnergyAtom) {		// error of the energy value
		data[13] = computeCostTemplate(pe_atom, CostTarget::ENERGY);
	}	
	if (fatom && refContainForce) {								// error of the force value
		data[14] = computeCostTemplate(fatom, CostTarget::FORCE);
	}	
	if (stress_atom && refContainVirial && evalVirialAtom) {	// error of the virial value
		data[15] = computeCostTemplate(stress_atom, CostTarget::VIRIAL);
	}

	// 5. Save relaxed configration, e.g. for elastic constant calculation
	if (saveRelaxFlag) {
		snap_save_self(md, 1);
	}

	/*---------------------------------------------------------------------------------------*/
	// 7.output evaluate data
	minu_vector3(data, get_boxhi(md), get_boxlo(md));
	double* tilt = get_tilt(md);

	data[3]	= tilt[0];
	data[4]	= tilt[1];
	data[5]	= tilt[2];
	data[6]	= pe_glob;

	for (size_t i = 0; i < 6; i++) {
		data[7 + i] = stress_glob[i];
	}

	data[18] = get_atomnum(md);
	force->pair->export_computeMD(this);

	param.atomNum = get_atomnum(md);
	param.energy = pe_glob;
	param.Ec = -pe_glob / param.atomNum;
	param.energyCost = data[13];
	param.forceCost = data[14];
	param.virialCost = data[15];

	param.rhoAve = data[16];
	param.embAve = data[17];

	param.tag = get_atomtag(md);
	param.type = get_atomtype(md);
	param.pos = get_atomx1d(md);

	param.energyV = pe_atom;
	param.forceV  = fatom;
	param.virialV = stress_atom;

	param.energyW = param.energyV ? refEnergyWeight.data() : NULL;
	param.forceW  = param.forceV  ? refForceWeight.data() : NULL;
	param.virialW = param.virialV ? refVirialWeight.data() : NULL;

	param.energyR = param.energyV ? refEnergyValue.data() : NULL;
	param.forceR  = param.forceV  ? refForceValue.data() : NULL;
	param.virialR = param.virialV ? refVirialValue.data() : NULL;

	set_vector6(param.lattice, data);
	set_vector6(param.stress, stress_glob);

	//error->all(FLERR, PY_STRING_AS_STRING(PyObject_Str(instance)));
}


void ComputeEnergy::extracheck(int type) {

#define NUM 256
	
	double fchk[NUM], *fref = NULL;
	switch (type)
	{
	case 0: {
		static double tref[] = {
			  3.55180010527968,       3.55180010527968,       3.55180010527968,                      0,                      0,                      0,
			 -15.3073394652571,
		   -0.0107780673379036,    -0.0107780672751285,    -0.0107780673968488,  -3.18313169083536e-11,  -3.34515833002222e-11,  -1.13677303685219e-10,
		  5.46040031366899e-19,   7.14430768069989e-29,   1.24106134969294e-13,

			 -4.42668876553804,      -3.62688356657305,      -3.62688356657305,      -3.62688356657305,

		 -8.82974249272195e-15,  -7.71605002114484e-15,  -4.78783679369599e-15,
		  9.82547376793264e-15,   9.98398412555002e-15,  -5.96050986345631e-15,
		  9.76996261670138e-15,  -1.10363107541644e-14,   4.66987559732956e-15,
		 -1.06858966120171e-14,   8.88178419700125e-15,   5.74540415243519e-15,
			   932230.48938457,       932230.489384568,        932230.48938457,  -4.44693309953337e-11,  -1.46748792284601e-09,  -1.00055994739501e-10,
			 -256762.769762955,      -256762.769762954,      -418704.466926153,  -1.47999492218845e-10,   1.62313058132968e-09,   1.61757191495526e-09,
			 -256762.769762953,      -418704.466926154,      -256762.769762952,  -1.55642658483668e-10,  -1.42301859185068e-09,   1.81768390443426e-09,
			 -418704.466926154,      -256762.769762955,      -256762.769762954,  -8.89386619906674e-11,   1.60975504036624e-09,  -1.11173327488334e-11,
		};
		fref = tref;
		break;
	}
	case 1: {
		static double tref[] = {
			  4.36221148170271,       2.51852397322314,       4.14796110647395,                      0,                      0,                      0,
			 -16.3606069171567,
		   -0.0121067092379126,    -0.0121067093307496,     -0.025944114671808,   4.60382900952528e-11,   1.23916649613128e-10,   1.11631251233427e-10,
		  3.68590566707322e-23,   3.36098429718507e-29,   1.33113978712282e-18,

			 -3.72084896141321,      -3.72084896141321,      -4.45945449716514,      -4.45945449716514,

		  8.93729534823251e-15,    3.9343528435154e-15,  -4.06619182768964e-15,
		 -1.00752739484733e-14,  -2.60902410786912e-15,  -3.54469058272411e-15,
		  8.36830604811212e-15,   2.38697950294409e-15,   4.30211422042248e-15,
		 -7.14706072102445e-15,  -3.88339534140858e-15,   3.18609410230632e-15,
			 -599172.497493366,      -599172.497493373,      -67605.5492492111,   1.33407992986001e-10,  -1.51195725384135e-09,  -2.92385851294319e-09,
			 -599172.497493377,      -599172.497493368,      -67605.5492492192,  -9.78325281897341e-10,  -1.88994656730168e-09,    8.8929840864829e-11,
			  599172.773350106,        599172.77335011,        67606.140397368,  -9.56090616399674e-10,  -7.11509295925339e-10,  -1.66759991232501e-11,
			  599172.773350118,       599172.773350116,         67606.14039738,   2.58477986410377e-10,  -2.77699083902421e-09,  -2.71262545870058e-09,
		};
		fref = tref;
		break;
	}
	case 2: {
		static double tref[] = {
			  2.51852406537657,       2.18110582065857,       4.14796082790241,      -1.25926203268829,                      0,                      0,
			 -8.18030345857827,
		   -0.0694933589458104,    -0.0694933585282336,      0.104380741016488,    7.2105943123206e-11,  -1.03565931541139e-10,  -3.49888763168752e-11,
			5.024743627806e-23,   4.56004037874186e-31,    7.6325590780483e-19,

			 -3.72084898001765,      -4.45945447856062,

		  1.22124532708767e-15,  -5.55111512312578e-17,   5.27355936696949e-16,
		 -8.88178419700125e-16,   3.46944695195361e-17,  -4.16333634234434e-16,
			 -599171.722247188,      -599171.722247191,      -67606.9526295952,  -2.26793588076202e-09,   1.37854926085534e-09,   2.66815985972002e-10,
			  599173.305684199,       599173.305684195,       67604.5742681076,   2.89050651469669e-10,   1.37854926085534e-09,   2.44581320474335e-10,
		};
		fref = tref;
		break;
	}
	case 3: {
		static double tref[] = {
			  4.73246283714957,       4.73246283714957,       4.73246283714957,                      0,                      0,                      0,
			 -30.5252128455139,
		 -3.89804320137015e-06,   -3.8983465466604e-06,  -3.89799285360414e-06,   -2.6432577158616e-11,     2.936953017624e-11,   3.94390833795224e-11,
		  1.05469354254628e-22,   3.84786425514745e-29,   1.22211200912674e-21,

			 -3.53332378333163,      -4.09797942804687,      -4.09797942804687,      -4.09797942804687,      -3.53332378333163,      -3.53332378333163,
			 -3.53332378333163,      -4.09797942804687,

		 -1.66533453693773e-16,   1.10050857315969e-14,                      0,
		 -2.08166817117217e-17,   1.05269627379261e-14,  -1.72594821464325e-16,
		 -1.11022302462516e-16,   -1.0325074129014e-14,   5.55111512312578e-17,
							 0,   1.04360964314765e-14,   2.77555756156289e-16,
		 -1.11022302462516e-16,  -1.11022302462516e-14,   2.22044604925031e-16,
		 -1.14491749414469e-16,   1.09432929840288e-14,   2.71494388385737e-16,
		 -5.55111512312578e-17,  -1.10250350515706e-14,  -6.15725190018096e-17,
		  2.53269627492614e-16,  -1.05393124782971e-14,   1.60472085923222e-16,
			 -114159.273988777,      -114159.273988774,      -114159.273988777,                     -0,  -8.89386619906674e-11,   2.22346654976668e-11,
			  114159.274092066,       114159.274092068,       114159.274092066,   -8.8156974531765e-12,  -9.61909845260392e-12,   2.22346654976668e-11,
			  114159.274092065,       114159.274092068,       114159.274092065,   8.89386619906674e-11,                     -0,  -3.18971910313209e-11,
			  114159.274092067,        114159.27409207,       114159.274092067,                     -0,  -8.89386619906674e-11,  -2.22346654976668e-11,
			 -114159.273988778,      -114159.273988774,      -114159.273988778,                     -0,                     -0,   1.25721399640128e-11,
			 -114159.273988777,      -114159.273988774,      -114159.273988777,  -8.79398391265144e-12,  -9.61909845260392e-12,  -6.67039964930005e-11,
			 -114159.273988777,      -114159.273988774,      -114159.273988777,  -9.59738491207885e-12,   7.93195635380634e-11,   1.26155670450629e-11,
			  114159.274092066,       114159.274092069,       114159.274092066,  -9.85360469027462e-11,  -9.61909845260392e-12,  -7.63230949456044e-11,
		};
		fref = tref;
		break;
	}
	case 4: {
		static double tref[] = {
			  3.34635657611862,       2.89802980503984,       2.73228870296587,       1.67317828805931,       1.67317828805931,      0.966009935013282,
			  -7.6313032113785,
		   -0.0184582688129108,     -0.018458268826581,    -0.0184582690132988,   2.42092116784767e-10,  -4.72905154080028e-10,  -7.40885110150092e-11,
		  1.09071902918858e-23,   1.90126304492581e-29,   7.31696544695068e-18,

			 -3.53332378498426,      -4.09797942639424,

		  -4.9960036108132e-15,  -5.05151476204446e-15,    2.4980018054066e-15,
		  4.85722573273506e-15,    5.2579468556857e-15,  -2.47371567674293e-15,
			 -114159.012464822,      -114159.012464823,      -114159.012464818,  -3.02391450768269e-09,   6.13676767735605e-09,   7.55978626920673e-10,
			   114159.50155914,        114159.50155914,       114159.501559141,  -3.25737849540819e-09,   5.45861037967721e-09,   1.25069993424376e-10,
		};
		fref = tref;
		break;
	}
	case 5: {
		static double tref[] = {
			  5.57148309204278,       5.57148309204278,       5.57148309204278,                      0,                      0,                      0,
			 -44.9407144720738,
		  2.57698214867443e-06,   2.57700358264327e-06,   2.57690433955081e-06,   -5.2875813288779e-11,   1.64199870003221e-11,   4.09394831253444e-11,
		  4.03293616039042e-23,   1.04413111207386e-29,   4.99743215441984e-18,

			 -4.04046532232178,      -4.04046532232179,      -4.04046532232179,      -4.04046532232179,      -3.15424797337499,      -3.15424797337499,
			 -3.15424797337499,      -3.15424797337499,      -4.04046532232178,      -4.04046532232178,      -4.04046532232178,      -4.04046532232178,

		 -3.69733269608291e-16,   -3.1641356201817e-15,   1.09634523681734e-15,
		  6.43335075966797e-16,  -3.59434704222394e-15,  -2.98372437868011e-15,
		 -2.72598919348957e-16,   -2.1163626406917e-16,   -3.7470027081099e-16,
		 -1.58974531672476e-16,  -1.58974531672476e-16,  -8.80619497678828e-16,
		  4.44089209850063e-15,   2.88657986402541e-15,  -5.27355936696949e-16,
		  3.99680288865056e-15,   5.28743715477731e-15,   1.87350135405495e-15,
		  2.85188539450587e-15,   3.15372727932584e-15,   3.15806408801578e-15,
		  6.38378239159465e-15,    6.6197047843275e-15,   3.72965547335014e-16,
		 -4.94049245958195e-15,  -5.14865927669916e-15,   1.43027950594288e-15,
		 -4.94049245958195e-15,  -5.05151476204446e-15,  -1.49880108324396e-15,
		  -4.9960036108132e-15,  -8.74300631892311e-16,   1.55084278752327e-15,
		 -3.21964677141295e-15,   5.55111512312578e-16,  -2.95596880306448e-15,
			  690405.050311619,        690405.05031162,       690405.050311622,   6.22570633934671e-10,  -4.60257575801704e-09,  -8.39358622536923e-10,
			  690405.050311624,       690405.050311624,       690405.050311626,   2.66815985972002e-09,   5.41969971505629e-09,   2.77933318720835e-10,
			  690405.050311623,       690405.050311623,       690405.050311625,   9.53311283212466e-10,   6.44805299432338e-10,    8.7826928715784e-10,
			  690405.050311625,       690405.050311624,       690405.050311626,  -6.71208964710818e-10,  -6.26739633715484e-10,  -6.26739633715484e-10,
			 -1380810.10073466,      -1380810.10073466,      -1380810.10073466,   2.57922119772935e-09,   1.08949860938568e-09,  -7.11509295925339e-10,
			 -1380810.10073466,      -1380810.10073466,      -1380810.10073466,   2.00111989479002e-09,  -2.51251720123635e-09,  -6.60786465258786e-10,
			 -1380810.10073466,      -1380810.10073466,      -1380810.10073466,   1.12840927400659e-09,   9.33855950902007e-10,  -1.06934844377841e-09,
			 -1380810.10073468,      -1380810.10073468,      -1380810.10073468,   3.47416648401044e-10,   1.88994656730168e-10,   2.71679819049617e-10,
			  690405.050311621,       690405.050311622,       690405.050311624,  -1.24514126786934e-09,   6.84966663987499e-09,   6.78296264338199e-09,
			  690405.050311621,       690405.050311622,       690405.050311622,  -1.11173327488334e-09,  -6.55922632181172e-09,  -6.59535765324543e-09,
			  690405.050311622,       690405.050311622,       690405.050311625,   1.62313058132968e-09,  -1.24514126786934e-09,  -7.00530929835866e-09,
			  690405.050311624,       690405.050311625,       690405.050311627,   2.80156785270602e-09,  -8.89386619906674e-11,   5.62676003750331e-09,
		};
		fref = tref;
		break;
	}
	case 6: {
		static double tref[] = {
			   3.9396333892682,       3.41182259670365,       3.21669719244619,        1.9698166946341,        1.9698166946341,       1.13727419890122,
			 -11.2351786180185,
			0.0663226584823189,     0.0663226588513903,     0.0663226587782724,  -1.27796016118024e-10,  -4.47401485841535e-11,  -1.36791718659596e-10,
		  9.34045447148902e-23,   9.31496257003398e-30,   4.40888820617365e-18,

			 -3.15424790475876,      -4.04046535662987,      -4.04046535662987,

		  5.87030424270552e-15,  -9.95731275210687e-16,  -7.32053306862213e-16,
		 -1.88737914186277e-15,   4.08006961549745e-15,   7.35522753814166e-16,
		 -4.06619182768964e-15,  -3.24826970876657e-15,   1.07119174641568e-16,      -1380811.16179403,      -1380811.16179404,      -1380811.16179404,
		  3.48528381675928e-09,    4.2245864445567e-10,   3.91330112758936e-09,       690404.147110932,       690404.147110927,       690404.147110928,
		 -2.65704252697119e-09,  -1.68983457782268e-09,   1.61201324858085e-09,       690404.147110929,       690404.147110925,       690404.147110927,
		  4.56922375977054e-09,    4.2565487762096e-09,   4.58589975889379e-10,
		};
		fref = tref;
		break;
	}
	case 7: {
		static double tref[] = {
			  3.55180015116228,       3.55180015116227,       3.55180015116228,                      0,                      0,                      0,
			 -15.3073394652572,
			-0.066714994121254,    -0.0667149935281038,    -0.0667149937821935,  -2.32722533396353e-10,  -2.87879432845767e-10,  -2.55536559329344e-10,
							 0,   2.02614923446306e-15,                      0,

			  -4.4266887376747,      -3.62688357586081,      -3.62688357586081,      -3.62688357586082,

		  1.19386910635289e-08,   1.19387109920321e-08,   1.19386942831756e-08,
		 -4.02988678538385e-08,  -4.02988881847977e-08,   6.86590481621674e-08,
		 -4.02988685477279e-08,   6.86590657938968e-08,  -4.02988714343078e-08,
		  6.86590458376379e-08,  -4.02988886982758e-08,  -4.02988712955299e-08,
			  932230.589725169,       932230.589725181,       932230.589725174,   1.97888522929235e-09,   1.64536524682735e-09,   1.71206924332035e-09,
			 -256761.860257241,      -256761.860257272,      -418703.879914019,  -7.44861294171839e-10,   4.76933574924954e-09,   3.37411048927094e-09,
			  -256761.86025724,      -418703.879914007,      -256761.860257257,    4.1245304498172e-09,   4.66927975451004e-10,   3.31296515915236e-09,
			  -418703.87991403,      -256761.860257274,      -256761.860257261,    4.3579944375427e-09,   5.18067706095637e-09,   8.22682623413673e-10,
		};
		fref = tref;
		break;
	}
	case 8: {
		static double tref[] = {
			  3.61883831979598,       3.61883831979598,       3.61883831979598,                      0,                      0,                      0,
			 -14.9951050352789,
		  0.000130181208644278,   0.000130181302064879,   0.000130181105693883,       15734.5171796992,       15734.5171796991,       15734.5171796993,
							 0,      0.798106754213925,                      0,

			 -4.25167376011698,      -3.58114375838732,      -3.58114375838732,      -3.58114375838732,

			 -1.26575705814681,      -1.26575705814681,      -1.26575705814681,
			 0.841490052275341,      0.841490052275338,     -0.417223046403876,
			 0.841490052275342,      -0.41722304640387,      0.841490052275342,
			-0.417223046403875,      0.841490052275339,      0.841490052275343,
			  38977.7876106516,       38977.7876106517,       38977.7876106511,      -372847.269116067,      -372847.269116066,      -372847.269116068,
			 -30590.3988944855,      -30590.3988944881,       22203.0040087359,      -719181.618999517,       173167.174941727,       173167.174941726,
			 -30590.3988944882,       22203.0040087364,      -30590.3988944874,       173167.174941724,      -719181.618999517,       173167.174941725,
			  22203.0040087378,       -30590.398894489,      -30590.3988944855,       173167.174941725,       173167.174941726,      -719181.618999519,
		};
		fref = tref;
		break;
	}
	case 9: {
		static double tref[] = {
							 4,                      4,                      4,                      0,                      0,                      0,
			 -13.9121734856509,
			 -200195.054449997,      -200195.054449997,      -200195.054449997,  -5.79458138659668e-07,  -5.79468430877877e-07,  -5.79452818842239e-07,
							 0,   7.12651253309955e-12,                      0,

			  -3.9342382421602,      -3.32597841449688,      -3.32597841449688,      -3.32597841449688,

		  3.44570485633078e-06,   3.44570485626009e-06,   3.44570485688936e-06,
		  3.04906909470715e-07,   3.04906909941692e-07,  -4.05551867521366e-06,
		  3.04906909567859e-07,  -4.05551867582428e-06,   3.04906909151526e-07,
		 -4.05551867549425e-06,   3.04906909581737e-07,   3.04906909276426e-07,
			  3766164.35598274,       3766164.35598274,       3766164.35598274,  -1.05087275693312e-05,   -1.0508736602164e-05,  -1.05086643395012e-05,
			  3181145.87600818,       3181145.87600818,       2684027.37680074,  -3.72926104916537e-05,   4.24432540781891e-05,   4.24431526325278e-05,
			  3181145.87600818,       2684027.37680074,       3181145.87600818,   4.24432985475201e-05,  -3.72924367833295e-05,   4.24433145286859e-05,
			  2684027.37680073,       3181145.87600818,       3181145.87600818,   4.24432638058553e-05,   4.24433527445173e-05,  -3.72924076003311e-05,
		};
		fref = tref;
		break;
	}
	case 10: {
		static double tref[] = {
			  4.40811921475094,       2.54502881525642,       4.26981932370878,
							 0,                      0,                      0,
			 -14.1363691163586,       20.8327364056863,      -2.24035840048455,
		};
		fref = tref;
		break;
	}
	case 11: {
		static double tref[] = {
			  4.40811921475094,       2.54502881525642,       25.6189159422527,
							 0,       1.46937307158365,                      0,      -13.3416709167759,
		};
		fref = tref;
		break;
	}
	case 12: {
		static double tref[] = {
			  3.61500000168923,       3.61500000168923,       3.61500000168923,
							 0,                      0,                      0,
			 -14.1600000002286,       21.3485224755235,      -2.24022015076935,
		};
		fref = tref;
		break;
	}
	case 13: {
		static double tref[] = {
			  4.42745271214947,       2.55619101518383,       25.0454546891493,
							 0,       1.47581757071649,                      0,       55.9999978167406,
		};
		fref = tref;
		break;
	}
	case 14: {
		static double tref[] = {
			  4.42745271214947,       2.55619101518383,       25.0454546891493,
							 0,       1.47581757071649,                      0,       44.1228995013744,
		};
		fref = tref;
		break;
	}
	case 15: {
		static double tref[] = {
			  3.45980481407256,       3.45980481407254,       3.57757028346991,
							 0,                      0,                      0,
			 -16.3297239239421,       27.9834195123194,      -2.49628152835075,
		};
		fref = tref;
		break;
	}
	case 16: {
		static double tref[] = {
			  10.3794144422177,       3.45980481407254,       3.57757028346991,
			  3.45980481407256,                      0,                      0,       -16.329723923942,
		};
		fref = tref;
		break;
	}
	}
	compute();
	int nlocal = get_atomnum(md);
	double *force = get_atomf1d(md);

	/*---------------------------------------------------------------------------------------*/
	// 2.2 Sort test (tag check): 
	// atom tag sort check
	/*---------------------------------------------------------------------------------------*/
	int* tag = get_atomtag(md);
	for (int i = 0; i < nlocal; i++) {
		if (refTag[i] != tag[i]){
			ErrorAll("refTag != lmp->atom->tag after sort!: %d != %d ", refTag[i], tag[i]);
		}			
	}

	/*---------------------------------------------------------------------------------------*/
	// 3. add check data into chk[]
	/*---------------------------------------------------------------------------------------*/

	double ratio;
	int total = 0;
	switch (type)
	{
	case 0: case 1:	case 2:	case 3:	case 4:	case 5:
	case 6:	case 7:	case 8:	case 9: {
		int NVectorChk = data.size() - 3;
		for (int i = 0; i < NVectorChk; i++)
			fchk[i] = data[i];

		double* pe_atom = get_atompe(md, 0);
		double* stress_atom = get_atomsts(md, 0);

		int idx = NVectorChk;
		for (int i = 0; i < nlocal; i++)
			fchk[idx++] = pe_atom[i];

		for (int i = 0; i < nlocal * 3; i++)
			fchk[idx++] = force[i];
		for (int i = 0; i < nlocal * 6; i++)
			fchk[idx++] = stress_atom[i];

		total = nlocal * 10 + NVectorChk;
		break;
	}
	case 10: case 12: case 15:
		temp_memcpy(fchk, data.data(), 7);
		fchk[7] = data[16]; fchk[8] = data[17];
		total = 9;
		break;
	case 11: case 13:  case 14:
		set_vector6(fchk, data);
		ratio = 16020 / (data[0] * data[1]);
		fchk[6] = (data[6] - remapRefInstance->data[6] * 6) * ratio;
		total = 7; break;
	case 16:
		temp_memcpy(fchk, data.data(), 7);
		fchk[6] /= 3;
		total = 7; break;
	default:
		break;
	}

	/*---------------------------------------------------------------------------------------*/
	// 4. check current with before and print check message
	/*---------------------------------------------------------------------------------------*/
	
#if 1
	 
#define SwitchCheck(TYPE, NAME, MAX, SUM)									\
	case TYPE: error->check(FLERR, total, fchk, fref, 1, "ComputeEnergy", NAME, 5e-14, 5e-15, MAX, SUM); break;

	switch (type) {
		SwitchCheck(0, "L12", 4.2887206936793402e-15, 5.1369821323095516e-14);
		SwitchCheck(1, "Hex", 3.7254392703425378e-15, 3.6753798062730597e-14);
		SwitchCheck(2, "p",   3.8792413187604519e-15, 3.1369829747298761e-14);
		SwitchCheck(3, "B1",  4.3339897012057582e-15, 1.4150455268317216e-13);
		SwitchCheck(4, "p",   4.2065290524835561e-15, 4.2435532967440684e-14);
		SwitchCheck(5, "CsCl", 4.5553832125739274e-15, 1.151072108113016e-13);
		SwitchCheck(6, "p",   3.5143704943909598e-15, 3.6412594988939848e-14);
		SwitchCheck(7, "Rba", 4.1571422268222694e-15, 4.6776048774712504e-14);
		SwitchCheck(8, "Rb",  2.7745208312731416e-15, 3.9303808105435516e-14);
		SwitchCheck(9, "Ra",  3.3853382918470135e-15, 4.5118571769984284e-14);

		SwitchCheck(10, "hcp", 2.513172689222795e-15, 6.3750532748243873e-15);
		SwitchCheck(11, "Ys",  1.8640090815261436e-15, 5.7760585529946956e-15);
		SwitchCheck(12, "fcc", 2.7598764453513137e-15, 7.2265350919316855e-15);
		SwitchCheck(13, "YsF", 1.276655724803316e-15, 4.7854968709256604e-15);
		SwitchCheck(14, "YsR", 1.276655724803316e-15, 4.8293869584241209e-15);
		SwitchCheck(15, "L10", 1.9580504396846945e-15, 5.3229476307783374e-15);
		SwitchCheck(16, "map", 5.0059122161187938e-15, 9.133211115679564e-15);
	}
#else	

	/*---------------------------------------------------------------------------------------*/
	// 5. Display data, (check data source)
	/*---------------------------------------------------------------------------------------*/
	FILE* pf = fopen("temp/atomdata.log", "a");

	const char* fmt = "%22.15g, ";
	fprintf(pf, "		case %d: {\n", type);
	fprintf(pf, "			static double tref[] = {\n\t\t\t");

	switch (type)
	{
	case 0:	case 1:	case 2:	case 3:	case 4:	case 5:
	case 6:	case 7:	case 8:	case 9: {
		int i, s = 0;
		for (i = 0; i < 6; i++) {
			fprintf(pf, fmt, fchk[i]);
		}
		fprintf(pf, "\n\t\t\t");

		fprintf(pf, fmt, fchk[6]); 
		fprintf(pf, "\n\t\t\t");

		for (i = 7; i < 13; i++) {
			fprintf(pf, fmt, fchk[i]);
		}
		fprintf(pf, "\n\t\t\t");
		for (i = 13; i < 16; i++) {
			fprintf(pf, fmt, fchk[s + i]);
		}
		fprintf(pf, "\n\t\t\t"); s = 16;

		for (i = 0; i < nlocal; i++) {
			if (i % 6 == 0)fprintf(pf, "\n\t\t\t");
			fprintf(pf, fmt, fchk[s + i]);
		}
		fprintf(pf, "\n\t\t\t"); s += i;

		for (i = 0; i < nlocal * 3; i++) {
			if (i % 3 == 0)fprintf(pf, "\n\t\t\t");
			fprintf(pf, fmt, fchk[s + i]);
		}

		for (i = nlocal * 3; i < nlocal * 9; i++) {
			if (i % 6 == 0)fprintf(pf, "\n\t\t\t");
			fprintf(pf, fmt, fchk[s + i]);
		}
		fprintf(pf, "\n\t\t\t");
		break;
	}
	case 10:
	case 12:
	case 14:
		for (int i = 0; i < 9; i++) {
			fprintf(pf, fmt, fchk[i]);
			if (i % 3 == 2)fprintf(pf, "\n\t\t\t");
		}
		break;

	case 11:
	case 13:
	case 15: {
		for (int i = 0; i < 3; i++) {
			fprintf(pf, fmt, fchk[i]);
		}
		fprintf(pf, "\n\t\t\t");
		for (int i = 3; i < 7; i++) {
			fprintf(pf, fmt, fchk[i]);
		}
		fprintf(pf, "\n\t\t\t");
		break;
	}
	}
	fprintf(pf, "};\n");
	fprintf(pf, "		fref = tref;\n");
	fprintf(pf, "		break;\n");
	fprintf(pf, "	}\n");

	fclose(pf);
#endif

#undef NUM

}



/*
1       26   -3.8268349        4    3.5518001    3.5518001    3.5518001 -6.5708174e-05
  Stopping criterion = force tolerance
  Force max component initial, final = 8.56507 2.74209e-09
  Iterations, force evaluations = 26 31

2       26   -3.8268349        4    3.5518001    3.5518001    3.5518001 -7.2090538e-05
  Stopping criterion = force tolerance
  Force max component initial, final = 8.56507 3.00844e-09
  Iterations, force evaluations = 26 31

4       26   -3.8268367        4    3.5518621    3.5518621    3.5518621 0.0004910262
  Stopping criterion = force tolerance
  Force max component initial, final = 8.56507 2.04919e-08
  Iterations, force evaluations = 26 31

5       25   -3.8268352        4    3.5516133    3.5516133    3.5516133  0.020851706
  Stopping criterion = force tolerance
  Force max component initial, final = 8.56507 8.70079e-07
  Iterations, force evaluations = 25 29

10      25   -3.8268359        4    3.5513209    3.5513209    3.5513209 0.00075098192
  Stopping criterion = force tolerance
  Force max component initial, final = 8.56507 3.1331e-08
  Iterations, force evaluations = 25 29
*/