#include <ctype.h>

#include "memory.h"
#include "error.h"
#include "modify.h"

#include "compute.h"
#include "force.h"

using namespace EAPOT_NS;

int Compute::instance_total = 0;

Compute::Compute(EAPOT *eapot, const char* pid, const char* pstyle, const char* pfile)
: Pointers(eapot)
, instance_me(0)
, vparam(NULL)
{
	invokedFlag = 0;

	index_me = modify->ncompute;
	instance_me = instance_total++;

	// Compute ID, group, and style
	id = pid;

	for (size_t i = 0; i < id.size(); i++) {
		if (!isalnum(id[i]) && id[i] != '_') {
			error->all(FLERR, "Compute ID must be alphanumeric or underscore characters");
		}
	}
	styles.push_back("compute");
}


int Compute::styleCheck(const char* file, int line, const char* style, int errorFlag) {
	for (int i = 0; i < styles.size(); i++) {
		if (strcmp(style, styles[i]) == 0) {
			return i;
		}
	}

	if (errorFlag) {
		sprintf(error->ErrCheckBuff, "input style does match compute: %s", style);
		error->all(file, line, error->ErrCheckBuff);
	}
	return 0;
}
