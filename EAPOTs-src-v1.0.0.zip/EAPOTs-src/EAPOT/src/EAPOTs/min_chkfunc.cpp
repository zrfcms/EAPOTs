#include "min_chkfunc.h"
#include "math.h"
#include "stdio.h"
using namespace EAPOT_NS;

AnnealFunc::AnnealFunc()
:ChkFunc(){
	dim = 2;
};

AnnealFunc::~AnnealFunc(){};

double AnnealFunc::func(double* x){
	double sx = x[0];
	double sy = x[1];
	double pi = 3.14159265358979323846;
	double su = 8 - (1 + cos(sx * 20 / pi)) * (1 + cos(sy * 20 / pi)) -
		(1 + cos((sx - 0.7)*1.5)) * (1 + cos((sy - 0.7)*1.5))
		+ 0.2*((sx - 1)*(sx - 1) + (sy - 1) *(sy - 1));
	return su;
};

void AnnealFunc::reset(double* x){
	x[0] = 0;
	x[1] = 0;
}

void AnnealFunc::resetbound(double* lo, double* hi, double* len){
	lo[0] = lo[1] = -2;
	hi[0] = hi[1] = 3;
	len[0] = len[1] = 5;
}

bool AnnealFunc::check(double y, double* x){
	printf("%.10g: (%.10g, %.10g)\n", y, x[0], x[1]);
	return true;
}