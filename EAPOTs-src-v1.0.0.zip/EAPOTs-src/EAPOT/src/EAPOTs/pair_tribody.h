#ifndef EAPOT_PAIR_TRIBODY_H
#define EAPOT_PAIR_TRIBODY_H

#include "pair.h"
#include <vector>
#include <string>

namespace EAPOT_NS {

	class PairTribody : public Pair
	{
	public:

		PairTribody(EAPOT* eapot);
		~PairTribody();

		virtual void setFreeParamsStyle() {};
		void write(class DumpFile* dump);

	protected:	

		int paramNum;
		std::string triTitle;
		std::vector<double> val;
		std::vector<std::string> key;

		int getPyParamNum();
		void export_pair_template(void* md, const char* name);

	public:
		static int TribodyLoop3(double* p, double* f, int idx, int iparm, int n);
		static int TribodyLoopN2h(double* p, double* f, int idx, int iparm, int n);
		static int TribodyLoopN3(double* p, double* f, int idx, int iparm, int n);
		static int TribodyLoopN(double* p, double* f, int idx, int iparm, int n);
		static int TribodyLoopNg(double* p, double* f, int idx, int iparm, int n);
	};
}

#endif