#ifdef PAIR_CLASS
PairStyle(eam/voter1, PairEAMVoterCu)
PairStyle(eam/voter2, PairEAMVoterNi8)
PairStyle(eam/voter3, PairEAMVoterNi11)
#else

#ifdef LIBAPI
LIBAPI(void, setPairEAMVotermRoseSampleRange, (APITYPE void* pPair, double begin, double end, int nSample), (APINAME pPair, begin, end, nSample));
LIBAPI(void, setPairEAMVotermRoseSamplePoint, (APITYPE void* pPair, int nSample, double* point), (APINAME pPair, nSample, point));
LIBAPI(void, setPairEAMVotermRoseAxis, (APITYPE void* pPair, int axis), (APINAME pPair, axis));
LIBAPI(void, setPairEAMVotermRoseStructure, (APITYPE void* pPair, const char* pfile), (APINAME pPair, pfile));
LIBAPI(void, setPairEAMVotermScreenFile, (APITYPE void* pPair, const char* pfile), (APINAME pPair, pfile));
LIBAPI(void, setPairEAMVotermLogFile, (APITYPE void* pPair, const char* pfile), (APINAME pPair, pfile));
#else

#ifndef EAPOT_PAIR_EAM_VOTERM_H
#define EAPOT_PAIR_EAM_VOTERM_H

#include "pair_eam.h"

#include <vector>
#include <string>

using namespace std;

namespace EAPOT_NS {

	class PairEAMVoterm : public PairEAM
	{
		friend class PairStyle;
	public:
		PairEAMVoterm(EAPOT *eapot);
		~PairEAMVoterm();

		double emb(int type, double);
		double rho(int itype, int jtype, double);
		double phi(int itype, int jtype, double);

		void init_style();									// pair init, use LAMMPS create neighbor list
		void setFullParamsStyle();						// set initial parameter
		virtual void setFreeParamsStyle();				// alter parameter and create and calculate embedding energy interpolation coefficient
		void extra_check(int);								// 

	protected:
		string log, screen;
		int axis;											// sample axis and sample amount

		char buff[256];										// Temporary storage
		string structure;									// sample structure	
		double ratio[3], **cof;								// structure deform ratio and embedding energy interpolation coefficient

		struct Sample{									
			double rho, femb;								// sample electron density and embedding energy
		};
		static bool sampleCmp(const Sample &a, const Sample &b) {	// sample compare function for sort
			return a.rho < b.rho;
		}
		vector<double> rose_a0;								// remember: rose_a0 can not be merged in to sample
		vector<Sample> sample;								// b.c sample will be sorted
		vector<vector<double>> rlist;

	protected:
		virtual double rhoc(double r) = 0;
		virtual double rhod(double r) = 0;

		inline double phic(double lr) {
			double exprm = exp(aM * (RM - lr)) - 1;
			return DM * exprm * exprm - DM;
		}
		inline double phid(double lr) {
			double expr = exp(aM * (RM - lr));
			return -2 * DM * aM * expr * (expr - 1);
		}

		inline double smooth(double r, double f, double fc, double dfc) {
			return f - fc + rcn * (1 - pow(r / rc, NN)) * dfc;
		}

	protected:
		double DM, aM, RM, rc;
		double b, s1, u1, RA;
		double s2, u2, RB;
		double a0, Ec, B, v0, roseCof;

		int NN;
		double rcn, u12;
		double phicr, phidr, rhocr, rhodr;
		void* pA, * pB;

		virtual void function_check() {};
		virtual void testrun(int type) {};
	};

	class PairEAMVoterCu : public PairEAMVoterm
	{
	public:
		PairEAMVoterCu(EAPOT* eapot);
		~PairEAMVoterCu() {};

		double rhoc(double r);
		double rhod(double r);

		void function_check();
		void testrun(int type);
	};

	class PairEAMVoterNi11 : public PairEAMVoterm
	{
	public:
		PairEAMVoterNi11(EAPOT* eapot);
		~PairEAMVoterNi11() {};

		double rhoc(double r);
		double rhod(double r);
		void setFreeParamsStyle();

		void function_check();
		void testrun(int type);
	};

	class PairEAMVoterNi8 : public PairEAMVoterNi11
	{
	public:
		PairEAMVoterNi8(EAPOT* eapot);
		~PairEAMVoterNi8() {};

		void setFullParamsStyle();
		void setFreeParamsStyle();
	};

}

#endif
#endif
#endif