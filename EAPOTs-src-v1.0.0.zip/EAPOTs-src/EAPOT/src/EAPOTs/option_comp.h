#ifndef EAPOT_COMPSTYLE_H
#define EAPOT_COMPSTYLE_H

#include "pointers.h"

namespace EAPOT_NS {

	class CompStyle : protected Pointers {
	public:

		CompStyle(class EAPOT* eapot) :Pointers(eapot) {};

#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE NAME##PTYPE
#include "style_compute.h"
#undef  LIBAPI

	};

}

#endif