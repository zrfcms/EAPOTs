#ifndef CUBICSPLINECHAIN_H
#define CUBICSPLINECHAIN_H

namespace EAPOT_NS {

	class CubicSplineChain
	{
	public:
		CubicSplineChain() {
			a = r0 = a3 = a6 = 0;
		};
		~CubicSplineChain() {};

		void set(const double pa, const double pr0);

		double d(const int i, const double r);
		double p(const int i, const int j, const double r);

		double a, r0, a3, a6;

	};
}

#endif

