#ifdef COMMAND_CLASS

CommandStyle(loadvasp, LoadVasp)

#else

#ifndef EAPOT_TOOLS_H
#define EAPOT_TOOLS_H

#include "pointers.h"
#include "eapotaux.h"
#include "AtomConfig/AbinitoMDTool.h"
#include "AtomConfig/AtomConfig.h"
#include <string>
#include <vector>

namespace EAPOT_NS {

	using namespace std;

	class LoadVasp : protected Pointers {
	public:
		LoadVasp(class EAPOT*);
		~LoadVasp();
		void command(int, char**);
	
		LoadConfig_NS::LoadVaspData load;

	private:
		int checkFlag;
		void check();
		void CheckIfErrorOccurs(LoadConfig_NS::LoadErrorType);
	};

}

#endif
#endif
