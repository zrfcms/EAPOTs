#include <string.h>
#include <stdlib.h>

#include "memory.h"
#include "error.h"
#include "update.h"
#include "output.h"
#include "modify.h"
#include "min.h"

#include "minimize.h"
#include "style_minimize.h"

using namespace EAPOT_NS;

/* ---------------------------------------------------------------------- */

Update::Update(EAPOT *eapot) : Pointers(eapot)
{
	cost = NULL;
	ntimestep = 0;
	first_update = 0;

	whichflag = 0;
	firststep = laststep = 0;
	setupflag = 0;

	minimize_style = NULL;
	minimize = NULL;

	minimize_map = new MinimizeCreatorMap();

#define MINIMIZE_CLASS
#define MinimizeStyle(key,Class) \
	(*minimize_map)[#key] = &minimize_creator<Class>;
#include "style_minimize.h"
#undef MinimizeStyle
#undef MINIMIZE_CLASS

	setMinimizeStyle("cg");
}

/* ---------------------------------------------------------------------- */

Update::~Update()
{
	delete[] minimize_style;
	delete minimize;

	delete minimize_map;
}

/* ---------------------------------------------------------------------- */

void Update::init()
{
	// init the appropriate integrate and/or minimize class
	// if neither (e.g. from write_restart) then just return

	if (whichflag == 0) return;
	else if (whichflag == 2) minimize->init();

	// only set first_update if a run or minimize is being performed

	first_update = 1;
}

void Update::setRandomSeed(int seed) {

	if (seed <= 0) error->all(FLERR, "Illegal Update setRandomSeed command");
	srand(seed);
}

void Update::setMinimizeStyle(const char * style)
{
	delete[] minimize_style;
	delete minimize;

	if (minimize_map->find(style) != minimize_map->end()) {
		MinimizeCreator minimize_creator = (*minimize_map)[style];
		minimize = minimize_creator(eapot);
	}
	else error->all(FLERR, "Illegal setMinimize command");

	int n = strlen(style) + 1;
	minimize_style = new char[n];
	strcpy(minimize_style, style);
	eapot->once_initFlag = 0;
}

/* ----------------------------------------------------------------------
one instance per minimize style in style_minimize.h
------------------------------------------------------------------------- */

template <typename T>
Min *Update::minimize_creator(EAPOT *eapot)
{
	return new T(eapot);
}

/* ----------------------------------------------------------------------
reset timestep
called from rerun command and input script (indirectly)
------------------------------------------------------------------------- */

void Update::setMinimizeLogFlag(int flag) {
	minimize->logFlag = flag;
}

void Update::setTimestep(int newstep)
{
	ntimestep = newstep;
	if (ntimestep < 0) error->all(FLERR, "Timestep must be >= 0");

	// trigger reset of timestep for output
	// do not allow any timestep-dependent fixes to be already defined

	output->setTimestep(ntimestep);
}

void Update::runMinimize(void* cost, double etol, double ftol, int nstep, int neval) {
	Minimize min(eapot);
	min.command(cost, etol, ftol, nstep, neval);
}

