#ifndef EAPOT_EXCEPTIONS_H
#define EAPOT_EXCEPTIONS_H

#include <string>
#include <exception>

namespace EAPOT_NS {

	class EAPOTException : public std::exception
	{
	public:
		std::string message;

		EAPOTException(std::string msg) : message(msg) {
		}

		~EAPOTException() throw() {
		}

		virtual const char * what() const throw() {
			return message.c_str();
		}
	};

	enum ErrorType {
		ERROR_NONE = 0,
		ERROR_NORMAL = 1,
		ERROR_ABORT = 2
	};
}

#endif
