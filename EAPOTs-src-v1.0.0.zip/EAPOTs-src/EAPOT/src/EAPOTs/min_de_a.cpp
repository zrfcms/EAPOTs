#include "min_de_a.h"
#include <ctype.h>
#include <stdlib.h>
#include "eapot_math.h"
#include "string.h"

#include "memory.h"
#include "error.h"
#include "update.h"
#include "pair.h"
#include "force.h"
#include "output.h"

#include "option_mini.h"
#include "min_chkfunc.h"

using namespace std;
using namespace EAPOT_NS;

MinDE::MinDE(EAPOT* eapot)
	: Min(eapot) {
	
	styles.push_back("de/a");
	linestyle = 0;
	
	range = 0.4;
	geneNum = 20;

	bestIdx = 0;
	bestEval = DBL_MAX;

	mut = 0.8;
	crossp = 0.7;
}

MinDE::~MinDE() {

}

void MinDE::init() {
	Min::init();
}

void MiniStyle::setDifferentialEvolutionGeneNum(int n) {
	update->minimize->styleCheck(FLERR, "de/a", 1);
	((MinDE*)update->minimize)->geneNum = n;
	if (n <= 10) error->all(FLERR, "Illegal setDifferentialEvolutionGeneNum command");
}

void MiniStyle::setDifferentialEvolutionInitRange(double val) {
	update->minimize->styleCheck(FLERR, "de/a", 1);
	((MinDE*)update->minimize)->range = val;
	if (val <= 0) error->all(FLERR, "Illegal setDifferentialEvolutionInitRange command");
}

void MiniStyle::setDifferentialEvolutionMutRat(double val) {
	update->minimize->styleCheck(FLERR, "de/a", 1);
	((MinDE*)update->minimize)->mut = val;
	if (val <= 0 || val >= 1) error->all(FLERR, "Illegal setDifferentialEvolutionMutRat command");
}

void MiniStyle::setDifferentialEvolutionCrossRat(double val) {
	update->minimize->styleCheck(FLERR, "de/a", 1);
	((MinDE*)update->minimize)->crossp = val;
	if (val <= 0 || val >= 1) error->all(FLERR, "Illegal setDifferentialEvolutionCrossRat command");
}

void MinDE::setup_style(){
	genes.resize(geneNum);

	for (int i = 0; i < geneNum; i++) {
		genes[i].v.resize(nvec, 0);
	}

	gmin.resize(nvec);
	gmax.resize(nvec);
	diff.resize(nvec);
}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinDE::reset_vectors()
{
	double ratio_min = 1 - range * 0.5;
	double ratio_max = 1 + range * 0.5;
	for (int j = 0; j < nvec; j++) {
		gmin[j] = xvec[j] * ratio_min;
		gmax[j] = xvec[j] * ratio_max;
		diff[j] = xvec[j] * range;

		if (fabs(xvec[j]) < 1e-10) {
			gmin[j] = -0.05;
			gmin[j] = +0.05;
			diff[j] = 0.1;
		}
	}
}

void inline geneCopy(Gene& gene, double* p) {
	for (size_t i = 0; i < gene.v.size(); i++) {
		gene.v[i] = p[i];
	}
}

void getUnreplaceIndex(int nvec, int idx, int &ia, int& ib, int&ic) {
	do ia = (int)floor(rand() % nvec);
	while (ia == idx);

	do ib = (int)floor(rand() % nvec);
	while (ib == idx || ib == ia);

	do ic = (int)floor(rand() % nvec);
	while (ic == idx || ic == ia || ic == ib);
}

static inline double clip(double v, double min, double max) {
	double ret = v;
	if (ret < min)
		ret = min;
	if(ret > max)
		ret = max;
	return ret; 
}

int MinDE::iterate(int maxiter) {

	bestIdx = 0;

	for (int j = 0; j < nvec; j++) {
		genes[0].v[j] = 0.5 * (gmin[j] + gmax[j]);
		genes[0].eval = func(genes[0].v.data());
		bestEval = genes[0].eval;
	}

	// 1.initializes the individuals by generating random values
	// and evaluating these random vectors
	for (int idx = 1; idx < geneNum; idx++) {
		Gene& igene = genes[idx];
		for (int j = 0; j < nvec; j++) {
			igene.v[j] = gmin[j] + eqdist() * diff[j];
			igene.eval = func(igene.v.data());

			if (igene.eval < bestEval) {				
				bestEval = igene.eval;
				bestIdx = idx;
			}
		}
	}
	neval = 0;

	Gene trial;
	vector<double> mutant;
	trial.v.resize(nvec);
	mutant.resize(nvec);
	
	for (int iter = 0; iter < maxiter; iter++) {
		update->ntimestep++;
		niter++;

		eprevious = ecurrent;

		// function evaluation criterion
		if (neval >= update->max_eval) return return_final(MAXEVAL, genes[bestIdx].v.data());


		for (int idx = 0; idx < geneNum; idx++) {
			Gene& igene = genes[idx];

			int ia, ib, ic;
			// randomly choose 3 indexes without replacement	
			getUnreplaceIndex(nvec, idx, ia, ib, ic);
			Gene& a = genes[ia], & b = genes[ib], & c = genes[ic];

			bool anyCross = false;
			for (int j = 0; j < nvec; j++) {
				// Mutation
				// create a mutant vector by computing the difference
				mutant[j] = a.v[j] + mut * (b.v[j] - c.v[j]);

				// clipping the number to the interval, so values greater than 
				// gmax become gmax, and the values smaller than gmin become gmin			
				mutant[j] = clip(mutant[j], gmin[j], gmax[j]);

				// Recombination
				// For each position, we decide(with probability defined by crossp)
				// if that number will be replaced by the one in the mutant at the same position.

				// mixing the information of the mutant with the information of the current vector to create a trial vector
				// by changing the numbers at some positions in the current vector with the ones in the mutant vector
				if (eqdist() < crossp) {
					anyCross = true;
					trial.v[j] = mutant[j];
				}
				else {
					trial.v[j] = igene.v[j];
				}
			}

			if (!anyCross) {
				int j = rand() % nvec;
				trial.v[j] = mutant[j];
			}

			trial.eval = func(trial.v.data());

			// Replacement
			// we need to denormalize itand evaluate it to measure how good it is.
			// If this mutant is better than the current vector then we replace it with the new one.
			if (trial.eval < igene.eval) {
				igene.v = trial.v;
				igene.eval = trial.eval;
				if (trial.eval < bestEval) {
					bestIdx = idx;
					bestEval = trial.eval;
				}
			}
		}

		ecurrent = bestEval;
		if (output->next == update->ntimestep) {
			func(genes[bestIdx].v.data()); neval--;
			output->write(update->ntimestep);
		}
	}
	return return_final(MAXEVAL, genes[bestIdx].v.data());
}

// boundary values for self-adapting parameters
#define F_LOWER 0.1 /* lower value for F */
#define F_UPPER 0.9 /* upper value for F */
#define TAU_1 0.1   /* probability for changing F */
#define TAU_2 0.1   /* probability for changing CR */

MinDEA::MinDEA(EAPOT *eapot) : Min(eapot)
{
	linestyle = 0;

	D = 0;
	NP = 0;

	X = NULL;
	cost = NULL;
	trial = NULL;
	xi_opt = NULL;
	pop_1 = NULL;
	pop_2 = NULL;
}

/* ---------------------------------------------------------------------- */

MinDEA::~MinDEA()
{
	memory->destroy(cost);
	memory->destroy(X);
}


void MinDEA::init()
{
	Min::init();
}

/* ---------------------------------------------------------------------- */

void MinDEA::setup_style()
{
	D = nvec + 2;
	NP = 15 * D;	// number of total population

	memory->destroy(X);
	memory->destroy(cost);

	memory->create(cost, NP, "MinDEA::cost");
	memory->create(X, 2 * NP + 2, D, "MinDEA::X");

	trial = X[0];
	xi_opt = X[1];
	pop_1 = &X[2];
	pop_2 = &X[2 + NP];
}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinDEA::reset_vectors()
{
	temp_memcpy(trial, xvec, nvec);
}

/****************************************************************
*  differential evolution
****************************************************************/

void MinDEA::init_population(double** pop, double* xi, double* cost)
{
	// copy initial population into all populations
	for (int i = 0; i < NP; i++) {
		for (int j = 0; j < (D - 2); j++)
			pop[i][j] = xi[j];
		pop[i][D - 2] = F_LOWER + eqdist() * F_UPPER;
		pop[i][D - 1] = eqdist();
	}

	// create random populations (except for first one)
	for (int i = 1; i < NP; i++) {
		for (int j = 0; j < nvec; j++) {
			pop[i][j] = xi[j] * (0.2 * eqdist() + 0.9);
		}
	}

	for (int i = 0; i < NP; i++)
		cost[i] = func(pop[i]);
}

/****************************************************************
*  differential evolution
****************************************************************/

int MinDEA::iterate(int maxiter)
{
	int ntimestep = 0;
	const int ndim = force->pair->get_fsize();

	int a, b;					/* store randomly picked numbers */
	double cost_sum = 0.0;		/* average sum of squares for all configurations */
	//double crit = 1000.0;		/* treshold for stopping criterion */
	double min_cost = 10e10;	/* current minimum for all configurations */
	double max_cost = 0.0;		/* current maximum for all configurations */

	init_population(pop_1, xvec, cost);

	for (int i = 0; i < NP; i++) {
		if (cost[i] < min_cost) {
			min_cost = cost[i];
			temp_memcpy(xi_opt, pop_1[i], D);
		}
		if (cost[i] > max_cost)
			max_cost = cost[i];

		cost_sum += cost[i];
	}
	//crit = max_cost - min_cost;

	//printf("Loops\t\tOptimum\t\tAverage error sum\t\tMax-Min\n");
	//printf("%5d\t\t%15f\t%20e\t\t%.2e\n", 0, min_cost, cost_sum / (NP), crit);

	for (int iter = 0; iter < maxiter; iter++) {
		ntimestep = ++update->ntimestep;
		niter++;

		eprevious = ecurrent;

		// function evaluation criterion
		if (neval >= update->max_eval) return return_final(MAXEVAL, xi_opt);

		max_cost = 0.0;

		// randomly create new populations
		for (int i = 0; i < NP; i++) {
			// generate random numbers a and b
			do a = (int)floor(eqdist() * NP);
			while (a == i);

			do b = (int)floor(eqdist() * NP);
			while (b == i || b == a);

			int j = (int)floor(eqdist() * ndim);

			// self-adaptive parameters
			if (eqdist() < TAU_1)
				trial[D - 2] = F_LOWER + eqdist() * F_UPPER;
			else
				trial[D - 2] = pop_1[i][D - 2];

			if (eqdist() < TAU_2)
				trial[D - 1] = eqdist();
			else
				trial[D - 1] = pop_1[i][D - 1];

			double temp = 0.0;

			// create trail vectors with different methods
			for (int k = 1; k <= ndim; k++) {
				if (eqdist() < trial[D - 1] || k == j) {
					temp = xi_opt[j] + trial[D - 2] * (pop_1[a][j] - pop_1[b][j]);
					trial[j] = temp;
				}
				else {
					trial[j] = pop_1[i][j];
				}
				j = (j + 1) % ndim;
			}

			double force = func(trial);

			if (force < min_cost) {
				temp_memcpy(xi_opt, trial, D);
				min_cost = force;
			}

			if (force <= cost[i]) {
				temp_memcpy(pop_2[i], trial, D);
				cost[i] = force;
				if (force > max_cost) max_cost = force;
			}
			else {
				temp_memcpy(pop_2[i], pop_1[i], D);
				if (cost[i] > max_cost) max_cost = cost[i];
			}
		}

		cost_sum = 0.0;
		for (int i = 0; i < NP; i++)
			cost_sum += cost[i];
		//if (iter % 10 == 0)	printf("%5d\t\t%15f\t%20e\t\t%.2e\n", 
		//	iter + 1, min_cost, cost_sum / NP, max_cost - min_cost);

		temp_memcpy(pop_1[0], pop_2[0], D*NP);

		ecurrent = min_cost;
		if (output->next == ntimestep) {
			func(xi_opt); neval--;
			output->write(ntimestep);
		}
	}
	return return_final(MAXITER, xi_opt);
}
