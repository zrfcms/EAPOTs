#ifdef PAIR_CLASS
#else

#ifdef LIBAPI
typedef void (*DofMapCallback)(void*, int, double*, int, int, double*, double*, const char**);
LIBAPI(void, setPairDof, (APITYPE void* pPair, int nfree, int nconst), (APINAME pPair, nfree, nconst));
LIBAPI(void, setPairDofScript, (APITYPE void* pPair, const char* script), (APINAME pPair, script));
LIBAPI(void, setPairDofCallback, (APITYPE void* pPair, DofMapCallback callback, void* caller), (APINAME pPair, callback, caller));
LIBAPI(void, setPairPotCallback, (APITYPE void* pPair, VoidCallback callback, void* caller), (APINAME pPair, callback, caller));
LIBAPI(void, setPairFullParams, (APITYPE void* pPair, double* vec), (APINAME pPair, vec));
LIBAPI(void, setPairFreeParams, (APITYPE void* pPair, double* vec), (APINAME pPair, vec));
LIBAPI(void, setPairCommByFile, (APITYPE void* pPair, int flag), (APINAME pPair, flag));
LIBAPI(void, setPairDumpImageLimitSampleValue, (APITYPE void* pPair, int figidx1, 
	int figidx2, double x), (APINAME pPair, figidx1, figidx2, x));
LIBAPI(void, setPairDumpImageXLimit, (APITYPE void* pPair, int figidx, double lo, double hi), (APINAME pPair, figidx, lo, hi));
LIBAPI(void, setPairDumpImageYLimit, (APITYPE void* pPair, int figidx, double lo, double hi), (APINAME pPair, figidx, lo, hi));
#else

#ifndef EAPOT_PAIR_H
#define EAPOT_PAIR_H

#include "imageTypes.h"
#include "pointers.h"
#include <vector>
#include <string>

typedef void (*DofMapCallback)(void*, int, double*, int, int, double*, double*, const char**);

namespace EAPOT_NS {

	class Pair : protected Pointers {
	friend class PairStyle;
	friend class ComputeTerm;
	public:
		Pair(class EAPOT *);
		~Pair();
		int fvec_allocated;								// 0/1 = whether arrays are allocated

		std::string pythonScript;
		VoidCallback potCallback;
		DofMapCallback dofMapCallback;
		void* dofMapCaller, * potCaller;

	public:
		void add_fsize(int n);
		void add_csize(int n);
		int get_fsize() const;
		int get_csize() const;
		
		virtual void fvec_allocate();
		void fvec_clear(){ fsize = csize = 0; };
		double* get_fvec() { return fvec.data(); }
		
		virtual void extra_check(int) = 0;
		virtual void setFullParams(double *);
		virtual void setFreeParams(double *);		

	protected:
		std::vector<double> paramVec;
		std::vector<std::string> paramName;

		virtual void setFullParamsStyle() {
			setFreeParamsStyle();
		};
		virtual void setFreeParamsStyle() = 0;

	private:
		int fsize, fsize_custom;						// # of freedom  variable
		int csize, csize_custom;						// # of constant variable
		std::vector<double> fvec;						// vector for freedom  variable
		std::vector<double> cvec;						// vector for constant variable

		virtual int getPyParamNum() = 0;
		virtual void defaultDofMap(double*, double*) = 0;

	public:
		void init();
		virtual void init_style() {};

		virtual void export_init(void*) = 0;
		virtual void export_pair(void*) = 0;
		virtual void export_computeMD(void* compute) {};

	//dump
	public:
		bool transByFileMode;
		std::string chkStyle;
		std::vector<const char*> styles;
		int styleCheck(const char*, int, const char*, int);
		virtual void transByFile(const char*);

		std::vector<double>	dump_sample;				// dump Sampling point
		std::vector<AxisLimit> ylim, xlim;
		void updateAxisLimitByCustom();

		virtual void write(class DumpFile* dump) = 0;
		static inline double safedump(double v) {
			return isfinite(v) ? v : 0;
		}
		void pack_image(class DumpImage* dumpimage);
		virtual int image(class DumpImage* dumpimage);

	// check
	public:
		enum AddMDCompEnum {
			RunDump = 1 << 0,
			RunEcho = 1 << 1,
		};

		static const char* CuFccCost[], * NbBccCost[], * CDiaCost[], * SiCDiaCost[];
		static const char* FccChk, * BccChk, *DiaChk;
		static const char* CuNiAlloyCost[], * VNbAlloyCost[], * AlloyChk;

		typedef const char* CPCHAR;

		void runMDCompute(int step, int mode, int nther, CPCHAR cost[], CPCHAR chk, CPCHAR minstyle, CPCHAR filename);
		void evalCompute(double* BoxChk, double* ElaChk, int nbox = 3, int elalo = 3, int nela = 3);

		void addMDComputeAlloy();
		void addMDComputeFcc();
		void addMDComputeBcc();
		void addMDComputeCDia();
		void addMDComputeSiCDia();

		void addMDCheckCubic(const char* file, int line, int icomp, const char* name,
			const char* title, double* ref, double smaxerr, double saveerr);
	};

}

#endif
#endif
#endif
