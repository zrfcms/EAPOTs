
#ifndef EAPOT_UPDATE_H
#define EAPOT_UPDATE_H

#include "pointers.h"
#include <map>
#include <string>

namespace EAPOT_NS {

	class Update : protected Pointers {
	public:
		double etol, ftol;              // minimizer tolerances on energy/force
		int ntimestep;					// current step (dynamics or min iterations)
		int nsteps;                     // # of steps to run (dynamics or min iter)
		int whichflag;                  // 0 for unset, 1 for dynamics, 2 for min

		int firststep, laststep;		// 1st & last step of this run
		int first_update;               // 0 before initial update, 1 after
		int max_eval;                   // max force evaluations for minimizer
		int setupflag;                  // set when setup() is computing forces

		class Min *minimize;
		char *minimize_style;
		typedef Min *(*MinimizeCreator)(EAPOT *);
		typedef std::map<std::string, MinimizeCreator> MinimizeCreatorMap;
		MinimizeCreatorMap *minimize_map;

		Update(class EAPOT *);
		~Update();
		void init();
		class Compute* cost;

	public: // API
		void setTimestep(int);
		void setRandomSeed(int);
		void setMinimizeLogFlag(int);
		void setMinimizeStyle(const char* style);
		void runMinimize(void* pComp, double etol, double ftol, int nstep, int neval);

	private:
		template <typename T> static Min *minimize_creator(EAPOT *);
	};

}

#endif
