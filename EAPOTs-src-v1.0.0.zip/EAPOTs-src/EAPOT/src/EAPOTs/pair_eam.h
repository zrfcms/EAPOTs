#ifdef PAIR_CLASS
#else

#ifdef LIBAPI
LIBAPI(void, setPairEAMDumpFormat, (APITYPE void* pPair, int Nrho, double drho, 
	int Nr, double dr, double cut), (APINAME pPair, Nrho, drho, Nr, dr, cut));
LIBAPI(void, setPairEAMDumpNrho, (APITYPE void* pPair, int num), (APINAME pPair, num));
LIBAPI(void, setPairEAMDumpNr, (APITYPE void* pPair, int num), (APINAME pPair, num));
LIBAPI(void, setPairEAMDumpdrho, (APITYPE void* pPair, double delta), (APINAME pPair, delta));
LIBAPI(void, setPairEAMDumpdr, (APITYPE void* pPair, double delta), (APINAME pPair, delta));
LIBAPI(void, setPairEAMDumpCutoff, (APITYPE void* pPair, double cut), (APINAME pPair, cut));
LIBAPI(void, setPairEAMDumpImageEmbXMult, (APITYPE void* pPair, double ratio), (APINAME pPair, ratio));
LIBAPI(void, setPairEAMDumpImageLimitRlo, (APITYPE void* pPair, double lo), (APINAME pPair, lo));
LIBAPI(void, setPairEAMDumpFileElementTitle, (APITYPE void* pPair, int ele, const char* title), (APINAME pPair, ele, title));
LIBAPI(void, setPairEAMOutputMode, (APITYPE void* pPair, const char* mode), (APINAME pPair, mode));
#else

#ifndef EAPOT_PAIR_EAM_H
#define EAPOT_PAIR_EAM_H

#include "pair.h"
#include <string>
#include <vector>
namespace EAPOT_NS {

	class PairEAM : public Pair
	{
		friend class PairStyle;
	public:
		class PairEAMFmt
		{
		public:
			PairEAMFmt() {
				nrho = nr = 0;
				drho = dr = 1.0;
				cut = 0.0;
			}
			int nrho, nr;
			double drho, dr, cut;
		};

		int eam_fsize;				// # of freedom  variable for differnet function form
		int eam_csize;				// # of constant variable for differnet function form
		double cutmax;

		PairEAM(EAPOT *eapot);
		~PairEAM();

		virtual int getPyParamNum();
		virtual void defaultDofMap(double*, double*);
		virtual void fvec_allocate();

		// Atomic type markers start at 1, for example 1, 2, 3...

		virtual double emb(int type, double x) = 0;
		virtual double rho(int itype, int jtype, double x) = 0;
		virtual double phi(int itype, int jtype, double x) = 0;

		virtual void init_style();
		void chkListFunc(int Nrho, double rholo, double drho, int Nr, double rlo, 
			double dr, double* fChk, double* rChk, double* pChk, int fs, int printFlag = 0);

	// export 
	public:
		bool unExportFlag;
		bool exportAsFsFlag;
		virtual void setFreeParamsStyle();
		void export_init(void*);
		void export_pair(void*);
		void export_computeMD(void*);

		double** export_frho;
		double** export_rhor;
		double** export_z2r;

	// file dump
	public:
		PairEAMFmt m_dump;
		std::vector<std::string> element_title;

		double dump_sample_fmult;		// image_rhohi = 12 * MAX(rho(dump_sample)) * dump_sample_fmult

		const char* ele_title(int);
		virtual void write(class DumpFile* dump);
		virtual void write_style(class DumpFile* dump) {};

	// image dump
	public:
		virtual int image(class DumpImage* dumpimage);
		virtual void back_image(class DumpImage* dumpimage, void *paxesf, void *paxesr, void *paxesp) {};
	};
}

#endif
#endif
#endif