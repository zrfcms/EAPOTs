#ifdef DUMP_CLASS
DumpStyle(image, DumpImage)
#else

#ifdef LIBAPI
LIBAPI(void, setDumpImageSize, (APITYPE void* pDump, int w, int h), (APINAME pDump, w, h));
#else

#ifndef EAPOT_DUMP_IMAGE_H
#define EAPOT_DUMP_IMAGE_H

#include "dump.h"

namespace EAPOT_NS {

	class DumpImage : public Dump {
	public:
		DumpImage(EAPOT *, const char* id, const char* style, const char* file);
		~DumpImage();
		typedef unsigned char ubyte;
		class Image *image;              // class that renders each image
	protected:

		void init_style();
		void write();
	};

}

#endif
#endif
#endif
