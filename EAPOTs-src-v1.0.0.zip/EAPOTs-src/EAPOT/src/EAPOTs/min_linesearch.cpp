
#include "min_linesearch.h"
#include "update.h"
#include "modify.h"
#include "memory.h"
#include "error.h"
#include "pair.h"
#include "force.h"

#include "option_mini.h"

using namespace EAPOT_NS;

// ALPHA_MAX = max alpha allowed to avoid long backtracks
// ALPHA_REDUCE = reduction ratio, should be in range [0.5,1)
// BACKTRACK_SLOPE, should be in range (0,0.5]
// QUADRATIC_TOL = tolerance on alpha0, should be in range [0.1,1)
// EMACH = machine accuracy limit of energy changes (1.0e-8)
// EPS_QUAD = tolerance for quadratic projection

#define ALPHA_MAX 1.0
#define ALPHA_REDUCE 0.5
#define BACKTRACK_SLOPE 0.4
#define QUADRATIC_TOL 0.1
//#define EMACH 1.0e-8
#define EMACH 1.0e-16
#define EPS_QUAD 1.0e-28

/* ---------------------------------------------------------------------- */

MinLineSearch::MinLineSearch(EAPOT *eapot) : Min(eapot)
{
	styles.push_back("lineSearch");
	gradientDependFlag = 1;
	linestyle = 0;

	x0 = NULL;
	g = NULL;
	h = NULL;

	linemin = &MinLineSearch::linemin_backtrack;
}

/* ---------------------------------------------------------------------- */

MinLineSearch::~MinLineSearch()
{
	memory->destroy(x0);
	memory->destroy(g);
	memory->destroy(h);
}

void MiniStyle::setLineSearchMethod(const char* style)
{
	update->minimize->styleCheck(FLERR, "lineSearch", 1);
	MinLineSearch* min = (MinLineSearch*)update->minimize;
	if (strcmp(style, "backtrack") == 0) min->linestyle = 0;
	else if (strcmp(style, "quadratic") == 0) min->linestyle = 1;
	else if (strcmp(style, "forcezero") == 0) min->linestyle = 2;
	else error->all(FLERR, "Illegal setLineSearchMethod command");
}

/* ---------------------------------------------------------------------- */

void MinLineSearch::init()
{
	Min::init();

	if (linestyle == 0) linemin = &MinLineSearch::linemin_backtrack;
}

/* ---------------------------------------------------------------------- */

void MinLineSearch::setup_style()
{
	memory->destroy(x0);
	memory->destroy(g);
	memory->destroy(h);

	memory->create(x0, nvec, "MinLineSearch::x0");
	memory->create(g, nvec, "MinLineSearch::g");
	memory->create(h, nvec, "MinLineSearch::h");
}

/* ----------------------------------------------------------------------
set current vector lengths and pointers
called after atoms have migrated
------------------------------------------------------------------------- */

void MinLineSearch::reset_vectors()
{
	temp_memcpy(x0, xvec, nvec);	
}

/* ----------------------------------------------------------------------
line minimization methods
find minimum-energy starting at x along h direction
input args:   eoriginal = energy at initial x
input extra:  n,x,x0,f,h for atomic, extra global, extra per-atom dof
output args:  return 0 if successful move, non-zero alpha
return non-zero if failed
alpha = distance moved along h for x at min eng config
update neval counter of eng/force function evaluations
output extra: if fail, energy_force() of original x
if succeed, energy_force() at x + alpha*h
atom->x = coords at new configuration
atom->f = force at new configuration
ecurrent = energy of new configuration
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------
linemin: backtracking line search (Proc 3.1, p 41 in Nocedal and Wright)
uses no gradient info, but should be very robust
start at maxdist, backtrack until energy decrease is sufficient
------------------------------------------------------------------------- */

int MinLineSearch::linemin_backtrack(double eoriginal, double &alpha)
{
	int i;
	double fdothall, hmaxall;
	double de_ideal, de;

	// fdothall = projection of search dir along downhill gradient
	// if search direction is not downhill, exit with error

	fdothall = 0.0;
	for (i = 0; i < nvec; i++) fdothall -= fvec[i] * h[i];
	//if (output->thermo->normflag) fdothall /= atom->natoms;
	if (fdothall <= 0.0) return DOWNHILL;

	// set alpha so no dof is changed by more than max allowed amount
	// for atom coords, max amount = dmax
	// for extra per-atom dof, max amount = extra_max[]
	// for extra global dof, max amount is set by fix
	// also insure alpha <= ALPHA_MAX
	// else will have to backtrack from huge value when forces are tiny
	// if all search dir components are already 0.0, exit with error

	hmaxall = 0.0;
	for (i = 0; i < nvec; i++) hmaxall = MAX(hmaxall, fabs(h[i]));
	alpha = MIN(ALPHA_MAX, dmax / hmaxall);
	if (hmaxall == 0.0) return ZEROFORCE;

	// store box and values of all dof at start of linesearch
	for (i = 0; i < nvec; i++) x0[i] = xvec[i];

	// // important diagnostic: test the gradient against energy
	// double etmp;
	// double alphatmp = alpha*1.0e-4;
	// etmp = alpha_step(alphatmp,1);
	// printf("alpha = %g dele = %g dele_force = %g err = %g\n",
	//        alphatmp,etmp-eoriginal,-alphatmp*fdothall,
	//        etmp-eoriginal+alphatmp*fdothall);
	// alpha_step(0.0,1);

	// backtrack with alpha until energy decrease is sufficient

	while (1) {
		ecurrent = alpha_step(alpha, 1, 0);

		// if energy change is better than ideal, exit with success

		de_ideal = -BACKTRACK_SLOPE*alpha*fdothall;
		de = ecurrent - eoriginal;
		if (de <= de_ideal && isfinite(de)) {
			energy_force(0, 1);
			return 0;
		}
		// reduce alpha

		alpha *= ALPHA_REDUCE;

		// backtracked too much
		// reset to starting point
		// if de is positive, exit with error
		// if de is negative, exit with ETOL

		if (alpha <= 0.0 || de_ideal >= -EMACH) {
			ecurrent = alpha_step(0.0, 0, 1);
			if (de < 0.0) return ETOL;
			else return ZEROALPHA;
		}
	}
}
/* ---------------------------------------------------------------------- */

double MinLineSearch::alpha_step(double alpha, int resetflag, int gradientFlag)
{
	int i;

	// reset to starting point
	for (i = 0; i < nvec; i++) xvec[i] = x0[i];

	// step forward along h
	if (alpha > 0.0) {
		for (i = 0; i < nvec; i++) xvec[i] += alpha*h[i];
	}
	// compute and return new energy

	neval++;
	return energy_force(resetflag, gradientFlag);
}
