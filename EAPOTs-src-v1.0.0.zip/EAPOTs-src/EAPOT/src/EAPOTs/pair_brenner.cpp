#include "pair_tersoff.h"

#include "error.h"
#include "force.h"

#include "math.h"
#include "option_pair.h"
using namespace EAPOT_NS;


PairBrenner::PairBrenner(EAPOT* eapot)
	: PairTersoff(eapot)
{
	styles.push_back("bop/brenner");
	key = {
	"m", "gamma", "lam3", "c", "d",
	"cos0", "n", "beta", "mu", "S",
	"R", "D", "r0", "D0", };
};

PairBrenner::~PairBrenner() {

}

#define IDX(i,j,k) (i*n2+j*n+k)
#define Val(iParam, itri) paramVec[iParam*n3 + itri]

void PairBrenner::setFreeParamsStyle() {

	const int n = force->get_ntypes();
	const int n2 = n * n;
	const size_t n3 = (size_t)n * n * n;

	if (val.size() != paramVec.size()) {
		val.resize(paramVec.size(), 0.0);
	}

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			for (int k = 0; k < n; k++) {
				const int itri = IDX(i, j, k);

				double mu = Val(8, itri);
				double S = Val(9, itri);
				double r0 = Val(12, itri);
				double D0 = Val(13, itri);

				if (mu == 0 || S == 0 || r0 == 0 || D0 == 0) {
					continue;
				}

				Val(8, itri) = mu * sqrt(2 / S);									// lambda2
				Val(9, itri) = S * D0 / (S - 1) * exp(mu * sqrt(2 / S) * r0);		// B
				Val(12, itri) = mu * sqrt(2 * S);									// lambda1
				Val(13, itri) = D0 / (S - 1) * exp(mu * sqrt(2 * S) * r0);		// A
			}

}

void PairBrenner::extra_check(int type) {
	const char* name = NULL;

	switch (type) {
	case 0:
		name = "Brenners";
		addMDComputeCDia();
		break;
	case 1:
		name = "Brennerc";
		addMDComputeSiCDia();
		break;
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}

	if (0) {
		// run test
		switch (type) {
		case 0: {
			double param[] = { 19900, 7.0, -0.34, 0.99, 4.2E-06, 2.00, 1.5, 1.5, 3.74, 3, 1, 0, 1.95, 0.15 };
			pairStyle->setPairFullParams(force->pair, param);
			runMDCompute(120, RunDump | RunEcho, 40, CDiaCost, DiaChk, "nms", "C.*.tersoff");
			break;
		}
		case 1: {
			pairStyle->setPairDof(force->pair, 22, 9);
			double param[] = { 19981, 100390, 7.034, 16.217,
				-0.339, -0.598, 0.990, 0.787, 4.16E-06, 1.10E-06,
				2.00, 1.73, 1.47,  1.50, 1.47, 1.43,  1.54, 1.83, 2.30,  3.74, 3.44, 2.67,
				3, 1, 0, 1.95, 2.85, 2.35726, 0.15, 0.15271, 0.152719 };
			pairStyle->setPairFullParams(force->pair, param);
			runMDCompute(200, RunDump | RunEcho, 20, SiCDiaCost, DiaChk, "nms", "SiC.*.tersoff");
			break;
		}
		}
		return;
	}
	else {
		runMDCompute(-1, 0, 10, NULL, NULL, NULL, NULL);
	}

	error->add_chklog(0, name, "");

	switch (type) {
	case 0: {
		// data from LAMMPS
		double BoxChk[2], BoxRef[2] = { 3.556293280574872, 7.472988510456348 };
		double ElaChk[3], ElaRef[3] = { 1007.7415420195915, 168.83099246073704, 545.108929945727 };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, 2, BoxChk, BoxRef, 1, name, "Box", 5e-6, 4e-6, 1.923612768702623e-06, 2.6294582967503796e-06);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 1e-4, 5e-5, 7.0907823876800309e-05, 8.6131660947475915e-05);
		break;
	}
	case 1: {
		// data from LAMMPS
		double BoxChk[2], BoxRef[2] = { 4.279594682807735, 6.433833351360659 };
		double ElaChk[3], ElaRef[3] = { 446.64200848299805, 138.13290163643632, 292.6709709663819 };
		evalCompute(BoxChk, ElaChk, 1, 1, 1);

		error->check(FLERR, 2, BoxChk, BoxRef, 1, name, "Box", 5e-6, 3e-6, 7.8915829578948502e-07, 1.2077121165940107e-06);
		error->check(FLERR, 3, ElaChk, ElaRef, 1, name, "Ela", 5e-5, 2e-5, 3.4370417449738071e-05, 5.1616718298270759e-05);
		break;
	}
	default:
		error->all(FLERR, "Illegal MEAM extra_check");
	}
};