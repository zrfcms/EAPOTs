
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "thermo.h"

#include "memory.h"
#include "error.h"
#include "input.h"
#include "update.h"
#include "modify.h"
#include "output.h"

#include "min.h"
#include "dump.h"
#include "compute.h"
#include "compute_external.h"

#define ONE "step err"
using namespace EAPOT_NS;

#define INVOKED_SCALAR 1
#define INVOKED_VECTOR 2
#define INVOKED_VECTOR2D 4
#define INVOKED_VECTOR3D 8

Thermo::Thermo(EAPOT *eapot, const char* pstyle, int num, const char** keys)
: Pointers(eapot)
, style(NULL)
, normflag(0)
, modified(0)
, blankFlag(0)
, line(NULL)

, vfunc(NULL)
, nfield(0)
, nfield_initial(0)
, keyword(NULL)
, vtype(NULL)

, ifield(0)
, field2index(NULL)
, argindex1(NULL)
, argindex2(NULL)

, ncompute(0)
, id_compute(NULL)
, compute_which(NULL)
, computes(NULL)
, err(NULL)

, format(NULL)
, format_line_user(NULL)

, format_float_user(NULL)
, format_int_user(NULL)
, format_column_user(NULL)

, format_float_one_def(NULL)
, format_int_one_def(NULL)

, firststep(0)
, lineflag(0)
, last_time(0)
, last_step(0)

, costflag(0)
, format_cost_num(0)
, format_cost(NULL)
, format_cost_line_user(NULL)
, format_cost_float_user(NULL)
, format_cost_float_one_def(NULL)

, ivalue(0)
, dvalue(0)
, svalue(NULL)
{

	int n = strlen(pstyle) + 1;
	style = new char[n];
	strcpy(style, pstyle);

	// set thermo_modify defaults

	modified = 0;
	costflag = 1;
	printHeaderFlag = 0;
	format_cost_num = 0;
	lineflag = ONELINE;

	// set style and corresponding lineflag
	// custom style builds its own line of keywords, including wildcard expansion
	// customize a new thermo style by adding to if statement
	// allocate line string used for 3 tasks
	//   concat of custom style args
	//   one-time thermo output of header line
	//   each line of numeric thermo output
	//   256 = extra for ONE or MULTI string or multi formatting
	//   64 = max per-arg chars in header or numeric output

	if (strcmp(style, "one") == 0) {
		line = new char[256 + 16 * 64];
		strcpy(line, ONE);
	}
	else if (strcmp(style, "custom") == 0) {
		if (keys == NULL) {
			error->all(FLERR, "Illegal thermo style custom command");
			return;
		}

		line = new char[2560 + (size_t)num * 64];
		line[0] = '\0';
		for (int iarg = 0; iarg < num; iarg++) {
			strcat(line, keys[iarg]);
			strcat(line, " ");
		}
		line[strlen(line) - 1] = '\0';
	}
	else error->all(FLERR, "Illegal thermo style command");

	// count fields in line
	// allocate per-field memory
	// process line of keywords

	nfield_initial = input->count_words(line);
	allocate();
	parse_fields(line);

	// format strings

	format_float_one_def = (char *) "%14.8g";
	format_int_one_def = (char *) "%8d";
	format_cost_float_one_def = (char *) "%10.4g ";

	format_line_user = NULL;
	format_float_user = NULL;
	format_int_user = NULL;

	format_cost = NULL;
	format_cost_line_user = NULL;
	format_cost_float_user = NULL;

	eapot->once_initFlag = 0;
}

/* ---------------------------------------------------------------------- */

Thermo::~Thermo()
{
	delete[] style;
	delete[] line;

	deallocate();

	// format strings

	delete[] format_line_user;
	delete[] format_float_user;
	delete[] format_int_user;
}

/* ---------------------------------------------------------------------- */

void Thermo::init()
{
	int i, n;

	// add Volume field if volume changes and not style = custom
	// this check must come after domain init, so box_change is set
	err = (ComputeTerm*)update->minimize->cost;

	nfield = nfield_initial;

	// set format string for each field
	// include keyword if lineflag = MULTILINE
	// add '/n' every 3 values if lineflag = MULTILINE
	// add trailing '/n' to last value

	char *format_line = NULL;
	if (format_line_user) {
		int n = strlen(format_line_user) + 1;
		format_line = new char[n];
		strcpy(format_line, format_line_user);
	}

	char *ptr = NULL;
	char *format_line_ptr = NULL;
	for (i = 0; i < nfield; i++) {
		format[i][0] = '\0';
		if (lineflag == MULTILINE && i % 3 == 0) strcat(format[i], "\n");

		if (format_line) {
			if (i == 0) format_line_ptr = strtok(format_line, " \0");
			else format_line_ptr = strtok(NULL, " \0");
		}

		if (format_column_user[i]) ptr = format_column_user[i];
		else if (vtype[i] == FLOAT) {
			if (format_float_user) ptr = format_float_user;
			else if (format_line_user) ptr = format_line_ptr;
			else if (lineflag == ONELINE) ptr = format_float_one_def;
		}
		else if (vtype[i] == INT) {
			if (format_int_user) ptr = format_int_user;
			else if (format_line_user) ptr = format_line_ptr;
			else if (lineflag == ONELINE) ptr = format_int_one_def;
		}
		else if (vtype[i] == STRING) {
			if (format_line_user) ptr = format_line_ptr;
			else ptr = (char*)"%s";

			char* penter = strstr(ptr, "\\n");
			if (penter) sprintf(penter, "\n");
		}

		n = strlen(format[i]);
		if (lineflag == ONELINE) sprintf(&format[i][n], "%s ", ptr);
		else sprintf(&format[i][n], "%-8s = %s ", keyword[i], ptr);
	}

	delete[] format_line;


	if (format_cost_line_user) {
		int n = strlen(format_cost_line_user) + 1;
		format_line = new char[n];
		strcpy(format_line, format_cost_line_user);

		format_cost_num = input->count_words(format_line);
		memory->grow(format_cost, format_cost_num, 32, "Thermo::format_cost");

		for (i = 0; i < format_cost_num; i++) {
			format_cost[i][0] = '\0';
			if (lineflag == MULTILINE && i % 3 == 0) strcat(format_cost[i], "\n");

			if (i == 0) format_line_ptr = strtok(format_line, " \0");
			else format_line_ptr = strtok(NULL, " \0");

			n = strlen(format_cost[i]);
			if (lineflag == ONELINE) sprintf(&format_cost[i][n], "%s ", format_line_ptr);
			else sprintf(&format_cost[i][n], "%-8s = %s ", keyword[i], format_line_ptr);
		}
		delete[] format_line;
	}	

	// find current ptr for each Compute ID

	int icompute;
	for (i = 0; i < ncompute; i++) {
		icompute = modify->find_compute(id_compute[i]);
		if (icompute < 0) error->all(FLERR, "Could not find thermo compute ID");
		computes[i] = modify->compute[icompute];
	}

	int idump;
	for (size_t i = 0; i < id_dump.size(); i++) {
		idump = output->findDump(id_dump[i].c_str());
		if (idump < 0) error->all(FLERR, "Could not find thermo dump ID");
		dumps.push_back(idump);
	}
}

/* ---------------------------------------------------------------------- */

void Thermo::header()
{
	if (lineflag == MULTILINE) return;

	printHeaderFlag = 1;

	int loc = 0;
	for (int i = 0; i < nfield; i++)
		loc += sprintf(&line[loc], "%s ", keyword[i]);

	sprintf(&line[loc], "\n");	
	if (screen && !blankFlag) fputs(line, screen);
	if (output->thermolog && update->ntimestep == 0) fputs(line, output->thermolog);
	if (logfile && !blankFlag) fputs(line, logfile);

	if (costflag){
		int loc = 0;
		for (ifield = 0; ifield < nfield; ifield++) {
			(this->*vfunc[ifield])();
			if (vtype[ifield] == FLOAT)
				loc += sprintf(&line[loc], format[ifield], dvalue);
			else if (vtype[ifield] == INT)
				loc += sprintf(&line[loc], format[ifield], ivalue);
			else if (vtype[ifield] == STRING) {				
				loc += sprintf(&line[loc], format[ifield], svalue);
			}						
		}
		
		sprintf(&line[loc], "\n");
		if (screen && !blankFlag) fputs(line, screen);
		if (output->thermolog && update->ntimestep == 0) fputs(line, output->thermolog);
		if (logfile && !blankFlag) fputs(line, logfile);
	}

	printHeaderFlag = 0;
	if (output->thermolog) fflush(output->thermolog);
}

/* ---------------------------------------------------------------------- */

void Thermo::compute(int flag)
{
	firststep = flag;
	//int ntimestep = update->ntimestep;

	// invoke Compute methods needed for thermo keywords

	//for (i = 0; i < ncompute; i++)
	//if (compute_which[i] == SCALAR) {
	//	if (!(computes[i]->invokedFlag & INVOKED_SCALAR)) {
	//		computes[i]->compute_scalar();
	//		computes[i]->invokedFlag |= INVOKED_SCALAR;
	//	}
	//}
	//else if (compute_which[i] == VECTOR) {
	//	if (!(computes[i]->invokedFlag & INVOKED_VECTOR)) {
	//		computes[i]->compute_vector();
	//		computes[i]->invokedFlag |= INVOKED_VECTOR;
	//	}
	//}
	//else if (compute_which[i] == VECTOR2D) {
	//	if (!(computes[i]->invokedFlag & INVOKED_VECTOR2D)) {
	//		computes[i]->compute_vector2d();
	//		computes[i]->invokedFlag |= INVOKED_VECTOR2D;
	//	}
	//}

	// if lineflag = MULTILINE, prepend step/cpu header line

	int loc = 0;

	// add each thermo value to line with its specific format

	for (ifield = 0; ifield < nfield; ifield++) {
		(this->*vfunc[ifield])();
		if (vtype[ifield] == FLOAT)
			loc += sprintf(&line[loc], format[ifield], dvalue);
		else if (vtype[ifield] == INT)
			loc += sprintf(&line[loc], format[ifield], ivalue);	
		else if (vtype[ifield] == STRING) 
			loc += sprintf(&line[loc], format[ifield], svalue);
		
	}

	// print line to screen and logfile
	//bug 20190506
	// can not use fprintf, b/c '%'(once) in fprintf will make error, e.g:
	// " 0  2.099480e-02    0.00188512%   6.55406e-06 2.1902829225468295587857074701299..."
	// to simplify from using '%%%%' in format_cost_user
	// use fputs here, where '%' can be output correctly
	sprintf(&line[loc], "\n");
	if (screen && !blankFlag) fputs(line, screen);
	if (output->thermolog) {
		fputs(line, output->thermolog);
		fflush(output->thermolog);
	}
	if (logfile && !blankFlag) fputs(line, logfile);

	// set to 1, so that subsequent invocations of CPU time will be non-zero
	// e.g. via variables in print command

	firststep = 1;
}

/* ----------------------------------------------------------------------
call function to compute property
------------------------------------------------------------------------- */

void Thermo::call_vfunc(int ifield)
{
	(this->*vfunc[ifield])();
}

/* ----------------------------------------------------------------------
allocate all per-field memory
------------------------------------------------------------------------- */

void Thermo::allocate()
{
	// n = specified fields + Volume field (added at run time)

	int n = nfield_initial + 1;

	keyword = new char*[n];
	for (int i = 0; i < n; i++) keyword[i] = NULL;
	vfunc = new FnPtr[n];
	vtype = new int[n];

	format = new char*[n];
	for (int i = 0; i < n; i++) format[i] = new char[32];
	format_column_user = new char*[n];
	for (int i = 0; i < n; i++) format_column_user[i] = NULL;

	field2index = new int[n];
	argindex1 = new int[n];
	argindex2 = new int[n];

	// factor of 3 is max number of computes a single field can add

	ncompute = 0;
	id_compute = new char*[3 * (size_t)n];
	compute_which = new int[3 * (size_t)n];
	computes = new Compute*[3 * (size_t)n];

	dumps.clear();
	id_dump.clear();
}

/* ----------------------------------------------------------------------
deallocate all per-field memory
------------------------------------------------------------------------- */

void Thermo::deallocate()
{
	int n = nfield_initial + 1;

	for (int i = 0; i < n; i++) delete[] keyword[i];
	delete[] keyword;
	delete[] vfunc;
	delete[] vtype;

	for (int i = 0; i < n; i++) delete[] format[i];
	delete[] format;
	for (int i = 0; i < n; i++) delete[] format_column_user[i];
	delete[] format_column_user;

	memory->destroy(format_cost);

	delete[] field2index;
	delete[] argindex1;
	delete[] argindex2;

	for (int i = 0; i < ncompute; i++) delete[] id_compute[i];
	delete[] id_compute;
	delete[] compute_which;
	delete[] computes;

	dumps.clear();
	id_dump.clear();
}

/* ----------------------------------------------------------------------
parse list of thermo keywords from str
set compute flags (temp, press, pe, etc)
------------------------------------------------------------------------- */

void Thermo::parse_fields(char *str)
{
	nfield = 0;

	// customize a new keyword by adding to if statement

	char *word = strtok(str, " \0");
	while (word) {

		if (strcmp(word, "step") == 0) {
			addfield("step", &Thermo::compute_step, INT);
		}
		else if(strcmp(word, "eval") == 0) {
			addfield("eval", &Thermo::compute_neval, INT);
		}
		else if (strcmp(word, "err") == 0) {
			addfield("err", &Thermo::compute_err, FLOAT);
		}
		else if (strcmp(word, "pylog") == 0) {
			addfield("pylog", &Thermo::compute_pylog, STRING);
		}
		// compute value = c_ID, fix value = f_ID, variable value = v_ID
		// count trailing [] and store int arguments
		else if ((strncmp(word, "c_", 2) == 0) || (strncmp(word, "f_", 2) == 0) ||
			(strncmp(word, "v_", 2) == 0) || (strncmp(word, "d_", 2) == 0)) {

			int n = strlen(word);
			char *id = new char[n];
			strcpy(id, &word[2]);

			// parse zero or one or two trailing brackets from ID
			// argindex1,argindex2 = int inside each bracket pair, 0 if no bracket

			char *ptr = strchr(id, '[');
			if (ptr == NULL) argindex1[nfield] = argindex2[nfield] = 0;
			else {
				*ptr = '\0';
				argindex1[nfield] =	input->int_between_brackets(ptr, 0);
				ptr++;
				if (*ptr == '[') {
					argindex2[nfield] = input->int_between_brackets(ptr, 0);
					ptr++;
				}
				else argindex2[nfield] = 0;
			}

			if (word[0] == 'c') {
				n = modify->find_compute(id);
				if (n < 0) error->all(FLERR, "Could not find thermo custom compute ID");
				if (argindex1[nfield] == 0)
					error->all(FLERR, "Thermo compute does not compute scalar");
				if (argindex1[nfield] > 0 && argindex2[nfield] > 0) {
					error->all(FLERR, "Thermo compute does not compute array");
				}

				field2index[nfield] = addCompute(id, VECTOR);
				addfield(word, &Thermo::compute_compute, FLOAT);

			}
			else if (word[0] == 'd') {
				n = output->findDump(id);
				if (n < 0) error->all(FLERR, "Could not find thermo custom dump ID");
				
				field2index[nfield] = add_dump(id);
				addfield(word, &Thermo::compute_dump, STRING);
			}
			delete[] id;

		}
		else error->all(FLERR, "Unknown keyword in thermo_style custom command");

		word = strtok(NULL, " \0");
	}
}

/* ----------------------------------------------------------------------
add field to list of quantities to print
------------------------------------------------------------------------- */

void Thermo::addfield(const char *key, FnPtr func, int typeflag)
{
	int n = strlen(key) + 1;
	delete[] keyword[nfield];
	keyword[nfield] = new char[n];
	strcpy(keyword[nfield], key);
	vfunc[nfield] = func;
	vtype[nfield] = typeflag;
	nfield++;
}

/* ----------------------------------------------------------------------
add compute ID to list of Compute objects to call
return location of where this Compute is in list
if already in list with same which, do not add, just return index
------------------------------------------------------------------------- */

int Thermo::addCompute(const char *id, int which)
{
	int icompute;
	for (icompute = 0; icompute < ncompute; icompute++)
	if ((strcmp(id, id_compute[icompute]) == 0) &&
		which == compute_which[icompute]) break;
	if (icompute < ncompute) return icompute;

	int n = strlen(id) + 1;
	id_compute[ncompute] = new char[n];
	strcpy(id_compute[ncompute], id);
	compute_which[ncompute] = which;
	ncompute++;
	return ncompute - 1;
}

/* ----------------------------------------------------------------------
add dump ID to list of Dump objects to call
return location of where this Dump is in list
------------------------------------------------------------------------- */

int Thermo::add_dump(const char* id) {
	id_dump.push_back(id);
	return int(id_dump.size()) - 1;
}

/* ----------------------------------------------------------------------
add fix ID to list of Fix objects to call
------------------------------------------------------------------------- */


/* ----------------------------------------------------------------------
extraction of Compute, Fix, Variable results
compute/fix are normalized by atoms if returning extensive value
variable value is not normalized (formula should normalize if desired)
------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */

void Thermo::compute_compute()
{
	int m = field2index[ifield];
	Compute *compute = computes[m];

	// check for out-of-range access if vector/array is variable length
	dvalue = compute->data[(size_t)argindex1[ifield] - 1];
}

void Thermo::compute_dump() {

	int idump = dumps[field2index[ifield]];
	Dump* dump = output->dump[idump];

	if (printHeaderFlag) {
		svalue = dump->dumpHeadinfo.c_str();
	}
	else if(output->last_dump[idump] == update->ntimestep) {
		svalue = dump->dumpAbstract.c_str();
	}
	else {
		svalue = "";
	}	
}

/* ----------------------------------------------------------------------
one method for every keyword thermo can output
called by compute() or evaluate_keyword()
compute will have already been called
set ivalue/dvalue/bivalue if value is int/double/int
customize a new keyword by adding a method
------------------------------------------------------------------------- */

void Thermo::compute_step()
{
	ivalue = printHeaderFlag ? 0 : update->ntimestep;
}

void Thermo::compute_neval()
{
	ivalue = printHeaderFlag ? 0 : update->minimize->neval;
}

void Thermo::compute_err()
{
	if (!err) error->all(FLERR, "no minimize cost target!");
	//dvalue = err->scalar;
	dvalue = printHeaderFlag ? 0 : update->minimize->ecurrent;
}

void Thermo::compute_pylog()
{
	if (!err) {
		error->all(FLERR, "no minimize cost target!");
		return;
	}
	svalue = printHeaderFlag ? err->costThermoHead.c_str() : err->costThermoLog.c_str();
}

void Thermo::compute_checklog()
{
	if (!err) {
		error->all(FLERR, "no minimize cost target!");
		return;
	}
	svalue = printHeaderFlag ? err->costThermoHead.c_str() : err->costThermoLog.c_str();
}


