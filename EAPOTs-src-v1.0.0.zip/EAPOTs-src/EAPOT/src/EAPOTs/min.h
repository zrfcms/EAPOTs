#ifdef MINIMIZE_CLASS
#else

#ifdef LIBAPI
LIBAPI(void, setMinDmax, (APITYPE double dmax), (APINAME dmax));
LIBAPI(void, setMinDelta, (APITYPE double delta), (APINAME delta));
#else

#ifndef EAPOT_MIN_H
#define EAPOT_MIN_H

#include <vector>
#include "pointers.h"

namespace EAPOT_NS {

	class Min : protected Pointers {
		friend class Update;
		friend class Thermo;					// accesses compute_pe
		friend class MiniStyle;
		typedef const char* CPCHAR;
	public:
		int logFlag;							// 1 if output header, else 0
		int niter, neval;

		CPCHAR stopstr;
		int stop_condition;		
		std::vector<const char*> styles;

		Min(class EAPOT *eapot);
		virtual ~Min();
		virtual void init();
		int styleCheck(CPCHAR, int, CPCHAR style, int errorFlag);
		void setup(int flag = 1);
		void run(int);

		virtual int iterate(int) = 0;
		virtual void setup_style() = 0;
		virtual void reset_vectors() = 0;
		// possible return values of iterate() method
		enum {
			MAXITER, MAXEVAL, ETOL, FTOL, DOWNHILL, ZEROALPHA, ZEROFORCE,
			ZEROQUAD, TRSMALL, INTERROR, TIMEOUT
		};

		double get_ecurrent() {
			return ecurrent;
		}

	protected:

		double dmax;                // max dist to move any atom in one step
		int linestyle;              // 0 = backtrack, 1 = quadratic, 2 = forcezero
		double alphaFinal;
		double forceDelta;

		double efinal;
		double einitial;
		double ecurrent;
		double eprevious;

		class Compute* cost;		// compute for potential cost function	

		int nvec;                   // total dof for entire problem = length of xvec
		double* xvec;				// variables vector for dof, as 1d vector
		std::vector<double> fvec;	// force vector for dof, as 1d vector
		bool gradientDependFlag;	// Minimize whether the process depends on gradient information

		double fnorm_sqr();
		void force_clear();
		virtual double func(double*);

		double energy_force(int, int);
		int return_final(int, double*);
		CPCHAR stopstrings(int);

		
	};

}

#endif
#endif
#endif