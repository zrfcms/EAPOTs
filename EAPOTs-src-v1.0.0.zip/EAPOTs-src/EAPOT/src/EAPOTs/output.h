#ifndef EAPOT_OUTPUT_H
#define EAPOT_OUTPUT_H

#include "pointers.h"
#include <map>
#include <string>

using namespace std;

namespace EAPOT_NS {

	class Output : protected Pointers {
	public:
		int dumpdirFlag;
		int chkdirFlag;					// have create chkdata path or not
		string EACHKDir;					// path for EACHK.py		e.g. "eachk		../../EACHK"
		string lammpsDir;					// path for lammps system	e.g. "lammps	../../../LAMMPS/"

		int next;							// next timestep for any kind of output
		int next_thermo;					// next timestep for thermo output
		int thermo_every;					// output freq for thermo, 0 if first/last only
		int last_thermo;					// last timestep thermo was output
		char *var_thermo;					// variable name for thermo freq, NULL if every
		int ivar_thermo;					// variable index for thermo frequency
		class Thermo *thermo;				// Thermodynamic computations

		int ndump;							// # of Dumps defined
		int max_dump;						// max size of Dump list
		int next_dump_any;					// next timestep for any Dump
		int *every_dump;					// write freq for each Dump, 0 if var
		int *next_dump;						// next timestep to do each Dump
		int *last_dump;						// last timestep each snapshot was output
		class Dump **dump;					// list of defined Dumps

		FILE* thermolog, * dumplog;
		std::string thermoLogName, dumpLogName;

		typedef Dump *(*DumpCreator)(EAPOT *, const char* id, const char* style, const char* file);
		typedef std::map<std::string, DumpCreator> DumpCreatorMap;
		DumpCreatorMap *dump_map;

		Output(class EAPOT *);
		~Output();
		void init();
		void setup(int memflag = 1);													// initial output before run/min
		void write(int);																// output for current timestep
		void write_dump(int);															// force output of dump snapshots
		int findDump(const char *);														// find a Dump ID

		void memory_usage();															// print out memory usage
		void setTimestep(int step);														// reset next timestep for all output
		void dump_lmp(const char*, int, double*, int*, int*, double*);

	private:
		template <typename T> static Dump *dump_creator(EAPOT *, 
			const char* id, const char* style, const char* file);

		void write_dumplog();
	
	
	public: // API
		void runDumpOnce();
		void delThermoFormat();

		void* addDump(int step, const char* id, const char* style, const char* file);
		void* getDump(const char* id, const char* style);

#define OUTPUTAPI
#define LIBAPI(TYPE, NAME, PTYPE, PNAME) TYPE NAME##PTYPE
#include "extraAPI.h"
#undef  LIBAPI
#undef  OUTPUTAPI
	};

}

#endif