#if !defined(_SET_VECTOR3_)
#define _SET_VECTOR3_

#include <math.h>

#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}

#define load_vector3(u, v, off) { u[0] = v[3*off+0]; u[1] = v[3*off+1]; u[2] = v[3*off+2]; }

#define set_minusvector3(u, v) {u[0] = -v[0];u[1] = -v[1];u[2] = -v[2];}

#define zero_vector3(u) {u[0] = 0;u[1] = 0;u[2] = 0;}

#define minu_vector3(u, v, w){u[0] = v[0] - w[0];u[1] = v[1] - w[1];u[2] = v[2] - w[2];}

#define plus_vector3(u, v, w){u[0] = v[0] + w[0];u[1] = v[1] + w[1];u[2] = v[2] + w[2];}

#define mult_vector3(u, v, r){u[0] = v[0] * r;u[1] = v[1] * r;u[2] = v[2] * r;}

#define divi_vector3(u, v, r){u[0] = v[0] / r;u[1] = v[1] / r;u[2] = v[2] / r;}

#define selfminu_vector3(u, w){u[0] -= w[0];u[1] -= w[1];u[2] -= w[2];}

#define selfplus_vector3(u, w){u[0] += w[0];u[1] += w[1];u[2] += w[2];}

#define selfmult_vector3(u, r){u[0] *= r;u[1] *= r;u[2] *= r;}

#define selfdivi_vector3(u, r){u[0] /= r;u[1] /= r;u[2] /= r;}

#define norm2_vector3(u) (u[0]*u[0] + u[1]*u[1] + u[2]*u[2])

#define norm_vector3(u) (sqrt(u[0]*u[0] + u[1]*u[1] + u[2]*u[2]))

#define normalize_vector3(u) {double r = sqrt(u[0]*u[0] + u[1]*u[1] + u[2]*u[2]);if(r!=0){u[0] /= r;u[1] /= r;u[2] /= r;}}

#define dis2_vector3(u, v) ((u[0]-v[0])*(u[0]-v[0]) + (u[1]-v[1])*(u[1]-v[1]) + (u[2]-v[2])*(u[2]-v[2]))

#define dis_vector3(u, v) (sqrt((u[0]-v[0])*(u[0]-v[0]) + (u[1]-v[1])*(u[1]-v[1]) + (u[2]-v[2])*(u[2]-v[2])))

#define dot_vector3(u, v) (u[0]*v[0] + u[1]*v[1] + u[2]*v[2])

#define cos_vector3(cos, u, v) {cos = u[0]*v[0] + u[1]*v[1] + u[2]*v[2];\
	cos /= (sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2])); \
	cos /= (sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])); }

//scanf("%lf %lf %lf", &a, &b, &c);
//scanf("%lf %lf %lf", &d, &e, &f);
//x = b*f - c*e;//������������ʽ
//y = c*d - a*f;
//z = a*e - b*d;

#define cross_vector3(u, v, w) {u[0]=v[1]*w[2]-v[2]*w[1]; u[1]=v[2]*w[0]-v[0]*w[2]; u[2]=v[0]*w[1]-v[1]*w[0];}

#define eachmult_vector3(u, v, w) {u[0]=v[0]*w[0]; u[1]=v[1]*w[1]; u[2]=v[2]*w[2];}

#define eachdivi_vector3(u, v, w) {u[0]=v[0]/w[0]; u[1]=v[1]/w[1]; u[2]=v[2]/w[2];}

#define selfeachmult_vector3(u, v) {u[0]*=v[0]; u[1]*=v[1]; u[2]*=v[2];}

#define selfeachdivi_vector3(u, v) {u[0]/=v[0]; u[1]/=v[1]; u[2]/=v[2];}

#define set_matrix33(u,v) {\
	u[0][0] = v[0][0]; u[0][1] = v[0][1]; u[0][2] = v[0][2]; \
	u[1][0] = v[1][0]; u[1][1] = v[1][1]; u[1][2] = v[1][2]; \
	u[2][0] = v[2][0]; u[2][1] = v[2][1]; u[2][2] = v[2][2]; }

#define trans_matrix33(u,v) {\
	u[0][0] = v[0][0]; u[0][1] = v[1][0]; u[0][2] = v[2][0]; \
	u[1][0] = v[0][1]; u[1][1] = v[1][1]; u[1][2] = v[2][1]; \
	u[2][0] = v[0][2]; u[2][1] = v[1][2]; u[2][2] = v[2][2]; }

#define dot_matrix33(u,v,w) {										\
	u[0][0] = v[0][0]*w[0][0] + v[0][1]*w[1][0] + v[0][2]*w[2][0];	\
	u[0][1] = v[0][0]*w[0][1] + v[0][1]*w[1][1] + v[0][2]*w[2][1];	\
	u[0][2] = v[0][0]*w[0][2] + v[0][1]*w[1][2] + v[0][2]*w[2][2];	\
	u[1][0] = v[1][0]*w[0][0] + v[1][1]*w[1][0] + v[1][2]*w[2][0];	\
	u[1][1] = v[1][0]*w[0][1] + v[1][1]*w[1][1] + v[1][2]*w[2][1];	\
	u[1][2] = v[1][0]*w[0][2] + v[1][1]*w[1][2] + v[1][2]*w[2][2];	\
	u[2][0] = v[2][0]*w[0][0] + v[2][1]*w[1][0] + v[2][2]*w[2][0];	\
	u[2][1] = v[2][0]*w[0][1] + v[2][1]*w[1][1] + v[2][2]*w[2][1];	\
	u[2][2] = v[2][0]*w[0][2] + v[2][1]*w[1][2] + v[2][2]*w[2][2];	\
}

#define vec_matrix33(u,v,w) {							\
	u[0] = v[0]*w[0][0] + v[1]*w[1][0] + v[2]*w[2][0];	\
	u[1] = v[0]*w[0][1] + v[1]*w[1][1] + v[2]*w[2][1];	\
	u[2] = v[0]*w[0][2] + v[1]*w[1][2] + v[2]*w[2][2];	\
}

#define set_vector3d(u, x, y, z) {u[0] = x;u[1] = y;u[2] = z;}

#define ceil_vector3(u, v)  {u[0] = ceil(v[0]);u[1] = ceil(v[1]);u[2] = ceil(v[2]);}

#define floor_vector3(u, v)  {u[0] = floor(v[0]);u[1] = floor(v[1]);u[2] = floor(v[2]);}

#define max_vector3(m, u)  {m = u[0] > u[1]?u[0]:u[1]; m = m>u[2]?m:u[2];}

#define min_vector3(m, u)  {m = u[0] < u[1]?u[0]:u[1]; m = m<u[2]?m:u[2];}

#define sum_vector3(u)  (u[0]+u[1]+u[2])

#define set_vector6d(u, v1,v2,v3,v4,v5,v6) {u[0] = v1;u[1] = v2;u[2] = v3; u[3] = v4;u[4] = v5;u[5] = v6;}

#define set_vector4(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];u[3] = v[3];}

#define set_vector6(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2]; u[3] = v[3];u[4] = v[4];u[5] = v[5];}

#define zero_vector6(u) {u[0] = 0;u[1] = 0;u[2] = 0;u[3] = 0;u[4] = 0;u[5] = 0;}

#define mult_vector6(u, v, r){u[0] = v[0]*r;u[1] = v[1]*r;u[2] = v[2]*r;u[3] = v[3]*r;u[4] = v[4]*r;u[5] = v[5]*r;}

#define divi_vector6(u, v, r){u[0] = v[0]/r;u[1] = v[1]/r;u[2] = v[2]/r;u[3] = v[3]/r;u[4] = v[4]/r;u[5] = v[5]/r;}

#define selfminu_vector6(u, w){u[0] -= w[0];u[1] -= w[1];u[2] -= w[2];u[3] -= w[3];u[4] -= w[4];u[5] -= w[5];}

#define selfplus_vector6(u, w){u[0] += w[0];u[1] += w[1];u[2] += w[2];u[3] += w[3];u[4] += w[4];u[5] += w[5];}

#define selfmult_vector6(u, r){u[0] *= r;u[1] *= r;u[2] *= r;u[3] *= r;u[4] *= r;u[5] *= r;}

#define selfdivi_vector6(u, r){u[0] /= r;u[1] /= r;u[2] /= r;u[3] /= r;u[4] /= r;u[5] /= r;}

/*20170804 ROT01*/
#define set_tensor(u,v) {u[0][0] = v[0][0];u[0][1] = v[0][1];u[0][2] = v[0][2];  u[1][0] = v[1][0];u[1][1] = v[1][1];u[1][2] = v[1][2];  u[2][0] = v[2][0];u[2][1] = v[2][1];u[2][2] = v[2][2];}
#define zero_tensor(u) {u[0][0] = 0;u[0][1] = 0;u[0][2] = 0;  u[1][0] = 0;u[1][1] = 0;u[1][2] = 0;  u[2][0] = 0;u[2][1] = 0;u[2][2] = 0;}
#define eye_tensor(u)  {u[0][0] = 1;u[0][1] = 0;u[0][2] = 0;  u[1][0] = 0;u[1][1] = 1;u[1][2] = 0;  u[2][0] = 0;u[2][1] = 0;u[2][2] = 1;}

#endif