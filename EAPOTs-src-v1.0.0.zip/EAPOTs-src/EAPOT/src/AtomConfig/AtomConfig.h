#ifndef ATOM_CONFIG_H
#define ATOM_CONFIG_H

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include "string.h"

namespace LoadConfig_NS {

	enum class CellType {
		Oth, Tri3, Tri6
	};

	enum class LoadErrorType {
		NONE, FileOpenError, FileTypeIsNONE, NumericStrEmpty, NumericLackOfParam,
		IllegalFloatParam, IllegalIntegerParam, MapAtomTypeNumber, VolumeIsZero, 
		IllegalConfigDataPtr, IllegalIdxPtr, IllegalTypePtr, IllegalPosPtr, IllegalExtraPtr,

		IllegalNTypeNumber, UnableAtomTypeMap, 
		LMPData_NoEnoughHeadInfo, LMPData_NoAtomsKeyWord, MemoryMallocFailed,
        OUTCARIllegalAtomPosData, IllegalGroundEnergyNumber, OUTCARInsufficInfo,

		IllegalDuplicateParm, 
	};

	enum class LoadFileType {
		NONE, LMP_DATA, LMP_DUMP, VASP
	};

	class AtomConfigData {
	public:
		AtomConfigData(int = 0);
		~AtomConfigData();

		void reset();

		void set(int pnum, int pntype) {
			num = pnum;
			ntype = pntype;
		}

		void set(int* pidx, int* ptype, double* ppos) {
			idx = pidx;
			type = ptype;
			pos = ppos;
		}

	public:
		// core data
		int num, ntype, nextra;

		int* idx, *type;
		double* pos, *extra;

		char keyword[512], info[512];

		double basis[3][3];
		double boxhi[3], boxlo[3];
		double tilt[3];		// xy xz yz

	public:
		// core informaton
		std::vector<int> eleNum;
        std::vector<std::string> eleName;   // must consist with eleNum

		bool lamdaFlag;
		double basis_inv[3][3];
		LoadFileType filetype;

        int ErrLine;
        const char* ErrFile;
        LoadErrorType err;

	public:
		// get informaton
		static int ele2int(const char* ele);
		static const char* int2ele(const int num);
        static double volumn(double* mat);
        static CellType getCellType(double* mat);
		static LoadErrorType get_inverse(double* inv, double* mat);
		static void productN33(double* C, const int N, double* A, double* b);

        double getVolumn();
        void basisTranspose();
		LoadErrorType lamda2x(int n = -1);
		LoadErrorType x2lamda(int n = -1);		
		LoadErrorType reformType(bool saveEleName = false);

	public:
		// modify
		LoadErrorType warpByPBC(int* sum = NULL);
		LoadErrorType Tri6ToTri3(double prec, int nvec = 0, double** vec = NULL);
		LoadErrorType Tri3HalfConditionWarp(double prec);
        LoadErrorType Transform(double mat[3][3], double move[3], int flag);
		LoadErrorType AtomDisplace(double scale, unsigned int seed, int flag);
		LoadErrorType Replicate(int Nx, int Ny, int Nz);

		enum TransFlag {
			TransDomain = 1 << 0,
			TransParticle = 1 << 1,
			TransMatFinal = 1 << 2,
			TransMatDelta = 1 << 3,
			TransMoveFinal = 1 << 4,
		};

		enum DispFlag {
			DispX = 1 << 0,
			DispY = 1 << 1,
			DispZ = 1 << 2,
		};

		bool tiltQualified(double& tilt, double len, double prec);
		bool tiltPrecModify(double& tilt, double len, double prec);
		void tiltTranslateModify(double& tilt, double len);

	public:
		int capacity;
		double mult_ratio;
		void updateBasis();
		void auto_atomidx();
        LoadErrorType AtomTypeMap(const std::vector<size_t> &aim, bool& changeflag);
		LoadErrorType AtomTypeMap(const std::vector<std::string> &aim, bool& changeflag);
		LoadErrorType atomResize(int pnum);
		LoadErrorType atomReserve(int pnum);
		LoadErrorType typeResize(int pntype);
		LoadErrorType typeReserve(int pntype);
		LoadErrorType copy(AtomConfigData*);

	private:
		int memoryFlag;
	};

	class AtomConfigLoad {
	public:
		AtomConfigLoad(AtomConfigData* = NULL);
		~AtomConfigLoad();

		LoadErrorType error;

		static const char* error_msg(LoadErrorType);

		char fmt[16], splitWord[16];

		AtomConfigData* data;
		struct VaspInfo
		{
			double ratio;
			int dynamicFlag;
			int cartesianFlag;
		} vasp;
		
	public:

		enum {
			ReformType = 1 << 0,
		};

		LoadFileType prase_file_type();
		LoadErrorType read_head(const char* path);
		LoadErrorType read_data();
		LoadErrorType write(const char* path = NULL, int flag = 0);

		LoadErrorType read_head_LMP_DATA();
		LoadErrorType read_data_LMP_DATA();
		LoadErrorType write_LMP_DATA(int flag = 0);

		LoadErrorType read_head_LMP_DUMP();
		LoadErrorType read_data_LMP_DUMP();
		LoadErrorType write_LMP_DUMP(int flag = 0);

		LoadErrorType read_head_VASP();
		LoadErrorType read_data_VASP();
		LoadErrorType write_VASP(int flag = 0);

	public:	

		static inline bool isMember(int val, int n, int* data) {	
			for (int i = 0; i < n; i++) {
				if (val == data[i]) return true;
			}
			return false;			
		}

		static LoadErrorType inumeric(int&, const char* str);
		static LoadErrorType numeric(double&, const char* str);

		static LoadErrorType inumerics(char* str, int n, int* data, bool chkFlag = true, const char* = " \t\n\r\f");
		static LoadErrorType numerics(char* str, int n, double* data, bool chkFlag = true, const char* = " \t\n\r\f");

        static LoadErrorType inumerics(std::string str, int n, int* data, bool chkFlag = true, const char* = " \t\n\r\f");
        static LoadErrorType numerics(std::string str, int n, double* data, bool chkFlag = true, const char* = " \t\n\r\f");

		static int count_words(const char* line, const char* = " \t\n\r\f");

		static LoadErrorType open(FILE* &pf, char const* _FileName, char const* _Mode);

		static void split(std::vector<std::string>&, const std::string&, const std::string&);

		static void split(std::vector<std::string>&, const char*, const char* = " \t\n\r\f");

		static void split(std::vector<std::string>&, char*, const char* = " \t\n\r\f");

		typedef std::string str;

		static inline bool find(size_t& res, str& buff, const str& Right, const size_t Off = 0, bool moveFlag = false) {
			
			res = buff.find(Right, Off);
			if (res == str::npos) return true;
			if (moveFlag) res += Right.size();
			return false;
		}

		static inline bool rfind(size_t& res, str& buff, const str& Right, const size_t Off = str::npos, bool moveFlag = false) {

			res = buff.rfind(Right, Off);
			if (res == str::npos) return true;
			if (moveFlag) res += Right.size();
			return false;
		}


		static inline bool find(size_t& res, str& buff, const char* Right, const size_t Off = 0, bool moveFlag = false) {
			
			res = buff.find(Right, Off);
			if (res == str::npos) return false;
			if (moveFlag) res += strlen(Right);
			return false;
		}

		static inline bool rfind(size_t& res, str& buff, const char* Right, const size_t Off = str::npos, bool moveFlag = false) {

			res = buff.rfind(Right, Off);
			if (res == str::npos) return true;
			if (moveFlag) res += strlen(Right);
			return false;
		}


		static inline bool find(size_t& res, str& buff, const char Right, const size_t Off = 0, bool moveFlag = false) {
			
			res = buff.find(Right, Off);
			if (res == str::npos) return false;
			if (moveFlag) res++;
			return false;
		}

		static inline bool rfind(size_t& res, str& buff, const char Right, const size_t Off = str::npos, bool moveFlag = false) {

			res = buff.rfind(Right, Off);
			if (res == str::npos) return true;
			if (moveFlag) res++;
			return false;
		}


		static inline bool find_first_of(size_t& res, str& buff, const char* const Ptr, const size_t Off = 0) {

			res = buff.find_first_of(Ptr, Off);
			if (res == str::npos) return true;
			return false;
		}

		static inline bool find_first_not_of(size_t& res, str& buff, const char* const Ptr, const size_t Off = 0) {

			res = buff.find_first_not_of(Ptr, Off);
			if (res == str::npos) return true;
			return false;
		}

		static str& replace_all(str& mstr, const str& old_value, const str& new_value);

		static str& replace_all_distinct(str& mstr, const str& old_value, const  str& new_value);

	private:

		FILE* fp;

		inline void reserve(size_t n) {

			m_capacity *= 2;

			if (n > m_capacity) {
				m_capacity = n;
			}

			void* newdata = realloc(s, m_capacity * sizeof(char));
			if (newdata) { s = (char*)newdata; }
		}		

	public:
		char* s;
		size_t m_capacity, m_size;
	};

	class EString {

	public:
		EString(int size = 32) {
			m_capacity = size;
			s = (char*)malloc(m_capacity * sizeof(char));
		}
		~EString() {
			free(s);
		}

		bool reserve(size_t n = 0) {

			if (n < m_capacity) return true;

			m_capacity *= 2;

			if (n > m_capacity) {
				m_capacity = n;
			}

			void* newdata = realloc(s, m_capacity * sizeof(char));

			if (newdata) { s = (char*)newdata; }
			else { return false; }

			return true;
		}

		bool resize(size_t n) {

            if (n >= m_capacity) {
				return false;
			}
			s[n] = '\0';

			return true;
		}

        bool reserve(int n) {
            return reserve(static_cast<size_t>(n));
        }

		size_t capacity() { return	m_capacity; };
		const char* c_str() { return s; };
		const char* data() { return s; };

		char* s;
	private:
		size_t m_capacity;
	};

}

#endif
