#include "AbinitoMDTool.h"
#include "string.h"
using namespace LoadConfig_NS;
using namespace std;

#define Str AtomConfigLoad 

#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}

#define set_vector3d(u, x, y, z) {u[0] = x;u[1] = y;u[2] = z;}

#define set_vector6d(u, v1,v2,v3,v4,v5,v6) {u[0] = v1;u[1] = v2;u[2] = v3; u[3] = v4;u[4] = v5;u[5] = v6;}

#define set_vector6(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2]; u[3] = v[3];u[4] = v[4];u[5] = v[5];}

#define zero_vector6(u) {u[0] = 0;u[1] = 0;u[2] = 0;u[3] = 0;u[4] = 0;u[5] = 0;}

MDFitData::MDFitData()
{
	num = 0;
	AtomForceTarget = NULL;
	AtomForceWeight = NULL;
    Energy_Reference = "none";
    Box_Relax_Mode = "none";
    Energy_Scale_Method = "E";

	// 1.Relax and Reference Settings

    Relax_AtomX = false;
    Relax_AtomY = false;
    Relax_AtomZ = false;
    Reload = false;
    Ref_Drive = false;
    Use_MaxForce = false;

    ActiveLatticeGroup = true;
    ActiveEnergyGroup = true;
    ActiveStressGroup = true;
    ActiveForceGroup = true;
    ActiveMoreGroup = true;

	// 2.Energy, Force, Stress and Virial Fitting Target

	Global_Weight = 1.0;
	zero_vector6(Domain_Target);
	zero_vector6(Domain_Weight);
	zero_vector6(Stress_Global_Target);
	zero_vector6(Stress_Global_Weight);

    Energy_Target = 0.0;
    Energy_Weight = 1.0;
	Energy_Cost_Target = 0.0;
	Energy_Cost_Weight = 0.0;
	Energy_Cost_Method = "abs";
	Force_Cost_Target = 0.0;
	Force_Cost_Weight = 0.0;
	set_vector3d(Force_Cost_Method, "abs", "abs", "abs");
	Virial_Cost_Target = 0.0;
	Virial_Cost_Weight = 0.0;
	set_vector6d(Virial_Cost_Method, "abs", "abs", "abs", "abs", "abs", "abs");

	// 3.Elastic Fitting Target
	for (int i = 0; i < 7; i++) {
		zero_vector6(Elastic_Target[i]);
		zero_vector6(Elastic_Weight[i]);
	}

    paramPtr.push_back(&Relax_AtomX);
    paramPtr.push_back(&Relax_AtomY);
    paramPtr.push_back(&Relax_AtomZ);
    paramPtr.push_back(&Reload);
    paramPtr.push_back(&Ref_Drive);
    paramPtr.push_back(&Use_MaxForce);

    paramPtr.push_back(&ActiveLatticeGroup);
    paramPtr.push_back(&ActiveEnergyGroup);
    paramPtr.push_back(&ActiveStressGroup);
    paramPtr.push_back(&ActiveForceGroup);
    paramPtr.push_back(&ActiveMoreGroup);

    paramPtr.push_back(&Global_Weight);
    paramPtr.push_back(&Structure_Name);
    paramPtr.push_back(&Structure_Information);
    paramPtr.push_back(&Structure_Atom_Configuration);
    paramPtr.push_back(&Energy_Reference);
    paramPtr.push_back(&Box_Relax_Mode);
    paramPtr.push_back(&Energy_Scale_Method);

    paramPtr.push_back(Domain_Target);
    paramPtr.push_back(Domain_Weight);
    paramPtr.push_back(Stress_Global_Target);
    paramPtr.push_back(Stress_Global_Weight);

    paramPtr.push_back(&Energy_Target);
    paramPtr.push_back(&Energy_Weight);
    paramPtr.push_back(&Energy_Cost_Target);
    paramPtr.push_back(&Energy_Cost_Weight);
    paramPtr.push_back(&Energy_Cost_Method);
    paramPtr.push_back(&Force_Cost_Target);
    paramPtr.push_back(&Force_Cost_Weight);
    paramPtr.push_back(&Force_Cost_Method[0]);
    paramPtr.push_back(&Force_Cost_Method[1]);
    paramPtr.push_back(&Force_Cost_Method[2]);
    paramPtr.push_back(&Virial_Cost_Target);
    paramPtr.push_back(&Virial_Cost_Weight);
    paramPtr.push_back( Virial_Cost_Method);

    paramPtr.push_back(Elastic_Target);
    paramPtr.push_back(Elastic_Weight);

    vector<void*> paramPtr;

}

vector<const char*> MDFitData::name = {
    "Relax_AtomX",
    "Relax_AtomY",
    "Relax_AtomZ",
    "Reload",
    "Ref_Drive",
    "Use_MaxForce",

    "ActiveLatticeGroup",
    "ActiveEnergyGroup",
    "ActiveStressGroup",
    "ActiveForceGroup",
    "ActiveMoreGroup",

    "Global_Weight",
    "Structure_Name",
    "Structure_Information",
    "Structure_Atom_Configuration",
    "Energy_Reference",
    "Box_Relax_Mode",
    "Energy_Scale_Method",

    "Domain_Target",
    "Domain_Weight",
    "Stress_Global_Target",
    "Stress_Global_Weight",

    "Energy_Target",
    "Energy_Weight",
    "Energy_Cost_Target",
    "Energy_Cost_Weight",
    "Energy_Cost_Method",
    "Force_Cost_Target",
    "Force_Cost_Weight",
    "Force_Cost_Method[0]",
    "Force_Cost_Method[1]",
    "Force_Cost_Method[2]",
    "Virial_Cost_Target",
    "Virial_Cost_Weight",
    "Virial_Cost_Method",

    "Elastic_Target",
    "Elastic_Weight",
};

int MDFitData::getParamIdx(const char* param){
    int num = static_cast<int>(name.size());
    for (int i = 0; i < num; i++){
        if (strcmp(param, name[i]) == 0){
            return i;
        }
    }
    return -1;
}

MDFitData::~MDFitData() {
	free(AtomForceTarget);
	free(AtomForceWeight);
}

// Energy Calculation Items, can be: none/either/global/atom
const char* MDFitData::get_Energy_Calculation() {
	bool atom = Energy_Cost_Weight != 0.0;
    bool global = Energy_Weight != 0.0;
	
	if (atom && global) {
		return "either";
	}
	else if (!atom && global) {
		return "global";
	}
	else if (atom && !global) {
		return "atom";
	}
	else if (!atom && !global) {
		return "none";
	}
	else {
		return "none";
	}
}

// Force Calculation Items, can be: none/atom
const char* MDFitData::get_Force_Calculation() {
	if (Force_Cost_Weight == 0) {
		return "none";
	}
	else {
		return "atom";
	}
}

// Stress Calculation Items, can be: none/either/global/atom
const char* MDFitData::get_Stress_Calculation() {
	bool atom = Virial_Cost_Weight != 0.0;
    bool global = Box_Relax_Mode != "none";

	for (int i = 0; i < 6; i++) {
		if (Stress_Global_Weight[i] != 0) {
			global = true;
			break;
		}
	}

	if (atom && global) {
		return "either";
	}
	else if (!atom && global) {
		return "global";
	}
	else if (atom && !global) {
		return "atom";
	}
	else if (!atom && !global) {
		return "none";
	}
	else {
		return "none";
	}
}

const char* MDFitData::get_Elatic_Calculation() {
	for (int i = 0; i < NEla; i++) {
		for (int j = 0; j < NDof; j++) {
			if (Elastic_Weight[i][j] != 0) {
				return "global";
			}
		}
	}
	return "none";
}

LoadErrorType MDFitData::resize(int n) {

	num = n;
	if (AtomForceTarget) free(AtomForceTarget);
	if (AtomForceWeight) free(AtomForceWeight);
	size_t size = (size_t)n * 3 * sizeof(double);
	AtomForceTarget = (double*)malloc(size);
	AtomForceWeight = (double*)malloc(size);

	if (AtomForceTarget == NULL || AtomForceWeight == NULL) {
		return LoadErrorType::MemoryMallocFailed;
	}
	memset(AtomForceTarget, 0, size);
	memset(AtomForceWeight, 0, size);
	return LoadErrorType::NONE;
}


#define IfErrorCustom(TYPE) if (err != LoadErrorType::NONE) {     \
    ErrFile = __FILE__;                                     \
    ErrLine = __LINE__;                                     \
    return LoadErrorType::TYPE;                             \
}

#define IfErrorReturn if (err != LoadErrorType::NONE) {     \
    ErrFile = __FILE__;                                     \
    ErrLine = __LINE__;                                     \
    return LoadErrorType::OUTCARInsufficInfo;               \
}

#define IfFailedReturn(Cond) if (Cond) {                    \
    ErrFile = __FILE__;                                     \
    ErrLine = __LINE__;                                     \
    return LoadErrorType::OUTCARInsufficInfo;               \
}

LoadVaspData::LoadVaspData()
	: target()
	, config(1) {
	CONTCAR = "";
    OUTCAR = "";

    ErrFile = "";
    ErrLine = -1;
}

LoadVaspData::~LoadVaspData() {
}



LoadErrorType LoadVaspData::parse(double prec, const char* splitWord) {

	// 1. load Atom CONTCAR
	AtomConfigLoad atomLoad(&config);
	err = atomLoad.read_head(CONTCAR.c_str()); IfErrorReturn;
	err = atomLoad.read_data(); IfErrorReturn;

	// 2. load OUTCAR
	err = target.resize(config.num); IfErrorReturn;
    if (!OUTCAR.empty()) {
        err = parse_OUTCAR(OUTCAR, splitWord); IfErrorReturn;
    }


	// 3. Convert Vasp CONTCAR To LAMMPS data file
	err = config.Tri6ToTri3(prec, 1, &target.AtomForceTarget); IfErrorReturn;
	err = config.Tri3HalfConditionWarp(prec); IfErrorReturn;

	// 4.Update other parameters
	set_vector6d(target.Domain_Target, 
		config.basis[0][0], config.basis[1][1], config.basis[2][2],
		config.basis[1][0], config.basis[2][0], config.basis[2][1]);

	return LoadErrorType::NONE;
}

LoadErrorType LoadVaspData::updateType(vector<string> Type) {

	// 1. safe check
	if (Type.size() < (size_t)config.ntype) {
		return LoadErrorType::UnableAtomTypeMap;
	}
	Type.resize(config.ntype);

	// 2. map if necessary
	bool changeflag = false;
    err = config.AtomTypeMap(Type, changeflag); IfErrorCustom(UnableAtomTypeMap);
	if (changeflag) {
        err = config.reformType(); IfErrorCustom(UnableAtomTypeMap);
	}

	return LoadErrorType::NONE;
}

LoadErrorType LoadVaspData::updateEnergy(vector<double> Energy, double* res, bool norm) {

	if (Energy.size() < (size_t)config.ntype) {
		return LoadErrorType::IllegalGroundEnergyNumber;
	}
	Energy.resize(config.ntype);

	// evaluate final Energy
	int ntype = static_cast<int>(config.eleNum.size());
    double eng = target.initEnergy;
	for (int itype = 0; itype < ntype; itype++) {
        eng -= Energy[itype] * config.eleNum[itype];
	}

	if (norm) {
		eng /= config.num;
	}

    if (res) {
        *res = eng;
    } else {
        target.Energy_Target = eng;
	}

	return LoadErrorType::NONE;
}

LoadErrorType LoadVaspData::exportData(const char* dir, bool dump_lammpsFlag){

	FILE* pf;
	string str;
	AtomConfigLoad write(&config);
	config.filetype = LoadFileType::LMP_DATA;

	write.write(NULL);
	lmp.assign(write.s, write.m_size);

    if (dump_lammpsFlag && customSavePath == "") {
		str = dir + ("/" + target.Structure_Name) + ".lmp";
		
		err = AtomConfigLoad::open(pf, str.c_str(), "w"); 
		IfErrorReturn;
		fwrite(lmp.c_str(), sizeof(char), lmp.size(), pf);
		fclose(pf);
	}

	err = exportToReflog(buf, &target); IfErrorReturn;
	if(buf.s) ref.assign(buf.s);

    if (dump_lammpsFlag && customSavePath == "") {
		str = dir + ("/" + target.Structure_Name) + ".log";

		err = AtomConfigLoad::open(pf, str.c_str(), "w"); 
		IfErrorReturn;
		fwrite(ref.c_str(), sizeof(char), ref.size(), pf);
		fclose(pf);
	}

    string name;
    if(customSavePath == "") {
        name = dir + ("/" + target.Structure_Name) + ".json";
    }
    else{
        name = customSavePath;
    }
    exportToJson(name.c_str());
	return LoadErrorType::NONE;
}




LoadErrorType LoadVaspData::parse_OUTCAR(string file, const char* splitWord) {

    FILE* fp;
    err = AtomConfigLoad::open(fp, file.c_str(), "r");
    IfErrorReturn;

    fseek(fp, 0, SEEK_END);
    size_t fsize = static_cast<size_t>(ftell(fp));
    rewind(fp);

    string readbuff;
    readbuff.resize(fsize + 1);
    fread(&readbuff[0], sizeof(char), fsize, fp);
    fclose(fp);


	string val;
	size_t begin, end;

	/****************************************** 1.Energy *********************************************/
	//   free  energy   TOTEN  =        -8.81637577 eV
	// unit for Energy in vasp is eV, equal to EAPOT, no need to convert

    IfFailedReturn(Str::rfind(begin, readbuff, "free  energy   TOTEN  =", string::npos, true));

    IfFailedReturn(Str::find_first_not_of(begin, readbuff, splitWord, begin));

    IfFailedReturn(Str::find_first_of(end, readbuff, splitWord, begin));

	val = readbuff.substr(begin, end - begin);
    err = Str::numeric(target.initEnergy, val.c_str()); IfErrorReturn;
    target.Energy_Target = target.initEnergy;

	/****************************************** 2.Stress *********************************************/
	/*
		FORCE on cell =-STRESS in cart. coord.  units (eV):
		Direction    XX          YY          ZZ          XY          YZ          ZX
		--------------------------------------------------------------------------------------
		Total       0.04390     0.04390     0.04390     0.00000     0.00000    -0.00000
		in kB       3.08048     3.08048     3.08048     0.00000     0.00000    -0.00000
		external pressure =        3.08 kB  Pullay stress =        0.00 kB

		unit for stress in EAPOT is bar
		unit for stress in vasp is kBar, so need to convert
	*/

    IfFailedReturn(Str::rfind(begin, readbuff, "FORCE on cell =-STRESS in cart"));

    IfFailedReturn(Str::find(begin, readbuff, "in kB", begin, true));

    IfFailedReturn(Str::find(end, readbuff, '\n', begin));

	val = readbuff.substr(begin, end - begin);
    err = AtomConfigLoad::numerics(val, 6, target.Stress_Global_Target);
    IfFailedReturn(err != LoadErrorType::NONE);

	for (int i = 0; i < 6; i++) {
		target.Stress_Global_Target[i] *= 1000;
	}

	/****************************************** 3.Force  *********************************************/
	/*
	POSITION                                       TOTAL-FORCE (eV/Angst)
	-----------------------------------------------------------------------------------
		  0.00000      0.00000      0.00000         0.000000     -0.000000      0.000000
		  1.41843      1.41843      1.41843        -0.000000      0.000000      0.000000
	-----------------------------------------------------------------------------------
		total drift:                                0.000000      0.000000      0.000000

	// unit for Force in vasp is eV/Angst, equal to EAPOT, no need to convert
	*/

    IfFailedReturn(Str::rfind(begin, readbuff, "POSITION"));
    IfFailedReturn(Str::find(end, readbuff, '\n', begin, true));

	for (int i = 0; i < config.num; i++) {

		// Extract keywords
        IfFailedReturn(Str::find(begin, readbuff, '\n', end, true));
        IfFailedReturn(Str::find(end, readbuff, '\n', begin));
		val = readbuff.substr(begin, end - begin);

		// ship front three words
        char* str = &val[0];
        char* next = strtok(str, splitWord);
		if (next == NULL) {
            return LoadErrorType::OUTCARIllegalAtomPosData;
		}

		for (int m = 1; m < 3; m++) {
			next = strtok(NULL, splitWord);
			if (next == NULL) {
                return LoadErrorType::OUTCARIllegalAtomPosData;
			}
		}

		// read force
		for (int m = 0; m < 3; m++) {
			next = strtok(NULL, splitWord);
			if (next == NULL) {
                return LoadErrorType::OUTCARIllegalAtomPosData;
			}
			target.AtomForceTarget[i * 3 + m] = atof(next);
		}
	}
    return LoadErrorType::NONE;
}

const char* LoadVaspData::fmt = "%24.17g";

#define SafePrint buf.reserve(s + safe); s += sprintf

#define evalString(Key)																				\
	buf.reserve(s + safe); s += sprintf(&buf.s[s], "  \"" #Key "\": \"%s\",\n", target.Key.c_str());

#define evalStringEx(Key, Value)																	\
	buf.reserve(s + safe); s += sprintf(&buf.s[s], "  \"" #Key "\": \"%s\",\n", target.Value);

#define evalBool(Key)	if(target.Key){                                                             \
		buf.reserve(s + safe); s += sprintf(&buf.s[s], "  \"" #Key "\": true,\n");					\
	}																								\
	else {																							\
		buf.reserve(s + safe); s += sprintf(&buf.s[s], "  \"" #Key "\": false,\n");					\
	}

#define evalDouble(Key)												\
	buf.reserve(s + safe); s += sprintf(&buf.s[s], "  \"" #Key "\": %.17g,\n", target.Key);


#define evalArray(Key, N)	{																		\
	buf.reserve(s + safe); s += sprintf(&buf.s[s], "  \"" #Key "\": [");							\
	for (int i = 0; i < N; i++) {																	\
		buf.reserve(s + safe); s += sprintf(&buf.s[s], "%.17g, ", target.Key[i]);					\
	}																								\
	s -= 2;																							\
	buf.reserve(s + safe); s += sprintf(&buf.s[s], "], \n");										\
}

#define evalMatrix(Key, M, N)	{																	\
	buf.reserve(s + safe); s += sprintf(&buf.s[s], "  \"" #Key "\": [");							\
	for (int i = 0; i < M; i++) {																	\
		for (int j = 0; j < N; j++) {																\
			buf.reserve(s + safe); s += sprintf(&buf.s[s], "%.17g, ", target.Key[i][j]);			\
		}																							\
	}																								\
	s -= 2;																							\
	buf.reserve(s + safe); s += sprintf(&buf.s[s], "], \n");										\
}



LoadErrorType LoadVaspData::exportToJson(const char* path) {
	FILE* pf;
	LoadErrorType err;
    int s = 0, safe = 256;

    err = AtomConfigLoad::open(pf, path, "w");
	if (err != LoadErrorType::NONE) { return err; }

	buf.reserve(s + safe); s += sprintf(&buf.s[s], "{\n");   

	// 1.Relax and Reference Settings
	evalDouble(Global_Weight);
	evalString(Structure_Name);

    evalString(Box_Relax_Mode);
    evalString(Energy_Scale_Method);
    evalString(Energy_Reference);

    evalBool(Relax_AtomX);
    evalBool(Relax_AtomY);
    evalBool(Relax_AtomZ);
    evalBool(Reload);
    evalBool(Ref_Drive);
    evalBool(Use_MaxForce);

    evalBool(ActiveLatticeGroup);
    evalBool(ActiveEnergyGroup);
    evalBool(ActiveStressGroup);
    evalBool(ActiveForceGroup);
    evalBool(ActiveMoreGroup);

	// 2.Domain and Stress Target
	evalArray(Domain_Target, 6);
	evalArray(Domain_Weight, 6);
	evalArray(Stress_Global_Target, 6);
	evalArray(Stress_Global_Weight, 6);

	// 3.Energy, Force, and Virial Fitting Target	
	evalStringEx(Energy_Calculation, get_Energy_Calculation());
    evalDouble(Energy_Target);
    evalDouble(Energy_Weight);
	evalDouble(Energy_Cost_Target);
	evalDouble(Energy_Cost_Weight);

	evalStringEx(Force_Calculation, get_Force_Calculation());
	evalDouble(Force_Cost_Target);
	evalDouble(Force_Cost_Weight);

	evalStringEx(Virial_Calculation, get_Stress_Calculation());
	evalDouble(Virial_Cost_Target);
	evalDouble(Virial_Cost_Weight);

	// 4.Elastic Fitting Target
	evalMatrix(Elastic_Target, 7, 6);
	evalMatrix(Elastic_Weight, 7, 6);

	// 5.Save others
    fwrite(buf.s, sizeof(char), static_cast<size_t>(s), pf);

    string lmpJson = lmp;
    Str::replace_all_distinct(lmpJson, "\n", "\\n");
	fprintf(pf, "  \"Structure_Information\": \"");
    fwrite(lmpJson.c_str(), sizeof(char), lmpJson.size(), pf);
	fprintf(pf, "\",\n");

    string refJson = ref;
    Str::replace_all_distinct(refJson, "\n", "\\n");
	fprintf(pf, "  \"Structure_Atom_Configuration\": \"");
    fwrite(refJson.c_str(), sizeof(char), refJson.size(), pf);
	fprintf(pf, "\"\n");

	fprintf(pf, "}");
	fclose(pf);
	return LoadErrorType::NONE;
}

LoadErrorType LoadVaspData::exportToReflog(EString &buf, MDFitData *tar) {
	char format[256];
	size_t s = 0, safe = 256;

	buf.reserve(s + safe); 
	s += sprintf(&buf.s[s], 
		"# id force cost_force %s %s %s\n",
		tar->Force_Cost_Method[0].c_str(), 
		tar->Force_Cost_Method[1].c_str(), 
		tar->Force_Cost_Method[2].c_str());

	sprintf(format, "%%-4d %s %s %s %s %s %s\n", fmt, fmt, fmt, fmt, fmt, fmt);

	double *t, *w;
	for (int i = 0; i < tar->num; i++) {
		buf.reserve(s + safe);
		t = &tar->AtomForceTarget[i * 3];
		w = &tar->AtomForceWeight[i * 3];
		s += sprintf(&buf.s[s], format, i + 1, w[0], w[1], w[2], t[0], t[1], t[2]);
	}

	buf.resize(s);
	return LoadErrorType::NONE;
}
