#include "AtomConfig.h"
#include <string.h>
#include <ctype.h>

using namespace LoadConfig_NS;
#define SafePrint if(k + safe >= m_capacity) reserve(k + safe); k += sprintf


LoadErrorType AtomConfigLoad::read_head_LMP_DUMP() {
	return LoadErrorType::NONE;
};

LoadErrorType AtomConfigLoad::read_data_LMP_DUMP() {
	return LoadErrorType::NONE;
};

LoadErrorType AtomConfigLoad::write_LMP_DUMP(int) {
	return LoadErrorType::NONE;
}

