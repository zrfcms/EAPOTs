#include "AtomConfig.h"
#include <string.h>
#include <ctype.h>
#include <math.h>


#include <algorithm>

using namespace LoadConfig_NS;
using namespace std;

#define load_vector3(u, v, off) { u[0] = v[3*off+0]; u[1] = v[3*off+1]; u[2] = v[3*off+2]; }

#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}

#define set_vector3d(u, x, y, z) {u[0] = x;u[1] = y;u[2] = z;}

#define zero_vector3(u) {u[0] = 0;u[1] = 0;u[2] = 0;}

#define minu_vector3(u, v, w){u[0] = v[0] - w[0];u[1] = v[1] - w[1];u[2] = v[2] - w[2];}

#define plus_vector3(u, v, w){u[0] = v[0] + w[0];u[1] = v[1] + w[1];u[2] = v[2] + w[2];}

#define mult_vector3(u, v, r){u[0] = v[0] * r;u[1] = v[1] * r;u[2] = v[2] * r;}

#define divi_vector3(u, v, r){u[0] = v[0] / r;u[1] = v[1] / r;u[2] = v[2] / r;}

#define selfminu_vector3(u, w){u[0] -= w[0];u[1] -= w[1];u[2] -= w[2];}

#define selfplus_vector3(u, w){u[0] += w[0];u[1] += w[1];u[2] += w[2];}

#define selfmult_vector3(u, r){u[0] *= r;u[1] *= r;u[2] *= r;}

#define selfdivi_vector3(u, r){u[0] /= r;u[1] /= r;u[2] /= r;}

#define norm2_vector3(u) (u[0]*u[0] + u[1]*u[1] + u[2]*u[2])

#define norm_vector3(u) (sqrt(u[0]*u[0] + u[1]*u[1] + u[2]*u[2]))

#define dot_vector3(u, v) (u[0]*v[0] + u[1]*v[1] + u[2]*v[2])

#define set_matrix33(u,v) {\
	u[0][0] = v[0][0]; u[0][1] = v[0][1]; u[0][2] = v[0][2]; \
	u[1][0] = v[1][0]; u[1][1] = v[1][1]; u[1][2] = v[1][2]; \
	u[2][0] = v[2][0]; u[2][1] = v[2][1]; u[2][2] = v[2][2]; }

#define dot_matrix33(u,v,w) {										\
	u[0][0] = v[0][0]*w[0][0] + v[0][1]*w[1][0] + v[0][2]*w[2][0];	\
	u[0][1] = v[0][0]*w[0][1] + v[0][1]*w[1][1] + v[0][2]*w[2][1];	\
	u[0][2] = v[0][0]*w[0][2] + v[0][1]*w[1][2] + v[0][2]*w[2][2];	\
	u[1][0] = v[1][0]*w[0][0] + v[1][1]*w[1][0] + v[1][2]*w[2][0];	\
	u[1][1] = v[1][0]*w[0][1] + v[1][1]*w[1][1] + v[1][2]*w[2][1];	\
	u[1][2] = v[1][0]*w[0][2] + v[1][1]*w[1][2] + v[1][2]*w[2][2];	\
	u[2][0] = v[2][0]*w[0][0] + v[2][1]*w[1][0] + v[2][2]*w[2][0];	\
	u[2][1] = v[2][0]*w[0][1] + v[2][1]*w[1][1] + v[2][2]*w[2][1];	\
	u[2][2] = v[2][0]*w[0][2] + v[2][1]*w[1][2] + v[2][2]*w[2][2];	\
}

#define vec_matrix33(u,v,w) {							\
	u[0] = v[0]*w[0][0] + v[1]*w[1][0] + v[2]*w[2][0];	\
	u[1] = v[0]*w[0][1] + v[1]*w[1][1] + v[2]*w[2][1];	\
	u[2] = v[0]*w[0][2] + v[1]*w[1][2] + v[2]*w[2][2];	\
}

#define set_vector6d(u, v1,v2,v3,v4,v5,v6) {u[0] = v1;u[1] = v2;u[2] = v3; u[3] = v4;u[4] = v5;u[5] = v6;}

#define set_vector4(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];u[3] = v[3];}

#define set_vector6(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2]; u[3] = v[3];u[4] = v[4];u[5] = v[5];}

#define zero_vector6(u) {u[0] = 0;u[1] = 0;u[2] = 0;u[3] = 0;u[4] = 0;u[5] = 0;}


#ifndef SIZE_T
#define INT(A) static_cast<int>(A)
#define SIZE_T(A) static_cast<size_t>(A)
#define DOUBLE(A) static_cast<double>(A)
#endif



#define IfErrorReturn if (err != LoadErrorType::NONE) {     \
    ErrFile = __FILE__;                                     \
    ErrLine = __LINE__;                                     \
    return LoadErrorType::OUTCARInsufficInfo;               \
}

AtomConfigData::AtomConfigData(int pmemoryFlag)
 : keyword(""), info("")
{
	memoryFlag = pmemoryFlag;

	type = NULL;
	idx = NULL;
	pos = NULL;
	extra = NULL;

	num = 0;
	ntype = 0;
	nextra = 0;

	capacity = 0;
	mult_ratio = 1.0;

	if (memoryFlag) {
		capacity = 16;
		idx = (int*)malloc(sizeof(int) * capacity);
		type = (int*)malloc(sizeof(int) * capacity);
		pos = (double*)malloc(sizeof(double) * capacity * 3);
	}

	reset();
}

void AtomConfigData::reset() {

	lamdaFlag = 0;

	zero_vector3(basis[0]);
	zero_vector3(basis[1]);
	zero_vector3(basis[2]);
	zero_vector3(boxhi);
	zero_vector3(boxlo);
	zero_vector3(tilt);

	filetype = LoadFileType::NONE;
}


AtomConfigData::~AtomConfigData() {

	if (!memoryFlag) { return; }
		
	if (idx) free(idx);
	if (type) free(type);
	if (pos) free(pos);
}

LoadErrorType AtomConfigData::atomReserve(int) {
	if (!memoryFlag) { return LoadErrorType::NONE; }
	if (num * mult_ratio <= capacity) { return LoadErrorType::NONE; }

	capacity = static_cast<int>(num * mult_ratio + 1);
	
	int* tint;
	double* tdbl;
	
	if (idx) {
		tint = (int*)realloc(idx, sizeof(int) * capacity);
		if (tint == NULL) return LoadErrorType::MemoryMallocFailed;
		idx = tint;
	}
	if (type) {
		tint = (int*)realloc(type, sizeof(int) * capacity);
		if (tint == NULL) return LoadErrorType::MemoryMallocFailed;
		type = tint;
	}
	if (pos) {
		tdbl = (double*)realloc(pos, sizeof(double) * capacity * 3);
		if (tdbl == NULL) return LoadErrorType::MemoryMallocFailed;
		pos = tdbl;
	}
	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigData::atomResize(int pnum) {
	num = pnum;
	return atomReserve(pnum);
};

LoadErrorType AtomConfigData::typeReserve(int pntype) {

	int osize = static_cast<int>(eleName.size());

	eleNum.resize(pntype);
	eleName.resize(pntype);

	for (int i = osize; i < pntype; i++) {
		eleName[i] = int2ele(i + 1);
	}

	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigData::typeResize(int pntype) {
	ntype = pntype;
	return typeReserve(ntype);
};

LoadErrorType AtomConfigData::copy(AtomConfigData* ref) {

    if (ref == NULL) {
		return LoadErrorType::IllegalConfigDataPtr;
	}

	err = atomResize(ref->num); IfErrorReturn;
	err = typeResize(ref->ntype); IfErrorReturn;

	memcpy(idx, ref->idx, sizeof(int) * num);
	memcpy(type, ref->type, sizeof(int) * num);
	memcpy(pos, ref->pos, sizeof(double) * num * 3);

	set_vector3(basis[0], ref->basis[0]);
	set_vector3(basis[1], ref->basis[1]);
	set_vector3(basis[2], ref->basis[2]);

	set_vector3(boxhi, ref->boxhi);
	set_vector3(boxlo, ref->boxlo);
	set_vector3(tilt, ref->tilt);

	set_vector3(basis_inv[0], ref->basis_inv[0]);
	set_vector3(basis_inv[1], ref->basis_inv[1]);
	set_vector3(basis_inv[2], ref->basis_inv[2]);

	eleNum = ref->eleNum;
	eleName = ref->eleName;

	return LoadErrorType::NONE;
}

void AtomConfigData::auto_atomidx() {

	for (int i = 0; i < num; i++) {
		idx[i] = i + 1;
	}
}



bool needToMap(const vector<size_t> &aim, bool& changeflag){
    for (size_t i = 0; i < aim.size(); i++) {
        if (aim[i] == i) continue;
        changeflag = true;
        return changeflag;
    }
    changeflag = false;
    return changeflag;
}

// type[i] = aim[type[i]];
// e.g. 
// input: 3 2 0 1
// before: 0 1 1 2 2 3 3 3
// after:  3 2 2 0 0 1 1 1

LoadErrorType AtomConfigData::AtomTypeMap(const vector<size_t> &aim, bool& changeflag) {

    // 1. safe check
    const size_t ntype_s = SIZE_T(ntype);
    if (aim.size() != ntype_s) {
        return LoadErrorType::UnableAtomTypeMap;
    }

	// 2. if same, return
    if (!needToMap(aim, changeflag)) {
		return LoadErrorType::NONE;
    }

	// 3. evaluate map target
	for (int i = 0; i < num; i++) {

		if (type[i] > ntype) {
			return LoadErrorType::UnableAtomTypeMap;
		}
        int oldtype = type[i];
        type[i] = aim[oldtype];
	}
	return LoadErrorType::NONE;
}

// e.g. 
// input: Li H He
// before: H He Li
// before: 0 0 1 1 2 2 2
// after:  2 2 0 0 1 1 1

// need: 2 0 1

size_t StrFind(const vector<string> &vec, const string& str){
    for (size_t i = 0; i < vec.size(); i++){
        if (str == vec[i]) return i;
    }
    return vec.size();
}

LoadErrorType AtomConfigData::AtomTypeMap(const vector<string> &aim, bool& changeflag) {

    // 1. safe check
    const size_t ntype_s = SIZE_T(ntype);
    if (aim.size() != ntype_s) {
        return LoadErrorType::UnableAtomTypeMap;
    }

	// 2. evaluate map target
    vector<size_t> intaim(ntype_s, 0);

    for (size_t i = 0; i < ntype_s;  i++) {

        size_t idx = StrFind(eleName, aim[i]);

        if (idx >= eleName.size()){
            return LoadErrorType::UnableAtomTypeMap;
        } else {
            intaim[i] = idx;
        }
	}

	eleName = aim;
	return AtomTypeMap(intaim, changeflag);
}


/*
								  | ax ay az |
{ dx, dy, dz } = { lx, ly, lz } * | bx by bz |
								  | cx cy cz |

				 | ax ay az |-1
{ dx, dy, dz } * | bx by bz |   = { lx, ly, lz } 
				 | cx cy cz |				

*/

double AtomConfigData::getVolumn() {
    return volumn(basis[0]);
}

#define NTypeAssert(condition) 	if (!(condition)) { return LoadErrorType::IllegalNTypeNumber; }


LoadErrorType AtomConfigData::reformType(bool saveEleName) {

    size_t ntype_s = SIZE_T(ntype);
	NTypeAssert(ntype >= 1);	
    eleNum.assign(ntype_s, 0);

	// 1.create TypeIdxNumberMap: TypeIdx =map=> TypeNumber(type[i])
	int nmap = 0;
    int* TypeList = new int[ntype_s];
	for (int i = 0; i < num; i++) {
		if (AtomConfigLoad::isMember(type[i], nmap, TypeList)) {
			continue;
		}

		NTypeAssert(nmap < ntype);
		TypeList[nmap] = type[i];
		nmap++;		
	}
	 
	// 2.sort and create TypeNumberIdxMap: TypeNumber(type[i]) =map=> TypeIdx
	NTypeAssert(nmap == ntype);
    qsort(TypeList, ntype_s, sizeof(int), [](const void* a, const void* b)
		-> int {return (*(int*)a - *(int*)b); }
	);
	
    size_t maxtype = TypeList[ntype - 1];
	int* Number2Idx = new int[maxtype + 1];
	memset(Number2Idx, 0, sizeof(int) * maxtype);
	for (int i = 0; i < ntype; i++) {
		Number2Idx[TypeList[i]] = i;
	}

	// 3.count atom number for each type
	for (int i = 0; i < num; i++) {
		type[i] = Number2Idx[type[i]];
		eleNum[type[i]]++;
	}

	// 4.save element name id needed
	if (saveEleName) {
		for (int i = 0; i < ntype; i++) {
			eleName[i] = int2ele(TypeList[i]);
		}
	}

	delete[] TypeList;
	delete[] Number2Idx;
	return LoadErrorType::NONE;
}

#define NELEMENTS 109

int AtomConfigData::ele2int(const char* element) {
	static const char* name[NELEMENTS] = {
		"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
		"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
		"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
		"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
		"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
		"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
		"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
		"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
		"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
		"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
		"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt"
	};
	for (int i = 0; i < NELEMENTS; i++)
		if (strcmp(element, name[i]) == 0) return i + 1;
	return -1;
}

const char* AtomConfigData::int2ele(const int num) {
	static const char* name[NELEMENTS] = {
		"H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
		"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
		"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
		"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
		"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
		"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
		"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
		"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
		"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
		"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
		"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt"
	};

	return name[num - 1];
}


double AtomConfigData::volumn(double* m) {
	double v =
		m[0] * m[4] * m[8] - m[0] * m[5] * m[7] - m[1] * m[3] * m[8]
		+ m[1] * m[5] * m[6] + m[2] * m[3] * m[7] - m[2] * m[4] * m[6];

	return v;
}

LoadErrorType AtomConfigData::get_inverse(double* i, double* m) {
    double pv = volumn(m);
	if (!pv) return LoadErrorType::VolumeIsZero;

    memset(i, 0, 9*sizeof(double));

	switch (getCellType(m))
	{
	case LoadConfig_NS::CellType::Oth:
		i[0] = 1.0 / m[0];
		i[4] = 1.0 / m[4];
		i[8] = 1.0 / m[8];
		break;

	case LoadConfig_NS::CellType::Tri3:

		i[0] = 1.0 / m[0];
		i[4] = 1.0 / m[4];
		i[8] = 1.0 / m[8];
		
		i[3] = -m[3] / (m[0] * m[4]);
		i[6] = (m[3] * m[7] - m[4] * m[6]) / (m[0] * m[4] * m[8]);
		i[7] = -m[7] / (m[4] * m[8]);
		break;

	case LoadConfig_NS::CellType::Tri6:
		pv = 1.0 / pv;

		i[0] = m[4] * m[8] - m[5] * m[7];
		i[1] = m[2] * m[7] - m[1] * m[8];
		i[2] = m[1] * m[5] - m[2] * m[4];

		i[3] = m[5] * m[6] - m[3] * m[8];
		i[4] = m[0] * m[8] - m[2] * m[6];
		i[5] = m[2] * m[3] - m[0] * m[5];

		i[6] = m[3] * m[7] - m[4] * m[6];
		i[7] = m[1] * m[6] - m[0] * m[7];
		i[8] = m[0] * m[4] - m[1] * m[3];

		for (int k = 0; k < 9; k++) {
			i[k] *= pv;
		}	

	default:
		break;
	}

	return LoadErrorType::NONE;
}

CellType AtomConfigData::getCellType(double* mat) {

	if (mat[1] == 0 && mat[2] == 0 && mat[5] == 0) {
		if (mat[3] == 0 && mat[6] == 0 && mat[7] == 0) {
			return CellType::Oth;
		}
		else {
			return CellType::Tri3;
		}
	}
	else {
		return CellType::Tri6;
	}
}

void AtomConfigData::productN33(double* C, const int N, double* A, double* b) {

	double B[3][3] = {
		{ b[0], b[3], b[6], },
		{ b[1], b[4], b[7], },
		{ b[2], b[5], b[8], },
	};

	double* iA, *jB, sum;
	for (int i = 0; i < N; i++) {
		iA = &A[i * 3];

		for (int j = 0; j < 3; j++) {
			jB = B[j];

			sum = iA[0] * jB[0]
				+ iA[1] * jB[1]
				+ iA[2] * jB[2];

			C[i * 3 + j] = sum;
		}
	}
}



void AtomConfigData::basisTranspose(){
#define SWAP(a, b) {double c = a; a = b; b = c; }
    SWAP(basis[1][2], basis[2][1]);
    SWAP(basis[0][2], basis[2][0]);
    SWAP(basis[0][1], basis[1][0]);
#undef SWAP
}


LoadErrorType AtomConfigData::lamda2x(int n) {

	if (n <= 0) n = num;

	double lamda[3], *ipos;

	switch (getCellType(basis[0]))
	{
	case LoadConfig_NS::CellType::Oth:
		for (int i = 0; i < n; i++) {
			ipos = &pos[3 * i];
			set_vector3(lamda, ipos);
			ipos[0] = boxlo[0] + lamda[0] * basis[0][0];
			ipos[1] = boxlo[1] + lamda[1] * basis[1][1];
			ipos[2] = boxlo[2] + lamda[2] * basis[2][2];
		}
		break;

	case LoadConfig_NS::CellType::Tri3:
		for (int i = 0; i < n; i++) {
			ipos = &pos[3 * i];
			set_vector3(lamda, ipos);
			ipos[0] = boxlo[0] + lamda[0] * basis[0][0] + lamda[1] * basis[1][0] + lamda[2] * basis[2][0];
			ipos[1] = boxlo[1] + lamda[1] * basis[1][1] + lamda[2] * basis[2][1];
			ipos[2] = boxlo[2] + lamda[2] * basis[2][2];
		}
		break;

	case LoadConfig_NS::CellType::Tri6:
		for (int i = 0; i < n; i++) {
			ipos = &pos[3 * i];
			set_vector3(lamda, ipos);
			ipos[0] = boxlo[0] + lamda[0] * basis[0][0] + lamda[1] * basis[1][0] + lamda[2] * basis[2][0];
			ipos[1] = boxlo[1] + lamda[0] * basis[0][1] + lamda[1] * basis[1][1] + lamda[2] * basis[2][1];
			ipos[2] = boxlo[2] + lamda[0] * basis[0][2] + lamda[1] * basis[1][2] + lamda[2] * basis[2][2];
		}
		break;

	default:
		break;
	}

	lamdaFlag = false;
	return LoadErrorType::NONE;
}


LoadErrorType AtomConfigData::x2lamda(int n) {

	if (n <= 0) n = num;
	double *ipos, delta[3];	

	switch (getCellType(basis[0]))
	{
	case LoadConfig_NS::CellType::Oth:
		for (int i = 0; i < n; i++) {
			ipos = &pos[3 * i];
			minu_vector3(delta, ipos, boxlo);

			ipos[0] = delta[0] * basis_inv[0][0];
			ipos[1] = delta[1] * basis_inv[1][1];
			ipos[2] = delta[2] * basis_inv[2][2];
		}
		break;

	case LoadConfig_NS::CellType::Tri3:
		for (int i = 0; i < n; i++) {
			ipos = &pos[3 * i];
			minu_vector3(delta, ipos, boxlo);

			ipos[0] = delta[0] * basis_inv[0][0] + delta[1] * basis_inv[1][0] + delta[2] * basis_inv[2][0];
			ipos[1] = delta[1] * basis_inv[1][1] + delta[2] * basis_inv[2][1];
			ipos[2] = delta[2] * basis_inv[2][2];
		}
		break;

	case LoadConfig_NS::CellType::Tri6:
		for (int i = 0; i < n; i++) {
			ipos = &pos[3 * i];
			minu_vector3(delta, ipos, boxlo);

			ipos[0] = delta[0] * basis_inv[0][0] + delta[1] * basis_inv[1][0] + delta[2] * basis_inv[2][0];
			ipos[1] = delta[0] * basis_inv[0][1] + delta[1] * basis_inv[1][1] + delta[2] * basis_inv[2][1];
			ipos[2] = delta[0] * basis_inv[0][2] + delta[1] * basis_inv[1][2] + delta[2] * basis_inv[2][2];
		}
		break;

	default:
		break;
	}

	lamdaFlag = true;
	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigData::warpByPBC(int* sum)
{
	LoadErrorType err;
	err = x2lamda(); IfErrorReturn;

	if (sum == NULL) {
		for (int i = 0; i < num * 3; i++) {
			if (pos[i] >= 1.0) {
				pos[i] -= floor(pos[i]);
			}
			else if (pos[i] < 0.0) {
				pos[i] -= floor(pos[i]);
			}
		}
	}
	else {
		int total = 0;
		for (int i = 0; i < num * 3; i++) {
			if (pos[i] >= 1.0) {
				pos[i] -= floor(pos[i]);
				total++;
			}
			else if (pos[i] < 0.0) {
				pos[i] -= floor(pos[i]);
				total++;
			}
		}
		*sum = total;
	}


	return lamda2x();
}

#define Mat33Loop 				\
for (int i = 0; i < 3; i++) 	\
for (int j = 0; j < 3; j++) 

LoadErrorType AtomConfigData::Transform(double pmat[3][3], double [3], int flag) {

	double trans[3][3];
	double after[3][3];
	LoadErrorType err;
	set_matrix33(trans, pmat);
	
	// 1.get Transformation Matrix: Before, Trans and After
	if (flag & TransMatFinal) {

		// After = Before * Mat
		// beforeT * After = Mat
		set_matrix33(after, trans);

		double beforeT[3][3];
		err = get_inverse(beforeT[0], basis[0]); IfErrorReturn;
		dot_matrix33(trans, beforeT, after);
	}
	else {
		if (flag & TransMatDelta) {
			trans[0][0] += 1.0;
			trans[1][1] += 1.0;
			trans[2][2] += 1.0;
		}
		dot_matrix33(after, basis, trans);
	}

	// 2. update Basis
	if (flag & TransDomain) {
		set_matrix33(basis, after);
		updateBasis();
	}

	// 3. update Particles
	if (flag & TransParticle) {
		double *ipos, vec[3], lo[3];
		set_vector3(lo, boxlo);

		for (int i = 0; i < num; i++) {
			ipos = &pos[3 * i];
			minu_vector3(vec, ipos, lo);
			vec_matrix33(ipos, vec, trans);
			selfplus_vector3(ipos, lo);
		}
	}

	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigData::AtomDisplace(double scale, unsigned int seed, int flag) {
	double *ipos;

	srand(seed);
	scale *= 2;

	bool xflag = flag & DispX;
	bool yflag = flag & DispY;
	bool zflag = flag & DispZ;

	for (int i = 0; i < num; i++) {

		ipos = &pos[3 * i];

		if (xflag) ipos[0] += (((double)rand()) / RAND_MAX - 0.5) * scale;
		if (yflag) ipos[1] += (((double)rand()) / RAND_MAX - 0.5) * scale;
		if (zflag) ipos[2] += (((double)rand()) / RAND_MAX - 0.5) * scale;
	}
	return LoadErrorType::NONE;
}


LoadErrorType AtomConfigData::Replicate(int Nx, int Ny, int Nz) {

	int total = Nx * Ny * Nz;

	if (Nx <= 0 || Ny <= 0 || Nz <= 0) {
		return LoadErrorType::IllegalDuplicateParm;
	}
	if (1 == total) {
		return LoadErrorType::NONE;
	}

	int onum = num;
	double *ipos, *jpos, delta[3];
	atomResize(num * total);

	int idx = onum;
	for (int i = 0; i < Nx; i++) {
		for (int j = 0; j < Ny; j++) {
			for (int k = 0; k < Nz; k++) {

				if (i == 0 && j == 0 && k == 0)continue;
				
				delta[0] = i * basis[0][0] + j * basis[1][0] + k * basis[2][0];
				delta[1] = i * basis[0][1] + j * basis[1][1] + k * basis[2][1];
				delta[2] = i * basis[0][2] + j * basis[1][2] + k * basis[2][2];

				for (int m = 0; m < onum; m++) {

					ipos = &pos[3 * idx];
					jpos = &pos[3 * m];

					plus_vector3(ipos, jpos, delta);
					type[idx] = type[m];
					idx++;
				}				
			}
		}
	}

	auto_atomidx();

	selfmult_vector3(basis[0], Nx);
	selfmult_vector3(basis[1], Ny);
	selfmult_vector3(basis[2], Nz);
	updateBasis();

	return LoadErrorType::NONE;
}


void AtomConfigData::updateBasis() {
    set_vector3d(boxhi, basis[0][0], basis[1][1], basis[2][2]);
    set_vector3d(tilt, basis[1][0], basis[2][0], basis[2][1]);
    get_inverse(basis_inv[0], basis[0]);
}

LoadErrorType AtomConfigData::Tri6ToTri3(double prec, int nvec, double** vec) {

	double xx, yy, zz, xy, xz, yz;

	/************************************************************************************************/
	// 1. Calculate the lattice that meets the requirements of lammps

	if (getCellType(basis[0]) != CellType::Tri6) return LoadErrorType::NONE;
	
	double lx = norm_vector3(basis[0]);
	double ly = norm_vector3(basis[1]);
	double lz = norm_vector3(basis[2]);

	double dotab = dot_vector3(basis[0], basis[1]);	// lx*ly*cos(xy)
	double dotac = dot_vector3(basis[0], basis[2]);	// lx*lz*cos(xz)
	double dotbc = dot_vector3(basis[1], basis[2]);	// ly*lz*cos(yz)

	xx = lx;
	set_vector3d(basis[0], xx, 0, 0);				// set vector a

	// dot<a, b> = (xx, 0, 0)*(xy, yy, 0) = xx * xy
	xy = dotab / xx;
	tiltPrecModify(xy, xx, prec);

	yy = sqrt(ly * ly - xy * xy);
	set_vector3d(basis[1], xy, yy, 0);				// set vector b

	// dot<a, c> = (xx, 0, 0)*(xz, yz, zz) = xx * xz
	xz = dotac / xx;
	tiltPrecModify(xz, xx, prec);

	// dot<b, c> = (xy, yy, 0)*(xz, yz, zz) = xy * xz + yy * yz
	// yz = (dot<b, c> - xy * xz) / yy
	yz = (dotbc - xy * xz) / yy;
	tiltPrecModify(yz, yy, prec);

	zz = sqrt(lz * lz - xz * xz - yz * yz);
	set_vector3d(basis[2], xz, yz, zz);				// set vector c

	/************************************************************************************************/
	// 2. Calculate the rotation matrix between two lattices and then rotate
	double rotate[9];

	double* xold = (double*)malloc((size_t)num * 3 * sizeof(double));
	if (xold == NULL) {
		return LoadErrorType::MemoryMallocFailed;
	}
	productN33(rotate, 3, basis_inv[0], basis[0]);

	// data.x = xold * rotate
	memcpy(xold, pos, (size_t)num * 3 * sizeof(double));
	productN33(pos, num, xold, rotate);

	for (int ivec = 0; ivec < nvec; ivec++) {
		// data.f = fold * rotate
		memcpy(xold, vec[ivec], (size_t)num * 3 * sizeof(double));
		productN33(vec[ivec], num, xold, rotate);
	}

	free(xold);
	set_vector3d(basis[0], xx, 0, 0);
	set_vector3d(basis[1], xy, yy, 0);
	set_vector3d(basis[2], xz, yz, zz);
	updateBasis();

	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigData::Tri3HalfConditionWarp(double prec) {

	if (getCellType(basis[0]) == CellType::Tri6) return LoadErrorType::NONE;

	double xx = basis[0][0];
	double yy = basis[1][1];
	double zz = basis[2][2];
	 
	double xy = basis[1][0];
	double xz = basis[2][0];
	double yz = basis[2][1];	

	/************************************************************************************************/
	// Translate the lattice. Make it meet the requirements of LAMMPS

	int tranlateFlag = 0;
	if (!tiltQualified(xy, xx, prec)) {
		tiltTranslateModify(xy, xx);
		tranlateFlag = 1;
	}
	if (!tiltQualified(xz, xx, prec)) {
		tiltTranslateModify(xz, xx);
		tranlateFlag = 1;
	}
	if (!tiltQualified(yz, yy, prec)) {
		tiltTranslateModify(yz, yy);
		tranlateFlag = 1;
	}

	set_vector3d(basis[0], xx, 0, 0);
	set_vector3d(basis[1], xy, yy, 0);
	set_vector3d(basis[2], xz, yz, zz);	
	updateBasis();

	if (tranlateFlag) { warpByPBC(); }
	return LoadErrorType::NONE;
}

/*
	if ((fabs(xy / (boxhi[0] - boxlo[0])) > 0.5 && xperiodic) ||
		(fabs(xz / (boxhi[0] - boxlo[0])) > 0.5 && xperiodic) ||
		(fabs(yz / (boxhi[1] - boxlo[1])) > 0.5 && yperiodic)) {
*/

bool AtomConfigData::tiltQualified(double& tilt, double len, double) {

	return fabs(tilt / len) <= 0.5;

}

bool AtomConfigData::tiltPrecModify(double &tilt, double len, double prec) {

	if (tiltQualified(tilt, len, prec)) return false;

	if (fabs(tilt / len - 0.5) < prec) {
		tilt = len * 0.5;
		return true;
	}

	return false;
}

void AtomConfigData::tiltTranslateModify(double& tilt, double len) {

	double translate = floor(tilt / len + 0.5);
	tilt -= translate * len;
}










AtomConfigLoad::AtomConfigLoad(AtomConfigData* pdata)
	: data(pdata)
	, vasp({ 1.0, 0, 0 })
{

	strcpy(fmt, "%24.17g");
	strcpy(splitWord, " \t\n\r\f");

	error = LoadErrorType::NONE;

	fp = NULL;
	m_size = 0;
	m_capacity = 256 * 256;
	s = (char*)malloc(m_capacity * sizeof(char));
}

AtomConfigLoad::~AtomConfigLoad() {
	if (fp) {
		fclose(fp);
		fp = NULL;
	};

	if (s) {
		free(s);
	}
}




#define MaxBuf 1023

LoadFileType AtomConfigLoad::prase_file_type() {

	char buf[MaxBuf + 1];
	fread(buf, sizeof(char), MaxBuf, fp);
    rewind(fp);

	buf[MaxBuf] = '\0';

	if (strstr(buf, "ITEM: TIMESTEP")) {
		return LoadFileType::LMP_DUMP;
	}
	else if (strstr(buf, "Atoms")) {
		return LoadFileType::LMP_DATA;
	}
    else {
        for (int i = 0; i< 8; i++){
            fgets(buf, MaxBuf, fp);
        }
        rewind(fp);

        char* p = strtok(buf, " \t\n\r\f");
        if (!p) return LoadFileType::NONE;

        if (p[0] == 'D' || p[0] == 'C' || p[0] == 'K' || p[0] == 'd' || p[0] == 'c' || p[0] == 'k') {
            return LoadFileType::VASP;
        }
    }

	return LoadFileType::NONE;
}

LoadErrorType AtomConfigLoad::read_head(const char* path) {

	fp = fopen(path, "r");

	if (fp == NULL) {
		return LoadErrorType::FileOpenError;
	}

	if (data->filetype == LoadFileType::NONE) {
		data->filetype = prase_file_type();
	}

	LoadErrorType err = LoadErrorType::NONE;
	switch (data->filetype)
	{
	case LoadConfig_NS::LoadFileType::NONE:
		return LoadErrorType::FileTypeIsNONE;
		break;
	case LoadConfig_NS::LoadFileType::LMP_DATA:
		err = read_head_LMP_DATA();
		break;
	case LoadConfig_NS::LoadFileType::LMP_DUMP:
		err = read_head_LMP_DUMP();
		break;
	case LoadConfig_NS::LoadFileType::VASP:
		err = read_head_VASP();
		break;
	default:
		break;
	}

	data->atomResize(data->num);
	data->typeResize(data->ntype);
	data->updateBasis();

	return err;
}


LoadErrorType AtomConfigLoad::read_data() {

	switch (data->filetype)
	{
	case LoadConfig_NS::LoadFileType::NONE:
		return LoadErrorType::FileTypeIsNONE;
		break;
	case LoadConfig_NS::LoadFileType::LMP_DATA:
		read_data_LMP_DATA();
		break;
	case LoadConfig_NS::LoadFileType::LMP_DUMP:
		read_data_LMP_DUMP();
		break;
	case LoadConfig_NS::LoadFileType::VASP:
		read_data_VASP();
		break;
	default:
		break;
	}

	// close the file
	fclose(fp);

	data->reformType(true);

	return error;
}

LoadErrorType AtomConfigLoad::write(const char* path, int flag) {

	if (path) {
		fp = fopen(path, "w");
		if (fp == NULL) {
			return LoadErrorType::FileOpenError;
		}
	}

	switch (data->filetype)
	{
	case LoadConfig_NS::LoadFileType::NONE:
		return LoadErrorType::FileTypeIsNONE;
		break;
	case LoadConfig_NS::LoadFileType::LMP_DATA:
		write_LMP_DATA(flag);
		break;
	case LoadConfig_NS::LoadFileType::LMP_DUMP:
		write_LMP_DUMP(flag);
		break;
	case LoadConfig_NS::LoadFileType::VASP:
		write_VASP(flag);
		break;
	default:
		break;
	}

	if (path) {
		fwrite(s, sizeof(char), m_size, fp);
		fclose(fp);
	}

	return error;
}

#define CASEMSG(TYPE) case LoadConfig_NS::LoadErrorType::TYPE: return "MapAtomTypeNumber";

const char* AtomConfigLoad::error_msg(LoadErrorType perror) {

	switch (perror)	{
        CASEMSG(NONE);
        CASEMSG(FileOpenError);
        CASEMSG(FileTypeIsNONE);
        CASEMSG(NumericStrEmpty);
        CASEMSG(NumericLackOfParam);
        CASEMSG(IllegalFloatParam);
        CASEMSG(IllegalIntegerParam);
        CASEMSG(MapAtomTypeNumber);
        CASEMSG(VolumeIsZero);
        CASEMSG(IllegalConfigDataPtr);
        CASEMSG(IllegalIdxPtr);
        CASEMSG(IllegalTypePtr);
        CASEMSG(IllegalPosPtr);
        CASEMSG(IllegalExtraPtr);
        CASEMSG(IllegalNTypeNumber);
        CASEMSG(UnableAtomTypeMap);
        CASEMSG(LMPData_NoEnoughHeadInfo);
        CASEMSG(LMPData_NoAtomsKeyWord);
        CASEMSG(MemoryMallocFailed);
        CASEMSG(OUTCARIllegalAtomPosData);
        CASEMSG(IllegalGroundEnergyNumber);
        CASEMSG(OUTCARInsufficInfo);
        CASEMSG(IllegalDuplicateParm);
	}

	return "NONE";
}


LoadErrorType AtomConfigLoad::numeric(double&res, const char* str) {
	if (!str) {
		res = 0.0;
		return LoadErrorType::NumericStrEmpty;
	}

	size_t n = strlen(str);
	if (n == 0) {
		res = 0.0;
		return LoadErrorType::NumericStrEmpty;
	}

	for (size_t i = 0; i < n; i++) {
		if (isdigit(str[i])) continue;
		if (str[i] == '-' || str[i] == '+' || str[i] == '.') continue;
		if (str[i] == 'e' || str[i] == 'E') continue;

		res = 0.0;
		return LoadErrorType::IllegalFloatParam;
	}
	res = atof(str);
	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigLoad::inumeric(int& res, const char* str) {
	if (!str) {
		res = 0;
		return LoadErrorType::NumericStrEmpty;
	}

	size_t n = strlen(str);
	if (n == 0) {
		res = 0;
		return LoadErrorType::NumericStrEmpty;
	}

	for (size_t i = 0; i < n; i++) {
		if (isdigit(str[i]) || str[i] == '-' || str[i] == '+') continue;

		res = 0;
		return LoadErrorType::IllegalIntegerParam;
	}

	res = atoi(str);
	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigLoad::numerics(char* str, int n, double* data, bool chkFlag, const char* splitword) {

	char* next = strtok(str, splitword);
	if (next == NULL) {
		return LoadErrorType::NumericStrEmpty;
	}
	if (chkFlag) { 
		LoadErrorType merr = numeric(data[0], next);
		if (merr != LoadErrorType::NONE) return merr;
	}
	else { data[0] = atof(next); }	

	for (int m = 1; m < n; m++) {
		next = strtok(NULL, splitword);
		if (next == NULL) {
			return LoadErrorType::NumericLackOfParam;
		}
		if (chkFlag) { 
			LoadErrorType merr = numeric(data[m], next);
			if (merr != LoadErrorType::NONE) return merr;		
		}
		else { data[m] = atof(next); }
	}
	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigLoad::inumerics(char* str, int n, int* data, bool chkFlag, const char* splitword) {

	char* next = strtok(str, splitword);
	if (next == NULL) {
		return LoadErrorType::NumericStrEmpty;
	}
	if (chkFlag) { 
		LoadErrorType merr = inumeric(data[0], next);
		if (merr != LoadErrorType::NONE) return merr;
	}
	else { data[0] = atoi(next); }

	for (int m = 1; m < n; m++) {
		next = strtok(NULL, splitword);
		if (next == NULL) {
			return LoadErrorType::NumericLackOfParam;
		}
		if (chkFlag) { 
			LoadErrorType merr = inumeric(data[m], next);
			if (merr != LoadErrorType::NONE) return merr;
		}
		else { data[m] = atoi(next); }
	}
	return LoadErrorType::NONE;
}

LoadErrorType AtomConfigLoad::inumerics(std::string str, int n, int* data, bool chkFlag, const char* splitword){
    return inumerics(&str[0], n, data, chkFlag, splitword);
}

LoadErrorType AtomConfigLoad::numerics(std::string str, int n, double* data, bool chkFlag, const char* splitword){
    return numerics(&str[0], n, data, chkFlag, splitword);
}

int AtomConfigLoad::count_words(const char* line, const char* splitword)
{
	size_t n = strlen(line) + 1;
	char* ptr, * copy = new char[n];
	strcpy(copy, line);

	if ((ptr = strchr(copy, '#'))) *ptr = '\0';

	if (strtok(copy, splitword) == NULL) {
		delete[] copy;
		return 0;
	}
	n = 1;
	while (strtok(NULL, splitword)) n++;

	delete[] copy;
	return static_cast<int>(n);
}

void AtomConfigLoad::split(std::vector<std::string>& dest, char* str, const char* delim) {
	if (str == NULL || str[0] == '\0') return;

	dest.clear();

	char* p = strtok(str, delim);
	while (p) {
		dest.push_back(p);
		p = strtok(NULL, delim);
	}
}

void AtomConfigLoad::split(std::vector<std::string>& dest, const char* str, const char* delim) {
	if (str == NULL || str[0] == '\0') return;

	dest.clear();

	// First convert the string to be cut from a string type to a character type
	char* strs = new char[strlen(str) + 1]; // add 1 at last 
	strcpy(strs, str);

	char* p = strtok(strs, delim);
	while (p) {
		dest.push_back(p);
		p = strtok(NULL, delim);
	}

	delete[] strs;
}

void AtomConfigLoad::split(std::vector<std::string>& dest, 
	const std::string& str, const std::string& delim) {

	if (str.empty()) return;

	dest.clear();

	// First convert the string to be cut from a string type to a character type
	char* strs = new char[str.length() + 1]; // add 1 at last 
	strcpy(strs, str.c_str());

	char* d = new char[delim.length() + 1];  // add 1 at last 
	strcpy(d, delim.c_str());

	char* p = strtok(strs, d);
	while (p) {
		dest.push_back(p);
		p = strtok(NULL, d);
	}

	delete[] strs;
	delete[] d;
}

LoadErrorType AtomConfigLoad::open(FILE* &pf, char const* _FileName, char const* _Mode) {

	pf = fopen(_FileName, _Mode);
	if (pf == NULL) {
		return LoadErrorType::FileOpenError;
	}

	return LoadErrorType::NONE;
}

string& AtomConfigLoad::replace_all(string& str, const string& old_value, const string& new_value)
{
	if (old_value == new_value) return  str;

	const size_t old_value_length = old_value.length();

	while (true)
	{
		string::size_type pos(0);
		if ((pos = str.find(old_value)) != string::npos)
		{
			str.replace(pos, old_value_length, new_value);
		}
		else { break; }
	}
	return  str;
}

string& AtomConfigLoad::replace_all_distinct(string& str, const string& old_value, const  string& new_value)
{
	if (old_value == new_value) return  str;

	const size_t old_value_length = old_value.length();
	const size_t new_value_length = new_value.length();

	for (string::size_type pos(0); pos != string::npos; pos += new_value_length)
	{
		if ((pos = str.find(old_value, pos)) != string::npos)
		{
			str.replace(pos, old_value_length, new_value);
		}
		else { break; }
	}
	return  str;
}
