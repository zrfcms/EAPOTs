#include "AtomConfig.h"
#include <string.h>
#include <ctype.h>
#include <cstdlib>
using namespace LoadConfig_NS;

#define MaxBuf 1024
#define ErrorCheck if (error != LoadErrorType::NONE) return error
#define SafePrint if(static_cast<size_t>(k + safe) >= m_capacity) reserve(static_cast<size_t>(k + safe)); k += sprintf

#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}
#define mult_vector3(u, v, r){u[0] = v[0] * r;u[1] = v[1] * r;u[2] = v[2] * r;}
#define selfmult_vector3(u, r){u[0] *= r;u[1] *= r;u[2] *= r;}


LoadErrorType AtomConfigLoad::read_head_VASP() {

	vasp.ratio = 1.0;
	vasp.dynamicFlag = 0;
	vasp.cartesianFlag = 0;

	char buf[MaxBuf];
	double (*basis)[3] = data->basis;

	// skip first line and read ratio
	fgets(buf, MaxBuf, fp);
	fgets(buf, MaxBuf, fp);
	numerics(buf, 1, &vasp.ratio); ErrorCheck;

	// **********************************  read basis vector  **********************************
	fgets(buf, MaxBuf, fp);
	numerics(buf, 3, basis[0]); ErrorCheck;
	selfmult_vector3(basis[0], vasp.ratio);

	fgets(buf, MaxBuf, fp);
	numerics(buf, 3, basis[1]); ErrorCheck;
	selfmult_vector3(basis[1], vasp.ratio);

	fgets(buf, MaxBuf, fp);
	numerics(buf, 3, basis[2]); ErrorCheck;
	selfmult_vector3(basis[2], vasp.ratio);

	// ******************* read elements type and atom num for each element  *******************
	fgets(buf, MaxBuf, fp);
	split(data->eleName, buf, splitWord);

	fgets(buf, MaxBuf, fp);
	data->ntype = count_words(buf);
	int* elenum = new int[data->ntype];
	inumerics(buf, data->ntype, elenum); ErrorCheck;

	data->num = 0;
	data->eleNum.resize(data->ntype, 0);
	for (int i = 0; i < data->ntype; i++) {
		data->eleNum[i] = elenum[i];
		data->num += elenum[i];
	}
	delete[] elenum;

	// ************************* read Selective dynamics and Comment ***************************

	// determind Selective dynamics
	fgets(buf, MaxBuf, fp);
	if (buf[0] == 'S' || buf[0] == 's') {
		vasp.dynamicFlag = 1;
		fgets(buf, MaxBuf, fp);
	}

	// skip comments
	while (strlen(buf) == 1 || buf[0] == '!') {
		fgets(buf, MaxBuf, fp);
	}

	// Next line should contain a keyword deciding if the atom positions are in Direct or Cartesian coordinates
	// According to VASP documentation, anything starting with C, c, K or k switches to cartesian, anything else means
	if (*buf == 'C' || *buf == 'c' || *buf == 'K' || *buf == 'k') {
		vasp.cartesianFlag = 1;
	}

	return LoadErrorType::NONE;
};


LoadErrorType AtomConfigLoad::read_data_VASP() {

	if (!data->pos) return LoadErrorType::IllegalPosPtr;

	char buf[MaxBuf];
	double lamda[3], x[3];
	double(*basis)[3] = data->basis;
	double* ipos = NULL, ratio = vasp.ratio;
	const int num = data->num;

	for (int i = 0; i < num; i++) {

		fgets(buf, MaxBuf, fp);
		numerics(buf, 3, lamda, false); ErrorCheck;

		ipos = &data->pos[i * 3];
		if (vasp.cartesianFlag) {
			mult_vector3(ipos, lamda, ratio);
		}
		else {
			x[0] = lamda[0] * basis[0][0] + lamda[1] * basis[1][0] + lamda[2] * basis[2][0];
			x[1] = lamda[0] * basis[0][1] + lamda[1] * basis[1][1] + lamda[2] * basis[2][1];
			x[2] = lamda[0] * basis[0][2] + lamda[1] * basis[1][2] + lamda[2] * basis[2][2];
			set_vector3(ipos, x);
		}
	}

	if (data->idx) { data->auto_atomidx(); }

	if (data->type) {
		int k = 0, ptype;
		int* type = data->type;

		for (int itype = 0; itype < data->ntype; itype++) {

			ptype = data->ele2int(data->eleName[itype].c_str());
			for (int i = 0; i < data->eleNum[itype]; i++) {
				type[k++] = ptype;
			}

		}
	}


	return LoadErrorType::NONE;
};

/*
CuFe
   1.00000000000000
	 2.8373257159342593   -0.1134930286373704   -0.1134930286373704
	-0.1134930286373704    2.8373257159342593   -0.1134930286373704
	-0.1134930286373704   -0.1134930286373704    2.8373257159342593
   Ni   Cu
	 1     1
Direct
  0.0000000000000000  0.0000000000000000  0.0000000000000000
  0.5000000000000000  0.5000000000000000  0.5000000000000000

  0.00000000E+00  0.00000000E+00  0.00000000E+00
  0.00000000E+00  0.00000000E+00  0.00000000E+00

*/

int cmpfunc(const void * a, const void * b)
{
	return (*(int*)a - *(int*)b);
}

LoadErrorType AtomConfigLoad::write_VASP(int) {

    char format[256];
    int k = 0, safe = 256;
	double(*basis)[3] = data->basis;
	data->x2lamda();

	/************************************************************************************************/
    // printf head information

	SafePrint(&s[k], " \n");
	SafePrint(&s[k], "   1.00000000000000\n");

	sprintf(format, "     %s %s %s\n", fmt, fmt, fmt);
	SafePrint(&s[k], format, basis[0][0], basis[0][1], basis[0][2]);
	SafePrint(&s[k], format, basis[1][0], basis[1][1], basis[1][2]);
	SafePrint(&s[k], format, basis[2][0], basis[2][1], basis[2][2]);

	data->reformType();
	// printf element Name and element Number
	for (int i = 0; i < data->ntype; i++) {
		SafePrint(&s[k], "%s ", data->eleName[i].c_str());
	}
	SafePrint(&s[k], "\n");
	for (int i = 0; i < data->ntype; i++) {
		SafePrint(&s[k], "%d ", data->eleNum[i]);
	}
	SafePrint(&s[k], "\n");

	// printf atom position type 
	if (data->lamdaFlag) {
		SafePrint(&s[k], "Direct\n");
	}
	else {
		SafePrint(&s[k], "C\n");
	}	

	/************************************************************************************************/
	// printf atom position

	double* ipos = NULL;
	int* type = data->type;
	int ntype = data->ntype;
	double* pos = data->pos;
	const int num = data->num;

	sprintf(format, "\t%s %s %s\n", fmt, fmt, fmt);

	for (int itype = 0; itype < ntype; itype++) {
		for (int i = 0; i < num; i++) {
			if (itype != type[i]) continue;

			ipos = &pos[3 * i];
			SafePrint(&s[k], format, ipos[0], ipos[1], ipos[2]);
		}
	}

	m_size = k;
	s[m_size] = '\0';

	data->lamda2x();

	return LoadErrorType::NONE;
}
