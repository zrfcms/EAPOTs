#pragma once

#include <string>
#include <vector>
#include "AtomConfig.h"

namespace LoadConfig_NS {

#define NEla 7
#define NDof 6

	class MDFitData
	{
    friend class LoadVaspData;
	public:
		MDFitData();
		~MDFitData();

        bool Reload;                                // Calculation Options
        bool Ref_Drive;                             // Calculation Options
        bool Relax_AtomX;                           // Calculation Options
        bool Relax_AtomY;                           // Calculation Options
        bool Relax_AtomZ;                           // Calculation Options
        bool Use_MaxForce;                          // Calculation Options

        // view active
        bool ActiveLatticeGroup;                    // View Options
        bool ActiveEnergyGroup ;                    // View Options
        bool ActiveStressGroup ;                    // View Options
        bool ActiveForceGroup  ;                    // View Options
        bool ActiveMoreGroup   ;                    // View Options

		// 1.Relax and Reference Settings

		double Global_Weight;						// Global_Weight        
		std::string Structure_Name;					// Structure Name	(file name)				
		std::string Structure_Information;			// Structure Information					*.lmp
		std::string Structure_Atom_Configuration;	// Structure Atom Reference Configuration	*.log
        std::string Energy_Reference;               // Reference Cohesive Energy
        std::string Box_Relax_Mode;                 // none, iso, aniso, full
        std::string Energy_Scale_Method;            // Scale factor for energy, e.g. Ys, Es						

		// 2.Domain and Stress Target

		double Domain_Target[NDof];					// Global Domain fit target
		double Domain_Weight[NDof];					// Global Domain fit weight
		double Stress_Global_Target[NDof];			// Global Stress fit target
		double Stress_Global_Weight[NDof];			// Global Stress fit weight

		// 3.Energy, Force, and Virial Fitting Target

        double Energy_Target;                       // Energy fit target
        double Energy_Weight;                       // Energy fit weight
		double Energy_Cost_Target;					// Energy Cost Funtion fit target
		double Energy_Cost_Weight;					// Energy Cost Funtion fit weight
		std::string Energy_Cost_Method;				// Energy Cost Method: abs/norm
		double Force_Cost_Target;					// Force Cost Funtion fit target
		double Force_Cost_Weight;					// Force Cost Funtion fit weight
		std::string Force_Cost_Method[3];			// Force Cost Method: abs/norm
		double Virial_Cost_Target;					// Virial Cost Funtion fit target
		double Virial_Cost_Weight;					// Virial Cost Funtion fit weight
		std::string Virial_Cost_Method[6];			// Virial Cost Method: abs/norm

        // Energy Calculation Items, can be: none/either/global/atom
        // Force Calculation Items, can be: none/atom
        // Stress Calculation Items, can be: none/either/global/atom

		// 4.Elastic Fitting Target
		double Elastic_Target[NEla][NDof];			// Global Stress fit target
		double Elastic_Weight[NEla][NDof];			// Global Stress fit weight

	public:
		int num;
		double* AtomForceWeight;
		double* AtomForceTarget;

	public:
		LoadErrorType resize(int n);
		const char* get_Energy_Calculation();
		const char* get_Force_Calculation();
		const char* get_Stress_Calculation();
		const char* get_Elatic_Calculation();

        static int getParamIdx(const char*);
        std::vector<void*> paramPtr;
        static std::vector<const char*> name;
    public:
        double initEnergy;
	};

	class LoadVaspData {
	public:
		LoadVaspData();
		~LoadVaspData();

        int ErrLine;
        const char* ErrFile;
        LoadErrorType err;

        MDFitData target;
		AtomConfigData config;
		
		LoadErrorType parse(double prec = 4E-15, const char* = " \t\n\r\f");
		LoadErrorType exportData(const char* dir, bool dump_lammpsFlag = false);
		static LoadErrorType exportToReflog(EString &buf, MDFitData *tar);

		// Note: Type.size() >= config.ntype
        LoadErrorType updateType(std::vector<std::string> Type);
        // Note: Energy.size() >= config.ntype
        LoadErrorType updateEnergy(std::vector<double> Energy, double* res = NULL, bool norm = false);

        std::string customSavePath;
		std::string OUTCAR, CONTCAR;
	private:
        LoadErrorType parse_OUTCAR(std::string, const char* splitWord = " \t\n\r\f");

        LoadErrorType exportToJson(const char* path);

	private:
		static const char* fmt;
        EString buf;
		std::string lmp, ref;
	};

}
