#include "AtomConfig.h"
#include <string.h>
#include <ctype.h>

using namespace LoadConfig_NS;

#define MaxBuf 1024
#define ErrorCheck if (error != LoadErrorType::NONE) return error
#define SafePrint if(k + safe >= m_capacity) reserve(k + safe); k += sprintf

#define set_vector3(u, v) {u[0] = v[0];u[1] = v[1];u[2] = v[2];}
#define set_vector3d(u, x, y, z) {u[0] = x;u[1] = y;u[2] = z;}
/*
 LAMMPS data file

			8	atoms
			2   atom types

	  0.000000000     	4.000000000   xlo xhi
	  0.000000000     	4.000000000   ylo yhi
	  0.000000000    	4.000000000   zlo zhi

 Atoms

		   1	1	1.0	1.0	1.0
		   2	2	3.0	1.0	1.0
		   3	2	1.0	3.0	1.0
		   4	2	1.0	1.0	3.0
		   5	1	1.0	3.0	3.0
		   6	1	3.0	1.0	3.0
		   7	1	3.0	3.0	1.0
		   8	2	3.0	3.0	3.0
*/


LoadErrorType AtomConfigLoad::read_head_LMP_DATA() {

	char buf[MaxBuf];

	int setneed = 0;
	int setStopFlag = (1 << 5) - 1;
	double tmp[3];

	// skip comments until scan atoms and atom types
	while (true) {

		if (fgets(buf, MaxBuf, fp) == NULL) {
			return LoadErrorType::LMPData_NoEnoughHeadInfo;
		}

		if (strstr(buf, "atoms")) {	
			inumerics(buf, 1, &data->num);
			setneed |= (1 << 0);
		}
		else if (strstr(buf, "atom types")) {
			inumerics(buf, 1, &data->ntype);
			setneed |= (1 << 1);
		}
		else if (strstr(buf, "xlo xhi")) {
			numerics(buf, 2, tmp);
			data->boxlo[0] = tmp[0];
			data->boxhi[0] = tmp[1];

			setneed |= (1 << 2);
		}
		else if (strstr(buf, "ylo yhi")) {
			numerics(buf, 2, tmp);
			data->boxlo[1] = tmp[0];
			data->boxhi[1] = tmp[1];

			setneed |= (1 << 3);
		}
		else if (strstr(buf, "zlo zhi")) {
			numerics(buf, 2, tmp);
			data->boxlo[2] = tmp[0];
			data->boxhi[2] = tmp[1];

			setneed |= (1 << 4);
		}
        else if (strstr(buf, "xy")) {
			numerics(buf, 3, tmp);
			set_vector3(data->tilt, tmp);
        }

        if (strstr(buf, "Atoms")) {
            if (setneed == setStopFlag)
                break;
            else
                return LoadErrorType::LMPData_NoEnoughHeadInfo;
        }
    }

	set_vector3d(data->basis[0], data->boxhi[0] - data->boxlo[0], 0, 0);
	set_vector3d(data->basis[1], data->tilt[0], data->boxhi[1] - data->boxlo[1], 0);
	set_vector3d(data->basis[2], data->tilt[1], data->tilt[2], data->boxhi[2] - data->boxlo[2]);

	return LoadErrorType::NONE;
};

LoadErrorType AtomConfigLoad::read_data_LMP_DATA() {

	if (!data->idx) return LoadErrorType::IllegalIdxPtr;
	if (!data->type) return LoadErrorType::IllegalTypePtr;
	if (!data->pos) return LoadErrorType::IllegalPosPtr;

	char buf[MaxBuf];
	double* ipos = NULL;

	char* next;
	fgets(buf, MaxBuf, fp);

	int* idx = data->idx;
	int* type = data->type;
	double* pos = data->pos;
	const int num = data->num;

	for (int i = 0; i < num; i++) {
		fgets(buf, MaxBuf, fp);

		next = strtok(buf, splitWord);
		if (next == NULL) {
			return LoadErrorType::NumericStrEmpty;
		}
		idx[i] = atoi(next);

		next = strtok(NULL, splitWord);
		if (next == NULL) {
			return LoadErrorType::NumericStrEmpty;
		}
		type[i] = atoi(next);

		ipos = &pos[3 * i];
		for (int m = 0; m < 3; m++) {
			next = strtok(NULL, splitWord);
			if (next == NULL) {
				return LoadErrorType::NumericStrEmpty;
			}
			ipos[m] = atof(next);
		}
	}

	return LoadErrorType::NONE;
};

LoadErrorType AtomConfigLoad::write_LMP_DATA(int flag) {

	char format[256];
	size_t k = 0, safe = 256;

	/************************************************************************************************/
	// printf head information

	SafePrint(&s[k], " LAMMPS data file\n\n");

	SafePrint(&s[k], "			%4d\tatoms\n", data->num);
	SafePrint(&s[k], "			%4d\tatom types\n\n", data->ntype);

	sprintf(format, "     %s %s   xlo xhi\n", fmt, fmt);
	SafePrint(&s[k], format, data->boxlo[0], data->boxhi[0]);

	sprintf(format, "     %s %s   ylo yhi\n", fmt, fmt);
	SafePrint(&s[k], format, data->boxlo[1], data->boxhi[1]);

	sprintf(format, "     %s %s   zlo zhi\n", fmt, fmt);
	SafePrint(&s[k], format, data->boxlo[2], data->boxhi[2]);

	sprintf(format, "     %s %s %s  xy xz yz\n\n", fmt, fmt, fmt);
	SafePrint(&s[k], format, data->tilt[0], data->tilt[1], data->tilt[2]);
	SafePrint(&s[k], " Atoms\n\n");

	/************************************************************************************************/
	// printf atom position

	double* pi = NULL;
	sprintf(format, "\t\t%%-4d %%d %s %s %s\n", fmt, fmt, fmt);

	int* idx = data->idx;
	int* type = data->type;
	double* pos = data->pos;	
	const int num = data->num;
	const int ntype = data->ntype;

	int* rtype = new int[data->ntype];
	for (int i = 0; i < ntype; i++) {
		rtype[i] = data->ele2int(data->eleName[i].c_str());
	}

	if (idx == NULL) {
		if (flag & ReformType) {
			for (int i = 0; i < num; i++) {
				pi = &pos[3 * i];
				SafePrint(&s[k], format, i + 1, rtype[type[i]], pi[0], pi[1], pi[2]);
			}
		}
		else {
			for (int i = 0; i < num; i++) {
				pi = &pos[3 * i];
				SafePrint(&s[k], format, i + 1, type[i] + 1, pi[0], pi[1], pi[2]);
			}
		}
	}
	else {
		if (flag & ReformType) {
			for (int i = 0; i < num; i++) {
				pi = &pos[3 * i];
				SafePrint(&s[k], format, idx[i], rtype[type[i]], pi[0], pi[1], pi[2]);
			}
		}
		else {
			for (int i = 0; i < num; i++) {
				pi = &pos[3 * i];
				SafePrint(&s[k], format, idx[i], type[i] + 1, pi[0], pi[1], pi[2]);
			}
		}
	}

	m_size = k;
	s[m_size] = '\0';

	delete[] rtype;
	return LoadErrorType::NONE;
}
