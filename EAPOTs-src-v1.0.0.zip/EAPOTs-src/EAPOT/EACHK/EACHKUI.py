
import os
import json
import EACHKAlgo
from EACHKUI_Component import *
from tkinter import filedialog



class AlgoList(tk.Frame):
    def __init__(self, ui, **kw):
        super().__init__(ui, **kw)
        self.ui = ui

        sb = tk.Scrollbar(self)                                                 #垂直滚动条组件
        sb.pack(side=tk.RIGHT,fill=tk.Y)                                        #设置垂直滚动条显示的位置

        self.algo = tk.Listbox(self, yscrollcommand=sb.set,width=28)    
        self.algo.pack(side=tk.LEFT,fill=tk.BOTH)
        self.algo.bind('<<ListboxSelect>>', self.listbox_click)
        sb.config(command=self.algo.yview)                                      #设置Scrollbar组件的command选项为该组件的yview()方法

    def listbox_click(self, event):
        select = self.algo.curselection()
        if len(select) < 1: return
        idx = self.algo.curselection()[0]

        ilab   = ui.algoResPage.headFrames[idx]
        iframe = ui.algoResPage.mainFrames[idx]

        w = ui.algoResPage.headCanvas['scrollregion'].split(' ')
        h = ui.algoResPage.mainCanvas['scrollregion'].split(' ')
        
        ui.algoResPage.headCanvas.xview_moveto((ilab.winfo_x()-5)/int(w[2]))
        ui.algoResPage.mainCanvas.yview_moveto((iframe.winfo_y()-5)/int(h[3]))    

    def updateData(self, chkdata):
        self.data = chkdata
        self.algo.delete(0, tk.END)        
        for key, value in self.data.items():
            self.algo.insert(tk.END, value["id"])


class AlgoSetPage(tk.Frame):
    def __init__(self, ui, **kw):
        super().__init__(ui.tabview, **kw)
        self.ui = ui

        self.mainCanvas=tk.Canvas(self,scrollregion=(0,0,0,1600))                #创建canvas
        self.mainCanvas.pack(fill=tk.BOTH, expand = True)                        #放置canvas的位置
        vbar=tk.Scrollbar(self.mainCanvas,orient=tk.VERTICAL)                    #竖直滚动条
        vbar.pack(side=tk.RIGHT,fill=tk.BOTH)
        vbar.configure(command=self.mainCanvas.yview)
        self.mainCanvas.config(yscrollcommand=vbar.set)                          #设置

        self.mainFrame=tk.Frame(self.mainCanvas, width=200, bd=1)               #把frame放在canvas里
        self.mainFrame.pack(fill=tk.BOTH, expand = True)                                        #frame的长宽，和canvas差不多的
        self.mainCanvas.create_window(0,0, window=self.mainFrame, anchor=tk.NW)      #create_window
        self.pack(fill=tk.BOTH, expand = True)        

class AlgoResPage(tk.Frame):
    def __init__(self, ui, **kw):
        super().__init__(ui.tabview, **kw)
        self.ui = ui
        self.mainFrames = []
        self.headFrames = []

        Frame1 = tk.Frame(self)
        self.headCanvas=tk.Canvas(Frame1, height=60, scrollregion=(0,0,600,0))
        self.headCanvas.pack(fill=tk.X)
        self.headbar=tk.Scrollbar(Frame1, orient=tk.HORIZONTAL)
        self.headbar.pack(side=tk.TOP, fill=tk.X)
        self.headbar.configure(command=self.headCanvas.xview)
        self.headCanvas.config(xscrollcommand=self.headbar.set)

        self.headFrame=tk.Frame(self.headCanvas, bd=1)
        self.headFrame.pack(fill=tk.X)
        self.headCanvas.create_window(0,0, window=self.headFrame, anchor=tk.NW)


        Frame2 = tk.Frame(self)
        self.mainCanvas=tk.Canvas(Frame2, scrollregion=(0,0,0,200))
        self.mainCanvas.pack(side=tk.LEFT, anchor=tk.W, fill=tk.BOTH, expand = True, pady=2)
        self.mainbar=tk.Scrollbar(Frame2, orient=tk.VERTICAL)
        self.mainbar.pack(side=tk.LEFT,fill=tk.BOTH)
        self.mainbar.configure(command=self.mainCanvas.yview)
        self.mainCanvas.config(yscrollcommand=self.mainbar.set)
        self.mainCanvas.bind("<MouseWheel>", self.mainWheel)

        self.mainFrame=tk.Frame(self.mainCanvas, width=600, bd=1)
        self.mainFrame.pack(fill=tk.BOTH, anchor=tk.N, expand = True)
        self.mainCanvas.create_window(0,0, window=self.mainFrame, anchor=tk.NW)
        
        Frame1.pack(fill=tk.BOTH)
        Frame2.pack(fill=tk.BOTH, expand = True)
        self.pack(fill=tk.BOTH, expand = True)

    def mainWheel(self, event):
        direction = mouseWheelDirect(event.num, event.delta)
        self.mainCanvas.yview_scroll(direction, "units")

    def headWheel(self, event):
        direction = mouseWheelDirect(event.num, event.delta)
        self.headCanvas.xview_scroll(direction, "units")

    def updateData(self, chkdata):

        self.data = chkdata
        for iframe in self.mainFrames: iframe.destroy()
        for iframe in self.headFrames: iframe.destroy()
        self.mainFrames = []
        self.headFrames = []

        font = tkFont.Font(family='Consolas', size=11)

        ilab, iframe = None, None
        for key, ivalue in self.data.items():
            
            value = ivalue.copy()
            text = ' %s \n %s '%(value.pop('headinfo'), value.pop('abstract'))
            ilab=tk.Label(self.headFrame, text=text, relief='raised', height=3, font=font)
            ilab.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)    
            ilab.bind("<MouseWheel>", self.headWheel)
            self.headFrames.append(ilab)

            iframe = tk.Frame(self.mainFrame)
            iframe.ui = self.ui
            iframe.pack(fill=tk.BOTH, expand=True) 

            id, type = value.pop('id'), value.pop('type')
            Algo = eval('EACHKAlgo.'+type)
            keys = value.keys() if ui.fullView else Algo.topKeys
            itree = EATreeView(iframe, value, keys, (id, type))
            itree.bind("<MouseWheel>", self.mainWheel)
            itree.pack(fill=tk.BOTH, expand=True) 
            self.mainFrames.append(iframe)

            ExtraFrames(self, iframe, type, value)

        if ilab and iframe:
            ilab.update()            
            x,w = ilab.winfo_x(), ilab.winfo_width()
            self.headCanvas['scrollregion']=(0,0,x+w,0) 
            iframe.update()                       
            y,h=iframe.winfo_y(), iframe.winfo_height(), 
            self.mainCanvas['scrollregion']=(0,0,0,y+h)

        # for iframe in self.mainFrames:
        #     print(iframe.winfo_geometry())



class EACHKUI(tk.Frame):
    def __init__(self, root, **kw):
        super().__init__(root, **kw)
        self.root = root
        self.pop = None

        self.algolist = AlgoList(self)
        self.algolist.pack(side=tk.LEFT,fill=tk.Y)

        self.tabview = ttk.Notebook(self)
        self.tabview.pack(side=tk.LEFT, expand = True, fill = tk.BOTH)

        self.algoSetPage = AlgoSetPage(self)
        self.algoResPage = AlgoResPage(self)

        self.tabview.add(self.algoSetPage, text = "  Validation Settings  ")
        self.tabview.add(self.algoResPage, text = "  Validation Results  ")

        self.menubar = tk.Menu(root)

        self.filemenu = tk.Menu(self.menubar, tearoff=False)
        self.filemenu.add_command(label="Open", command=self.open)
        self.filemenu.add_command(label="Save")
        self.filemenu.add_separator()
        self.filemenu.add_command(label="Quit", command=root.quit)
        self.menubar.add_cascade(label="File", menu=self.filemenu)

        self.editmenu = tk.Menu(self.menubar, tearoff=False)        
        self.editmenu.add_checkbutton(label='Full Data', command=self.cmdFullView)
        #self.editmenu.invoke(self.editmenu.index('Anchovy'))
        self.menubar.add_cascade(label="View", menu=self.editmenu)
        
        root.config(menu=self.menubar)

        self.data = {}
        self.fullView = False
        self.chkDir = os.path.expanduser('~')
        self.chkDir = './test'

    def open(self):
        file_path = filedialog.askopenfilename(title=u'select', initialdir=(self.chkDir))
        if not file_path: return

        self.chkDir = os.path.dirname(file_path)
        with open(file_path, 'r') as r:
            self.data = json.load(r)
            self.datainfo = self.data['info']
            self.data.pop('info')
        self.updateData()

    def cmdFullView(self): 
        self.fullView=not self.fullView
        self.updateData()

    def updateData(self):
        self.algolist.updateData(self.data)
        self.algoResPage.updateData(self.data)
        return self
        
root = tk.Tk()
root.geometry("1000x800")

ui = EACHKUI(root)
ui.pack(fill=tk.BOTH, expand = True)
ui.updateData()
ui.updateData()
tk.mainloop()