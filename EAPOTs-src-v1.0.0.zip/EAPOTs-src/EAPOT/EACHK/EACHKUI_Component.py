import tkinter as tk
from tkinter import ttk
import tkinter.font as tkFont

import matplotlib
matplotlib.use('Agg')
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, NavigationToolbar2Tk)
# Implement the default Matplotlib key bindings.
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

from mpl_toolkits.mplot3d import Axes3D
 
import numpy as np

def mouseWheelDirect(num, delta):
    if num == 5 or delta == -120:
        return 1
    elif num == 4 or delta == 120:
        return -1
    else:
        return 0


class EntryPopup(tk.Entry):

    def __init__(self, parent, rid, cid, text, readonly, **kw):
        ''' If relwidth is set, then width is ignored '''
        super().__init__(parent, **kw)
        self.tv = parent
        self.ui = parent.ui
        self.insert(0, text) 
        self.rid, self.cid = rid, cid
        
        if readonly: 
            self['state'] = 'readonly'
            self.selection_range(0, 'end')
        # self['readonlybackground'] = 'white'
        # self['selectbackground'] = '#1BA1E2'
        self['exportselection'] = False

        self.focus_force()
        self.bind("<Return>", self.save)
        self.bind("<Control-a>", self.select_all)
        self.bind("<Escape>", self.escape)

    def escape(self, event=None):
        self.ui.pop = None
        self.destroy()   

    def save(self, event=None):
        self.tv.set(self.rid, column=self.cid, value=self.get())
        self.ui.pop = None
        self.destroy()        

    def select_all(self, *ignore):
        ''' Set selection on the whole text '''
        self.selection_range(0, 'end')

        # returns 'break' to interrupt default key-bindings
        return 'break'

class EATreeView(ttk.Treeview):

    def __init__(self, parent, ialgo, keys, head, **kw):
        self.ui = parent.ui

        super().__init__(parent, show="headings", columns=('col1','col2'), height=len(keys), **kw)

        self.column('col1', width=150, anchor='w')
        self.column('col2', width=600, anchor='w')
        self.heading('col1', text=head[0])
        self.heading('col2', text=head[1])

        idx = 0
        for ikey in keys:
            self.insert('', idx, values=(ikey, str(ialgo[ikey])))
            idx += 1
    
        self.bind("<Double-1>", self.onDoubleClick) 


    def onDoubleClick(self, event):
        # close previous popups
        if self.ui.pop: self.ui.pop.save()

        rowid, column = self.identify_row(event.y), self.identify_column(event.x)
        if rowid=='' or column == '#1': return
        x, y, width, height = self.bbox(rowid, column)

        # place Entry popup properly         
        text = self.item(rowid, 'values')[-1]
        entryPopup = EntryPopup(self, rowid, column, text, True)
        entryPopup.place(x=x, y=y, anchor=tk.NW, relwidth=1)
        self.ui.pop = entryPopup
        self.selection_remove(rowid)

    # def set_cell_value(event): # 双击进入编辑状态
    #     rowid, column = tree.identify_row(event.y), tree.identify_column(event.x)
    #     if column == '#1': return
    #     x, y, width, height = tree.bbox(rowid, column)
    #     text = tree.item(rowid, 'values')[-1]

    #     entryedit = tk.Text(frame, width=600,height = 1)            
    #     entryedit.insert("insert", text)
    #     entryedit.place(x=x, y=y, anchor=tk.NW)

    #     def saveedit():
    #         tree.set(rowid, column=column, value=entryedit.get(0.0, "end"))
    #         entryedit.destroy()
    #         okb.destroy()
    #     okb = ttk.Button(frame, text='OK', width=4, command=saveedit)
    #     okb.place(x=x-40, y=y-3, anchor=tk.NW)

def ExtraFrames(algoResPage, iframe, type, value):
    if type == 'ElasticConstant':
        axis = ('xx','yy','zz','xy','xz','yz')
        data = [round(i, 4) for i in value['ElasticConstant']]
        Cij = ttk.Treeview(iframe, columns=[str(i) for i in range(6)], height=6)
        Cij.bind("<MouseWheel>", algoResPage.mainWheel)
        Cij.pack(fill=tk.BOTH, expand=True, padx = 20)
    
        Cij.column('#0', width=20, anchor=tk.CENTER)
        for icol in range(6):
            Cij.column('%d'%icol, width=20, anchor=tk.CENTER)
            Cij.heading('%d'%icol, text=axis[icol])
        
        for irow in range(6):
            Cij.insert('', irow, values=data[irow*6:(irow+1)*6], text=axis[irow])

    elif type == 'GammaSurface':

        if value["isSurface"]:
            fig = Figure(figsize=(5, 5))
            ax3d = Axes3D(fig)
            area, size = value["area"], value["size"]

            X = np.array(value['X']).reshape(size)
            Y = np.array(value['Y']).reshape(size)
            Z = np.array(value['Relaxed']).reshape(size)

            offset = -Z.max() * 0.5
            ax3d.plot_surface(X,Y,Z, cmap = 'hot')    
            ax3d.contourf(X, Y, Z, offset = offset, cmap = 'hot')

            ax3d.set_xlim(X.min(), X.max()); 
            ax3d.set_ylim(Y.min(), Y.max())
            ax3d.set_zlim(offset, None)           

            canvas = FigureCanvasTkAgg(fig, master=iframe)  # A tk.DrawingArea.
            canvas.draw()
            canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)
            canvas.get_tk_widget().bind("<MouseWheel>", algoResPage.mainWheel)
            ax3d.mouse_init()

        else:
            fig = Figure(figsize=(5, 4))
            fig_plot = fig.add_subplot(111)
            t = np.sqrt(np.array(value['X'])**2 + np.array(value['Y'])**2)
            u, r = np.array(value['Unrelaxed']), np.array(value['Relaxed'])
            fig_plot.plot(t, u)
            fig_plot.plot(t, r)
            fig_plot.set_xlim(t.min(), t.max()); 
            fig_plot.set_ylim(u.min(), u.max()*1.1); 

            canvas = FigureCanvasTkAgg(fig, master=iframe)  # A tk.DrawingArea.
            canvas.draw()
            canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)
            canvas.get_tk_widget().bind("<MouseWheel>", algoResPage.mainWheel)

            toolbar = NavigationToolbar2Tk(canvas, iframe)
            toolbar.update()
            canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)
            toolbar.bind("<MouseWheel>", algoResPage.mainWheel)

