from EACHK import PyChkBase
from EACHK import Script
import os, math

#########################################################################################################
#                                           CohensiveEnergy

class CohensiveEnergy(PyChkBase):

    def __init__(self, script, id):
        PyChkBase.__init__(self, script, id)

        self.type = 'CohensiveEnergy'
        self.restart = self.exportId + ".restart"        

        self.headinfo = ' a0    Ec   '
        self.abstract = lambda x: '%5.3f %5.3f '%(x.lat[0], x.Ec)
        

    def collectResult(self, data):
        data = tuple(map(float, data.split(',')))
        
        N = int(data[7])
        self.data = data
        self.Ec = -data[6]/N
        self.lat = (data[0], data[1], data[2], data[3], data[4], data[5])
        a0 = self.latInit

        mdict = {
            'id': self.id,
            'structure': os.path.basename(self.structureScript.rstrip()),
            'restart': self.exportId + '.restart', 
            'lattice': self.lat,
            'latticeInit': a0,
            'scale': (data[0]/a0[0], data[1]/a0[1], data[2]/a0[2]),
            'energy': data[6],
            'atomNum': N,
            'Ec': self.Ec,
            'headinfo': self.headinfo,
            'abstract': self.abstract(self),
        }
        return mdict
    topKeys = ['structure', 'lattice', 'latticeInit', 'scale', 'energy', 'atomNum', 'Ec']

    def createScript(self):
        PyChkBase.createScript(self)

        rep = self.replicate      
        self.latInit, self.triclinicFlag = PyChkBase.readLattice(self.structureScript.split()[1])
  
        cmd  = self.structureScript
        if rep[0] > 0:
            cmd += "replicate       %d %d %d\n"%(rep[0], rep[1], rep[2])
        
        if not self.triclinicFlag and self.relax.triclinicFlag:
            cmd += "change_box    all    triclinic\n"
        
        cmd += self.pairScript        
        cmd += PyChkBase.dumpForceEngCmd(self.dumpStep, self.exportId)
        cmd += self.relax.createFix() + self.relax.createScript()
        
        cmd += "variable        res    string    ${res}$(lx),$(ly),$(lz),$(xy),$(xz),$(yz),$(pe),$(atoms),\n";
        cmd += "write_restart   " + self.restart + "\n"

        self.cmdList[0] += cmd + "print @EACHK:${res}@\n"

#########################################################################################################
#                                           RoseFunction

class RoseFunction(PyChkBase):

    def __init__(self, script, id, begin, end, delta):
        PyChkBase.__init__(self, script, id)
       
        self.begin = begin
        self.end = end
        self.resValueCount = math.ceil((end-begin)/delta)
        self.type = 'RoseFunction'
        self.deltaStep = delta
        self.delta = delta*self.resValueCount
        
        self.sampleAxis = 1        
        self.neighborModifyScript = "neigh_modify every 1 delay 0 check yes\n"

        self.headinfo = '  Ec  '
        self.abstract = lambda x: '%5.3f '%-min(x.Eng)

    def setRoseParam(self, a0, v0, B, Ec):
        self.a0 = a0
        self.v0 = v0
        self.B = B
        self.Ec = -Ec

    def collectResult(self, data):
        
        # collect info from thermo print
        lo = data.find('Step PotEng')
        lo = data.find('\n', lo) + 1    # skip 'Step PotEng Lx Ly Lz'
        lo = data.find('\n', lo) + 1    # skip step0 b.c. step0 is equal to step1
        hi = data.find('\nLoop time')
        info = data[lo:hi].split()

        lo = data.find('with', hi) + 5
        hi = data.find('atoms', lo)
        N = int(data[lo:hi])
        count = self.resValueCount

        # 2. get energy with lattice data
        # note that there is a row misalignment problem when using fix loading
        # 7 -13.368567180772954 3.5 3.5 3.5
        # 8 -13.957501470474419 3.6 3.6 3.6
        # 9 -14.157712873657575 3.7 3.7 3.7 -> (3.6)
        # 10 -14.06192449900760 3.8 3.8 3.8
        self.Eng = tuple(map(lambda x: float(x)/N, info[1::5]))
        dx = (self.dx[0]/count,self.dx[1]/count,self.dx[2]/count)
        lat = [tuple(map(lambda x: float(x) - dx[0], info[2::5])),
               tuple(map(lambda x: float(x) - dx[1], info[3::5])),
               tuple(map(lambda x: float(x) - dx[2], info[4::5]))]     

        # 3. create ref
        eV = 1.6021765E-19 * 1E21
        roseCof = math.sqrt((9 * self.v0 * self.B) / (-self.Ec * eV))  
        roseCurve = tuple(map(lambda ai: (ai/self.a0-1)*roseCof, lat[self.sampleAxis]))
        roseCurve = tuple(map(lambda sx: self.Ec*(1+sx)*math.exp(-sx), roseCurve))

        # 4. pack as dict
        if   self.sampleAxis == 0: sample = 'lx'
        elif self.sampleAxis == 1: sample = 'ly'
        elif self.sampleAxis == 2: sample = 'lz'

        self.a0 = lat[self.sampleAxis]
        abstract = self.abstract(self)
        headinfo = self.headinfo.ljust(len(abstract), ' ')

        mdict = {
            'id': self.id,
            'structure': os.path.basename(self.structureScript.rstrip()),

            'box': lat,
            'energy': self.Eng,
            'roseFunction': roseCurve,
            'sample': sample,

            'headinfo': headinfo,
            'abstract': abstract,
        }
        return mdict
    topKeys = ['structure', 'box', 'energy', 'roseFunction', 'sample']

    def changeBox(self, ai):

        f = self.dblfmt        
        r = ai/self.sample
        a = self.latInit

        if self.triclinicFlag:            
            cmd = "change_box       all x final 0 %s y final 0 %s z final 0 %s "    \
                "xy final %s xz final %s yz final %s remap units box\n"%            \
                (f%(a[0]*r), f%(a[1]*r),f%(a[2]*r),f%(a[3]*r),f%(a[4]*r),f%(a[5]*r))
        else:
            cmd = "change_box		all x final 0 %s y final 0 %s z final 0 %s "    \
                "remap units box\n"%(f%(a[0]*r), f%(a[1]*r), f%(a[2]*r))

        return cmd

    def createScript(self):
        PyChkBase.createScript(self)

        f = self.dblfmt        
        rep = self.replicate   

        # 1. read Lattice Info
        struct = self.structureScript.split()[1]
        self.latInit, self.triclinicFlag = PyChkBase.readLattice(struct)
        a0 = self.latInit
        lref = a0[self.sampleAxis]
        dx = tuple(map(lambda x: x/lref*self.delta, a0[0:3]))
        self.dx = dx

        # 2. create structure and change box to start
        cmd  = self.structureScript
        if rep[0] > 0:
            cmd += "replicate       %d %d %d\n"%(rep[0], rep[1], rep[2])
            self.latInit = [a0[0]*rep[0], a0[1]*rep[1], a0[2]*rep[2]]
        
        self.sample = self.latInit[self.sampleAxis]
        cmd += self.changeBox(self.begin)
        
        # add pair,  neighbor and dump settings
        cmd += self.pairScript
        #cmd += self.neighborModifyScript
        cmd += PyChkBase.dumpForceEngCmd(self.dumpStep, self.exportId)

        # prepare run script
        if self.triclinicFlag:  
            cmd += "fix 1 all deform 1 x delta 0 %s y delta 0 %s z delta 0 %s "                     \
                "xy delta %s xz delta %s yz delta %s remap units box"% (f%dx[0], f%dx[1], f%dx[2],  \
                f%(dx[0]*a0[3]/a0[0]), f%(dx[0]*a0[4]/a0[0]), f%(dx[1]*a0[5]/a0[1]))
        else:
            cmd += "fix 1 all deform 1 x delta 0 %s y delta 0 %s z delta 0 %s "                     \
                "units box\n"%(f%dx[0], f%dx[1], f%dx[2])

        cmd += "thermo 1\n"
        cmd += "thermo_style custom step pe lx ly lz\n"
        cmd += 'thermo_modify format line "%%d %s %s %s %s"\n'%(f,f,f,f)

        cmd += "print @EACHK:\n"
        cmd += "run %d\n"%(self.resValueCount)        
        cmd += "print @\n"

        self.cmdList[0] += cmd

#########################################################################################################
#                                           StressCurve

class StressCurve(PyChkBase):

    @staticmethod
    def StressCurveAbstract(StsCv):
        thermo = StsCv.thermo
        return ' '.join(list(map(lambda x: '%5.2f'%(float(x[5])*1e-4), thermo)))

    def __init__(self, script, id, EcAlgo):
        PyChkBase.__init__(self, script, id)
       
        self.type = 'StressCurve'
        self.latc = [
            (0.94, 1.0, 1.0), (0.95, 1.0, 1.0), (0.96, 1.0, 1.0), 
            (0.97, 1.0, 1.0), (0.98, 1.0, 1.0), (0.99, 1.0, 1.0), 
            (1.00, 1.0, 1.0), (1.01, 1.0, 1.0), (1.02, 1.0, 1.0), 
            (1.03, 1.0, 1.0), (1.04, 1.0, 1.0), (1.05, 1.0, 1.0),
        ]
        self.EcRef = EcAlgo
        self.relax.customFix = 'fix		BoxRelax all box/relax y 0 z 0 vmax 0.001\n'
        
        self.sampleAxis = 0
        self.headinfo = ' '.join(list(map(lambda x: '%4.2g%%'%((x[0]-1)*100), self.latc)))
        self.abstract = self.StressCurveAbstract

    def collectResult(self, data):
        
        # collect info from thermo print
        lo = data.find('Step PotEng')

        self.thermo = []
        while lo >= 0:
            hi = data.find('\nLoop time', lo)
            info = data[lo:hi].split('\n')[-1].split()
            lo = data.find('Step PotEng', hi)
            self.thermo.append(info)

        N = len(self.thermo)

        mdict = {
            'id': self.id,
            'structure': os.path.basename(self.EcRef.restart),

            'energy': list(map(lambda x: float(x[1]), self.thermo)), 
            'lx': list(map(lambda x: float(x[2]), self.thermo)), 
            'ly': list(map(lambda x: float(x[3]), self.thermo)), 
            'lz': list(map(lambda x: float(x[4]), self.thermo)),             
            'pxx': list(map(lambda x: float(x[5])*1e-4, self.thermo)), 
            'pyy': list(map(lambda x: float(x[6])*1e-4, self.thermo)), 
            'pzz': list(map(lambda x: float(x[7])*1e-4, self.thermo)), 

            'headinfo': self.headinfo,
            'abstract': self.abstract(self),
        }
        return mdict
    topKeys = ['structure', 'lx', 'ly', 'lz', 'pxx', 'pyy', 'pzz']

    def createScript(self):
        PyChkBase.createScript(self)
        f = self.dblfmt
        self.cmdList += ['']
        
        # 2. create structure and change box to start
        cmd  = "read_restart    " + self.EcRef.restart + "\n"
        cmd += self.pairScript

        # add pair and dump settings
        cmd += "thermo %d\n"%self.relax.minNStep
        cmd += "thermo_style custom step pe lx ly lz pxx pyy pzz\n"
        cmd += 'thermo_modify format line "%%d %s %s %s %s %s %s %s"\n'%(f,f,f,f,f,f,f)
        cmd += self.relax.createFix()

        self.cmdList[0] += cmd

    def updateScript(self):
           
        f = self.dblfmt
        rep = self.replicate
        a0 = self.EcRef.lat        

        cmd = ''
        if rep[0] > 0:
            cmd += "replicate       %d %d %d\n"%(rep[0], rep[1], rep[2])
            a0 = [a0[0]*rep[0], a0[1]*rep[1], a0[2]*rep[2]]

        if self.EcRef.relax.triclinicFlag:
            print("not support for triclinic box")
            return

        cmd += "print @EACHK:\n"

        for rat in self.latc:
            # prepare run script
            cmd += "change_box		all x final 0 %s y final 0 %s z final 0 %s remap units box\n"%\
                (f%(a0[0]*rat[0]), f%(a0[1]*rat[1]), f%(a0[2]*rat[2]))
            cmd += self.relax.createScript()   
        cmd += "print @\n"

        self.a0 = a0
        self.cmdList[1] += cmd

#########################################################################################################
#                                           ElasticConstant
class ElasticConstant(PyChkBase):

    headinfo3 = ' C11   C12   C44  '
    abstract3 = lambda x: '%5.4g %5.4g %5.4g '%\
        (x.short[0], x.short[1], x.short[2])

    headinfo6 = ' C11   C12   C13   C33   C44   C66  '
    abstract6 = lambda x: '%5.4g %5.4g %5.4g %5.4g %5.4g %5.4g '%\
        (x.short[0], x.short[1], x.short[2], x.short[3], x.short[4], x.short[5]) 

    def __init__(self, script, id, restart, collect):

        PyChkBase.__init__(self, script, id)

        self.delta = 1.0e-8
        self.type = 'ElasticConstant'
        self.relax.relaxBox = False
        self.relax.relaxAtom = False
        self.relax.runExtraScript = "post no"
        self.boxTiltLarge = False

        self.restartRef = restart
        self.loadMethod = self.changeBoxMethod
        self.collect = collect
        collect(self, True)

    @staticmethod
    def collect3(algo, initFlag = False):
        if initFlag: 
            algo.headinfo = ElasticConstant.headinfo3
            algo.abstract = ElasticConstant.abstract3
        else:
            C = algo.C
            C11 = (C[0][0] + C[1][1] + C[2][2]) / 3
            C12 = (C[0][1] + C[1][0] + C[0][2] + C[2][0]) * 0.25
            C44 = (C[3][3] + C[4][4] + C[5][5]) / 3
            algo.short = (C11, C12, C44)

    @staticmethod
    def print(C, format = '%5.0f\t'):
        formatLine = format*6
        for row in C: print(formatLine%tuple(row))

    @staticmethod
    def collect6(algo, initFlag = False):
        if initFlag: 
            algo.headinfo = ElasticConstant.headinfo6
            algo.abstract = ElasticConstant.abstract6
        else:
            C = algo.C
            C11 = (C[0][0] + C[1][1]) * 0.5
            C12 = (C[0][1] + C[1][0]) * 0.5
            C13 = (C[0][2] + C[2][0] + C[1][2] + C[2][1]) * 0.25
            C33 = C[2][2]
            C44 = (C[3][3] + C[4][4]) * 0.5
            C66 = C[5][5]
            algo.short = (C11, C12, C13, C33, C44, C66)
        
    def createScript(self):
        PyChkBase.createScript(self)

        cmd  = ''
        if self.boxTiltLarge: cmd += 'box tilt large\n'
        cmd += "read_restart    " + self.restartRef + "\n"        
        cmd += "change_box      all    triclinic\n"

        self.cmdList[0] += cmd
        self.loadMethod()
        self.cmdList[0] +="print @EACHK:${res}@\n"
        
    def changeBoxMethod(self):
        pdelta = self.dblfmt%self.delta
        pdelta2 = self.dblfmt%(self.delta*2)

        post  = " remap units box\n"
        post += self.relax.createFix() + self.relax.createScript()
        post += "variable        res    string    ${res}$(pxx),$(pyy),$(pzz),$(pyz),$(pxz),$(pxy),\n"

        cmd  = self.pairScript
        cmd += "thermo_style    custom lx ly lz pxx pyy pzz pyz pxz pxy\n"        

        cmd +="change_box all x delta 0 $(-%s*lx)                    "%(pdelta)         + post
        cmd +="change_box all x delta 0  $(%s*lx)"%pdelta2                              + post

        cmd +="change_box all y delta 0 $(-%s*ly) x delta 0 $(-%s*lx)"%(pdelta, pdelta) + post
        cmd +="change_box all y delta 0  $(%s*ly)"%pdelta2                              + post

        cmd +="change_box all z delta 0 $(-%s*lz) y delta 0 $(-%s*ly)"%(pdelta, pdelta) + post
        cmd +="change_box all z delta 0  $(%s*lz)"%pdelta2                              + post

        cmd +="change_box all yz delta  $(-%s*lz) z delta 0 $(-%s*lz)"%(pdelta, pdelta) + post
        cmd +="change_box all yz delta   $(%s*lz)"%pdelta2                              + post

        cmd +="change_box all xz delta  $(-%s*lz) yz delta  $(-%s*lz)"%(pdelta, pdelta) + post
        cmd +="change_box all xz delta   $(%s*lz)"%pdelta2                              + post
        
        cmd +="change_box all xy delta  $(-%s*ly) xz delta  $(-%s*lz)"%(pdelta, pdelta) + post
        cmd +="change_box all xy delta   $(%s*ly)"%pdelta2                              + post
                
        self.cmdList[0] += cmd

    def restartMethod(self):

        pdelta = self.dblfmt%self.delta
        restart = self.exportId + ".restart"
        cmd  = self.pairScript + "write_restart   " + restart + "\n"

        pre  = "clear\nunits           metal\n"
        if self.boxTiltLarge: pre += 'box tilt large\n'
        pre += "read_restart    " + restart + " remap\n" + self.pairScript
        pre += "thermo_style    custom lx ly lz pxx pyy pzz pyz pxz pxy\n" 

        post  = " remap units box\n"
        post += self.relax.createFix() + self.relax.createScript()
        post += "variable        res string ${res}$(pxx),$(pyy),$(pzz),$(pyz),$(pxz),$(pxy),\n"       

        cmd += pre + "change_box all x delta 0 $(-%s*lx)"%pdelta + post
        cmd += pre + "change_box all x delta 0  $(%s*lx)"%pdelta + post

        cmd += pre + "change_box all y delta 0 $(-%s*ly)"%pdelta + post
        cmd += pre + "change_box all y delta 0  $(%s*ly)"%pdelta + post

        cmd += pre + "change_box all z delta 0 $(-%s*lz)"%pdelta + post
        cmd += pre + "change_box all z delta 0  $(%s*lz)"%pdelta + post

        cmd += pre + "change_box all yz delta  $(-%s*lz)"%pdelta + post
        cmd += pre + "change_box all yz delta   $(%s*lz)"%pdelta + post

        cmd += pre + "change_box all xz delta  $(-%s*lz)"%pdelta + post
        cmd += pre + "change_box all xz delta   $(%s*lz)"%pdelta + post

        cmd += pre + "change_box all xy delta  $(-%s*ly)"%pdelta + post
        cmd += pre + "change_box all xy delta   $(%s*ly)"%pdelta + post        
                
        self.cmdList[0] += cmd


    def collectResult(self, data):
        data = tuple(map(float, data.split(',')))
        coefficient = 1.0 / self.delta * 0.0001 * 0.5
        C = [[0,0,0,0,0,0,] for i in range(6)]
        for i in range(6):
            for j in range(6):
                C[i][j] = (data[12 * i + j] - data[12 * i + 6 + j]) * coefficient
        self.C = C

        self.collect(self, False)

        mdict = {
            'id': self.id,
            'structure': os.path.basename(self.restartRef),
            'ElasticConstant': C[0]+C[1]+C[2]+C[3]+C[4]+C[5], 
            'short': self.short,
            'headinfo': self.headinfo,
            'abstract': self.abstract(self),
            
        }
        return mdict
    topKeys = ['structure', 'ElasticConstant', 'short']

#########################################################################################################
#                                           VacancyEnergy
class VacancyEnergy(PyChkBase):

    def __init__(self, script, id, restart):
        PyChkBase.__init__(self, script, id)

        self.type = 'VacancyEnergy'
        self.relax.relaxBox = False
        self.restartRef = restart
        self.pos = (1.25, 1.25, 1.25)
        self.replicate = [4, 4, 4]

        self.headinfo = "Ev/u Ev/r "
        self.abstract = lambda x: '%4.2f %4.2f '% (x.Evu, x.Evr)

    def collectResult(self, data):
        data = tuple(map(float, data.split(',')))

        Eref = data[0] / data[1] * (data[1] - 1)
        self.Evu = data[2] - Eref
        self.Evr = data[3] - Eref
        
        mdict = {
            'id': self.id,
            'structure': os.path.basename(self.restartRef),
            'Unrelaxed': self.Evu, 
            'Relaxed': self.Evr, 
            'replicate': self.replicate,
            'headinfo': self.headinfo,
            'abstract': self.abstract(self),
        }
        return mdict
    topKeys = ['structure', 'Unrelaxed', 'Relaxed', 'replicate']

    def createScript(self):
        PyChkBase.createScript(self)

        fmt = self.dblfmt
        rep = self.replicate        
        
        cmd  = "read_restart    " + self.restartRef + "\n"
        cmd += "replicate       %d %d %d\n"%(rep[0], rep[1], rep[2])
        cmd += self.pairScript
        
        cmd += "run             0\n";
        cmd += "variable        res    string    ${res}$(pe),$(atoms),\n"
        
        cmd += "variable        a equal $(xlo+lx*%s)\n"%(fmt%(self.pos[0]/rep[0]))
        cmd += "variable        b equal $(ylo+ly*%s)\n"%(fmt%(self.pos[1]/rep[1]))
        cmd += "variable        c equal $(zlo+lz*%s)\n"%(fmt%(self.pos[2]/rep[2]))
        cmd += "region          centpoint block $(v_a-0.5) $(v_a+0.5) $(v_b-0.5) "\
               "$(v_b+0.5) $(v_c-0.5) $(v_c+0.5) units box\n"
        cmd += "delete_atoms    region centpoint\n"
        
        
        cmd += "run             0\n"
        cmd += "variable        res    string    ${res}$(pe),\n"
        
        cmd += PyChkBase.dumpForceEngCmd(self.dumpStep, self.exportId)
        cmd += self.relax.createFix() + self.relax.createScript()
        cmd += "variable        res    string    ${res}$(pe),\n"

        self.cmdList[0] += cmd + "print @EACHK:${res}@\n"

#########################################################################################################
#                                           CohensiveBaseAlgo

class CohensiveBaseAlgo(PyChkBase):

    def __init__(self, script, id, refId):
        PyChkBase.__init__(self, script, id)

        self.refId = refId
        self.relax.relaxBox = False
        

    def updateScript(self):
         
        f = self.dblfmt
        r = self.script.res[self.refId]['scale']   
        self.ratio = r
        a0 = self.latInit

        if self.triclinicFlag:            
            self.cmdList[1] = "change_box		all x final 0.0 %s y final 0.0 %s z final 0.0 %s "      \
            "xy final %s xz final %s yz final %s remap units box\n"%                                    \
            (f%(r[0]*a0[0]), f%(r[1]*a0[1]), f%(r[2]*a0[2]), f%(r[0]*a0[3]), f%(r[0]*a0[4]), f%(r[1]*a0[5]))
        else:
            self.cmdList[1] = "change_box		all x final 0.0 %s y final 0.0 %s z final 0.0 %s "      \
            "remap units box\n"%(f%(r[0]*a0[0]), f%(r[1]*a0[1]), f%(r[2]*a0[2]))

    def createScript(self):
        PyChkBase.createScript(self)
        self.cmdList += ['', '']

        struct = self.structureScript.split()[1]
        self.latInit, self.triclinicFlag = PyChkBase.readLattice(struct)

#########################################################################################################
#                                           SurfaceEnergy

class SurfaceEnergy(PyChkBase):

    def __init__(self, script, id, refId):
        CohensiveBaseAlgo.__init__(self, script, id, refId)

        self.zcut = 30
        self.type = 'SurfaceEnergy'
        self.relax.relaxBox = False
        self.replicate = [1, 1, 8]

        self.headinfo = "Es/u Es/r "
        self.abstract = lambda x: '%4.0f %4.0f '% (x.Evu, x.Evr)


    def collectResult(self, data):
        data = tuple(map(float, data.split(',')))

        ratio = 16020 / 2 / data[3]
        self.Evu = (data[1] - data[0])*ratio
        self.Evr = (data[2] - data[0])*ratio

        mdict = {
            'id': self.id,
            'structure': os.path.basename(self.structureScript.rstrip()),
            'Unrelaxed': self.Evu,
            'Relaxed': self.Evr,
            'replicate' : self.replicate,
            'headinfo': self.headinfo,
            'abstract': self.abstract(self),
        }
        return mdict
    topKeys = ['structure', 'Unrelaxed', 'Relaxed', 'replicate']

    def updateScript(self):
        CohensiveBaseAlgo.updateScript(self)
        
        self.replicate[2] = math.ceil(self.zcut/(self.ratio[2]*self.latInit[2]))
        rep = self.replicate
        self.cmdList[1] += "replicate       %d %d %d\n"%(rep[0], rep[1], rep[2])

    def createScript(self):
        
        CohensiveBaseAlgo.createScript(self)
        self.cmdList[0] += self.structureScript

        cmd  = self.pairScript

        cmd += "run             0\n"
        cmd += "variable        res string ${res}$(pe),\n"
        cmd += "change_box      all z final -10.0 $(lz+10) units box\n"

        cmd += "run             0\n"
        cmd += "variable        res string ${res}$(pe),\n"
        
        cmd += PyChkBase.dumpForceEngCmd(self.dumpStep, self.exportId)
        cmd += self.relax.createFix() + self.relax.createScript()
        cmd += "variable        res string ${res}$(pe),$(lx*ly),\n"

        self.cmdList[2] = cmd + "print @EACHK:${res}@\n"

#########################################################################################################
#                                           GammaSurface

class GammaSurface(PyChkBase):

    headbcc = 'U:Yu R:Yu '
    abstbcc = lambda x: '%-4.0f %-4.0f '%(x.Yu[3],x.Yr[3])
    pontbcc = (('Unstable',), (3,))
  
    headfcc = 'U:Yu   Ys   Yt2  R:Yu   Ys   Yt1  Yt2  Yt3  '
    abstfcc = lambda x: '%-5.1f %-5.1f %-4.0f %-5.1f %-5.1f %-4.0f %-4.0f %-4.0f '%(
            x.Yu[1],x.Yu[2],x.Yu[4],  x.Yr[1],x.Yr[2],x.Yr[3],x.Yr[4],x.Yr[5])
    pontfcc = (('Unstable', 'Stable', 'Top1', 'Top2', 'Top3'), tuple(range(1,6)))


    headdia = '  U:Yu   Ys    Top    R:Yu  Ys  Yu110  Top  '
    abstdia = lambda x: '%-8.2e %-3.1f %-8.2e %-5.2f %-3.1f %-5.4g %-5.4g '%(
            x.Yu[1]/1000,x.Yu[2]/1000,x.Yu[4]/1000,  x.Yr[1]/1000,x.Yr[2]/1000,x.Yr[3]/1000,x.Yr[4]/1000)
    pontdia = (('Unstable', 'Stable', 'Yu110', 'Top2', 'Top3'), tuple(range(1,6)))

    def __init__(self, script, id, refId):
        CohensiveBaseAlgo.__init__(self, script, id, refId)

        self.zcut = 30
        self.baseEng = 0
        self.type = 'GammaSurface'
        self.relax.relaxBox = False
        self.replicate = [1, 1, 8]
        self.replicateScript = None
        self.layerRange = [ 0.15, 0.495, 0.85 ]
        self.size = [ 0, 0 ]
        self.isSurface = False

        self.track = []

        self.pointInfo = GammaSurface.pontfcc
        self.headinfo  = GammaSurface.headfcc
        self.abstract  = GammaSurface.abstfcc

    def collectResult(self, data):
        data = tuple(map(float, data.split(',')))

        N = len(self.track)
        Ru = data[self.baseEng*2]
        Rr = data[self.baseEng*2+1]
        ratio = 16020 / (data[-1] * data[-2])

        self.Yu = list(map(lambda i:(i-Ru)*ratio, data[0:-2:2]))
        self.Yr = list(map(lambda i:(i-Rr)*ratio, data[1:-2:2]))
        lx, ly = data[-2], data[-1]

        mdict = {
            'id': self.id,
            'structure': os.path.basename(self.structureScript.rstrip()),
            'size': self.size,
            'replicate' : self.replicate,
            'isSurface': self.isSurface,

            'X': list(map(lambda x: x[0]*lx, self.track)),
            'Y': list(map(lambda x: x[1]*ly, self.track)),
            'Unrelaxed': self.Yu,
            'Relaxed': self.Yr,

            'area': data[-2:],
            'pointName': self.pointInfo[0], 
            'pointData': [self.Yr[idx] for idx in self.pointInfo[1]], 
            'headinfo': self.headinfo,
            'abstract': self.abstract(self),            
        }  
        return mdict
    topKeys = ['structure', 'size', 'replicate', 'X', 'Y', 'Unrelaxed', 'Relaxed', 'area', 'pointName', 'pointData']
      
    def createScan1d(self, x1, x2, dx):
        for i in range(x1, x2):
            self.track.append((i*dx, 0.0))
        self.size = [1, x2 - x1]

    def createScan2d(self, x1, x2, dx, y1, y2, dy):
        for i in range(y1, y2):
            for j in range(x1, x2):
                self.track.append((j*dx, i*dy)) 
        self.size = [y2 - y1, x2 - x1]
        self.isSurface = True

    def updateScript(self):
        CohensiveBaseAlgo.updateScript(self)
        
        self.replicate[2] = math.ceil(self.zcut/(self.ratio[2]*self.latInit[2]))

        if self.replicateScript:
            self.replicate = self.replicateScript(self.replicate)

        rep = self.replicate
        self.cmdList[1] += "replicate       %d %d %d\n"%(rep[0], rep[1], rep[2])

    def createRestartScript(self):

        self.cmdList[0] += self.structureScript

        fmt = self.dblfmt 
        srange = [fmt%i for i in self.layerRange]

        cmd  = "variable    cenlayer equal $(" + srange[1] + "*lz)\n"
        cmd += "region        upperAtoms block INF INF INF INF $(" + srange[2] + "*lz) INF  units box\n"
        cmd += "region        lowerAtoms block INF INF INF INF INF $(" + srange[0] + "*lz)  units box\n"
        cmd += "region        upintAtoms block INF INF INF INF ${cenlayer} INF  units box\n"
        cmd += "region        lointAtoms block INF INF INF INF INF ${cenlayer}  units box\n"

        # define group
        cmd += "group        upperAtoms region upperAtoms\n"
        cmd += "group        lowerAtoms region lowerAtoms\n"
        cmd += "group        upintAtoms region upintAtoms\n"
        cmd += "group        lointAtoms region lointAtoms\n"
        cmd += "group        fixedatoms union  upperAtoms lowerAtoms\n"
        cmd += "group        mobilatoms subtract all fixedatoms\n"

        #calculate initial energy
        cmd += "change_box    all z final -10.0 $(10.0+lz) units box\n"
        cmd += self.pairScript
        cmd += "write_restart    " + self.exportId + ".restart\n"
        self.restartLoadScript = "read_restart    " + self.exportId + ".restart remap\n";

        self.cmdList[2] += cmd

    def createScript(self):

        CohensiveBaseAlgo.createScript(self)
        self.createRestartScript()

        cmd = ''
        fmt = self.dblfmt 
        dumpDir = self.exportId + ".%02d"

        for i, p in enumerate(self.track):
            # initialize
            cmd += "clear\n" + self.restartLoadScript + self.pairScript

            # displace atoms        
            cmd += "displace_atoms  upintAtoms move $(lx*%s) $(ly*%s) 0.0 " \
                "units box\n"%(fmt%p[0], fmt%p[1])

            cmd += "run         0\n"
            cmd += "variable    res string ${res}$(pe),\n"

            # relax along y axis
            cmd += PyChkBase.dumpForceEngCmd(self.dumpStep, dumpDir%i)

            cmd += self.relax.createFix()
            cmd += "fix        1 fixedatoms setforce 0.0 0.0 0.0\n"
            cmd += "fix        2 mobilatoms lineforce 0.0 0.0 1.0\n"
            cmd += self.relax.createScript()
            cmd += "variable    res string ${res}$(pe),\n"

        cmd += "variable    res string ${res}$(lx),$(ly),\n"
        self.cmdList[2] += cmd + "print @EACHK:${res}@\n"