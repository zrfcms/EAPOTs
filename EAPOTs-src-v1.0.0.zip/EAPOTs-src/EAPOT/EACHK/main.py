import EACHK as Chk
import EACHKChk
import EACHKTool
import EACHKAlgo
import EACHKComb
import EACHKInter


def fcc():

    suffix = '.Cu'
    lammpsDir = '../../LAMMPS'    

    # 创建一个校核任务，每个任务包含多个子校核项
    Inter = EACHKInter.EACHKInter(lammpsDir, 'chkdata/', ['Cu',], 'eam/alloy')
    script = Inter.script

    # 添加fcc晶格常数和聚合能校核，'Ec.fcc.Cu'为此校核项的id
    Ecfcc      = EACHKAlgo.CohensiveEnergy(script, 'Ec.fcc'+suffix)
    # 设置松弛目标压强，单位是kBar, 1GPa = 1e4 kBar
    Ecfcc.relax.stress = [0*1e4, 0*1e4, 0*1e4, 0.0, 0.0, 0.0]
    # 打开该标志表示重启LAMMPS，以使得后面的结果可以使用松弛的晶格常数
    Ecfcc.SeparatorFlag = 1

    # 添加fcc晶格常数和聚合能校核，'Ec.fcc'为此校核项的id
    Evfcc      = EACHKAlgo.VacancyEnergy(script, "Ev.fcc"+suffix, Ecfcc.restart)
    # 删除原子位置(单位是lattice)，和replicate次数
    Evfcc.pos, Evfcc.replicate = (1.25, 1.25, 1.25), [4, 4, 4]

    # 添加fcc晶格常数和聚合能校核，'Ec.fcc'为此校核项的id
    Ela = EACHKAlgo.ElasticConstant
    Elafcc     = Ela(script, "Ela.fcc"+suffix, Ecfcc.restart, Ela.collect3)

    # 校核层错能曲线，共校核6个点。可以使用2d将校核层错能面
    Ysfcc111   = EACHKAlgo.GammaSurface(script,  "Ys.fcc.111"+suffix, Ecfcc.id)
    # Ysfcc111.createScan2d(0, 25, 1.0 / 24, 0, 19, 1.0 / 18)
    Ysfcc111.createScan1d(0, 49, 1.0 / 48)
    Ysfcc111.abstract = lambda x: '%-5.1f %-5.1f %-4.0f %-5.1f %-5.1f %-4.0f %-4.0f %-4.0f '%(
            x.Yu[2],x.Yu[4],x.Yu[8],  x.Yr[2],x.Yr[4],x.Yr[6],x.Yr[8],x.Yr[10])

    # 校核层表面能
    Esfcc100   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.100"+suffix, Ecfcc.id)
    Esfcc100.headinfo = "S100 u/r  "
    Esfcc110   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.110"+suffix, Ecfcc.id)
    Esfcc110.headinfo = "S110 u/r  "
    Esfcc111   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.111"+suffix, Ecfcc.id)
    Esfcc111.headinfo = "S111 u/r  "
    Esfcc112   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.112"+suffix, Ecfcc.id)
    Esfcc112.headinfo = "S112 u/r  "        
    script.algo[-1].SeparatorFlag = 1

    # 添加校核势函数类型命令
    Inter.pair = 'pair_style %s\npair_coeff * * ${Pair0} %s\n'%(Inter.type, 'Cu')
    EACHKComb.addpairstruct(script, Inter.pair, 0, len(script.algo))

    # 初始化，创建LAMMPS脚本
    print(Inter.init(None))
    # 输出LAMMPS脚本供参考
    Inter.script.printScript('script.in')

    pot = 'test/FeCuNi'
    # 运行LAMMPS，并解析日志得到校核结果
    print(Inter.run([pot + '.eam'], pot + '.chk.json'))
    print('cost %.3fs'%(Inter.script.dt), end = '')



def check():
    script = EACHKChk.check(True, True, [] )
    #script = EACHKChk.check(True, False, ['CohensiveEnergy','GammaSurface',] )

def InterTest():
    inter = EACHKInter.EACHKInter('../../LAMMPS', 'chkdata/', ('Mg',), 'eam/alloy')
    pair = inter.add('hcp', inter.ele)   

    GSF = inter.script.algo[-2]
    GSF.track = []
    GSF.createScan1d(0, 48, 1.0 / 48)
    GSF.abstract = lambda x: '%-5.1f %-5.1f %-4.0f %-5.1f %-5.1f %-4.0f %-4.0f %-4.0f '%(
            x.Yu[6],x.Yu[16],x.Yu[32],  x.Yr[8],x.Yr[16],x.Yr[24],x.Yr[32],x.Yr[40])

    pot = 'C:/Files/work-EAPOT/Exp-CuTaMg/Figure/Mg.000700'
    print(inter.init(None))
    print(inter.run([pot + '.eam'], pot + '.chk.json'))

#fcc()
check()

    