#from matplotlib import pyplot as plt 
import numpy as np
import math, os, shutil
import time

import ctypes
ReadEAMAlloy = ctypes.CDLL(os.path.join(os.path.dirname(__file__), 'ReadEAMAlloy.so'))
ReadEAMAlloy.load.argtypes = (ctypes.c_char_p, 
    np.ctypeslib.ndpointer(ndim=2,flags="C_CONTIGUOUS"),
    np.ctypeslib.ndpointer(ndim=2,flags="C_CONTIGUOUS"),
    np.ctypeslib.ndpointer(ndim=2,flags="C_CONTIGUOUS"),
    ctypes.c_size_t, ctypes.c_size_t, ctypes.c_size_t, ctypes.c_size_t)

class EAMFile(object):

    def __init__(self, File, id, *, resetPhi = False, fastMode = False, readByNumpy = False):
        with open(File, 'r') as f:
            f.readline()
            f.readline()
            f.readline()

            self.element = f.readline().split()[1:]
            self.NEle = len(self.element)
            self.NPair = int(self.NEle*(self.NEle+1)/2)

            t = f.readline().split()
            fmt = [int(t[0]), float(t[1]), int(t[2]), float(t[3]), float(t[4])]
            self.fmt = fmt      

            f.readline()
            self.LineWordNum = len(f.readline().split())

        self.id = id
        self.file = File
        
        if readByNumpy:
            self.numpy_read(fastMode)
        else:
            self.cpp_read(fastMode)

        self.rhot = np.arange(fmt[0])*fmt[1]
        self.r    = np.arange(fmt[2])*fmt[3]
        if resetPhi:
            self.phi[:,1:] = self.phi[:,1:]/self.r[1:]
        self.resetPhi = resetPhi

        # print(self.emb.shape)
        # print(self.rho.shape)
        # print(self.phi.shape)
        # print('%d %.17g %s %.17g %.17g '%tuple(self.fmt))
 
    def cpp_read(self, fastMode):
        self.emb = np.zeros((self.NEle,  self.fmt[0]))
        self.rho = np.zeros((self.NEle,  self.fmt[2]))
        self.phi = np.zeros((self.NPair, self.fmt[2]))
        ReadEAMAlloy.load(bytes(self.file, 'utf-8'), self.emb, self.rho, self.phi,
            self.NEle, self.NPair, self.fmt[0], self.fmt[2])

    def numpy_read(self, fastMode):
    
        LineWordNum = self.LineWordNum
        if fastMode:
            self.fmt[0] = math.ceil(self.fmt[0]/LineWordNum)
            self.fmt[2] = math.ceil(self.fmt[2]/LineWordNum)
            self.fmt[1] = self.fmt[1]*LineWordNum
            self.fmt[3] = self.fmt[3]*LineWordNum

        NextRead = 5
        NEle = self.NEle        
        Nemb, Nrho = self.fmt[0], self.fmt[2]

        self.emb = np.zeros((0, Nemb))
        self.rho = np.zeros((0, Nrho))

        if fastMode:
            data = np.loadtxt(self.file, skiprows=NextRead, usecols=0)

            Next, Nembrho = 0, Nemb + Nrho
            for i in range(NEle):
                Next += 1
                self.emb = np.r_[self.emb, np.reshape(data[Next:Next+Nemb], (1, Nemb))]
                self.rho = np.r_[self.rho, np.reshape(data[Next+Nemb:Next+Nembrho], (1, Nrho))]  
                Next += Nembrho

            self.phi = np.reshape(data[Next:], (self.NPair, Nrho))
        else:
            LineReadNum = math.ceil((Nemb + Nrho)/LineWordNum)
            for i in range(NEle):
                NextRead += 1
                data = np.loadtxt(self.file, skiprows=NextRead, max_rows=LineReadNum)
                data = np.reshape(data, (1, Nemb + Nrho))
    
                self.emb  = np.r_[self.emb, data[:, :Nemb]]
                self.rho  = np.r_[self.rho, data[:, Nemb:]]
                NextRead += LineReadNum 

            data = np.loadtxt(self.file, skiprows=NextRead)
            self.phi = np.reshape(data, (int(NEle*(NEle+1)/2), Nrho))
    
    def femb(self, itype, lr, order=0):
        p = lr * self.list_rdrho + 1.0
        m = int(p)
        m = max(1, min(m, self.nrho - 1));
        p -= m
        p = min(p, 1.0)
        coeff = self.frho_spline[self.type2frho[itype]][m]
        if (lr > self.list_rhomax):
            if order == 0:
                fp = (coeff[0] * p + coeff[1]) * p + coeff[2]
                f = ((coeff[3] * p + coeff[4]) * p + coeff[5]) * p + coeff[6]
                return f + fp * (lr - self.list_rhomax)
            elif order == 1:
                return (coeff[0]*p + coeff[1])*p + coeff[2]
            else:
                return 0.0
        else:
            if order == 0:
                return ((coeff[3] * p + coeff[4]) * p + coeff[5]) * p + coeff[6]
            elif order == 1:
                return (coeff[0]*p + coeff[1])*p + coeff[2]
            else:
                return (2*coeff[0]*p + coeff[1]) * self.list_rdrho

    def frho(self, itype, jtype, r, order=0):
        if r >= self.cutmax: return 0

        p = r * self.list_rdr + 1.0
        m = int(p)
        m = min(m, self.nr - 1)
        p -= m
        p = min(p, 1.0)

        coeff = self.rhor_spline[self.type2rhor[itype][jtype]][m]

        if order == 0:
            return ((coeff[3] * p + coeff[4]) * p + coeff[5]) * p + coeff[6]
        elif order == 1:
            return (coeff[0]*p + coeff[1])*p + coeff[2]
        else:
            return (2*coeff[0]*p + coeff[1]) * self.list_rdr

    def fphi(self, itype, jtype, r, order=0):

        if r >= self.cutmax: return 0

        p = r * self.list_rdr + 1.0
        m = int(p)
        m = min(m, self.nr - 1)
        p -= m
        p = min(p, 1.0)

        recip = 1.0 / r
        coeff = self.z2r_spline[self.type2z2r[itype][jtype]][m]
        z2 = ((coeff[3] * p + coeff[4])*p + coeff[5])*p + coeff[6]

        if order == 0:            
            return z2*recip
        elif order == 1:
            z2p = (coeff[0]*p + coeff[1])*p + coeff[2]
            return z2p*recip - z2*recip*recip
        else:
            z2p = (coeff[0]*p + coeff[1])*p + coeff[2]
            z2p2 = (2*coeff[0]*p + coeff[1]) * self.list_rdr
            return z2p2*recip - 2*z2p*recip*recip + 2*z2*recip*recip*recip

    def array2spline(self):

        if self.resetPhi: print("Error: resetPhi = true")

        self.type2frho = np.zeros(self.NEle+1).astype(np.int)
        self.type2rhor = np.zeros((self.NEle+1, self.NEle+1)).astype(np.int)
        self.type2z2r  = np.zeros((self.NEle+1, self.NEle+1)).astype(np.int)

        self.cutmax = self.fmt[4]
        self.list_rhomax = self.fmt[0] * self.fmt[1]
        self.nrho, self.nr = self.fmt[0], self.fmt[2]
        self.drho, self.dr = self.fmt[1], self.fmt[3]

        self.nfrho = self.NEle
        self.nrhor = self.NEle
        self.nz2r = self.NPair
        
        self.list_rdr = 1.0 / self.dr
        self.list_rdrho = 1.0 / self.drho

        self.frho_spline = np.zeros((self.nfrho, self.nrho + 1, 7))
        self.rhor_spline = np.zeros((self.nrhor, self.nr + 1, 7))
        self.z2r_spline  = np.zeros((self.nz2r,  self.nr + 1, 7))

        for i in range(self.nfrho):
            self.frho_spline[i] = self.interpolate(self.nrho, self.drho, self.emb[i])
        for i in range(self.nrhor):
            self.rhor_spline[i] = self.interpolate(self.nr, self.dr, self.rho[i])
        for i in range(self.nz2r):
            self.z2r_spline[i]  = self.interpolate(self.nr, self.dr, self.phi[i])

    def interpolate(self, n, delta, f):
        spline = np.zeros((n + 1, 7))
        spline[1:n+1, 6] = f[0:n]

        spline[1,5]   =        spline[2,6] - spline[1  ,6]
        spline[2,5]   = 0.5 * (spline[3,6] - spline[1  ,6])
        spline[n-1,5] = 0.5 * (spline[n,6] - spline[n-2,6])
        spline[n,5]   =        spline[n,6] - spline[n-1,6]

        spline[3:n-1,5] = ((spline[1:n-3,6] - spline[5:n+1,6]) + 8.0*(spline[4:n,6] - spline[2:n-2,6])) / 12.0

        spline[1:n,4] = 3.0*(spline[2:n+1,6] - spline[1:n,6]) - 2.0*spline[1:n,5] - spline[2:n+1,5]
        spline[1:n,3] = spline[1:n,5] + spline[2:n+1,5] - 2.0*(spline[2:n+1,6] - spline[1:n,6])

        spline[n,4], spline[n,3] = 0.0, 0.0

        spline[:, 2] =     spline[:, 5] / delta
        spline[:, 1] = 2.0*spline[:, 4] / delta
        spline[:, 0] = 3.0*spline[:, 3] / delta
        return spline

def plotEAM(eam, file):

    dp = 100

    Nele = len(eam.element)

    plt.figure(figsize=(12, 6))
    plt.subplot(1,3,1)
    for i in range(Nele):   
        plt.plot(eam.rhot[::dp], eam.emb[i, ::dp])
    plt.xlim(left = 0)
    plt.ylim(top  = 0)

    plt.subplot(1,3,2)
    for i in range(Nele):   
        plt.plot(eam.rhot[::dp], eam.rho[i, ::dp])

    plt.subplot(1,3,3)
    for i in range(int(Nele*(Nele+1)/2)):   
        plt.plot(eam.rhot[::dp], eam.phi[i, ::dp])    

    plt.savefig(file)
    plt.cla()

import pyqtgraph as pg
import pyqtgraph.exporters
from pyqtgraph.Qt import QtCore, QtGui

# def getRainbow(x):
#     if   x < 1./6:
#         return (int(255*(3*x+0.5)), 0, 0)
#     elif x < 1./2:
#         return (int(255*-3*(x-0.5)), int(255*3*(x-1./6)), 0)
#     elif x < 5./6:
#         return (0, int(255*-3*(x-5./6)), int(255*3*(x-0.5)))
#     else:
#         return (0, 0, int(255*-3*(x-7./6)))

# def getRainbow(x):
#     if x < 1./2:
#         return (int(255*(1.0-x)), int(255*2*x), 0)
#     else:
#         return (0, int(255*-2*(x-1.0)), int(255*x))

# def getRainbow(x):
#     if x < 1./3:
#         return (int(255*(1.0-3*x)), int(255*3*x), 0)
#     elif x < 2./3:
#         return (0, int(255*(2-3*x)), int(255*(3*x-1)))
#     else:
#         return (int(255*(3*x-2)), 0, int(255*(3-3*x)))

def getRainbow(x):
    if x < 1./3:
        return (255, int(255*3*x), 0)
    elif x < 2./3:
        return (int(255*(2-3*x)), 255, int(255*(3*x-1)))
    else:
        return (0, int(255*(3-3*x)), 255)


pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')

class EAMPlot(object):

    def __init__(self, legend = True):
    
        self.xlim   = [0, 0]
        self.penIdx = [0, 0]
        self.penNum = [0, 0]

        self.w = pg.GraphicsWindow(size=(1200,900))    
        self.p = [self.w.addPlot(row=0, col=1, rowspan=1, colspan=1),
                  self.w.addPlot(row=1, col=1, rowspan=1, colspan=1),
                  self.w.addPlot(row=0, col=0, rowspan=2, colspan=1)]
        if legend:
            for ip in self.p: ip.addLegend()

    @staticmethod
    def getSplineXlim(eamlist):
        xlim   = [0, 0]
        penNum = [0, 0]
        for eam in eamlist:
            penNum[0] += eam.NEle
            penNum[1] += eam.NPair
            xlim[0] = max(xlim[0], eam.fmt[0]*eam.fmt[1])
            xlim[1] = max(xlim[1], eam.fmt[2]*eam.fmt[3])
        return penNum, xlim
            
    def setAxisRange(self, ip, x1, x2, y1, y2):
        ip.setXRange(x1, x2)
        ip.setYRange(y1, y2)

    def createPlot(self, showWindow = True):
        p = self.p        
        p[2].addLine(y=0, pen='k')
        for ip in p: ip.showGrid(x=True, y=True, alpha = 0.2)

        if showWindow:
            QtGui.QApplication.instance().exec_()

    def getExport(self):
        pg.mkQApp().processEvents()
        return pyqtgraph.exporters.ImageExporter(self.w.scene())    

    def getColor(self, idx):
        rat = self.penIdx[idx]/self.penNum[idx]
        self.penIdx[idx] += 1
        return getRainbow(rat)

    def getPen(self, mode, width, partten):
        color=self.getColor(mode)  
        pen = pg.mkPen(color=color, width=width)
        if not partten is None:
            pen.setStyle(QtCore.Qt.CustomDashLine)
            pen.setDashPattern(partten)
        return pen

    def addEAMPlot(self, eam, *, philist=[], phipen=None, rhopen=None, width = 1.0, partten=None):
        ele = eam.element
        NEle = eam.NEle
        name = eam.id + '-'

        # emb and Electron density
        for i in range(NEle):         

            if rhopen is None: 
                pen = self.getPen(0, width=width, partten=partten)
            else:
                pen = rhopen[i]

            self.p[0].plot(x=eam.rhot, y=eam.emb[i, :], pen=pen, name=name+ele[i])
            self.p[1].plot(x=eam.r,    y=eam.rho[i, :], pen=pen, name=name+ele[i])  

        # Pair function
        idx = 0
        if philist == []:
            for i in range(NEle):
                for j in range(i+1):
                    philist.append((i, j))

        for iphi, ij in enumerate(philist):
            i, j = ij[0], ij[1]
            idx = int(i*(i+1)/2) + j
            name = eam.id+'-%2s-%2s'%(ele[i], ele[j])
            
            if phipen is None: 
                pen = self.getPen(1, width=width, partten=partten)
            else:
                pen = phipen[idx]

            self.p[2].plot(x=eam.r,   y=eam.phi[idx, :], pen=pen, name=name)


if __name__ == "__main__":

    eamlist = []
    tlast = time.time()
    edir = r'C:\MD\EAPOT\EAPOT\x64\CuVoter200228.Yu.2.use\\'
    # for ifile in os.listdir(edir):
    #     if ifile.endswith('.eam'):
    #         ieam = EAMFile(edir+ifile)
    #         ieam.name = ieam.name.split('.')[-2]
    #         eamlist.append(ieam)
    eamid = [
        15245250, 15245225, 15245200, 15545500, 15645475, 
        16045400, 16445400, 16645350, 16845500, 16845225, 
        17245450, 17545500, 17645350, 18245175, 18845100, 
        19045100, 18845200, 18845225, 19845150, 19845175, 
        20045200, 21245125, 21245100, 20245250, 20445400, 
        20545500, 20845300, 20845425, 21645400, 21545500, 
        22545350, 21645475, 22545500, 22045400, 23545300, 
        24545475, 24545375, ]
    
    lenth = len('Cu.200228.111029.')
    for id in eamid:
        sid = str(id)
        taskdir = edir + 'task.'+ sid[:3] + '.' + sid[3:5] + '/'
        file = os.listdir(taskdir)[0]
        file = file[:lenth] + '%06d.eam'%(id%1000)
        ieam = EAMFile(taskdir+file)
        ieam.name = sid
        eamlist.append(ieam)

    print(time.time() - tlast);tlast = time.time() 

    plot = EAMPlot(eamlist)

    for ieam in plot.eamlist:
        plot.addEAMPlot(ieam, 2)

    p = plot.p
    p[0].setXRange(0, plot.xlim[0]/2)
    p[0].setYRange(0, 50)      
    p[1].setXRange(0, plot.xlim[1])
    p[1].setYRange(0, 0.35)
    p[2].setXRange(1, plot.xlim[1])
    p[2].setYRange(-6, 3)

    for ip in p: ip.showGrid(x=True, y=True, alpha = 0.2)


    plot.createPlot()

    print(time.time() - tlast);tlast = time.time()
    
    QtGui.QApplication.instance().exec_()


if __name__ == '1__main__':

    plt.title("Rose function") 
    plt.xlabel("a0/A") 
    plt.ylabel("Ec/eV")

    for i in range(5):
        #plotEAM(eam, 'EAM.%d.png'%i)
        print(time.time() - tlast);tlast = time.time()


