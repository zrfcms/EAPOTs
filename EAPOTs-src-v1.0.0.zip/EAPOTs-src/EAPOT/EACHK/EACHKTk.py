#!/usr/bin/python
# -*- coding: UTF-8 -*-
 
import os, time, shutil
import EACHK as Chk
import EACHKComb as Comb
import EACHKInter

import tkinter as tk
from tkinter import ttk, filedialog


root = tk.Tk()

class AddDialog(tk.Toplevel):
  def __init__(self):
    super().__init__()
    self.title('Add Algorithm')

    row1 = tk.Frame(self)
    row1.pack(fill="x")
    tk.Label(row1, text='姓名：', width=8).pack(side=tk.LEFT)
    self.name = tk.StringVar()
    tk.Entry(row1, textvariable=self.name, width=20).pack(side=tk.LEFT)

    row2 = tk.Frame(self)
    row2.pack(fill="x", ipadx=1, ipady=1)
    tk.Label(row2, text='年龄：', width=8).pack(side=tk.LEFT)
    self.age = tk.IntVar()
    tk.Entry(row2, textvariable=self.age, width=20).pack(side=tk.LEFT)

    row3 = tk.Frame(self)
    row3.pack(fill="x")
    tk.Button(row3, text="取消", command=self.cancel).pack(side=tk.RIGHT)
    tk.Button(row3, text="确定", command=self.ok).pack(side=tk.RIGHT)

  def ok(self):
    self.userinfo = [self.name.get(), self.age.get()]
    self.destroy()

  def cancel(self):
    self.userinfo = None
    self.destroy()


menubar = tk.Menu(root)
 
filemenu = tk.Menu(menubar, tearoff=False)
filemenu.add_command(label="Open")
filemenu.add_separator()
filemenu.add_command(label="Quit", command=root.quit)
menubar.add_cascade(label="File", menu=filemenu)
 
editmenu = tk.Menu(menubar, tearoff=False)
editmenu.add_command(label="Cohensive Energy")
editmenu.add_command(label="Elastic Constant")
menubar.add_cascade(label="Algorithm", menu=editmenu)

root.config(menu=menubar)


SetFrame = tk.LabelFrame(root, text="Settings", labelanchor="n")

FuncSet = tk.Frame(SetFrame)

FuncTypeTuple = ('eam/alloy', 'eam/fs', 'meam', 'tersoff', 'sw')
tk.Label(FuncSet,text=" Potential Type ").pack(side=tk.LEFT)
FuncType = ttk.Combobox(FuncSet, values=FuncTypeTuple)
FuncType.pack(side=tk.LEFT)
FuncType.current(0)


ttk.Label(FuncSet,text=" Ele1 ").pack(side=tk.LEFT)
ttk.Entry(FuncSet, width=6).pack(side=tk.LEFT)
ttk.Label(FuncSet,text=" Ele2 ").pack(side=tk.LEFT)
ttk.Entry(FuncSet, width=6).pack(side=tk.LEFT)

ttk.Label(FuncSet,text=" ").pack(side=tk.LEFT, expand=1, fill=tk.X)

ttk.Button(FuncSet, text=" Add ").pack(side=tk.LEFT)
ttk.Button(FuncSet, text=" Run ").pack(side=tk.LEFT)




potInitDir = os.path.abspath('.')
def getPot():
    global potInitDir
    file = filedialog.askopenfilename(title='select potential file', initialdir=potInitDir)
    potInitDir = os.path.dirname(file)
    return file

FileSet = tk.Frame(SetFrame)

file1 = tk.StringVar()
file2 = tk.StringVar()

ttk.Label(FileSet, text=" File1 ").pack(side=tk.LEFT)
ttk.Entry(FileSet, textvariable = file1).pack(side=tk.LEFT, expand=1, fill=tk.X)
ttk.Button(FileSet, text="...", width=2, command = lambda:file1.set(getPot())).pack(side=tk.LEFT)

ttk.Label(FileSet, text=" File2 ").pack(side=tk.LEFT)
ttk.Entry(FileSet, textvariable = file2).pack(side=tk.LEFT, expand=1, fill=tk.X)
ttk.Button(FileSet, text="...", width=2, command = lambda:file2.set(getPot())).pack(side=tk.LEFT)


FuncSet.pack(fill=tk.X, padx=5, pady=2)
FileSet.pack(fill=tk.X, padx=5, pady=2)

SetFrame.pack(fill=tk.X, padx=5, pady=1)


AlgoFrame = tk.LabelFrame(root, text="Algorithms", labelanchor="n")
FileSet = tk.Frame(AlgoFrame)
FileSet.pack(expand=1, fill=tk.BOTH)
AlgoFrame.pack(expand=1, fill=tk.BOTH, padx=5, pady=1)

root.mainloop()




