import EACHK as Chk
import EACHKAlgo as Algo

Ela = Algo.ElasticConstant


def addpairstruct(script, pair, lo, hi):
    for i in range(lo, hi):
        ialgo = script.algo[i]
        ialgo.pairScript = pair

        id, type = ialgo.id, ialgo.type
        if type == 'ElasticConstant' or type == 'VacancyEnergy':
            continue

        struct = id[id.find('.')+1:id.rfind('.')]
        ialgo.structureScript = 'read_data %s%s.lammps\n'%(script.modDir, struct)

def addfcc(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    Ecfcc      = Algo.CohensiveEnergy(script, 'Ec.fcc'+suf)
    Ecfcc.SeparatorFlag = 1

    Evfcc      = Algo.VacancyEnergy(script, "Ev.fcc"+suf, Ecfcc.restart)
    Evfcc.pos, Evfcc.replicate = (1.25, 1.25, 1.25), [4, 4, 4]
    Elafcc     = Ela(script, "Ela.fcc"+suf,       Ecfcc.restart,     Ela.collect3)

    Ysfcc111   = Algo.GammaSurface(script,  "Ys.fcc.111"+suf, Ecfcc.id)
    Ysfcc111.createScan1d(0, 6, 1.0 / 6)
    Esfcc100   = Algo.SurfaceEnergy(script, "Es.fcc.100"+suf, Ecfcc.id)
    Esfcc100.headinfo = "S100 u/r  "
    Esfcc110   = Algo.SurfaceEnergy(script, "Es.fcc.110"+suf, Ecfcc.id)
    Esfcc110.headinfo = "S110 u/r  "
    Esfcc111   = Algo.SurfaceEnergy(script, "Es.fcc.111"+suf, Ecfcc.id)
    Esfcc111.headinfo = "S111 u/r  "
    Esfcc112   = Algo.SurfaceEnergy(script, "Es.fcc.112"+suf, Ecfcc.id)
    Esfcc112.headinfo = "S112 u/r  "
    
    script.algo[-1].SeparatorFlag = 1
    addpairstruct(script, pair, lo, len(script.algo))

def addbcc(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    Ecbcc      = Algo.CohensiveEnergy(script, 'Ec.bcc'+suf)
    Ecbcc.SeparatorFlag = 1

    Evbcc      = Algo.VacancyEnergy(script, "Ev.bcc"+suf, Ecbcc.restart)
    Evbcc.pos, Evbcc.replicate = (1.25, 1.25, 1.25), [4, 4, 4]
    Elabcc     = Ela(script, "Ela.bcc"+suf,       Ecbcc.restart,     Ela.collect3)

    Ys = Algo.GammaSurface
    Ysbcc110 = Algo.GammaSurface(script, "Ys.bcc.110"+suf, Ecbcc.id)
    Ysbcc110.headinfo, Ysbcc110.abstract,Ysbcc110.pointInfo = Ys.headbcc, Ys.abstbcc,Ys.pontbcc
    Ysbcc110.createScan1d(0, 4, 1.0 / 6)

    Ysbcc112 = Algo.GammaSurface(script, "Ys.bcc.112"+suf, Ecbcc.id)
    Ysbcc112.headinfo, Ysbcc112.abstract,Ysbcc112.pointInfo = Ys.headbcc, Ys.abstbcc,Ys.pontbcc
    Ysbcc112.createScan1d(0, 6, 1.0 / 6)  

    Esbcc100  = Algo.SurfaceEnergy(script, "Es.bcc.100"+suf, Ecbcc.id)
    Esbcc100.headinfo = "S100 u/r  "
    Esbcc110  = Algo.SurfaceEnergy(script, "Es.bcc.110"+suf, Ecbcc.id)
    Esbcc110.headinfo = "S110 u/r  "
    Esbcc111  = Algo.SurfaceEnergy(script, "Es.bcc.111"+suf, Ecbcc.id)
    Esbcc111.headinfo = "S111 u/r  "
    Esbcc112  = Algo.SurfaceEnergy(script, "Es.bcc.112"+suf, Ecbcc.id)
    Esbcc112.headinfo = "S112 u/r  "
    script.algo[-1].SeparatorFlag = 1
    addpairstruct(script, pair, lo, len(script.algo))

def addhcp(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    Echcp      = Algo.CohensiveEnergy(script, 'Ec.hcp'+suf)
    Echcp.headinfo = '  a0    c/a    Ec   '
    Echcp.abstract = lambda x: '%6.4f %5.3f %6.4f '%(x.lat[1], x.lat[2]/x.lat[1], x.Ec) 
    Echcp.SeparatorFlag = 1

    Evhcp      = Algo.VacancyEnergy(script, "Ev.hcp"+suf, Echcp.restart)
    Evhcp.pos, Evhcp.replicate = (1.25, 1.25, 1.25), [3, 5, 3]
    Elahcp     = Ela(script, "Ela.hcp"+suf,       Echcp.restart,     Ela.collect6)

    Yshcp0001 = Algo.GammaSurface(script,  "Ys.hcp.0001"+suf, Echcp.id)
    Yshcp0001.replicateScript = lambda rep: [1,1,(rep[2]+1)//2*2]
    Yshcp0001.createScan1d(0, 6, 1.0 / 6)

    Eshcp0001 = Algo.SurfaceEnergy(script, "Es.hcp.0001"+suf, Echcp.id)
    Eshcp0001.headinfo = "S0001 u/r "
    
    script.algo[-1].SeparatorFlag = 1  
    addpairstruct(script, pair, lo, len(script.algo))

def addalloy(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    EcL12_A3B  = Algo.CohensiveEnergy(script, 'Ec.L12_A3B'+suf)
    EcL12_AB3  = Algo.CohensiveEnergy(script, 'Ec.L12_AB3'+suf)
    EcB1       = Algo.CohensiveEnergy(script, 'Ec.B1'+suf)
    EcB2       = Algo.CohensiveEnergy(script, 'Ec.B2'+suf)
    script.algo[-1].SeparatorFlag = 1

    ElaL12_A3B = Ela(script, "Ela.L12_A3B"+suf,   EcL12_A3B.restart, Ela.collect3)
    ElaL12_AB3 = Ela(script, "Ela.L12_AB3"+suf,   EcL12_AB3.restart, Ela.collect3)
    ElaB1      = Ela(script, "Ela.B1"+suf,        EcB1.restart,      Ela.collect3)
    ElaB2      = Ela(script, "Ela.B2"+suf,        EcB2.restart,      Ela.collect3)

    script.algo[-1].SeparatorFlag = 1
    addpairstruct(script, pair, lo, len(script.algo))

def adddia(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    Ys = Algo.GammaSurface
    Ela = Algo.ElasticConstant

    EcdiaC     = Algo.CohensiveEnergy(script, 'Ec.dia'+suf) 
    script.algo[-1].SeparatorFlag = 1

    EvdiaC = Algo.VacancyEnergy(script, "Ev.dia"+suf, EcdiaC.restart)
    EvdiaC.pos = (1.375, 1.375, 1.375)
    EvdiaC.headinfo = " Ev/r  Ev/u  "
    EvdiaC.abstract = lambda x: '%5.3f %5.3f '% (x.Evu, x.Evr)

    EladiaC_u    = Algo.ElasticConstant(script, "Ela.dia"+suf,  EcdiaC.restart, Ela.collect3)
    EladiaC_u.headinfo3 = 'C11  C12 C44  '
    EladiaC_u.abstract3 = lambda x: '%4.0f %3.0f %4.0f '%(x.short[0], x.short[1], x.short[2])
    EladiaC_r    = Algo.ElasticConstant(script, "Ela.dia"+suf,  EcdiaC.restart, Ela.collect3)
    EladiaC_r.headinfo3 = 'C44/r '
    EladiaC_r.abstract3 = lambda x: '%4.0f  '%(x.short[2])
    EladiaC_r.relax.relaxAtom = True
    script.algo[-1].SeparatorFlag = 1

    YsdiaC111 = Algo.GammaSurface(script, "Ys.dia.111"+suf, "Ec.dia"+suf)
    YsdiaC111.createScan1d(0, 6, 1.0 / 6)
    YsdiaC111.replicateScript = lambda rep: [1,1,(rep[2]+1)//2*2]
    YsdiaC111.headinfo,YsdiaC111.abstract,YsdiaC111.pointInfo = Ys.headdia,Ys.abstdia, Ys.pontdia
    script.algo[-1].SeparatorFlag = 1

    head, abst = "Es/r Es/u ", lambda x: '%4.3g %4.3g '% (x.Evu/1000, x.Evr/1000)
    EsdiaC100  = Algo.SurfaceEnergy(script, "Es.dia.100"+suf,  "Ec.dia"+suf)
    EsdiaC110  = Algo.SurfaceEnergy(script, "Es.dia.110"+suf,  "Ec.dia"+suf)
    EsdiaC111  = Algo.SurfaceEnergy(script, "Es.dia.111"+suf,  "Ec.dia"+suf)
    EsdiaC112  = Algo.SurfaceEnergy(script, "Es.dia.112"+suf,  "Ec.dia"+suf)
    EsdiaC100.headinfo,EsdiaC100.abstract=head,abst
    EsdiaC110.headinfo,EsdiaC110.abstract=head,abst
    EsdiaC111.headinfo,EsdiaC111.abstract=head,abst
    EsdiaC112.headinfo,EsdiaC112.abstract=head,abst
    script.algo[-1].SeparatorFlag = 1

    EcgraC     = Algo.CohensiveEnergy(script, 'Ec.graphene'+suf)
    script.algo[-1].SeparatorFlag = 1
    ElagraC    = Algo.ElasticConstant(script, "Ela.graphene"+suf,  EcgraC.restart, Ela.collect3)
    ElagraC.headinfo3 = 'C11 C12 C44 '
    ElagraC.abstract3 = lambda x: '%3.0f %3.0f %3.0f '%(x.short[0], x.short[1], x.short[2])
    script.algo[-1].SeparatorFlag = 1
    
    addpairstruct(script, pair, lo, len(script.algo))

def addSiC(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    EcSiC    = Algo.CohensiveEnergy(script, 'Ec.SiC.beta%s'%(suf)) 
    script.algo[-1].SeparatorFlag = 1    
    ElaSiC   = Algo.ElasticConstant(script, 'Ela.SiC.beta%s'%(suf), EcSiC.restart, Ela.collect3)

    script.algo[-1].SeparatorFlag = 1
    addpairstruct(script, pair, 0, 2)

def addAlloy(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    EcL12_A3B  = Algo.CohensiveEnergy(script, 'Ec.L12_A3B'+suf)
    EcL12_AB3  = Algo.CohensiveEnergy(script, 'Ec.L12_AB3'+suf)
    EcB1       = Algo.CohensiveEnergy(script, 'Ec.B1'+suf)
    EcB2       = Algo.CohensiveEnergy(script, 'Ec.B2'+suf)
    script.algo[-1].SeparatorFlag = 1

    ElaL12_A3B = Ela(script, "Ela.L12_A3B"+suf,   EcL12_A3B.restart, Ela.collect3)
    ElaL12_AB3 = Ela(script, "Ela.L12_AB3"+suf,   EcL12_AB3.restart, Ela.collect3)
    ElaB1      = Ela(script, "Ela.B1"+suf,        EcB1.restart,      Ela.collect3)
    ElaB2      = Ela(script, "Ela.B2"+suf,        EcB2.restart,      Ela.collect3)

    script.algo[-1].SeparatorFlag = 1
    addpairstruct(script, pair, lo, len(script.algo))
    
def addEla(script, pair, ele):
    suf = '.' + ele
    lo = len(script.algo)

    Ecfcc      = Algo.CohensiveEnergy(script, 'Ec.fcc'+suf)
    Ecbcc      = Algo.CohensiveEnergy(script, 'Ec.bcc'+suf)
    Echcp      = Algo.CohensiveEnergy(script, 'Ec.hcp'+suf)
    Echcp.headinfo = ' a0    c/a   Ec   '
    Echcp.abstract = lambda x: '%5.3f %5.3f %5.3f '%(x.lat[1], x.lat[2]/x.lat[1], x.Ec) 
    script.algo[-1].SeparatorFlag = 1

    Elafcc     = Ela(script, "Ela.fcc"+suf, Ecfcc.restart, Ela.collect3)
    Elabcc     = Ela(script, "Ela.bcc"+suf, Ecbcc.restart, Ela.collect3)
    Elahcp     = Ela(script, "Ela.hcp"+suf, Echcp.restart, Ela.collect6)

    script.algo[-1].SeparatorFlag = 1
    addpairstruct(script, pair, lo, len(script.algo))

funcmap = {
    'fcc': addfcc,
    'bcc': addbcc,
    'hcp': addhcp,
    'dia': adddia,
    
    'cF4[225]A1': addfcc,
    'cI2[229]A2': addbcc,
    'hP2[194]A3': addhcp,
    'cF8[227]A4': adddia,
    
    'alloy': addAlloy,
    'ela': addEla,
    'SiC': addSiC,
}