import numpy as np

def getLatticeRatio(a1, a2, *, maxline = 50, maxprint = 0):
    data = np.zeros((maxline, 3))
    for idx in range(maxline):
        i = idx + 1
        j = np.round(i*a1/a2)
        data[idx, 0] = i
        data[idx, 1] = j
        data[idx, 2] = np.abs((i*a1 - j*a2)/(i*a1 + j*a2)/2)
        
    data = data[np.argsort(data[:,2])]

    if maxprint > maxline: maxprint = maxline
    for i in range(maxprint):
        print('%4d  %4d  %.6e'%(data[i, 0], data[i, 1], data[i, 2]))
    return data

class MDConfig(object):

    def __init__(self, *, lambdaFalg = True, fread = '', 
        Box = np.array([
            [4.0*np.sqrt(6)/2, 0.0, 0.0],
            [0.0,  4.0/np.sqrt(2),  0.0],
            [0.0,  0.0,  4.0*np.sqrt(3)]]),
        Boxlo = np.array([0.0,0.0,0.0]),    
        p = np.array([
            [ 1.,  3.,  2.],
            [ 5.,  3.,  6.],
            [ 9.,  3., 10.],
            [ 7.,  9.,  2.],
            [11.,  9.,  6.],
            [ 3.,  9., 10.]])/12,
        type = np.ones(6, dtype=int)):
        
        self.id = np.zeros(0)
        self.p, self.type = p, type
        self.Box, self.Boxlo = Box, Boxlo
        self.lambdaFalg = lambdaFalg

        if self.lambdaFalg: self.lambda2x()
        self.lastDumpFile = ''

        if fread != '': self.readLammpsData(fread)


    def lambda2x(self):        
        self.p = np.dot(self.p, self.Box) + self.Boxlo
        self.lambdaFalg = False

    def x2lambda(self):        
        pBox = np.linalg.inv(self.Box)
        self.p = np.dot(self.p-self.Boxlo, pBox)
        self.lambdaFalg = True

    def createId(self):
        self.id = np.arange(1, self.p.shape[0]+1, 1, dtype=int)

    def moveBox(self, delta):
        self.Boxlo += delta
        if self.lambdaFalg == False:
            self.p += delta

    def ChangeBox(self, BoxNew, *, printFlag = True):

        pBox = np.linalg.inv(self.Box)
        trans = np.dot(pBox, BoxNew)
        self.p = np.dot(self.p-self.Boxlo, trans)+self.Boxlo

        print('ChangeBox:')


        fmt = '|%18.12f %18.12f %18.12f|   ->   |%18.12f %18.12f %18.12f|'
        a, b = self.Box[0, :], BoxNew[0, :]
        print(fmt%(a[0], a[1], a[2], b[0], b[1], b[2]))
        a, b = self.Box[1, :], BoxNew[1, :]
        print(fmt%(a[0], a[1], a[2], b[0], b[1], b[2]))
        a, b = self.Box[2, :], BoxNew[2, :]
        print(fmt%(a[0], a[1], a[2], b[0], b[1], b[2]))

        self.Box = BoxNew


    def CoordinateCorrection(self, n):
        self.x2lambda()
        self.p = np.around(self.p*n, 0)/n
        self.lambda2x()

    # mult = [2, 3, 2]
    def Replicate(self, mult):

        Box, p, type = self.Box, self.p, self.type

        pref = p
        tref = type

        for i in range(1, mult[0]):
            p = np.r_[p, pref + np.dot(np.array([i,0,0]), Box)]
            type = np.r_[type, tref]
        
        pref = p
        tref = type
        for j in range(1, mult[1]):
            p = np.r_[p, pref + np.dot(np.array([0,j,0]), Box)]
            type = np.r_[type, tref]

        pref = p
        tref = type
        for k in range(1, mult[2]):
            p = np.r_[p, pref + np.dot(np.array([0,0,k]), Box)]
            type = np.r_[type, tref]
        
        self.p = p
        self.type = type
        self.Box = Box*np.array([[mult[0]], [mult[1]], [mult[2]]])
        self.createId()

    @staticmethod
    def getBox(xyz, tilt = np.zeros(3)):
        Box = np.array([
            [xyz[0],   0.0,      0.0   ],
            [tilt[0],  xyz[1],   0.0   ],
            [tilt[1],  tilt[2],  xyz[2]]
        ])

        return Box    

    def createBox(self, xyz, tilt = np.zeros(3)):   
        self.Box = self.getBox(xyz, tilt)

    @staticmethod
    def getType(natom, ntype):
        return np.ones(natom, dtype=int)*ntype

    def createType(self, n):
        self.type = self.getType(self.p.shape[0], n)

    def readLammpsData(self, file):
        n = 0
        iline = 0
        box = np.zeros(3)
        tilt = np.zeros(3)

        with open(file, "r") as f:
            while True:
                iline += 1
                line = f.readline()
                if line.find("atoms") >= 0:
                    n = int(line.split()[0])

                elif line.find("xlo") >= 0:
                    word = line.split()
                    self.Boxlo[0] = float(word[0])
                    box[0] = float(word[1]) - self.Boxlo[0]

                elif line.find("ylo") >= 0:
                    word = line.split()
                    self.Boxlo[1] = float(word[0])
                    box[1] = float(word[1]) - self.Boxlo[1]

                elif line.find("zlo") >= 0:
                    word = line.split()
                    self.Boxlo[2] = float(word[0])
                    box[2] = float(word[1]) - self.Boxlo[2]

                elif line.find("xy") >= 0:
                    word = line.split()
                    tilt[0] = float(word[0])
                    tilt[1] = float(word[1])
                    tilt[2] = float(word[2])

                elif line.find("Atoms") >= 0:
                    break
            
            iline += 1
            line = f.readline()
            while not line.strip():
                iline += 1
                line = f.readline()

            data = np.loadtxt(file, skiprows=iline-1)

            self.createBox(box, tilt)
            self.id   = data[:, 0].astype(dtype=int)
            self.type = data[:, 1].astype(dtype=int)
            self.p    = data[:, 2:5]


    def dumpLammpsData(self, file):        
        p, type = self.p, self.type
        Box, Boxlo = self.Box, self.Boxlo

        if not self.id.size: self.createId()

        self.lastDumpFile = file
        with open (file, "w") as f:
            n = p.shape[0]
            ntype = type.max()

            f.write(' LAMMPS data file\n')
            f.write('\n')
            f.write(' 			    %d	atoms\n'%(n))
            f.write(' 			    %d   atom types\n'%(ntype))
            f.write('\n')
            f.write('       %.17g       %.17g   xlo xhi\n'%(Boxlo[0], Box[0, 0]+Boxlo[0]))
            f.write('       %.17g       %.17g   ylo yhi\n'%(Boxlo[1], Box[1, 1]+Boxlo[1]))
            f.write('       %.17g      	%.17g   zlo zhi\n'%(Boxlo[2], Box[2, 2]+Boxlo[2]))
            f.write('       %.17g   %.17g   %.17g   xy xz yz\n'%(Box[1, 0], Box[2, 0], Box[2, 1]))
            f.write('\n')
            f.write('  Atoms\n')
            f.write('\n')

            for i in range(n):
                f.write('       %d\t%d\t%.17g\t%.17g\t%.17g\n'%(self.id[i], type[i], p[i, 0], p[i, 1], p[i, 2]))



#  LAMMPS data file

# 			6	atoms
# 			1   atom types

#       0.000000000     	   5.143928459844674   xlo xhi
#       0.000000000     	     2.9698484809835   ylo yhi
#       0.000000000    	   7.274613391789284   zlo zhi

#  Atoms 

# 	   1	1	0.4286607049870562	0.742462120245875	1.212435565298214
# 	   2	1	2.143303524935281	0.742462120245875	3.637306695894642
# 	   3	1	3.857946344883506	0.742462120245875	6.06217782649107
# 	   4	1	3.000624934909394	2.227386360737625	1.212435565298214
# 	   5	1	4.715267754857618	2.227386360737625	3.637306695894642
# 	   6	1	1.285982114961169	2.227386360737625	6.06217782649107