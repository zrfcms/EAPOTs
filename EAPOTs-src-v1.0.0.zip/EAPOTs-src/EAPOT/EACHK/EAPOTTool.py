import os, shutil
import numpy as np
import subprocess
import threading

class mEAPOT(threading.Thread):
    def __init__(self, id, task):
        threading.Thread.__init__(self)
        self.id = id
        self.task = task

    def run(self):
        task = self.task

        while True:
            task.lock.acquire()
            key, replace = task.getTask()
            print('%d %s'%(self.id, key))
            task.lock.release()
            if key is None: break

            dir = 'task.' + key + '/'            

            # 1. check savedir
            if os.path.exists(dir):
                if task.rewriteFlag: shutil.rmtree(dir)            
                else:                continue
            os.mkdir(dir)

            # 3. create script
            script = task.script            
            for rp in replace:
                script = script.replace(rp[0], rp[1])
            with open(dir + 'in.in', 'w') as input:
                input.write(script)

            # 4. run
            with open(dir + 'in.in') as input:
                with open(dir + 'out.log', 'w') as output:                
                    obj = subprocess.Popen(task.EAPOTDir, stdin=input, stdout=output, cwd=dir)
                    obj.wait()

            # 5. save files
            if os.path.exists(dir + 'thermo.log'):
                shutil.copy(dir + 'thermo.log','log/thermo.' +key+ '.log')


class mTask(object):
    def __init__(self, script):       
        
        self.key = []
        self.replace = []
        self.script = script
        self.lock = threading.RLock()
        
        self.rewriteFlag = False
        self.EAPOTDir = '../../bin/EAPOT'
        

    def run(self, nthread):
        self.idx = 0
        if not os.path.exists('log'): os.mkdir('log')
        self.ntask = min(len(self.key), len(self.replace))

        threads = []
        nthread = min(nthread, self.ntask)
        for i in range(nthread): threads.append(mEAPOT(i, self))        
        for ithread in threads:  ithread.start()
        for ithread in threads:  ithread.join()


    def getTask(self):
        i = self.idx
        if i < self.ntask:
            self.idx += 1
            return self.key[i], self.replace[i]
        else:
            return None, None

class EAPOTInter(object):

    def __init__(self, script):
        self.script = script
        self.EAPOTDir = '..\Release\EAPOT'
        self.rewriteFlag = False

        if not os.path.exists('log'): os.mkdir('log')

    def runEAPOT(self, key, *, replacelist=False):

        # 1. check savedir
        savedir = 'task.' + key
        if os.path.exists(savedir): 
            if self.rewriteFlag: shutil.rmtree(savedir)            
            else: return

        # 2. prepare temporary folder
        if os.path.exists('chkdata'): shutil.rmtree('chkdata')
        if os.path.exists('temp'):    shutil.rmtree('temp')

        # 3. create script
        script = self.script
        for rp in replacelist:
            script = script.replace(rp[0], rp[1])

        with open('log/EAPOT.' +key+ '.in', 'w') as input:
            input.write(script)

        # 4. run
        with open('log/EAPOT.' +key+ '.in', 'r') as input:
            with open('log/out.' +key+ '.log', 'w') as output:                
                obj = subprocess.Popen(self.EAPOTDir, stdin=input, stdout=output)
                obj.wait()

        # 5. save files
        os.rename('task', savedir)

        if os.path.exists('EACHK.log'):  shutil.move('EACHK.log', 'log/EACHK.' +key+ '.log')
        if os.path.exists('thermo.log'): shutil.move('thermo.log','log/thermo.' +key+ '.log')
        if os.path.exists('EAPOT.log'):  shutil.move('EAPOT.log','log/EAPOT.' +key+ '.log')

def rmAllTasks(path = './'):
    for idir in os.listdir(path):
        if idir.startswith('task'):
            shutil.rmtree(idir)

def getTaskDir(path, *, exclude = lambda x: False):
    dir = []
    for itask in os.listdir(path):
        if not itask.startswith('task.'): continue
        if exclude(itask): continue
        dir.append(itask)
  
    return dir


def getEAMParm(f):
    f.readline()
    f.readline()
    return f.readline()[1:]

def findFirstEAMFile(path):
    for ifile in os.listdir(path):
        if ifile.endswith('.eam'):
            return ifile

def Print(fmt, Ref, data, file):
    with open(file, "w") as f:
        f.write(fmt%Ref+'\n')
        for v in data: 
            f.write(fmt%tuple(v)+'\n')
    with open(file, "r") as f:
        print(f.read(), end = '')

def readThermo(path, *, key='thermo', skiprows=2, extraId = lambda id: int(id[1])):

    data = np.zeros(0)

    for file in os.listdir(path):
        # 1. skip other files
        if not file.startswith(key): continue

        # 2. load data
        idata = np.loadtxt(path + file, skiprows=skiprows)

        # 3. format check
        if not data.size:
            data = np.zeros((0, idata.shape[-1]))        

        if idata.ndim == 1: 
            idata = np.reshape(idata, (1, idata.size))

        # 4. append into data
        id = file.split('.')
        idata[:, 0] += extraId(id)
        data = np.r_[data, idata]

    return data

def printData(data, fmt, sel):
    pdata = data[:, sel]
    for v in pdata: print(fmt%tuple(v))


def selectData(data, selectCol, rat):  

    sdata = data.copy()
    N = ['(in, %d)'%(sdata.shape[0])]
    for col, j in enumerate(selectCol):

        for r in rat[col]:
            ave = np.average(sdata[:, j])
            lo = ave*(1 - r*0.5)
            hi = ave*(1 + r*0.5)
            sdata = sdata[(sdata[:, j]>lo) & (sdata[:, j]<hi), :]

        N.append('(%d, %d)'%(j, sdata.shape[0]))
    
    print(N)
    return N, sdata

def getFitParma(data, dest, src, filefmt = 'task.%d/task/Cu.%06d.eam'):

    for row in data:
        id = int(row[0])
        itask, step = int(id/1000), id%1000

        with open(filefmt%(itask, step), 'r') as r:
            r.readline()
            r.readline()
            row[dest] = float(r.readline().split()[src])

    return data

def selectByRcut(data, cut, index, filefmt = 'task.%d/task/Cu.%06d.eam'):
    N = data.shape[0]
    for row in data:
        id = int(row[0])
        itask, step = int(id/1000), id%1000

        with open(filefmt%(itask, step), 'r') as r:
            r.readline()
            r.readline()
            row[-1] = float(r.readline().split()[index])

    data = data[data[:, -1] <= cut, :]
    print('Rcut: %d -> %d'%(N, data.shape[0]))
    return data