import EACHK as Chk
import EACHKChk
import EACHKTool
import EACHKAlgo
import EACHKComb
import EACHKInter


def fcc(pressure, ele, elepot, elejson):

    suffix = '.'+ ele
    lammpsDir = '../../LAMMPS/'    

    # 创建一个校核任务，每个任务包含多个子校核项
    # EACHKInter为一个类，包含self, LAMMPSDir, exportDir, ele, type, oth = {}
    # 由EACHK创建一个script
    Inter = EACHKInter.EACHKInter(lammpsDir, 'chkdata/', [ele,], 'eam/alloy')
    script = Inter.script


    # 添加聚合能校核，'Ec.fcc.ele'为此校核项的id
    Ecfcc      = EACHKAlgo.CohensiveEnergy(script, 'Ec.fcc'+suffix)
    # 设置松弛目标压强，单位是kBar, 1GPa = 1e4 kBar
    Ecfcc.relax.stress = [pressure*1e4, pressure*1e4, pressure*1e4, 0.0, 0.0, 0.0]
    # 打开该标志表示重启LAMMPS，以使得后面的结果可以使用松弛的晶格常数
    Ecfcc.SeparatorFlag = 1

    # 添加空位形成能校核，'Ev.fcc.ele'为此校核项的id
    Evfcc      = EACHKAlgo.VacancyEnergy(script, "Ev.fcc"+suffix, Ecfcc.restart)
    # 删除原子位置(单位是lattice)，和replicate次数
    Evfcc.pos, Evfcc.replicate = (1.25, 1.25, 1.25), [4, 4, 4]

    # 添加弹性常数校核，'Ela.fcc.ele'为此校核项的id,Ela.abstract3为C11、C12、C44
    Ela        = EACHKAlgo.ElasticConstant
    Elafcc     = Ela(script, "Ela.fcc"+suffix, Ecfcc.restart, Ela.abstract3)

    # 校核层错能曲线，共校核6个点。可以使用2d将校核层错能面
    Ysfcc111   = EACHKAlgo.GammaSurface(script,  "Ys.fcc.111"+suffix, Ecfcc.id)
    #Ysfcc111.replicateScript = lambda rep: [1,1,(rep[2]+1)//2*2]

    Ysfcc111.abstract = lambda x: '%-5.1f %-5.1f %-4.0f %-5.1f %-5.1f %-4.0f %-4.0f %-4.0f '%(
            x.Yu[2],x.Yu[4],x.Yu[8],  x.Yr[2],x.Yr[4],x.Yr[6],x.Yr[8],x.Yr[10])

    Ysfcc111.createScan1d(0, 12, 1.0 / 12)

    # 校核层表面能
    Esfcc100   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.100"+suffix, Ecfcc.id)
    Esfcc100.headinfo = "S100 u/r  "
    Esfcc110   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.110"+suffix, Ecfcc.id)
    Esfcc110.headinfo = "S110 u/r  "
    Esfcc111   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.111"+suffix, Ecfcc.id)
    Esfcc111.headinfo = "S111 u/r  "
    Esfcc112   = EACHKAlgo.SurfaceEnergy(script, "Es.fcc.112"+suffix, Ecfcc.id)
    Esfcc112.headinfo = "S112 u/r  "        
    script.algo[-1].SeparatorFlag = 1

    # 添加校核势函数类型命令，type为eam/alloy,
    Inter.pair = 'pair_style %s\npair_coeff * * ${Pair0} %s\n'%(Inter.type, ele)
    EACHKComb.addpairstruct(script, Inter.pair, 0, len(script.algo))

    # 初始化，创建LAMMPS脚本
    print(Inter.init(None))
    # 输出LAMMPS脚本供参考
    Inter.script.printScript('script.in')
    # 运行LAMMPS，并解析日志得到校核结果
    print(Inter.run(['test/'+elepot], 'test/'+elejson))
#    print('cost %.3fs'%(Inter.script.dt), end = '')

ele = ['Cu']
for iele in ele:
    ielepot = iele +'.eam'
    ielejson = iele + '.chk.json'
    print(iele, end = '\n')
    for pressure in range(0,11,2):
        fcc(pressure, iele, ielepot, ielejson)
