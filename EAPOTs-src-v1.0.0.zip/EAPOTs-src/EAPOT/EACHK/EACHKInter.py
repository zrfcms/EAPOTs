import EACHK as Chk
import EACHKAlgo as Algo
import EACHKComb as Comb

import os


# from EACHKInter import *
# def check(inter):
#     ele = inter.ele
#     Comb.addfcc(inter.script, inter.single[0], inter.ele[0])

# def check(v):
#     Comb.addalloy(v.md.run, v.cross[0], ''.join(v.ele))

class EACHKInter(object):

    def __init__(self, LAMMPSDir, exportDir, ele, type, oth = {}):

        self.script = Chk.Script(LAMMPSDir, exportDir)

        self.ele = ele
        self.type = type
        self.echo = False

        if 'mass' in oth:
            self.mass = oth['mass']
        else:
            self.mass = tuple(Chk.Script.AtomicMass[Chk.Script.AtomicStr.index(iele)] for iele in ele)

    def add(self, comb, pele):
        type = self.type
        line = ' '.join(pele)
        self.suffix = ''.join(pele)

        if type == "meam":
            self.pair = 'pair_style meam\npair_coeff * * ${Pair0} %s ${Pair1} %s\n'%(line, line)
        elif type == "eam":
            self.pair = 'pair_style eam\npair_coeff * * ${Pair0}\n'
        else:
            self.pair = 'pair_style %s\npair_coeff * * ${Pair0} %s\n'%(type, line)

        if not type in ("eam","meam"): self.pair += self.getMass(pele)

        if comb in Comb.funcmap:
            Comb.funcmap[comb](self.script, self.pair, self.suffix)
        
        return self.pair

    def getMass(self, pele):
        massStr = ''
        for i, iele in enumerate(pele):
            eleidx = self.ele.index(iele)
            massStr += 'mass %d %f\n'%(i+1, self.mass[eleidx])
        return massStr

    def init(self, v):
        return self.script.createScript()

    def run(self, pair, output = None):
           
        self.script.runLAMMPS(pair, self.echo)

        pair0 = pair[0]
        if output is None:
            output = pair0[:pair0.rfind('.')] + '.chk.json'
            
        with open(output, 'w') as f:
            f.write(self.script.pack())

        return self.script.abstract



