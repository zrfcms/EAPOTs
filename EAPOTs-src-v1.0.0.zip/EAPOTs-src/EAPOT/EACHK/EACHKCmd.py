import os, time, shutil
import argparse
import EACHK as Chk
import EACHKComb as Comb
import EACHKInter

if __name__ == '__main__':

    lammpsDir = os.path.dirname(__file__)
    lammpsDir = os.path.abspath(os.path.join(lammpsDir, "../../LAMMPS"))

    # parse argument
    parser = argparse.ArgumentParser(description='Checking an EAM potential')
    
    parser.add_argument('potential', nargs='+', help='the potential user input')

    parser.add_argument('-c', required=True, dest='combolist', nargs='+', choices=Comb.funcmap.keys(),help='The potential check items list')
    parser.add_argument('-e', required=True, dest='element', nargs='+', help='The potential user input')
    parser.add_argument('-o', default='', dest='outdir', help='Path to save check results') 
    parser.add_argument('-l', default=lammpsDir, dest='lammpsDir', help='Path of LAMMPS') 
    parser.add_argument('-t', default='eam/alloy', dest='type', help='Potential Type, e.g. eam/alloy, eam/fs, meam, tersoff, sw') 
    parser.add_argument('-print', action='store_true', default=False, dest='printFlag', help='print LAMMPS thermo log') 
    parser.add_argument('-script', action='store_true', default=False, dest='printScript', help='print LAMMPS script') 
    parser.add_argument('-dump', default=0, dest='dump', type=int, help='dump step') 
    parser.add_argument('-v', action='version', version='%(prog)s 1.0')

    parser.add_argument('-clear', action='store_true', default=False, dest='clear', help='Clear the temporary folder')

    args = parser.parse_args()
    
    # get io file name, element and dir
    pot0   = args.potential[0]
    name   = os.path.basename(pot0)
    outdir = os.path.dirname(pot0) if args.outdir == '' else args.outdir
    
    # clear the temporary folder
    chkdata = os.path.join(outdir, 'chkdata/')
    chkjson = os.path.join(outdir, name + '.chk.json')
    if args.clear and os.path.exists(chkdata): shutil.rmtree('./chkdata')
    
    # create EACHK
    Inter = EACHKInter.EACHKInter(args.lammpsDir, chkdata, args.element, args.type)
    for icomb in args.combolist:
        Inter.add(icomb, args.element)

    for ialgo in Inter.script.algo:  
        if args.dump > 0: ialgo.dumpStep = args.dump

    Inter.echo = args.printFlag
    print(Inter.init(None))
    if args.printScript: 
        Inter.script.printScript('script.in')
    print(Inter.run(args.potential, chkjson))

    print('cost %.3fs'%(Inter.script.dt), end = '')


