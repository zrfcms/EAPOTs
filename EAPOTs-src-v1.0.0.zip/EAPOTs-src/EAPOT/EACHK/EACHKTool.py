unUseMatplotlib = True
try:
    from matplotlib import pyplot as plt 
    unUseMatplotlib = False
except ImportError:
    print('usematplotlib = False')
    unUseMatplotlib = True

import numpy as np

def reduce6(C): 
    C = [(C[0]+C[3])*0.5, (C[1]+C[2])*0.5, (C[4]+C[5])*0.5]
    return C

def setInsertCubic(ix, iy):

    # 2. prepare Spline Matrix
    N = len(ix) - 1
    x = ix.reshape((N+1, 1))
    y = iy.reshape((N+1, 1))
    h = x[1:]- x[:-1]

    B = np.zeros((N+1, 1))
    A = np.zeros((N+1, N+1))
    for i in range(1, N):
        A[i, i - 1] = h[i - 1]
        A[i, i] = 2 * (h[i - 1] + h[i])
        A[i, i + 1] = h[i]
        B[i] = 6 * ((y[i+1] - y[i]) / h[i] - (y[i] - y[i-1]) / h[i - 1])
    
    B[0], B[N] = 0, 0

    A[0, 0] = -h[1]
    A[0, 1] = h[0] + h[1]
    A[0, 2] = -h[0]

    A[N, N - 2] = -h[N - 1]
    A[N, N - 1] = h[N - 2] + h[N - 1]
    A[N, N - 0] = -h[N - 2]

    # 3. get interpolation coefficient
    m = np.linalg.solve(A,B)

    a = y[:-1]
    b = (y[1:] - y[:-1])/h - m[:-1]*h/2 - (m[1:] - m[:-1])*h/6
    c = m[:-1]/2
    d = (m[1:] - m[:-1])/h/6

    cof = np.c_[d, c, b, a]
    return cof

def getInsertCubic(cof, x, sx):

    sy = np.zeros(sx.shape)
    start = len(x) - 2
    for i, xi in enumerate(np.nditer(sx)):
        idx = start
        while(idx > 0):
            if xi >= x[idx]: break
            idx -= 1
            
        dx = xi - x[idx]
        cofi = cof[idx, :]
        sy[i] =  ((cofi[0] * dx + cofi[1]) * dx + cofi[2]) * dx + cofi[3]

    return sy

def plotRoseFunction(script, key, rat):
    data = script.res[key]

    x = np.array(data[data['sample']])

    yr = np.array(data['roseFunction'])
    yc = np.array(data['energy'])

    xmin, xmax = min(x), max(x)

    sx = np.linspace(xmin, xmax,1+(x.size-1)*rat)
    plt.plot(x, yr, '^')
    plt.plot(x, yc, '*')

    cof = setInsertCubic(x, yr)
    plt.plot(sx, getInsertCubic(cof, x, sx), '--')

    cof = setInsertCubic(x, yc)
    plt.plot(sx, getInsertCubic(cof, x, sx),  '-', label=key)

    return xmin, xmax

def plotRose(script, algos, rat, *, show = True):
    if unUseMatplotlib: return

    rat = 8
    plt.title("Rose function") 
    plt.xlabel("a0/A") 
    plt.ylabel("Ec/eV")

    xmin, xmax = 10, 1
    for ialgo in algos:
        imin, imax = plotRoseFunction(script, ialgo, 8)
        xmin = min(xmin, imin)
        xmax = max(xmax, imax)

    plt.xlim(xmin- 0.5, xmax + 0.5)
    plt.hlines(0, 0, 20, colors='g',linestyles='dashed')
    plt.legend()
    if show: plt.show()