import os
import re
import json
import time
import subprocess

class Script(object):

    AtomicMass = (
		1.0, 1.00794, 4.002602, 6.941, 9.0121831, 10.811, 12.0107, 14.0067, 15.9994, 18.998403163, 20.1797,
		22.98976928, 24.3050, 26.9815385, 28.0855, 30.973761998, 32.065, 35.453, 39.948, 39.0983, 40.078,
		44.955908, 47.867, 50.9415, 51.9961, 54.938044, 55.845, 58.933194, 58.6934, 63.546, 65.38,
		69.723, 72.64, 74.921595, 78.971, 79.904, 83.798, 85.4678, 87.62, 88.90584, 91.224,
		92.90637, 95.95, 98.9072, 101.07, 102.90550, 106.42, 107.8682, 112.414, 114.818, 118.710,
		121.760, 127.60, 126.90447, 131.293, 132.90545196, 137.327, 138.90547, 140.116, 140.90766, 144.242,
		144.9, 150.36, 151.964, 157.25, 158.92535, 162.500, 164.93033, 167.259, 168.93422, 173.054,
		174.9668, 178.49, 180.94788, 183.84, 186.207, 190.23, 192.217, 195.084, 196.966569, 200.59,
		204.3833, 207.2, 208.98040, 208.9824, 209.9871, 222.0176, 223.0197, 226.0245, 227.0277, 232.0377,
		231.03588, 238.02891, 237.0482, 239.0642, 243.0614, 247.0704, 247.0703, 251.0796, 252.0830, 257.0591,
		258.0984, 259.1010, 262.1097, 267.1218, 268.1257, 269.1286, 274.1436, 277.1519, 278, 281,
		282, 285, 284, 289, 288, 292, 294, 295,)

    AtomicStr = (
		"n", "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
		"Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
		"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
		"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
		"Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
		"Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
		"Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
		"Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
		"Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
		"Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
		"Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
		"Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
	)

    def __init__(self, LAMMPSDir, exportDir):

        self.algo = []

        self.LAMMPSDir = LAMMPSDir
        self.exportDir = exportDir

        self.LAMMPS = self.LAMMPSDir + "/lammps/lammps" 
        self.modDir = self.LAMMPSDir + "/struct/"
        self.LAMMPSLog = self.exportDir + "log.lammps"

        self.res = { 'info':{} }

    def pack(self):

        mjson = json.dumps(self.res)
        mjson = mjson.replace(' {', ' {\n  ')
        mjson = mjson.replace('}, "', '},\n"')
        #mjson = mjson.replace(', "', ',\n  "')

        p = re.compile(r', "([A-Za-z0-9_ ]+)":')
        mjson = p.sub(r',\n  "\1":', mjson)

        mjson = mjson.replace('{"', '{\n"')         # for first line
        mjson = mjson.replace('}}', '}\n}')         # for last line
        return mjson

    def printScript(self, file):
        with open(file, 'w') as w:
            for ialgo in self.algo:

                w.write('# %s'%ialgo.id)
                for icmd in ialgo.cmdList:
                    w.write(icmd)
                w.write('\n')    


    def createScript(self):
        
        self.headinfo = ''
        for ialgo in self.algo:
            ialgo.createScript()
            self.headinfo += ialgo.headinfo
        
        if not (os.path.exists(self.LAMMPS) or os.path.exists(self.LAMMPS+'.exe')): 
            raise(ValueError("LAMMPS does not exists"))
        if not len(self.algo): 
            raise(ValueError("no check algorithms defined "))

        self.algo[-1].SeparatorFlag = True
        self.res['info']['headinfo'] = self.headinfo
        return self.headinfo

    def runLAMMPS(self, pair, printLog = False):

        args = [self.LAMMPS,]
        for i, ipair in enumerate(pair):
            args += ['-v','Pair%d'%(i),ipair]

        if not os.path.exists(self.exportDir): os.mkdir(self.exportDir)
        obj = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        buf = 'echo none\n'
        
        NextLoad = 0
        self.abstract = ''
        self.dt, start = 0, time.time()
        for i, ialgo in enumerate(self.algo):
            
            ialgo.updateScript()
            buf += ''.join(ialgo.cmdList)
            if not ialgo.SeparatorFlag:   continue
            
            log = obj.communicate(input=buf.encode('utf-8'))[0].decode('utf-8')
            if printLog: print(log)

            # Subsequent calculations depend on previous calculations
            hi = 0
            for j in range(NextLoad, i+1):
                lo = log.find('@EACHK:', hi) + 7
                if lo < 7: return
                hi = log.find('@', lo) + 1

                jalgo = self.algo[j]
                mdict = jalgo.collectResult(log[lo:hi-2])
                mdict['type'] = jalgo.type
                self.res[jalgo.id] = mdict
                self.abstract += mdict['abstract']

            NextLoad = i + 1

            if i != len(self.algo) - 1:
                obj = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
                buf = 'echo none\n'

        self.dt = time.time() - start
        self.res['info']['pair'] = pair
        self.res['info']['abstract'] = self.abstract
        self.res['info']['time'] = self.dt        
        return self.abstract




class BoxRelax(object):    
    def __init__(self):
        self.relaxBox = True
        self.relaxAtom = True
        self.triclinicFlag = False
        self.minNStep = 5000
        self.minNEval = 5000
        self.runExtraScript = ''
        self.customFix = ''

        self.dblfmt = '%.17g'
        self.stress = [0., 0., 0., 0., 0., 0.]
        self.customRelaxScript = ''

    def createFix(self):
        if self.customFix != '': return self.customFix

        cmd = ''
        fmt = self.dblfmt
        if not (self.relaxBox or self.relaxAtom):
            return cmd

        sts = list([fmt%i for i in self.stress])
        if self.relaxBox:
            if self.triclinicFlag:
                cmd += "fix		BoxRelax all box/relax "            \
                "x %s y %s z %s xy %s yz %s xz %s vmax 0.001\n"%    \
                (sts[0], sts[1], sts[2], sts[3], sts[4], sts[5])

            else:
                cmd += "fix		BoxRelax all box/relax "            \
                "x %s y %s z %s vmax 0.001\n"%(sts[0], sts[1], sts[2])

        if not self.relaxAtom:
            cmd += "fix		FixAtom all setforce 0 0 0\n"

        return cmd

    def createScript(self):

        if self.customRelaxScript: 
            return self.customRelaxScript
        elif self.relaxBox or self.relaxAtom:
            return "minimize	1e-8 1e-10 %d %d\n"%(self.minNStep, self.minNEval)
        else:
            return "run			0 " + self.runExtraScript + "\n"


class PyChkBase(object):

    def __init__(self, script, id):
        self.id = id
        self.script = script
        script.algo.append(self)
        self.exportId = script.exportDir + id

        self.dumpStep = 0        
        self.relax = BoxRelax()
        self.replicate = [0,0,0] 
        self.SeparatorFlag = False

        self.dblfmt = '%.17g'
        self.pairScript = ''
        self.structureScript = ''

    def createScript(self):
        self.cmdList = ['\nclear\nunits metal\nvariable        res	string	\"\"\n',]

    def updateScript(self):
        return

    @staticmethod
    def isTriclinic(lat):
        return not (lat[3] == 0 and lat[4] == 0 and lat[5] == 0)

    @staticmethod
    def readLattice(struct):

        #    0.000000000     5.1439284598446742   xlo xhi
        #    0.000000000     2.9698484809834995   ylo yhi
        #    0.000000000     29.098453567157136   zlo zhi
        #    0   1.7146428199482247   0   xy xz yz
        lat = [0.,0.,0.,0.,0.,0.]
        with open(struct, 'r') as f:
            for line in f:
                if line.find('Atoms') >= 0: 
                    break
                elif line.find('xlo') >= 0: 
                    word = line.split()
                    lat[0] = float(word[1]) - float(word[0])
                elif line.find('ylo') >= 0:
                    word = line.split()
                    lat[1] = float(word[1]) - float(word[0])
                elif line.find('zlo') >= 0: 
                    word = line.split()
                    lat[2] = float(word[1]) - float(word[0])
                elif line.find('xy') >= 0:  
                    word = line.split()
                    lat[3] = float(word[0])
                    lat[4] = float(word[1])
                    lat[5] = float(word[2])

        return lat, PyChkBase.isTriclinic(lat)


    @staticmethod
    def dumpForceEngCmd(Nstep, Name):
        if Nstep <= 0:
            return ''
        cmd  = "compute		eng all pe/atom\n"
        cmd += 'dump            1 all custom %d %s.lmp id type x y z fx fy fz c_eng\n'%(Nstep, Name)
        cmd += 'dump_modify 	1 first yes format line "%d %d %.17g %.17g %.17g %10.6g %10.6g %10.6g %20.16g"\n'
        return cmd

    @staticmethod
    def dumpEngCmd(Nstep, Name):
        if Nstep <= 0:
            return ''
        cmd  = "compute		eng all pe/atom\n"
        cmd += 'dump            1 all custom %d %s.lmp id type x y z c_eng\n'%(Nstep, Name)
        cmd += 'dump_modify 	1 first yes format line "%d %d %.17g %.17g %.17g g %20.16g"\n'
        return cmd


