import os, shutil, time
import EACHK as Chk
import EACHKAlgo as Algo

import numpy as np

def check(fast, all, items):

    if all: fast = True

    refdict = {

        'Rose.fcc.Cu'       : [  3.1216361393078613,   -1.8368496931177574,   -3.3421417951932386,  -3.5154811247519002, 
                                -3.1540793459398944,   -2.6724508239424867,   -2.1517940856229965,  -1.6380254888166408,   
                                -1.1847611535069069,  -0.81880446623410963,  -0.53876698380111743, -0.33614725889997965, 
                               -0.19479910764112818, -0.097867853881308461, -0.033285903564572498,   1.6501705664992887,   
                                -2.0082262352248068,   -3.3410876977293773,   -3.5167841816451926,  -3.1745857605830339, 
                                -2.6505802414626465,   -2.1107169417706322,   -1.6281581828232983,  -1.2275231814560332, 
                                -0.90965693453138219, -0.66509251679358028,  -0.48105811913616442, -0.34487922888163369,  
                               -0.24542838829827573, -0.17356416584583406  ],
        'Rose.hcp.Cu'       : [  2.4137001862911771,  -2.8626588113640095,   -3.5184827841484227,    -2.9984500730760173, 
                                -2.2823877942995514,  -1.5572632638995685,  -0.96203359804222632,   -0.54014189396737222,  
                               -0.27200260486513433, -0.11247097691357216, -0.022622769960576057, 4.6122475027554987e-05,  
                                 1.0725228410501364,  -2.8916049618267472,   -3.5197444520001326,    -3.0050513940401338, 
                                -2.2452826585920862,  -1.5632436450389557,   -1.0417311194249113,   -0.67377589354826828, 
                               -0.42644624536701337, -0.26550399573335326,  -0.16318180779170638, -0.099255497813351343],

        'Ec.fcc.Cu'         : [ 3.6149250567085591, 3.6149250567085591, 3.6149250567085591, 3.5402183302154224],
        'Ec.bcc.Fe'         : [ 2.8553246191116828, 2.8553246191116828, 2.8553246191116828, 4.1224351007351947],
        'Ec.hcp.Cu'         : [ 4.4271994031202206, 2.5560447671476121, 4.1623347361345511, 3.5323981378738316],
        'Ec.L12_A3B.CuNi'   : [ 3.5572422610536329, 3.5572422610536329, 3.5572422610536329, 3.722447013215445 ],
        'Ec.L12_AB3.CuNi'   : [ 3.525384302037299 , 3.525384302037299 , 3.5253843020372986, 4.1951535691432165],

        "StsCv.fcc.Cu"      : [ 3.0574081912258082,  2.6599115751309426,  2.2394591014438769,  1.7636774595990072,  1.2312799345092904,  0.64334190306977179,
                              -2.9054632974374646e-08, -0.69911454117353122, -1.4542587154925699, -2.2648604715405551, -3.1290251332619459, -4.0431456467771358],
        "StsCv.bcc.Fe"      : [ 6.7796665425283882,  5.7354204828042059,  4.6433322648241946,  3.5529735838136682,  2.462777290837014,  1.299122619859429,
                              -2.5781432198746627e-11, -1.4030518814238959, -2.9122217363958725, -4.5297061487314405, -6.2554384042966653, -8.0894958611612413],
        "StsCv.hcp.Cu"      : [ 7.491399463625835,  6.2771733399819407,  5.0705139829090511,  3.8485868490947062,  2.5715122564221997,  1.2901696223509629,
                              -0.00034409148009336256, -1.2896110974869803, -2.5800948735726008, -3.8574288925145956, -5.0953785557383533, -6.2721573679297702],
    
        'Ela.fcc.Cu'        : [ 169.8756223011595,  122.58368418144582, 76.206131260542804],
        'Ela.bcc.Fe'        : [ 243.35941827311282, 145.00896879133239, 116.03678176133143],
        'Ela.hcp.Cu'        : [ 222.30405744140967, 105.04225417033408, 84.029745718519791,
                                215.67507472668945, 37.136639549709315, 58.630902060095664],
        'Ela.L12_A3B.CuNi'  : [ 211.85476631571098, 151.72842036262034, 92.256940501816345],
        'Ela.L12_AB3.CuNi'  : [ 249.61903476337594, 163.96581874257691, 115.60416517263759],
    
        'Ev.fcc.Cu'         : [ 1.309177437266726,  1.2735117606387121],
        'Ev.bcc.Fe'         : [ 1.8363593486978971, 1.7148145359398086],
        'Ev.hcp.Cu'         : [ 1.29399003053868,   1.2575904462170229],
    
        'Es.fcc.100.Cu'     : [ 1350.4006500436412, 1345.1717026376773],
        'Es.fcc.110.Cu'     : [ 1490.487279884373, 1475.314851026608  ],
        'Es.fcc.111.Cu'     : [ 1246.5415725603382, 1239.3900258984504],
        'Es.fcc.112.Cu'     : [ 1454.2151552817002, 1433.845552935928 ],
        'Es.bcc.100.Fe'     : [ 1790.082147011705,  1785.0579459989442],
        'Es.bcc.110.Fe'     : [ 1650.5020665862612, 1650.4071055815018],
        'Es.bcc.111.Fe'     : [ 2011.3285199688528, 1997.6911463889305],
        'Es.bcc.112.Fe'     : [ 1906.2375221510295, 1886.7305755956247], 
        'Es.hcp.0001.Cu'    : [ 1221.6061698292408, 1215.4362696465553],

        'Ys.fcc.111.Cu'     : [ 0, 180.63047660755646, 44.645557748318659, 757.06256429367363, 1808.0051366147991, 738.5441179017497, 
                                0, 162.28028626252379, 44.498295002401967, 493.60139594854928, 814.00179474658432, 485.08003632383299],
        'Ys.bcc.110.Fe'     : [ 0, 270.27630749495836, 654.95856776548442, 680.91616351395328, 
                                0, 267.84104338538452, 615.76723593691975, 661.6830004919658],
        'Ys.bcc.112.Fe'     : [ 0, 310.51186234195711, 752.56171114060623, 781.31267630570778, 752.56082319426935, 310.51149382992253, 
                                0, 307.04502318043097, 716.41156310672125, 759.56052737967559, 663.87067731743628, 302.38559528980392],
        'Ys.hcp.0001.Cu'    : [ 0, 140.81824399069612, -43.872449068063695, 714.48141952324352, 1814.9001392653331, 733.55314273010424, 
                                0, 118.17914316129374, -44.195398740190107, 439.81739734077559, 765.60941874392574, 448.41348688508373],
    }

    if os.path.exists('./chkdata'): shutil.rmtree('./chkdata')
    script = Chk.Script('../../LAMMPS', 'chkdata/')
    
    pairCu   = 'pair_style eam/alloy\npair_coeff	* *  ../res/pot/FeCuNi.eam Cu\n'
    pairFe   = 'pair_style eam/alloy\npair_coeff	* *  ../res/pot/FeCuNi.eam Fe\n'
    pairCuNi = 'pair_style eam/alloy\npair_coeff	* *  ../res/pot/FeCuNi.eam Cu Ni\n'
    
    # RoseFunction
    special = 'RoseFunction' in items
    if fast or special:
        RosefccCu = Algo.RoseFunction(script, 'Rose.fcc.Cu', 2.8, 7.0, 0.3)
        RosefccCu.setRoseParam(3.615, 3.615**3/4, 138.3385886, 3.540218)
    if all  or special:
        RosehcpCu = Algo.RoseFunction(script, 'Rose.hcp.Cu', 2.0, 5.6, 0.3)
        RosehcpCu.setRoseParam(2.556, 4.4272*2.550*4.1623/4, 137.12535, 3.532398)    
    if script.algo: script.algo[-1].SeparatorFlag = 1

    # CohensiveEnergy
    special = 'CohensiveEnergy' in items
    if fast or special:
        EcfccCu   = Algo.CohensiveEnergy(script, 'Ec.fcc.Cu') 
    if all  or special:
        EcbccFe   = Algo.CohensiveEnergy(script, 'Ec.bcc.Fe')    
        EchcpCu   = Algo.CohensiveEnergy(script, 'Ec.hcp.Cu')   
        EchcpCu.headinfo = ' a0    c/a   Ec   '
        EchcpCu.abstract = lambda x: '%6.4f %5.3f %6.4f '%(x.lat[1], x.lat[2]/x.lat[1], x.Ec) 
        EcL12_A3B = Algo.CohensiveEnergy(script, 'Ec.L12_A3B.CuNi')    
        EcL12_AB3 = Algo.CohensiveEnergy(script, 'Ec.L12_AB3.CuNi')
    script.algo[-1].SeparatorFlag = 1    

    special = 'StressCurve' in items
    if fast or special:
        StsCvfccCu   = Algo.StressCurve(script, "StsCv.fcc.Cu",       EcfccCu)  
    if all  or special:
        StsCvbccFe   = Algo.StressCurve(script, "StsCv.bcc.Fe",       EcbccFe)    
        StsCvhcpCu   = Algo.StressCurve(script, "StsCv.hcp.Cu",       EchcpCu)
    script.algo[-1].SeparatorFlag = 1    

    # ElasticConstant
    Ela = Algo.ElasticConstant
    special = 'ElasticConstant' in items
    if fast or special:
        ElafccCu   = Ela(script, "Ela.fcc.Cu",       EcfccCu.restart,   Ela.collect3)  
        ElafccCu.loadMethod = ElafccCu.restartMethod  
    if all  or special:
        ElabccFe   = Ela(script, "Ela.bcc.Fe",       EcbccFe.restart,   Ela.collect3)    
        ElahcpCu   = Ela(script, "Ela.hcp.Cu",       EchcpCu.restart,   Ela.collect6)
        ElaL12_A3B = Ela(script, "Ela.L12_A3B.CuNi", EcL12_A3B.restart, Ela.collect3)
        ElaL12_AB3 = Ela(script, "Ela.L12_AB3.CuNi", EcL12_AB3.restart, Ela.collect3)    
    script.algo[-1].SeparatorFlag = 1    

    # VacancyEnergy
    special = 'VacancyEnergy' in items
    if fast or special:
        EvfccCu = Algo.VacancyEnergy(script, "Ev.fcc.Cu", EcfccCu.restart)
        EvfccCu.pos, EvfccCu.replicate = (1.25, 1.25, 1.25), [4, 4, 4]
    if all  or special:
        EvbccFe = Algo.VacancyEnergy(script, "Ev.bcc.Fe", EcbccFe.restart)
        EvbccFe.pos, EvbccFe.replicate = (1.25, 1.25, 1.25), [4, 4, 4]
        EvhcpCu = Algo.VacancyEnergy(script, "Ev.hcp.Cu", EchcpCu.restart)
        EvhcpCu.pos, EvhcpCu.replicate = (1.25, 1.25, 1.25), [3, 5, 3]
    script.algo[-1].SeparatorFlag = 1  

    # SurfaceEnergy
    special = 'SurfaceEnergy' in items
    if fast or special:
        EsfccCu100  = Algo.SurfaceEnergy(script, "Es.fcc.100.Cu",  "Ec.fcc.Cu")
    if all  or special:
        EsfccCu110  = Algo.SurfaceEnergy(script, "Es.fcc.110.Cu",  "Ec.fcc.Cu")
        EsfccCu111  = Algo.SurfaceEnergy(script, "Es.fcc.111.Cu",  "Ec.fcc.Cu")
        EsfccCu112  = Algo.SurfaceEnergy(script, "Es.fcc.112.Cu",  "Ec.fcc.Cu")
        EsbccFe100  = Algo.SurfaceEnergy(script, "Es.bcc.100.Fe",  "Ec.bcc.Fe")
        EsbccFe110  = Algo.SurfaceEnergy(script, "Es.bcc.110.Fe",  "Ec.bcc.Fe")
        EsbccFe111  = Algo.SurfaceEnergy(script, "Es.bcc.111.Fe",  "Ec.bcc.Fe")
        EsbccFe112  = Algo.SurfaceEnergy(script, "Es.bcc.112.Fe",  "Ec.bcc.Fe")
        EshcpCu0001 = Algo.SurfaceEnergy(script, "Es.hcp.0001.Cu", "Ec.hcp.Cu")
    script.algo[-1].SeparatorFlag = 1  



    # GammaSurface
    special = 'GammaSurface' in items
    if fast or special:
        YsfccCu111 = Algo.GammaSurface(script, "Ys.fcc.111.Cu", "Ec.fcc.Cu")
        YsfccCu111.createScan1d(0, 6, 1.0 / 6)
    if all  or special:
        Ys = Algo.GammaSurface
        YsbccFe110 = Algo.GammaSurface(script, "Ys.bcc.110.Fe", "Ec.bcc.Fe")    
        YsbccFe110.headinfo, YsbccFe110.abstract,YsbccFe110.pointInfo = Ys.headbcc, Ys.abstbcc,Ys.pontbcc
        YsbccFe110.createScan1d(0, 4, 1.0 / 6)

        YsbccFe112 = Algo.GammaSurface(script, "Ys.bcc.112.Fe", "Ec.bcc.Fe")
        YsbccFe112.headinfo, YsbccFe112.abstract,YsbccFe112.pointInfo = Ys.headbcc, Ys.abstbcc,Ys.pontbcc
        YsbccFe112.createScan1d(0, 6, 1.0 / 6)

        YshcpCu0001 = Algo.GammaSurface(script, "Ys.hcp.0001.Cu", "Ec.hcp.Cu")
        YshcpCu0001.createScan1d(0, 6, 1.0 / 6)
    script.algo[-1].SeparatorFlag = 1  

    # add structure and pair script
    for ialgo in script.algo:
        id = ialgo.id
        type = ialgo.type

        if id.find('CuNi') >= 0: ialgo.pairScript = pairCuNi
        elif id.find('Cu') >= 0: ialgo.pairScript = pairCu
        elif id.find('Fe') >= 0: ialgo.pairScript = pairFe
        
        if type == 'ElasticConstant' or type == 'VacancyEnergy':
            continue

        struct = id[id.find('.')+1:id.rfind('.')]
        ialgo.structureScript = 'read_data %s%s.lammps\n'%(script.modDir, struct)
    
    script.createScript()

    start = time.time()
    script.runLAMMPS((), False)
    dt = time.time() - start  
  
    print('headinfo: ' + script.headinfo)
    print('abstract: ' + script.abstract)

    np.set_printoptions(formatter={'float': '{: .17g}'.format})

    err = {}
    for ialgo in script.algo:
        err[ialgo.type] = [0,0]

    for i, ialgo in enumerate(script.algo):
        idict = script.res[ialgo.id]
        ialgo = script.algo[i]

        # Organize inspection data
        if   idict['type'] == 'RoseFunction':            
            fcal = np.append(idict['energy'], idict['roseFunction']) 
        elif idict['type'] == 'CohensiveEnergy':            
            fcal = np.append(idict['lattice'][:3], idict['Ec']) 
        elif idict['type'] == 'StressCurve':            
            fcal = np.array(idict['pxx']);
        elif idict['type'] == 'ElasticConstant':
            fcal = np.array(idict['short']) 
        elif idict['type'] == 'VacancyEnergy':
            fcal = np.append(idict['Unrelaxed'], idict['Relaxed']) 
        elif idict['type'] == 'SurfaceEnergy':
            fcal = np.append(idict['Unrelaxed'], idict['Relaxed']) 
        elif idict['type'] == 'GammaSurface':
            fcal = np.append(idict['Unrelaxed'], idict['Relaxed'])
        

        fref = np.array(refdict[ialgo.id])
        #fref = fcal
        fdef = fcal - fref
        fref[fref == 0] = 1
        delta = np.sqrt(np.average((fdef/fref)**2))

        if delta != 0.0:
            print('%15s: %15e: '%(ialgo.id, delta), end = '\n')
            print(str(fcal).replace('\n', '').replace('  ', ' ').replace(' ', ', '))
            print(str(fref).replace('\n', '').replace('  ', ', '))

        err[ialgo.type][0] += 1
        err[ialgo.type][1] += delta

    print('Type                :  Num  Err')
    for key in err:
        print('%-20s:  %-5.0f%-20g'%(key,err[key][0],err[key][1]))
        
    print('check items finished with %.2fs'%dt)
    return script


