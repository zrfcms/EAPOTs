from MDConfig import *
import MDConfig as cfg
import numpy as np
import math, copy

class Bilayer(object):

    def __init__(self, Cu, nCu, Ag, nAg, *, Box=None, ly0=110, lyVac=10):


        self.ly0, self.lyVac = ly0, lyVac
        self.Cu, self.Ag = copy.copy(Cu), copy.copy(Ag)
        
        # 1. Replicate
        self.Cu.Replicate([nCu, math.ceil(ly0/self.Cu.Box[1,1]), nCu])
        self.Ag.Replicate([nAg, math.ceil(ly0/self.Ag.Box[1,1]), nAg])

        if Box is None: Box = (self.Cu.Box+self.Ag.Box)/2
        self.Box = Box.copy()

        # 2.1 ChangeBox for Cu    
        self.Box[1,1] = self.Cu.Box[1, 1]   # 
        self.Cu.ChangeBox(self.Box.copy())  # change Doamin box to CuAg

        # 2.2 ChangeBox for Ag    
        self.Box[1,1] = self.Ag.Box[1, 1]
        self.Ag.ChangeBox(self.Box.copy())     
        

    def moveAndVac(self):

        # 3.1 move Cu configuration
        lyCu = self.Cu.Box[1,1]
        self.Cu.p[:, 1] -= lyCu
        self.Cu.Boxlo = [0, -lyCu-self.lyVac, 0]

        # 3.2 add Vacuum layer
        self.Cu.Box[1,1] += self.lyVac
        self.Ag.Box[1,1] += self.lyVac

        return self

    def merge(self):
        # 4. merge two configurations
        self.CuAg = cfg.MDConfig(
            Box=self.Box.copy(), 
            Boxlo=self.Cu.Boxlo, 
            lambdaFalg=False,
            p=np.r_[self.Cu.p, self.Ag.p],
            type=np.r_[self.Cu.type, self.Ag.type])
        self.CuAg.Box[1,1] = self.Ag.Box[1,1] + self.Cu.Box[1,1]

        return self.CuAg